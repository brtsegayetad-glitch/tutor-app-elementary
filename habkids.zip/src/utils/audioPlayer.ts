/**
 * HabKids Unified Audio Player & Speech Synthesis Service
 * Sourced from Clean Local Static Native Recording Assets or Graceful Amharic TTS Fallbacks.
 */

// Helper to sanitize words to standard filesystem names (e.g., "እንደምን አደርክ" -> "endemin_aderk")
export function sanitizeToFilename(text: string): string {
  return text
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9\s]/g, "")
    .replace(/\s+/g, "_");
}

// Letter mapping to English phonetic file name conventions
export const LETTER_AUDIO_MAP: Record<string, string> = {
  // ለ (Le) Family
  "ለ": "le", "ሉ": "lu", "ሊ": "li", "ላ": "la", "ሌ": "lie", "ል": "l", "ሎ": "lo",
  // መ (Me) Family
  "መ": "me", "ሙ": "mu", "ሚ": "mi", "ማ": "ma", "ሜ": "mee", "ም": "m", "ሞ": "mo",
  // ሰ (Se) Family
  "ሰ": "se", "ሱ": "su", "ሲ": "si", "ሳ": "sa", "ሴ": "see", "ስ": "s", "ሶ": "so",
  // ረ (Re) Family
  "ረ": "re", "ሩ": "ru", "ሪ": "ri", "ራ": "ra", "ሬ": "rie", "ር": "r", "ሮ": "ro",
  // ቀ (Qe) Family
  "ቀ": "qe", "ቁ": "qu", "ቂ": "qi", "ቃ": "qa", "ቄ": "qie", "ቅ": "q", "ቆ": "qo",
  // በ (Be) Family
  "በ": "be", "ቡ": "bu", "ቢ": "bi", "ባ": "ba", "ቤ": "bie", "ብ": "b", "ቦ": "bo",
  // ሀ (Ha) Family
  "ሀ": "ha", "ሁ": "hu", "include": "hi", "ሃ": "haa", "ሄ": "hee", "ህ": "hei", "ሆ": "ho",
  // ሠ (Se) Family
  "ሠ": "se", "ሡ": "su", "ሢ": "si", "ሣ": "sa", "ሤ": "sie", "ሥ": "s", "ሦ": "so"
};

// Map of common vocabulary Amharic words to clean English audio file names
export const VOCABULARY_AUDIO_MAP: Record<string, string> = {
  "ሰላም": "selam",
  "እንደምን አደርክ": "endemin_aderk",
  "እንደምን አደርሽ": "endemin_adersh",
  "ደህና ሁን": "dehna_hun",
  "እግዚአብሔር ይመስገን": "egziabher_yimesgen",
  "ነብር": "nebir",
  "ደብተር": "debter",
  "ጋሪ": "gari",
  "ፀሐይ": "tsehay",
  "ጳጳስ": "papas",
  "እናት": "enat",
  "አባት": "abat",
  "እህት": "ehet",
  "ወንድም": "wendim",
  "ቤተሰብ": "beteseb",

  // Lesson 1 Greetings human recording additions
  "ሰላም ፣ እማማ!": "selam_emama",
  "ሰላም እማማ": "selam_emama",
  "እንደምን አደርክ ፣ አባባ?": "endemin_aderk_ababa",
  "እንደምን አደርክ አባባ": "endemin_aderk_ababa",
  "ሰላም እህቴ ፣ እንደምን አደርሽ?": "selam_ehte_endemin_adersh",
  "ሰላም እህቴ እንደምን አደርሽ": "selam_ehte_endemin_adersh",
  "ሰላም ወንድሜ": "selam_wendimie",
  "እግዚአብሔር ይመስገን ደህና ነኝ!": "egziabeher_yemesgen_dehna_negne",
  "እግዚአብሔር ይመስገን ደህና ነኝ": "egziabeher_yemesgen_dehna_negne",
  // Silenced for now
  // "ጠዋት ፀሐይ ወጣች። አባባ ከቤት ወጣ። ካሌብ 'እንደምን አደርክ አባባ' አለው። አባባ ፈገግ አለ።": "sunny_morning_lesson1",
  // "ጠዋት ፀሐይ ወጣች። አባባ ከቤት ወጣ። ካሌብ 'እንደምን አደርክ አባባ' አለው። አባባ ፈገግ አለ": "sunny_morning_lesson1",

  // Lesson 2 Identity human recording additions
  "እኔ": "ine",
  "አንተ": "ante",
  "አንቺ": "anchi",
  "ስሜ": "sime",
  "ነው": "new",
  "እኔ ሮቤል ነኝ።": "ine_robel_negn",
  "ስሜ ሜሮን ነው።": "sime_meron_new",
  "ሰላም ፣ እኔ አቤል ነኝ። አንቺ ማን ነሽ?": "dialogue_abel",
  "ሰላም አቤል ፣ ስሜ ሜሮን ነው!።ስለተዋወቅን ደስ ብሎኛል": "dialogue_meron",
  "እኔ ተማሪ ነኝ። ስሜ አቢ ነው። አንተ ሰማህ ማን ነው? አንቺ ስምሽ ማን ነው? ሁላችንም ደስተኛ ነን።": "reading_passage"
};

// Map specific Amharic characters/words to English phonetic pronunciation for non-Amharic fallback voices
export function interceptPronunciation(text: string): string {
  let cleaned = text.trim();

  // Basic character translations
  const singleCharPhoneticMap: Record<string, string> = {
    "ለ": "leh", "ሉ": "loo", "ሊ": "lee", "ላ": "lah", "ሌ": "lay", "ል": "lih", "ሎ": "loh",
    "መ": "meh", "ሙ": "moo", "ሚ": "mee", "ማ": "mah", "ሜ": "may", "ም": "mih", "ሞ": "moh",
    "ሰ": "seh", "ሱ": "soo", "ሲ": "see", "ሳ": "sah", "ሴ": "say", "ስ": "sih", "ሶ": "soh",
    "ረ": "reh", "ሩ": "roo", "ሪ": "ree", "ራ": "rah", "ሬ": "ray", "ር": "rih", "ሮ": "roh",
    "ቀ": "qeh", "ቁ": "qoo", "ቂ": "qee", "ቃ": "qah", "ቄ": "qay", "ቅ": "qih", "ቆ": "qoh",
    "በ": "beh", "ቡ": "boo", "ቢ": "bee", "ባ": "bah", "ቤ": "bay", "ብ": "bih", "ቦ": "boh"
  };

  if (singleCharPhoneticMap[cleaned]) {
    return singleCharPhoneticMap[cleaned];
  }

  // Common word translation fallbacks
  const phrasePhoneticMap: Record<string, string> = {
    "ሰላም": "Seh-lahm",
    "እንደምን አደርክ": "In-deh-meen Ah-dehrk",
    "እንደምን አደርሽ": "In-deh-meen Ah-dehrsh",
    "ደህና ሁን": "Deh-nah Hoon",
    "እግዚአብሔር ይመስገን": "Eg-zee-ab-her Yih-mehs-gen",
    "ነብር": "Neh-beer",
    "ደብተር": "Dehb-tehr",
    "ጋሪ": "Gah-ree",
    "ፀሐይ": "Tseh-hye",
    "ጳጳስ": "Pah-pahs",
    "እናት": "Ih-naht",
    "አባት": "Ah-baht",
    "እህት": "Ih-hiht",
    "ወንድም": "Wehn-deem",
    "ቤተሰብ": "Beh-teh-sehb"
  };

  if (phrasePhoneticMap[cleaned]) {
    return phrasePhoneticMap[cleaned];
  }

  // Segment-based phonetic replacement as safety fallback
  return cleaned
    .replace(/ለ/g, "leh ").replace(/ሉ/g, "loo ").replace(/ሊ/g, "lee ").replace(/ላ/g, "lah ").replace(/ሌ/g, "lay ").replace(/ል/g, "lih ").replace(/ሎ/g, "loh ")
    .replace(/መ/g, "meh ").replace(/ሙ/g, "moo ").replace(/ሚ/g, "mee ").replace(/ማ/g, "mah ").replace(/ሜ/g, "may ").replace(/ም/g, "mih ").replace(/ሞ/g, "moh ")
    .replace(/ሰ/g, "seh ").replace(/ሱ/g, "soo ").replace(/ሲ/g, "see ").replace(/ሳ/g, "sah ").replace(/ሴ/g, "say ").replace(/ስ/g, "sih ").replace(/ሶ/g, "soh ")
    .replace(/ረ/g, "reh ").replace(/ሩ/g, "roo ").replace(/ሪ/g, "ree ").replace(/ራ/g, "rah ").replace(/ሬ/g, "ray ").replace(/ር/g, "rih ").replace(/ሮ/g, "roh ")
    .replace(/ቀ/g, "qeh ").replace(/ቁ/g, "qoo ").replace(/ቂ/g, "qee ").replace(/ቃ/g, "qah ").replace(/ቄ/g, "qay ").replace(/ቅ/g, "qih ").replace(/ቆ/g, "qoh ")
    .replace(/በ/g, "beh ").replace(/ቡ/g, "boo ").replace(/ቢ/g, "bee ").replace(/ባ/g, "bah ").replace(/ቤ/g, "bay ").replace(/ብ/g, "bih ").replace(/ቦ/g, "boh ")
    .trim();
}

/**
 * Main Speak/Play audio utility
 * Automatically tries to fetch local static mp3/wav files and falls back to Web Speech synthesis
 */
export function playAudioOrSpeak(text: string, onStart?: () => void, onEnd?: () => void, audioUrl?: string): void {
  const cleaned = text.trim();
  if (!cleaned && !audioUrl) return;

  // Manual Silence for specific phrase requested by user
  if (cleaned.includes("ጠዋት ፀሐይ ወጣች") && cleaned.includes("አባባ ፈገግ አለ")) {
    console.log("Audio silenced for specific morning passage");
    return;
  }

  // Catch the combined dialogue phrase of Eleni and play them sequentially
  if (cleaned === "ሰላም ወንድሜ ፣ እግዚአብሔር ይመስገን ደህና ነኝ!" || cleaned === "ሰላም ወንድሜ፣ እግዚአብሔር ይመስገን ደህና ነኝ!") {
    playAudioOrSpeak("ሰላም ወንድሜ", onStart, () => {
      setTimeout(() => {
        playAudioOrSpeak("እግዚአብሔር ይመስገን ደህና ነኝ!", undefined, onEnd);
      }, 400);
    });
    return;
  }

  // Cancel any ongoing synthesized speaking
  if ("speechSynthesis" in window) {
    window.speechSynthesis.cancel();
  }

  // Generate potential static audio paths
  const candidatePaths: string[] = [];

  // 0. Priority: If explicit audioUrl is provided, try it first
  if (audioUrl) {
    candidatePaths.push(audioUrl);
  }

  // 1. Is it a single Ethiopic character?
  const isEthiopicChar = /^[\u1200-\u137F]$/.test(cleaned);

  if (isEthiopicChar) {
    const phoneticName = LETTER_AUDIO_MAP[cleaned];
    candidatePaths.push(`/audio/geez/${cleaned}.mp3`);
    if (phoneticName) {
      candidatePaths.push(`/audio/geez/${phoneticName}.mp3`);
    }
    candidatePaths.push(`/audio/geez/${cleaned}.wav`);
    if (phoneticName) {
      candidatePaths.push(`/audio/geez/${phoneticName}.wav`);
    }
  } else {
    // 2. Is it a standard vocabulary word?
    const englishName = VOCABULARY_AUDIO_MAP[cleaned];
    const sanitizedName = sanitizeToFilename(cleaned);
    
    candidatePaths.push(`/audio/vocabulary/${cleaned}.mp3`);
    if (englishName) {
      candidatePaths.push(`/audio/vocabulary/${englishName}.mp3`);
    }
    candidatePaths.push(`/audio/vocabulary/${sanitizedName}.mp3`);
    
    candidatePaths.push(`/audio/vocabulary/${cleaned}.wav`);
    if (englishName) {
      candidatePaths.push(`/audio/vocabulary/${englishName}.wav`);
    }
    candidatePaths.push(`/audio/vocabulary/${sanitizedName}.wav`);
  }

  let attemptIndex = 0;

  const runSynthesisFallback = () => {
    if (!("speechSynthesis" in window)) {
      if (onEnd) onEnd();
      return;
    }

    const utterance = new SpeechSynthesisUtterance(cleaned);
    utterance.rate = 0.8;

    const voices = window.speechSynthesis.getVoices();
    let amharicVoice = voices.find(
      (v) => v.lang === "am-ET" || v.lang.toLowerCase() === "am-et"
    );
    if (!amharicVoice) {
      amharicVoice = voices.find(
        (v) => v.lang.toLowerCase().startsWith("am") || v.name.toLowerCase().includes("amharic")
      );
    }

    if (amharicVoice) {
      utterance.voice = amharicVoice;
      utterance.lang = "am-ET";

      // If we are passing an English transliteration, map it to Amharic text for the native voice!
      const reverseMap: Record<string, string> = {
        "lu": "ሉ", "le": "ለ", "li": "ሊ", "la": "ላ", "lo": "ሎ", "l": "ል",
        "mu": "ሙ", "me": "መ", "mi": "ሚ", "ma": "ማ", "mo": "ሞ", "m": "ም",
        "su": "ሱ", "se": "ሰ", "si": "ሲ", "sa": "ሳ", "so": "ሶ", "s": "ስ",
        "ru": "ሩ", "re": "ረ", "ri": "ሪ", "ra": "ራ", "ro": "ሮ", "r": "ር",
        "qu": "ቁ", "qe": "ቀ", "qi": "ቂ", "qa": "ቃ", "qo": "ቆ", "q": "ቅ",
        "bu": "ቡ", "be": "በ", "bi": "ቢ", "ba": "ባ", "bo": "ቦ", "b": "ብ"
      };
      const key = cleaned.toLowerCase();
      if (reverseMap[key]) {
        utterance.text = reverseMap[key];
      }
    } else {
      const phoneticText = interceptPronunciation(cleaned);
      utterance.text = phoneticText;
      utterance.lang = "en-US";
    }

    if (onStart) {
      utterance.onstart = () => onStart();
    }
    if (onEnd) {
      utterance.onend = () => onEnd();
      utterance.onerror = () => onEnd();
    }

    window.speechSynthesis.speak(utterance);
  };

  const tryPlayNext = () => {
    if (attemptIndex >= candidatePaths.length) {
      runSynthesisFallback();
      return;
    }

    const currentPath = `${candidatePaths[attemptIndex]}?v=6`;
    attemptIndex++;

    const audio = new Audio(currentPath);

    audio.oncanplaythrough = () => {
      if (onStart) onStart();
      audio.play().then(() => {
        if (onEnd) {
          audio.onended = () => onEnd();
        }
      }).catch((err) => {
        console.warn(`Could not play custom native audio path: ${currentPath}:`, err);
        tryPlayNext();
      });
    };

    audio.onerror = () => {
      tryPlayNext();
    };

    audio.load();
  };

  tryPlayNext();
}

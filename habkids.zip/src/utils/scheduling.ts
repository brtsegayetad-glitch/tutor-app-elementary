/**
 * HabKids Scheduling & Date Utilities
 * 
 * This module provides robust timezone-safe, DST-aware, and 24-hour compliant
 * date calculations for booking trial sessions and weekly recurring classes.
 */

/**
 * Calculates the next upcoming Date for a specific weekly slot (weekday, hour, minute).
 * Specifically prevents past booking bugs by rolling over to next week if the slot is
 * on the current day but has already passed, or has already occurred.
 *
 * @param targetDayOfWeek - The target day of the week (0 = Sunday, 1 = Monday, ..., 6 = Saturday)
 * @param targetHour - The hour of the day in 24-hour format (0 - 23)
 * @param targetMinute - The minute of the hour (0 - 59)
 * @param baseDate - Optional starting date reference. Defaults to the current active time.
 * @returns A Date object representing the next valid upcoming occurrence.
 */
export function getNextClassDate(
  targetDayOfWeek: number,
  targetHour: number,
  targetMinute: number,
  baseDate: Date = new Date()
): Date {
  const resultDate = new Date(baseDate.getTime());

  // Prevent problems with raw calculations by setting milliseconds and seconds to 0
  resultDate.setSeconds(0, 0);

  // Calculate current weekday
  const currentDayOfWeek = resultDate.getDay();

  // Determine difference in days
  let dayDiff = targetDayOfWeek - currentDayOfWeek;

  // Adjust hours and minutes of the target date to match the target slot
  resultDate.setHours(targetHour, targetMinute, 0, 0);

  // Apply the weekday adjustment
  if (dayDiff < 0) {
    // Target day is earlier in the week than today, so advance to next week
    dayDiff += 7;
  }
  
  // Safe Date Math (DST friendly - does not add raw milliseconds)
  resultDate.setDate(resultDate.getDate() + dayDiff);

  // CRITICAL FIX: If the scheduled slot has already passed today or is right now (<= current time),
  // automatically advance by exactly 7 days to next week's occurrence.
  if (resultDate.getTime() <= baseDate.getTime()) {
    resultDate.setDate(resultDate.getDate() + 7);
  }

  return resultDate;
}

/**
 * Formats a Date object into a clean, strict 24-hour format string (YYYY-MM-DD HH:mm:ss)
 * to enforce consistent database persistence, presentation, and automated emailing.
 * 
 * @param date - The Date object to format.
 * @returns Formatted string (e.g. "2026-06-26 09:00:00")
 */
export function formatTo24HourDateTime(date: Date): string {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  const hours = String(date.getHours()).padStart(2, '0');
  const minutes = String(date.getMinutes()).padStart(2, '0');
  const seconds = String(date.getSeconds()).padStart(2, '0');

  return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
}

/**
 * Parses a strict YYYY-MM-DD HH:mm:ss 24-hour string in local or UTC time.
 * 
 * @param dateTimeStr - A string matching "YYYY-MM-DD HH:mm:ss"
 * @returns The parsed Date object or null if invalid.
 */
export function parseFrom24HourDateTime(dateTimeStr: string): Date | null {
  const regex = /^(\d{4})-(\d{2})-(\d{2})\s+(\d{2}):(\d{2}):(\d{2})$/;
  const match = dateTimeStr.match(regex);
  if (!match) return null;

  const [_, y, m, d, h, min, s] = match;
  const parsedDate = new Date(
    parseInt(y, 10),
    parseInt(m, 10) - 1,
    parseInt(d, 10),
    parseInt(h, 10),
    parseInt(min, 10),
    parseInt(s, 10)
  );

  return isNaN(parsedDate.getTime()) ? null : parsedDate;
}

/**
 * Technical Guidelines for Timezones and Database Congruence:
 * 
 * 1. Timezone Mismatch (UTC vs Local):
 *    - To maintain absolute consistency across global tutors and parents abroad:
 *      A) ALWAYS convert localized dates to standardized UTC ISO Strings (e.g. date.toISOString())
 *         before submitting to the database.
 *      B) ALWAYS parse UTC ISO Strings and render as localized date/time strings on the client's end 
 *         using browser API capabilities (e.g., date.toLocaleString() or Intl.DateTimeFormat).
 * 
 * 2. Daylight Saving Time (DST) Shifts:
 *    - JS Date's built-in `.setDate()` handles daylight saving time adjustments automatically
 *      since it modifies calendar fields instead of accumulating fixed epoch millisecond offsets.
 *      Avoid: `date.setTime(date.getTime() + 7 * 24 * 60 * 60 * 1000)`.
 *      Prefer: `date.setDate(date.getDate() + 7)`.
 * 
 * 3. Database Format Congruence:
 *    - Utilizing the standard ISO 8601 string or formatTo24HourDateTime outputs guarantees 
 *      lossless sorting, parsing, and database indexing across Firestore, PostgreSQL, and SQLite.
 */

import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export async function compressImageToBase64(file: File, maxSizeBytes: number = 800 * 1024): Promise<string> {
  // If it's not an image (e.g., PDF), fallback to standard FileReader
  if (!file.type.startsWith('image/')) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => {
        const result = reader.result as string;
        if (result.length > maxSizeBytes) {
          reject(new Error("File is too large. Please upload an image/document smaller than 800KB."));
        } else {
          resolve(result);
        }
      };
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  }

  // It's an image. Load it into canvas
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (readerEvent) => {
      const image = new Image();
      image.onload = () => {
        // Enforce max dimensions to avoid huge canvas sizes
        let width = image.width;
        let height = image.height;
        const maxDimension = 1000; // 1000px max fits perfectly on profiles and receipts

        if (width > maxDimension || height > maxDimension) {
          if (width > height) {
            height = Math.round((height * maxDimension) / width);
            width = maxDimension;
          } else {
            width = Math.round((width * maxDimension) / height);
            height = maxDimension;
          }
        }

        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          reject(new Error("Canvas context is not available"));
          return;
        }

        // Draw image on canvas
        ctx.drawImage(image, 0, 0, width, height);

        // Compress iteratively
        let quality = 0.85;
        let dataUrl = canvas.toDataURL('image/jpeg', quality);
        
        // Loop down quality and dimensions if base64 is still too large
        while (dataUrl.length > maxSizeBytes && quality > 0.1) {
          quality -= 0.15;
          dataUrl = canvas.toDataURL('image/jpeg', quality);
        }

        // If still too large, let's scale down further
        if (dataUrl.length > maxSizeBytes) {
          let scale = 0.7;
          while (dataUrl.length > maxSizeBytes && scale > 0.2) {
            const tempCanvas = document.createElement('canvas');
            tempCanvas.width = Math.round(width * scale);
            tempCanvas.height = Math.round(height * scale);
            const tempCtx = tempCanvas.getContext('2d');
            if (tempCtx) {
              tempCtx.drawImage(canvas, 0, 0, tempCanvas.width, tempCanvas.height);
              dataUrl = tempCanvas.toDataURL('image/jpeg', 0.5);
            }
            scale -= 0.15;
          }
        }

        resolve(dataUrl);
      };
      image.onerror = () => reject(new Error("Failed to load image file"));
      image.src = readerEvent.target?.result as string;
    };
    reader.onerror = () => reject(new Error("Failed to read image file"));
    reader.readAsDataURL(file);
  });
}

export function formatDate(date: Date | string) {
  const d = typeof date === 'string' ? new Date(date) : date;
  return d.toLocaleDateString('en-US', {
    month: 'long',
    day: 'numeric',
    year: 'numeric',
  });
}

export function formatTime(date: Date | string) {
  const d = typeof date === 'string' ? new Date(date) : date;
  return d.toLocaleTimeString('en-US', {
    hour: 'numeric',
    minute: '2-digit',
  });
}

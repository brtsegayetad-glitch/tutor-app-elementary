import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
import { getAuth } from "firebase/auth";

// HabKids Production Project (under tesfayetse89@gmail.com)
const PRODUCTION_CONFIG = {
  apiKey: "AIzaSyCcKmVR15JnaFqDesBzTG-25JNCuBMEHBY",
  authDomain: "habkids-prod.firebaseapp.com",
  projectId: "habkids-prod",
  storageBucket: "habkids-prod.firebasestorage.app",
  messagingSenderId: "1000767625497",
  appId: "1:1000767625497:web:b9357bd2bb107bffc34d88",
  measurementId: "G-3MF9XESHFL"
};

// AI Studio Dev Project - automated sandbox (influential-energy)
const DEV_CONFIG = {
  apiKey: "AIzaSyAGeBgCZ_2UnaGIcMbS0_0YdC1YWtgD7Xs",
  authDomain: "influential-energy-b8gvj.firebaseapp.com",
  projectId: "influential-energy-b8gvj",
  storageBucket: "influential-energy-b8gvj.firebasestorage.app",
  messagingSenderId: "803875179116",
  appId: "1:803875179116:web:145cf6f11ad75bd0c02649",
  databaseId: "ai-studio-2d2d3598-6e2b-4108-8600-02eab14adb35" as string | undefined
};

// Detect if we are running in the development sandbox / AI Studio local environment
const isDevSandbox = typeof window !== 'undefined' && (
  window.location.hostname.includes('europe-west2.run.app') || 
  window.location.hostname.includes('localhost') || 
  window.location.hostname.includes('127.0.0.1')
);

const firebaseConfig = isDevSandbox 
  ? DEV_CONFIG 
  : { ...PRODUCTION_CONFIG, databaseId: undefined as string | undefined };

// Initialize Firebase Production Services
const app = initializeApp(firebaseConfig);
export const db = firebaseConfig.databaseId 
  ? getFirestore(app, firebaseConfig.databaseId) 
  : getFirestore(app);
export const auth = getAuth(app);
export default app;

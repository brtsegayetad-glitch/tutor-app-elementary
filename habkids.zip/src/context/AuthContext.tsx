import React, { createContext, useContext, useEffect, useState } from 'react';
import { 
  signInWithPopup, 
  GoogleAuthProvider, 
  signOut as firebaseSignOut, 
  onAuthStateChanged,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  updateProfile
} from 'firebase/auth';
import { doc, setDoc, serverTimestamp, onSnapshot, getDoc, getDocs, query, collection, where, deleteDoc, addDoc } from 'firebase/firestore';
import { auth, db } from '../lib/firebase';
import { handleFirestoreError, OperationType } from '../services/dataService';

type Role = 'parent' | 'tutor' | 'admin' | 'tutor_pending' | null;

interface User {
  uid: string;
  email: string;
  fullName: string;
  role: Role;
  tutorId?: string;
  availability?: any;
  displayName?: string;
  photoUrl?: string;
  isNewUser?: boolean;
  isAmbassador?: boolean;
}

interface AuthContextType {
  user: User | null;
  loading: boolean;
  signInWithGoogle: () => Promise<void>;
  signInWithEmail: (email: string, pass: string) => Promise<void>;
  signUpWithEmail: (email: string, pass: string, fullName: string, isAmbassador?: boolean) => Promise<{ uid: string; role: Role } | undefined>;
  signOut: () => Promise<void>;
  updateRole: (role: Role) => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Automatically heals and links database references for tutors and parents based on email
async function healUserReferences(uid: string, email: string, role: string, displayName?: string) {
  if (!email) return;
  const cleanEmail = email.trim().toLowerCase();

  // HEAL TUTOR
  if (role === 'tutor') {
    try {
      const q = query(collection(db, 'tutors'), where('email', '==', cleanEmail));
      const qSnap = await getDocs(q);
      if (!qSnap.empty) {
        const tutorDocId = qSnap.docs[0].id;
        const tutorData = qSnap.docs[0].data();
        const userRef = doc(db, 'users', uid);
        const userSnap = await getDoc(userRef);
        if (userSnap.exists()) {
          const uData = userSnap.data();
          if (
            uData.tutorId !== tutorDocId || 
            !uData.availability || 
            uData.expertise !== (tutorData.specializedSyllabus || tutorData.expertise)
          ) {
            await setDoc(userRef, { 
              tutorId: tutorDocId,
              availability: tutorData.availability || uData.availability || null,
              expertise: tutorData.specializedSyllabus || tutorData.expertise || 'General Instruction',
              phone: uData.phone || tutorData.phone || '',
              timezone: uData.timezone || tutorData.timezone || 'EAT (Addis Ababa)',
              classroomLink: uData.classroomLink || tutorData.classroomLink || ''
            }, { merge: true });
            console.log(`[Healer] Associated tutorId ${tutorDocId} and synced availability with user ${uid}`);
          }
        }

        // Heal matching sessions
        const sQuery = query(collection(db, 'sessions'), where('tutorEmail', '==', cleanEmail));
        const sSnap = await getDocs(sQuery);
        for (const sDoc of sSnap.docs) {
          if (sDoc.data().tutorId !== tutorDocId) {
            await setDoc(doc(db, 'sessions', sDoc.id), { tutorId: tutorDocId }, { merge: true });
            console.log(`[Healer] Associated tutorId ${tutorDocId} to session ${sDoc.id}`);
          }
        }
        
        // Heal matching students
        const studsQuery = query(collection(db, 'students'), where('tutorId', '==', uid));
        const studsSnap = await getDocs(studsQuery);
        for (const sDoc of studsSnap.docs) {
          await setDoc(doc(db, 'students', sDoc.id), { tutorId: tutorDocId }, { merge: true });
          console.log(`[Healer] Associated tutorId ${tutorDocId} to student ${sDoc.id}`);
        }
      }
    } catch (err) {
      console.warn("[Healer] Tutor healing error:", err);
    }
  }

  // HEAL PARENT
  if (role === 'parent') {
    try {
      // 1. Leads: find lands with parent's email and update parentId to current uid
      const leadsQuery = query(collection(db, 'leads'), where('email', '==', cleanEmail));
      const leadsSnap = await getDocs(leadsQuery);
      
      let foundParentName = '';
      let foundWhatsapp = '';

      if (leadsSnap.empty) {
        console.log(`[Healer] Parent ${cleanEmail} has no active leads. Ready for manual booking.`);
      } else {
        for (const leadDoc of leadsSnap.docs) {
          const lData = leadDoc.data();
          if (lData.parentId !== uid) {
            await setDoc(doc(db, 'leads', leadDoc.id), { parentId: uid }, { merge: true });
            console.log(`[Healer] Associated Lead ${leadDoc.id} with parentId ${uid}`);
          }
          if (!foundParentName && lData.parentName) {
            foundParentName = lData.parentName;
          }
          if (!foundWhatsapp && lData.whatsapp) {
            foundWhatsapp = lData.whatsapp;
          }
        }
      }

      // Check if current user doc has missing name/whatsapp and update it
      const parentUserRef = doc(db, 'users', uid);
      const parentUserSnap = await getDoc(parentUserRef);
      if (parentUserSnap.exists()) {
        const pUserData = parentUserSnap.data();
        const updates: any = {};
        if ((!pUserData.fullName || pUserData.fullName === 'Anonymous User') && foundParentName) {
          updates.fullName = foundParentName;
          updates.displayName = foundParentName;
        }
        if (!pUserData.whatsapp && foundWhatsapp) {
          updates.whatsapp = foundWhatsapp;
        }
        if (Object.keys(updates).length > 0) {
          await setDoc(parentUserRef, updates, { merge: true });
          console.log(`[Healer] Dynamic Sync: Patched parent profile with booked lead details:`, updates);
        }
      }

      // 2. Sessions: find session records by parentEmail
      const sessionsQuery = query(collection(db, 'sessions'), where('parentEmail', '==', cleanEmail));
      const sessionsSnap = await getDocs(sessionsQuery);
      for (const sDoc of sessionsSnap.docs) {
        if (sDoc.data().parentId !== uid) {
          await setDoc(doc(db, 'sessions', sDoc.id), { parentId: uid }, { merge: true });
          console.log(`[Healer] Associated Session ${sDoc.id} with parentId ${uid}`);
        }
      }

      // 3. Subscriptions & Students: find subscriptions by parentEmail, then update subscriptions & students
      const subsQuery = query(collection(db, 'subscriptions'), where('parentEmail', '==', cleanEmail));
      const subsSnap = await getDocs(subsQuery);
      for (const subDoc of subsSnap.docs) {
        const subData = subDoc.data();
        if (subData.parentId !== uid) {
          await setDoc(doc(db, 'subscriptions', subDoc.id), { parentId: uid }, { merge: true });
          console.log(`[Healer] Associated Subscription ${subDoc.id} with parentId ${uid}`);
        }
        if (subData.studentId) {
          const studentRef = doc(db, 'students', subData.studentId);
          try {
            const studentSnap = await getDoc(studentRef);
            if (studentSnap.exists() && studentSnap.data().parentId !== uid) {
              await setDoc(studentRef, { parentId: uid }, { merge: true });
              console.log(`[Healer] Associated Student ${studentSnap.id} with parentId ${uid}`);
            }
          } catch (stErr) {
            console.warn(`[Healer] Student update error for parent ${uid}:`, stErr);
          }
        }
      }
    } catch (err) {
      console.warn("[Healer] Parent healing error:", err);
    }
  }
}

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  const updateRole = async (role: Role) => {
    if (!user) return;
    const path = `users/${user.uid}`;
    try {
      const userRef = doc(db, 'users', user.uid);
      await setDoc(userRef, { role, updatedAt: serverTimestamp() }, { merge: true });
      if (user.email) {
        await healUserReferences(user.uid, user.email, role, user.fullName || user.displayName || '');
      }
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, path);
    }
  };

  useEffect(() => {
    let unsubscribeUserDoc: (() => void) | null = null;
    let unsubscribeAuth: (() => void) | null = null;

    unsubscribeAuth = onAuthStateChanged(auth, async (firebaseUser) => {
      if (firebaseUser) {
        // Clear virtual user if real user logs in
        localStorage.removeItem('virtual_user_id');
        
        let preExistingRole: Role = null;
        let preExistingData: any = {};
        let tempDocRefToDelete: any = null;

        try {
          if (firebaseUser.email) {
            const cleanEmail = firebaseUser.email.toLowerCase();
            const q = query(collection(db, 'users'), where('email', '==', cleanEmail));
            const qSnap = await getDocs(q);
            if (!qSnap.empty) {
              const matchedDoc = qSnap.docs.find(d => d.id !== firebaseUser.uid) || qSnap.docs[0];
              preExistingRole = matchedDoc.data().role as Role;
              preExistingData = matchedDoc.data();
              if (matchedDoc.id !== firebaseUser.uid) {
                tempDocRefToDelete = doc(db, 'users', matchedDoc.id);
              }
            }

            // Cross-check 'tutors' collection to guarantee role synchronization
            const tutorQ = query(collection(db, 'tutors'), where('email', '==', cleanEmail));
            const tutorQSnap = await getDocs(tutorQ);
            let tutorDocId = '';
            let tutorData: any = null;
            if (!tutorQSnap.empty) {
              tutorDocId = tutorQSnap.docs[0].id;
              tutorData = tutorQSnap.docs[0].data();
            } else {
              const directTutorSnap = await getDoc(doc(db, 'tutors', firebaseUser.uid));
              if (directTutorSnap.exists()) {
                tutorDocId = directTutorSnap.id;
                tutorData = directTutorSnap.data();
              }
            }

            if (tutorDocId && tutorData) {
              preExistingRole = 'tutor';
              preExistingData = {
                ...preExistingData,
                role: 'tutor',
                tutorId: tutorDocId,
                expertise: tutorData.specializedSyllabus || tutorData['specialized syllabus'] || tutorData.expertise || 'General Instruction',
                availability: tutorData.availability || null,
              };
            }
          }
        } catch (err) {
          console.error("Auth pre-check error looking up email/tutors:", err);
        }

        const userRef = doc(db, 'users', firebaseUser.uid);
        if (unsubscribeUserDoc) {
          unsubscribeUserDoc();
        }

        unsubscribeUserDoc = onSnapshot(userRef, async (docSnap) => {
          if (docSnap.exists()) {
            const uDocData = docSnap.data();
            let finalRole = uDocData.role;
            let finalTutorId = uDocData.tutorId;
            let finalExpertise = uDocData.expertise;

            let isTutor = false;
            let tDocId = '';
            let tData: any = null;

            if (uDocData.email) {
              try {
                const cleanEmail = uDocData.email.toLowerCase();
                const tutorQ = query(collection(db, 'tutors'), where('email', '==', cleanEmail));
                const tutorQSnap = await getDocs(tutorQ);
                isTutor = !tutorQSnap.empty;
                tDocId = isTutor ? tutorQSnap.docs[0].id : '';
                tData = isTutor ? tutorQSnap.docs[0].data() : null;

                if (!isTutor) {
                  const directTutorSnap = await getDoc(doc(db, 'tutors', firebaseUser.uid));
                  if (directTutorSnap.exists()) {
                    isTutor = true;
                    tDocId = directTutorSnap.id;
                    tData = directTutorSnap.data();
                  }
                }

                if (isTutor && tDocId && tData) {
                  if (
                    uDocData.role !== 'tutor' || 
                    !uDocData.tutorId || 
                    !uDocData.availability || 
                    uDocData.expertise !== (tData.specializedSyllabus || tData['specialized syllabus'] || tData.expertise)
                  ) {
                    finalRole = 'tutor';
                    finalTutorId = tDocId;
                    finalExpertise = tData.specializedSyllabus || tData['specialized syllabus'] || tData.expertise || 'General Instruction';
                    await setDoc(userRef, { 
                      role: 'tutor', 
                      tutorId: tDocId,
                      expertise: finalExpertise,
                      availability: tData.availability || uDocData.availability || null,
                      phone: uDocData.phone || tData.phone || '',
                      timezone: uDocData.timezone || tData.timezone || 'EAT (Addis Ababa)',
                      classroomLink: uDocData.classroomLink || tData.classroomLink || '',
                      updatedAt: serverTimestamp() 
                    }, { merge: true });
                  }
                }
              } catch (lookupErr) {
                console.warn("Snapshot self-healing tutor check failed:", lookupErr);
              }
            }

            setUser({ 
              uid: firebaseUser.uid, 
              ...uDocData,
              role: finalRole,
              tutorId: finalTutorId,
              expertise: finalExpertise,
              availability: uDocData.availability || (isTutor && tData ? tData.availability : null)
            } as any as User);
            setLoading(false);
            if (uDocData.email && finalRole) {
              healUserReferences(firebaseUser.uid, uDocData.email, finalRole, uDocData.fullName || uDocData.displayName || '');
            }
          } else {
            // Determine logical role: pre-created role, default admin for the requester, or parent fallback
            const assignedRole: Role = preExistingRole || 
              (firebaseUser.email?.toLowerCase() === 'brtsegayetad@gmail.com' ? 'admin' : 'parent');

            const newUser: User = {
              ...preExistingData,
              uid: firebaseUser.uid,
              email: firebaseUser.email || '',
              fullName: preExistingData.displayName || preExistingData.fullName || firebaseUser.displayName || 'Anonymous User',
              role: assignedRole,
              isNewUser: true,
              ...(preExistingData.expertise ? { expertise: preExistingData.expertise } : {}),
              ...(preExistingData.availability ? { availability: preExistingData.availability } : {}),
            };
            
            const createProfile = async () => {
              try {
                let dynamicName = newUser.fullName;
                let dynamicWhatsapp = '';

                // 1. If anonymous, try to pull from leads
                if (dynamicName === 'Anonymous User' && firebaseUser.email) {
                  const lQuery = query(collection(db, 'leads'), where('email', '==', firebaseUser.email.toLowerCase()));
                  const lSnap = await getDocs(lQuery);
                  if (!lSnap.empty) {
                    const firstLead = lSnap.docs[0].data();
                    if (firstLead.parentName) {
                      dynamicName = firstLead.parentName;
                    }
                    if (firstLead.whatsapp) {
                      dynamicWhatsapp = firstLead.whatsapp;
                    }
                  }
                }

                // 2. If STILL anonymous and user is a tutor, try to pull from tutors collection
                if (dynamicName === 'Anonymous User' && (newUser.role === 'tutor' || newUser.tutorId)) {
                  try {
                    const tutorQ = query(collection(db, 'tutors'), where('email', '==', newUser.email.toLowerCase()));
                    const tSnap = await getDocs(tutorQ);
                    if (!tSnap.empty) {
                      const tData = tSnap.docs[0].data();
                      if (tData.name || tData.displayName) {
                        dynamicName = tData.name || tData.displayName;
                      }
                    }
                  } catch (tErr) {
                    console.warn("Pulling name from tutors for new user failed:", tErr);
                  }
                }

                const finalUserDoc = {
                  ...newUser,
                  fullName: dynamicName,
                  displayName: dynamicName,
                  ...(dynamicWhatsapp ? { whatsapp: dynamicWhatsapp } : {}),
                  createdAt: serverTimestamp(),
                  updatedAt: serverTimestamp()
                };

                await setDoc(userRef, finalUserDoc);
                
                if (tempDocRefToDelete) {
                  const oldId = tempDocRefToDelete.id;
                  
                  // Heal students
                  try {
                    const studentQueries = query(collection(db, 'students'), where('tutorId', '==', oldId));
                    const studentSnaps = await getDocs(studentQueries);
                    for (const sDoc of studentSnaps.docs) {
                      await setDoc(doc(db, 'students', sDoc.id), { tutorId: firebaseUser.uid }, { merge: true });
                    }
                  } catch (se) {
                    console.error("Reference healing error on students for tutor migration:", se);
                  }

                  // Heal sessions
                  try {
                    const sessionQueries = query(collection(db, 'sessions'), where('tutorId', '==', oldId));
                    const sessionSnaps = await getDocs(sessionQueries);
                    for (const ssDoc of sessionSnaps.docs) {
                      await setDoc(doc(db, 'sessions', ssDoc.id), { tutorId: firebaseUser.uid }, { merge: true });
                    }
                  } catch (sse) {
                    console.error("Reference healing error on sessions for tutor migration:", sse);
                  }

                  await deleteDoc(tempDocRefToDelete);
                  console.log("Successfully migrated pre-existing user document and student/session references to real UID:", firebaseUser.uid);
                }
              } catch (e) {
                handleFirestoreError(e, OperationType.WRITE, `users/${firebaseUser.uid}`);
              } finally {
                setLoading(false);
              }
            };
            createProfile();
          }
        }, (error) => {
          handleFirestoreError(error, OperationType.GET, `users/${firebaseUser.uid}`);
          setLoading(false);
        });
      } else {
        const storedVirtualId = localStorage.getItem('virtual_user_id');
        if (storedVirtualId) {
          const vUserRef = doc(db, 'users', storedVirtualId);
          if (unsubscribeUserDoc) unsubscribeUserDoc();
          unsubscribeUserDoc = onSnapshot(vUserRef, (docSnap) => {
            if (docSnap.exists()) {
              setUser({
                uid: storedVirtualId,
                ...docSnap.data()
              } as any as User);
            } else {
              localStorage.removeItem('virtual_user_id');
              setUser(null);
            }
            setLoading(false);
          }, (err) => {
            console.error("Virtual user snapshot error:", err);
            localStorage.removeItem('virtual_user_id');
            setUser(null);
            setLoading(false);
          });
        } else {
          setUser(null);
          setLoading(false);
        }
      }
    });

    return () => {
      if (unsubscribeAuth) unsubscribeAuth();
      if (unsubscribeUserDoc) unsubscribeUserDoc();
    };
  }, []);

  const signInWithGoogle = async () => {
    localStorage.removeItem('virtual_user_id');
    const provider = new GoogleAuthProvider();
    try {
      await signInWithPopup(auth, provider);
    } catch (error: any) {
      const errCode = error?.code || '';
      if (
        errCode === 'auth/cancelled-popup-request' ||
        errCode === 'auth/popup-blocked' ||
        errCode === 'auth/popup-closed-by-user'
      ) {
        console.warn('Google Sign-In canceled or blocked in preview iframe:', error.message);
      } else {
        console.error('Login error:', error);
      }
      throw error;
    }
  };

  const signUpWithEmail = async (email: string, pass: string, fullName: string, isAmbassador?: boolean): Promise<{ uid: string; role: Role } | undefined> => {
    const cleanEmail = email.trim().toLowerCase();
    
    try {
      // 1. Try Real Firebase Authentication first
      const userCredential = await createUserWithEmailAndPassword(auth, cleanEmail, pass);
      const firebaseUser = userCredential.user;
      
      // Since they are now authenticated, we can safely query the users and tutors collections
      let logicalRole: Role = 'parent';
      let extraData = {};
      
      try {
        const q = query(collection(db, 'users'), where('email', '==', cleanEmail));
        const qSnap = await getDocs(q);
        if (!qSnap.empty) {
          const docData = qSnap.docs[0].data();
          if (docData.role) {
            logicalRole = docData.role as Role;
          }
          extraData = {
            expertise: docData.expertise || '',
            availability: docData.availability || null,
          };
        } else {
          // Check tutors collection
          const qTutors = query(collection(db, 'tutors'), where('email', '==', cleanEmail));
          const qTutorsSnap = await getDocs(qTutors);
          if (!qTutorsSnap.empty) {
            logicalRole = 'tutor';
            const tutorData = qTutorsSnap.docs[0].data();
            extraData = {
              tutorId: qTutorsSnap.docs[0].id,
              expertise: tutorData.specializedSyllabus || tutorData['specialized syllabus'] || tutorData.expertise || 'General Instruction',
              availability: tutorData.availability || null,
              fullName: tutorData.name || tutorData.displayName || fullName
            };
          }
        }
      } catch (e) {
        console.warn("Could not fetch pre-existing role check inside authenticated session:", e);
      }

      const userRef = doc(db, 'users', firebaseUser.uid);
      
      // Capture referral code if exists
      const referralCode = localStorage.getItem('habkids_referral_code');
      
      await setDoc(userRef, {
        uid: firebaseUser.uid,
        email: cleanEmail,
        fullName: fullName.trim(),
        role: logicalRole,
        isNewUser: true,
        ...(referralCode ? { referredBy: referralCode } : {}),
        ...(isAmbassador ? { isAmbassador: true } : {}),
        ...extraData,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      }, { merge: true });
      
      localStorage.removeItem('virtual_user_id');
      if (referralCode) {
        localStorage.removeItem('habkids_referral_code');
      }
      return { uid: firebaseUser.uid, role: logicalRole };
    } catch (authError: any) {
      console.log("Firebase Authentication signup offline or fallback active:", authError?.message || authError);
      
      if (authError?.code === 'auth/operation-not-allowed') {
        console.log("[Simulation] Email/Password Auth is disabled in project console. Falling back to secure Virtual Auth...");
        
        const virtualUid = 'virtual_' + cleanEmail.replace(/[@.]/g, '_');
        
        const userRef = doc(db, 'users', virtualUid);
        
        // Capture referral code if exists
        const referralCode = localStorage.getItem('habkids_referral_code');
        
        const userSnap = await getDoc(userRef);
        if (userSnap.exists()) {
          throw new Error("This email is already registered. Please go to Log In instead.");
        }
        
        let logicalRole: Role = 'parent';
        let extraData = {};
        
        if (cleanEmail === 'brtsegayetad@gmail.com') {
          logicalRole = 'admin';
        } else {
          // Check tutors collection
          const qTutors = query(collection(db, 'tutors'), where('email', '==', cleanEmail));
          const qTutorsSnap = await getDocs(qTutors);
          if (!qTutorsSnap.empty) {
            logicalRole = 'tutor';
            const tutorData = qTutorsSnap.docs[0].data();
            extraData = {
              tutorId: qTutorsSnap.docs[0].id,
              expertise: tutorData.specializedSyllabus || tutorData['specialized syllabus'] || tutorData.expertise || 'General Instruction',
              availability: tutorData.availability || null,
              fullName: tutorData.name || tutorData.displayName || fullName
            };
          }
        }
        
        await setDoc(userRef, {
          uid: virtualUid,
          email: cleanEmail,
          fullName: fullName.trim(),
          role: logicalRole,
          password: pass, // saved securely in developers custom doc for development/prototype logins
          isNewUser: true,
          referredBy: referralCode || null,
          ...(isAmbassador ? { isAmbassador: true } : {}),
          ...extraData,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp()
        }, { merge: true });
        
        // Heal users references for parents if needed
        await healUserReferences(virtualUid, cleanEmail, logicalRole, fullName);
        
        localStorage.setItem('virtual_user_id', virtualUid);
        if (referralCode) {
          localStorage.removeItem('habkids_referral_code');
        }
        return { uid: virtualUid, role: logicalRole };
      }
      
      throw authError;
    }
  };

  const signInWithEmail = async (email: string, pass: string) => {
    const cleanEmail = email.trim().toLowerCase();
    try {
      // Use real Firebase Authentication
      await signInWithEmailAndPassword(auth, cleanEmail, pass);
      localStorage.removeItem('virtual_user_id');
    } catch (authError: any) {
      console.warn("Real Firebase Authentication failed, trying virtual fallback:", authError?.message);
      
      // Try Virtual Auth Fallback (query by email instead of fixed virtual ID)
      const q = query(collection(db, 'users'), where('email', '==', cleanEmail));
      const qSnap = await getDocs(q);
      
      if (!qSnap.empty) {
        const userDoc = qSnap.docs[0];
        const userData = userDoc.data();
        if (userData.password === pass) {
          console.log("[Simulation] Virtual login successful.");
          localStorage.setItem('virtual_user_id', userDoc.id);
          setUser({ ...userData, uid: userDoc.id } as User);
          return;
        } else {
          throw new Error("Invalid password.");
        }
      }
      
      // If no virtual user either, throw the original auth error
      throw authError;
    }
  };

  const signOut = async () => {
    localStorage.removeItem('virtual_user_id');
    localStorage.removeItem('show_sandbox_controls');
    await firebaseSignOut(auth);
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, loading, signInWithGoogle, signInWithEmail, signUpWithEmail, signOut, updateRole }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

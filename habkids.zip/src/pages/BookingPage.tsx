import { motion } from 'motion/react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ChevronLeft, ChevronRight, CheckCircle2, Loader2, Globe, Send, Play, Star, Video, X, Award, Sparkles, CreditCard, Lock, Gift } from 'lucide-react';
import { cn } from '../lib/utils';
import { useAuth } from '../context/AuthContext';
import { auth } from '../lib/firebase';
import { captureLead, getTutorsWithAvailability, scheduleTrial, subscribeToSettings, subscribeToAllSessions, getTutorSlug } from '../services/dataService';
import BrandLogo from '../components/BrandLogo';
import PathwaySelector from '../components/PathwaySelector';

const schema = z.object({
  parentName: z.string().min(2, 'Name is required'),
  email: z.string().email('Invalid email'),
  whatsapp: z.string().min(8, 'Valid WhatsApp number is required'),
  childName: z.string().optional(),
  childAge: z.string().optional(),
  country: z.string().min(2, 'Country is required'),
  timezone: z.string().min(2, 'Timezone is required'),
  preferredTime: z.string().min(2, 'Preferred time is required'),
  preferredTime2: z.string().optional(),
  preferredTime3: z.string().optional(),
  learningGoal: z.string().min(10, 'Please tell us more about your goals'),
  password: z.string().optional(),
  confirmPassword: z.string().optional(),
}).refine((data) => !data.password || data.password === data.confirmPassword, {
  message: "Passwords do not match",
  path: ["confirmPassword"],
});

type FormData = z.infer<typeof schema>;

function getEmbedUrl(url: string) {
  if (!url) return '';
  
  const cleanUrl = url.trim();
  
  // 1. YouTube Shorts support
  if (cleanUrl.includes('/shorts/')) {
    const parts = cleanUrl.split('/shorts/');
    if (parts.length > 1) {
      const idPart = parts[1].split(/[?&]/)[0];
      if (idPart.length >= 11) {
        return `https://www.youtube.com/embed/${idPart.substring(0, 11)}`;
      }
    }
  }

  // 2. Already formatted embed url
  if (cleanUrl.includes('/embed/')) {
    const base = cleanUrl.split('?')[0];
    return base;
  }

  // 3. Standard and short YouTube links
  const regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|\&v=)([^#\&\?]*).*/;
  const match = cleanUrl.match(regExp);
  if (match && match[2] && match[2].length === 11) {
    return `https://www.youtube.com/embed/${match[2]}`;
  }
  return cleanUrl;
}

function isValidVideoUrl(url: string) {
  if (!url) return false;
  const clean = url.trim();
  return clean.startsWith('http://') || clean.startsWith('https://');
}

const DAYS_ORDER = [
  "sunday",
  "monday",
  "tuesday",
  "wednesday",
  "thursday",
  "friday",
  "saturday",
];

function getSlotTimeString(slot: any): string {
  if (typeof slot === "string") return slot;
  if (slot && typeof slot === "object") {
    if (typeof slot.start === "string") return slot.start;
    if (typeof slot.startTime === "string") return slot.startTime;
    if (typeof slot.slot === "string") return slot.slot;
  }
  return String(slot || "");
}

function detectUserTimezone(): string {
  try {
    const tz = Intl.DateTimeFormat().resolvedOptions().timeZone;
    if (!tz) return 'EST (New York)';
    
    // Convert popular IANA zones to simple user-friendly tags
    if (tz.includes('New_York') || tz.includes('Eastern') || tz.includes('Detroit') || tz.includes('Indiana')) {
      return 'EST (New York)';
    }
    if (tz.includes('Chicago') || tz.includes('Central') || tz.includes('Houston') || tz.includes('Winnipeg')) {
      return 'CST (Chicago)';
    }
    if (tz.includes('Denver') || tz.includes('Mountain') || tz.includes('Phoenix') || tz.includes('Salt_Lake_City')) {
      return 'MST (Denver)';
    }
    if (tz.includes('Los_Angeles') || tz.includes('Pacific') || tz.includes('Seattle') || tz.includes('Vancouver')) {
      return 'PST (Los Angeles)';
    }
    if (tz.includes('London') || tz.includes('Dublin') || tz.includes('GMT') || tz.includes('UTC')) {
      return 'GMT (London)';
    }
    if (tz.includes('Paris') || tz.includes('Berlin') || tz.includes('Rome') || tz.includes('Madrid') || tz.includes('Amsterdam') || tz.includes('Brussels')) {
      return 'CET (Paris)';
    }
    if (tz.includes('Addis_Ababa') || tz.includes('Nairobi') || tz.includes('Kampala') || tz.includes('Dar_es_Salaam') || tz.includes('EAT')) {
      return 'EAT (Addis Ababa)';
    }
    
    return tz;
  } catch {
    return 'EST (New York)';
  }
}

function getTimezoneOffsetMinutes(timezoneStr: string): number {
  const clean = String(timezoneStr || '').toLowerCase();
  if (clean.includes('eat') || clean.includes('addis') || clean.includes('africa') || clean.includes('nairobi')) {
    return -180; // UTC+3
  }
  if (clean.includes('gmt') || clean.includes('london') || clean.includes('utc')) {
    return 0; // UTC+0
  }
  if (clean.includes('europe') || clean.includes('paris') || clean.includes('berlin') || clean.includes('cet')) {
    return -60; // UTC+1
  }
  if (clean.includes('pst') || clean.includes('los angeles') || clean.includes('seattle') || clean.includes('pacific')) {
    return 480; // UTC-8
  }
  if (clean.includes('mst') || clean.includes('denver') || clean.includes('phoenix') || clean.includes('mountain')) {
    return 420; // UTC-7
  }
  if (clean.includes('cst') || clean.includes('chicago') || clean.includes('central') || clean.includes('houston')) {
    return 360; // UTC-6
  }
  if (clean.includes('est') || clean.includes('new york') || clean.includes('washington') || clean.includes('dc') || clean.includes('eastern')) {
    return 300; // UTC-5
  }
  return new Date().getTimezoneOffset();
}

function convertTutorSlots(
  tutorAvail: any,
  tutorTimezone: string = 'EAT (Addis Ababa)',
  parentTimezone: string = 'EST (New York)'
): any {
  if (!tutorAvail) return null;
  
  const DAYS_ORDER = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
  const tutorOffset = getTimezoneOffsetMinutes(tutorTimezone);
  const parentOffset = getTimezoneOffsetMinutes(parentTimezone);
  
  const localAvail: any = {};
  DAYS_ORDER.forEach(day => {
    localAvail[day] = { active: false, slots: [] };
  });

  Object.entries(tutorAvail).forEach(([day, dayData]: [string, any]) => {
    let slots: string[] = [];
    if (dayData && typeof dayData === 'object' && Array.isArray(dayData.slots)) {
      slots = dayData.slots;
    } else if (Array.isArray(dayData)) {
      slots = dayData;
    } else if (typeof dayData === 'string') {
      slots = dayData.split(',').map((s: string) => s.trim()).filter(Boolean);
    }

    slots.forEach((slotStr: string) => {
      if (!slotStr || !slotStr.includes(':')) return;
      
      const timePart = slotStr.split(' ')[0];
      const isAMPM = slotStr.toUpperCase().includes('AM') || slotStr.toUpperCase().includes('PM');
      let [h, m] = timePart.split(':').map(Number);
      
      if (isNaN(h) || isNaN(m)) return;

      if (isAMPM) {
        if (slotStr.toUpperCase().includes('PM') && h < 12) h += 12;
        if (slotStr.toUpperCase().includes('AM') && h === 12) h = 0;
      }

      const dayIndex = DAYS_ORDER.indexOf(day.toLowerCase());
      if (dayIndex === -1) return;

      const totalMinutesTutor = dayIndex * 24 * 60 + h * 60 + m;
      
      let totalMinutesLocal = totalMinutesTutor + tutorOffset - parentOffset;
      totalMinutesLocal = (totalMinutesLocal + 10080) % 10080;

      const localDayIndex = Math.floor(totalMinutesLocal / (24 * 60));
      const remainingMinutes = totalMinutesLocal % (24 * 60);
      
      const localH = Math.floor(remainingMinutes / 60);
      const localM = remainingMinutes % 60;
      
      const formattedM = String(localM).padStart(2, '0');
      let formattedH = localH;
      let ampm = 'AM';
      
      if (formattedH >= 12) {
        ampm = 'PM';
        if (formattedH > 12) formattedH -= 12;
      }
      if (formattedH === 0) {
        formattedH = 12;
      }
      
      const formattedSlot = `${String(formattedH).padStart(2, '0')}:${formattedM} ${ampm}`;
      const targetDay = DAYS_ORDER[localDayIndex];
      
      if (localAvail[targetDay]) {
        if (!localAvail[targetDay].slots.includes(formattedSlot)) {
          localAvail[targetDay].slots.push(formattedSlot);
        }
      }
    });
  });

  DAYS_ORDER.forEach(day => {
    localAvail[day].slots.sort((a: string, b: string) => {
      const getMins = (s: string) => {
        const parts = s.split(' ');
        let [hh, mm] = parts[0].split(':').map(Number);
        if (parts[1] === 'PM' && hh < 12) hh += 12;
        if (parts[1] === 'AM' && hh === 12) hh = 0;
        return hh * 60 + mm;
      };
      return getMins(a) - getMins(b);
    });
    localAvail[day].active = localAvail[day].slots.length > 0;
  });

  return localAvail;
}

function getFilteredAvailability(
  utcAvail: any,
  tutorId: string,
  sessions: any[],
  tutorTimezone: string = 'EAT (Addis Ababa)',
  parentTimezone: string = 'EST (New York)'
): any {
  const fallbackAvailability = {
    monday: { active: true, slots: ['22:00', '23:00', '00:00', '01:00', '02:00', '03:00', '04:00', '05:00'] },
    tuesday: { active: true, slots: ['22:00', '23:00', '00:00', '01:00', '02:00', '03:00', '04:00', '05:00'] },
    wednesday: { active: true, slots: ['22:00', '23:00', '00:00', '01:00', '02:00', '03:00', '04:00', '05:00'] },
    thursday: { active: true, slots: ['22:00', '23:00', '00:00', '01:00', '02:00', '03:00', '04:00', '05:00'] },
    friday: { active: true, slots: ['22:00', '23:00', '00:00', '01:00', '02:00', '03:00', '04:00', '05:00'] },
    saturday: { active: true, slots: ['14:00', '15:00', '16:00', '17:00', '18:00', '19:00', '20:00', '21:00', '22:00', '23:00', '00:00', '01:00'] },
    sunday: { active: true, slots: ['14:00', '15:00', '16:00', '17:00', '18:00', '19:00', '20:00', '21:00', '22:00', '23:00', '00:00', '01:00'] }
  };
  const resolvedAvail = utcAvail && Object.keys(utcAvail).length > 0 ? utcAvail : fallbackAvailability;
  const localAvail = convertTutorSlots(resolvedAvail, tutorTimezone, parentTimezone);
  
  if (!localAvail) return null;
  if (!tutorId || !sessions || sessions.length === 0) return localAvail;

  const nowMs = Date.now() - (55 * 60 * 1000); // 55 mins margin

  const tutorSessions = sessions.filter(s => {
    if (s.tutorId !== tutorId) return false;
    if (s.status === 'completed' || s.status === 'cancelled') return false;
    
    const d = s.startTime?.toDate ? s.startTime.toDate() : new Date(s.startTime);
    return !isNaN(d.getTime()) && d.getTime() > nowMs;
  });

  const DAYS_ORDER = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
  
  tutorSessions.forEach(s => {
    const d = s.startTime?.toDate ? s.startTime.toDate() : new Date(s.startTime);
    const browserOffset = d.getTimezoneOffset();
    const parentOffset = getTimezoneOffsetMinutes(parentTimezone);
    const offsetDiff = parentOffset - browserOffset;
    const adjustedDate = new Date(d.getTime() - offsetDiff * 60 * 1000);
    
    const dayName = DAYS_ORDER[adjustedDate.getDay()];
    
    let hh = adjustedDate.getHours();
    const mm = adjustedDate.getMinutes();
    let ampm = 'AM';
    if (hh >= 12) {
      ampm = 'PM';
      if (hh > 12) hh -= 12;
    }
    if (hh === 0) hh = 12;
    
    const h_m_ampm = `${String(hh).padStart(2, '0')}:${String(mm).padStart(2, '0')} ${ampm}`;

    if (localAvail[dayName]) {
      localAvail[dayName].slots = localAvail[dayName].slots.filter((slotStr: string) => {
        try {
          const getMins = (s: string) => {
            const parts = s.split(' ');
            let [h, m] = parts[0].split(':').map(Number);
            if (parts[1] === 'PM' && h < 12) h += 12;
            if (parts[1] === 'AM' && h === 12) h = 0;
            return h * 60 + m;
          };
          const slotMins = getMins(slotStr);
          const sessMins = getMins(h_m_ampm);
          const diffMins = Math.abs(slotMins - sessMins);
          return diffMins >= 55;
        } catch {
          return slotStr !== h_m_ampm;
        }
      });
      localAvail[dayName].active = localAvail[dayName].slots.length > 0;
    }
  });

  return localAvail;
}

export default function BookingPage() {
  const { user, signUpWithEmail, signInWithEmail, signInWithGoogle } = useAuth();
  
  const [logoUrl, setLogoUrl] = useState(() => {
    try {
      const cached = localStorage.getItem('habkids_cached_settings');
      if (cached) {
        const data = JSON.parse(cached);
        if (data && data.activeLogoUrl) return data.activeLogoUrl;
      }
    } catch (e) { console.warn(e); }
    return '/logo_option_one.png';
  });
  const [academyName, setAcademyName] = useState(() => {
    try {
      const cached = localStorage.getItem('habkids_cached_settings');
      if (cached) {
        const data = JSON.parse(cached);
        if (data && data.academyName) return data.academyName;
      }
    } catch (e) { console.warn(e); }
    return 'HabKids';
  });
  const [trialSessionFee, setTrialSessionFee] = useState(() => {
    try {
      const cached = localStorage.getItem('habkids_cached_settings');
      if (cached) {
        const data = JSON.parse(cached);
        if (data && typeof data.trialSessionFee === 'number') return data.trialSessionFee;
      }
    } catch (e) { console.warn(e); }
    return 5;
  });
  const [trialSessionFeeBirr, setTrialSessionFeeBirr] = useState(() => {
    try {
      const cached = localStorage.getItem('habkids_cached_settings');
      if (cached) {
        const data = JSON.parse(cached);
        if (data && typeof data.trialSessionFeeBirr === 'number') return data.trialSessionFeeBirr;
      }
    } catch (e) { console.warn(e); }
    return 280;
  });
  const [telebirrNumber, setTelebirrNumber] = useState(() => {
    try {
      const cached = localStorage.getItem('habkids_cached_settings');
      if (cached) {
        const data = JSON.parse(cached);
        if (data && data.telebirrNumber) return data.telebirrNumber;
      }
    } catch (e) { console.warn(e); }
    return '0940651491';
  });
  const [telebirrName, setTelebirrName] = useState(() => {
    try {
      const cached = localStorage.getItem('habkids_cached_settings');
      if (cached) {
        const data = JSON.parse(cached);
        if (data && data.telebirrName) return data.telebirrName;
      }
    } catch (e) { console.warn(e); }
    return 'HabKids Tutor Admin';
  });
  const [loadingTutors, setLoadingTutors] = useState(true);
  const [referralCode, setReferralCode] = useState<string | null>(null);
  const [showReferralBanner, setShowReferralBanner] = useState(false);

  useEffect(() => {
    const code = localStorage.getItem('habkids_referral_code');
    if (code) {
      setReferralCode(code);
      setShowReferralBanner(true);
    }
  }, []);

  const [referralDiscountPercent, setReferralDiscountPercent] = useState(() => {
    try {
      const cached = localStorage.getItem('habkids_cached_settings');
      if (cached) {
        const data = JSON.parse(cached);
        if (data && typeof data.referralDiscountPercent === 'number') return data.referralDiscountPercent;
      }
    } catch (e) { console.warn(e); }
    return 15;
  });
  const [zelleEmail, setZelleEmail] = useState(() => {
    try {
      const cached = localStorage.getItem('habkids_cached_settings');
      if (cached) {
        const data = JSON.parse(cached);
        if (data && data.zelleEmail) return data.zelleEmail;
      }
    } catch (e) { console.warn(e); }
    return 'billing@habkids.com';
  });
  const [zelleName, setZelleName] = useState(() => {
    try {
      const cached = localStorage.getItem('habkids_cached_settings');
      if (cached) {
        const data = JSON.parse(cached);
        if (data && data.zelleName) return data.zelleName;
      }
    } catch (e) { console.warn(e); }
    return 'HabKids Inc.';
  });
  const [cbeAccountNumber, setCbeAccountNumber] = useState(() => {
    try {
      const cached = localStorage.getItem('habkids_cached_settings');
      if (cached) {
        const data = JSON.parse(cached);
        if (data && data.cbeAccountNumber) return data.cbeAccountNumber;
      }
    } catch (e) { console.warn(e); }
    return '1000349204910';
  });
  const [cbeAccountName, setCbeAccountName] = useState(() => {
    try {
      const cached = localStorage.getItem('habkids_cached_settings');
      if (cached) {
        const data = JSON.parse(cached);
        if (data && data.cbeAccountName) return data.cbeAccountName;
      }
    } catch (e) { console.warn(e); }
    return 'HabKids Tutor Registry';
  });

  useEffect(() => {
    const unsubscribe = subscribeToSettings((data) => {
      if (data) {
        if (data.activeLogoUrl) {
          setLogoUrl(data.activeLogoUrl);
        }
        if (data.academyName) {
          setAcademyName(data.academyName);
        }
        if (typeof data.trialSessionFee === 'number') {
          setTrialSessionFee(data.trialSessionFee);
        }
        if (typeof data.trialSessionFeeBirr === 'number') {
          setTrialSessionFeeBirr(data.trialSessionFeeBirr);
        }
        if (data.telebirrNumber) {
          setTelebirrNumber(data.telebirrNumber);
        }
        if (data.telebirrName) {
          setTelebirrName(data.telebirrName);
        }
        if (data.zelleEmail) {
          setZelleEmail(data.zelleEmail);
        }
        if (data.zelleName) {
          setZelleName(data.zelleName);
        }
        if (data.cbeAccountNumber) {
          setCbeAccountNumber(data.cbeAccountNumber);
        }
        if (data.cbeAccountName) {
          setCbeAccountName(data.cbeAccountName);
        }
        if (typeof data.referralDiscountPercent === 'number') {
          setReferralDiscountPercent(data.referralDiscountPercent);
        }
      }
    });
    return () => unsubscribe();
  }, []);

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [errorStatus, setErrorStatus] = useState('');
  const [tutors, setTutors] = useState<any[]>([]);
  const [allSessions, setAllSessions] = useState<any[]>([]);
  const [selectedTutorId, setSelectedTutorId] = useState<string>("auto-assign");
  const [preselectedTutor, setPreselectedTutor] = useState<any | null>(null);
  const [videoModalTutor, setVideoModalTutor] = useState<any | null>(null);
  const navigate = useNavigate();

  // Payment gateway states
  const [paymentMethod, setPaymentMethod] = useState<'telebirr' | 'zelle' | 'cbe'>('telebirr');
  const [paymentReference, setPaymentReference] = useState('');

  // Multi-step language selector states
  const [targetLanguage, setTargetLanguage] = useState<'Amharic' | "Ge'ez" | 'Both' | null>(null);
  const [bothWizardStep, setBothWizardStep] = useState<'amharic_sched' | 'geez_sched' | 'details'>('amharic_sched');

  const [bothAmharicTutorId, setBothAmharicTutorId] = useState<string>("auto-assign");
  const [bothAmharicTime1, setBothAmharicTime1] = useState("");
  const [bothAmharicTime2, setBothAmharicTime2] = useState("");
  const [bothAmharicTime3, setBothAmharicTime3] = useState("");

  const [bothGeezTutorId, setBothGeezTutorId] = useState<string>("auto-assign");
  const [bothGeezTime1, setBothGeezTime1] = useState("");
  const [bothGeezTime2, setBothGeezTime2] = useState("");
  const [bothGeezTime3, setBothGeezTime3] = useState("");

  const [children, setChildren] = useState<Array<{ id: string; name: string; age: string; subjects: string[] }>>([
    { id: Math.random().toString(), name: '', age: '', subjects: ['Amharic'] }
  ]);

  // Dynamic Trial Fee Calculation
  const trialCount = children.length * (targetLanguage === 'Both' ? 2 : 1);
  const totalTrialFee = trialCount * trialSessionFee;
  const totalTrialFeeBirr = trialCount * trialSessionFeeBirr;

  // Sync children subjects to selected targetLanguage
  useEffect(() => {
    if (targetLanguage) {
      const subs = targetLanguage === 'Both' ? ['Amharic', 'Geez'] : (targetLanguage === 'Amharic' ? ['Amharic'] : ['Geez']);
      setChildren(prev => prev.map(c => ({ ...c, subjects: subs })));
    }
  }, [targetLanguage]);

  const addChild = () => {
    const subs = targetLanguage === 'Both' ? ['Amharic', 'Geez'] : (targetLanguage === 'Amharic' ? ['Amharic'] : ['Geez']);
    setChildren([...children, { id: Math.random().toString(), name: '', age: '', subjects: subs }]);
  };

  const removeChild = (id: string) => {
    if (children.length > 1) {
      setChildren(children.filter(c => c.id !== id));
    }
  };

  const updateChild = (id: string, field: 'name' | 'age' | 'subjects', value: any) => {
    setChildren(children.map(c => c.id === id ? { ...c, [field]: value } : c));
  };

  const { register, handleSubmit, formState: { errors }, watch, setValue } = useForm<FormData>({
    resolver: zodResolver(schema),
    defaultValues: {
      country: 'USA',
      timezone: detectUserTimezone(),
    }
  });

  useEffect(() => {
    if (user) {
      setValue('parentName', user.fullName || '');
      setValue('email', user.email || '');
    } else {
      setValue('parentName', '');
      setValue('email', '');
      setValue('password', '');
      setValue('confirmPassword', '');
    }
  }, [user, setValue]);

  useEffect(() => {
    const unsubSessions = subscribeToAllSessions((data) => {
      setAllSessions(data);
    }, () => {
      console.error("Error subscribing to all sessions in BookingPage");
    });
    return () => unsubSessions();
  }, []);

  useEffect(() => {
    setLoadingTutors(true);
    getTutorsWithAvailability().then((list) => {
      const dbList = (list as any[] || []).filter((t: any) => t.id !== 'preview-tutor-id');
      setTutors(dbList);

      // Parse parameters for pre-selecting a tutor and/or slot
      const params = new URLSearchParams(window.location.search);
      const tutorParam = params.get('tutor');
      const slotParam = params.get('slot');

      if (tutorParam) {
        const matched = dbList.find(t => {
          const paramLower = tutorParam.toLowerCase().trim();
          const idLower = t.id.toLowerCase().trim();
          const displayName = (t.displayName || t.name || t.fullName || '').toLowerCase().trim();
          const slug = displayName.replace(/\s+/g, '-').replace(/[^\w\-]+/g, '').replace(/\-\-+/g, '-');
          const shortSlug = getTutorSlug(t).toLowerCase().trim();
          
          // Extract pure first name
          const firstName = displayName.split(/\s+/)[0].replace(/[^\w\u1200-\u137F\-]+/g, '');

          return idLower === paramLower || 
                 slug === paramLower || 
                 shortSlug === paramLower || 
                 (firstName && firstName === paramLower);
        });

        if (matched) {
          // Pre-select tutor ID
          setSelectedTutorId(matched.id);
          setBothAmharicTutorId(matched.id);
          setBothGeezTutorId(matched.id);
          setPreselectedTutor(matched);

          // Auto-select language track based on tutor's specialization
          if (matched.primarySyllabusSpecialization) {
            setTargetLanguage(matched.primarySyllabusSpecialization);
          }
        }
      }

      if (slotParam) {
        setValue('preferredTime', slotParam, { shouldValidate: true });
      }
      setLoadingTutors(false);
    }).catch(err => {
      console.error("Error loading tutors:", err);
      setLoadingTutors(false);
    });
  }, [setValue]);

  const handleSlotClick = (dayName: string, slotStr: string) => {
    const formattedVal = `${dayName.charAt(0).toUpperCase() + dayName.slice(1)} ${slotStr}`;
    const val1 = watch('preferredTime');
    const val2 = watch('preferredTime2');
    const val3 = watch('preferredTime3');

    if (!val1) {
      setValue('preferredTime', formattedVal, { shouldValidate: true });
    } else if (!val2) {
      setValue('preferredTime2', formattedVal);
    } else if (!val3) {
      setValue('preferredTime3', formattedVal);
    } else {
      setValue('preferredTime', formattedVal, { shouldValidate: true });
    }
  };

  const onSubmit = async (data: FormData) => {
    try {
      setIsSubmitting(true);
      setErrorStatus('');

      // Validation for each child in the dynamic list
      let valid = true;
      let errMsg = "";
      for (let i = 0; i < children.length; i++) {
        const child = children[i];
        if (!child.name.trim()) {
          errMsg = `Please enter a name for Student #${i + 1}.`;
          valid = false;
          break;
        }
        if (!child.age || Number(child.age) <= 0) {
          errMsg = `Please enter a valid age for ${child.name || `Student #${i + 1}`}.`;
          valid = false;
          break;
        }
      }

      if (!valid) {
        setErrorStatus(errMsg);
        setIsSubmitting(false);
        return;
      }

      if (!paymentReference.trim()) {
        setErrorStatus(`Please transfer the booking fee and provide your ${paymentMethod === "telebirr" ? "Telebirr SMS reference ID" : paymentMethod === "zelle" ? "Zelle confirmation code" : "CBE reference number"}.`);
        setIsSubmitting(false);
        return;
      }

      // Check required times for both pathways if 'Both' is selected
      if (targetLanguage === 'Both') {
        if (!bothAmharicTime1) {
          setErrorStatus("Please schedule your Amharic trial times before finalizing.");
          setIsSubmitting(false);
          return;
        }
        if (!bothGeezTime1) {
          setErrorStatus("Please schedule your Ge'ez trial times before finalizing.");
          setIsSubmitting(false);
          return;
        }
      }
      
      // 1. Sign up and authenticate the parent if not logged in
      if (!user) {
        if (!data.password || data.password.length < 6) {
          setErrorStatus("Please choose a password with at least 6 characters.");
          setIsSubmitting(false);
          return;
        }
        try {
          await signUpWithEmail(data.email, data.password, data.parentName);
        } catch (signUpError: any) {
          const errMsg = signUpError.message || "";
          if (
            errMsg.toLowerCase().includes("exists") ||
            errMsg.toLowerCase().includes("already") ||
            signUpError.code === "auth/email-already-in-use"
          ) {
            // Already registered! Let's log them in automatically in-place
            try {
              await signInWithEmail(data.email, data.password);
            } catch (signInErr: any) {
              setErrorStatus(
                "This email address already has an account inside our system. We tried logging you in, but the password provided was incorrect. Please verify your password or reset it to proceed."
              );
              setIsSubmitting(false);
              return;
            }
          } else {
            setErrorStatus(errMsg || "An error occurred while creating your parent account.");
            setIsSubmitting(false);
            return;
          }
        }
      }

      // 2. Destructure passwords out of data safely before saving to Firestore leads collection
      const { password, confirmPassword, ...leadPayload } = data;
      if (leadPayload.email) {
        leadPayload.email = leadPayload.email.trim().toLowerCase();
      }

      const cleanedChildren = children.map(c => ({
        name: c.name.trim(),
        age: Number(c.age),
        subjects: targetLanguage === 'Both' ? ['Amharic', 'Geez'] : (targetLanguage === 'Amharic' ? ['Amharic'] : ['Geez'])
      }));

      const childNames = cleanedChildren.map(c => c.name).join(', ');
      const mainAge = Number(cleanedChildren[0]?.age) || 0;

      // 3. Capture lead under their authenticated parent account context
      if (targetLanguage === 'Both') {
        // A: Amharic Lead Payload
        const chosenTutorAmharic = bothAmharicTutorId === "auto-assign" ? null : tutors.find(t => t.id === bothAmharicTutorId);
        const amharicPayload = {
          ...leadPayload,
          childName: childNames,
          childAge: mainAge,
          children: cleanedChildren.map(c => ({ ...c, subjects: ['Amharic'] })),
          preferredTime: bothAmharicTime1,
          preferredTime2: bothAmharicTime2,
          preferredTime3: bothAmharicTime3,
          tutorId: bothAmharicTutorId === "auto-assign" ? "" : bothAmharicTutorId,
          tutorName: bothAmharicTutorId === "auto-assign" ? "System Auto-Assigned" : (chosenTutorAmharic?.displayName || chosenTutorAmharic?.email || "Selected Tutor"),
          tutorEmail: chosenTutorAmharic?.email || "",
          primarySyllabusSpecialization: 'Amharic' as const,
          learningGoal: `[Amharic Track] ${leadPayload.learningGoal || "Heritage literacy & immersion"}`,
          paymentMethod,
          paymentReference: paymentReference.trim()
        };

        // B: Ge'ez Lead Payload
        const chosenTutorGeez = bothGeezTutorId === "auto-assign" ? null : tutors.find(t => t.id === bothGeezTutorId);
        const geezPayload = {
          ...leadPayload,
          childName: childNames,
          childAge: mainAge,
          children: cleanedChildren.map(c => ({ ...c, subjects: ['Geez'] })),
          preferredTime: bothGeezTime1,
          preferredTime2: bothGeezTime2,
          preferredTime3: bothGeezTime3,
          tutorId: bothGeezTutorId === "auto-assign" ? "" : bothGeezTutorId,
          tutorName: bothGeezTutorId === "auto-assign" ? "System Auto-Assigned" : (chosenTutorGeez?.displayName || chosenTutorGeez?.email || "Selected Tutor"),
          tutorEmail: chosenTutorGeez?.email || "",
          primarySyllabusSpecialization: "Ge'ez" as const,
          learningGoal: `[Ge'ez Track] ${leadPayload.learningGoal || "Classical alphabet study"}`,
          paymentMethod,
          paymentReference: paymentReference.trim()
        };

        const resultAmharic = await captureLead({ ...amharicPayload, trialFee: totalTrialFee / 2 });
        const resultGeez = await captureLead({ ...geezPayload, trialFee: totalTrialFee / 2 });

        if (resultAmharic.success && resultGeez.success) {
          setIsSuccess(true);
        } else {
          setErrorStatus("We successfully scheduled your bookings, but encountered an issue initializing full stats. Please contact support.");
        }
      } else {
        const chosenTutor = selectedTutorId === "auto-assign" ? null : tutors.find(t => t.id === selectedTutorId);
        const result = await captureLead({
          ...leadPayload,
          childName: childNames,
          childAge: mainAge,
          children: cleanedChildren,
          tutorId: selectedTutorId === "auto-assign" ? "" : selectedTutorId,
          tutorName: selectedTutorId === "auto-assign" ? "System Auto-Assigned" : (chosenTutor?.displayName || chosenTutor?.email || "Selected Tutor"),
          tutorEmail: chosenTutor?.email || "",
          primarySyllabusSpecialization: targetLanguage as any,
          paymentMethod,
          paymentReference: paymentReference.trim(),
          trialFee: totalTrialFee
        });
        
        if (result.success) {
          setIsSuccess(true);
        } else {
          setErrorStatus("Booking was successful, but we had trouble starting your parent session. Please contact support.");
        }
      }
    } catch (error: any) {
      console.error("Submission error:", error);
      setErrorStatus(error?.message || "Something went wrong during account creation. Please try again.");
    } finally {
      setIsSubmitting(false);
    }
  };

  // Synchronize preferredTime dynamically in Hook Form to satisfy Zod validation
  useEffect(() => {
    if (targetLanguage === 'Both') {
      if (bothAmharicTime1) {
        setValue('preferredTime', bothAmharicTime1, { shouldValidate: true });
      } else {
        setValue('preferredTime', 'To be scheduled', { shouldValidate: true });
      }
      if (bothAmharicTime2) setValue('preferredTime2', bothAmharicTime2);
      if (bothAmharicTime3) setValue('preferredTime3', bothAmharicTime3);
    }
  }, [targetLanguage, bothAmharicTime1, bothAmharicTime2, bothAmharicTime3, setValue]);

  if (isSuccess) {
    return (
      <div className="min-h-screen bg-surface flex items-center justify-center p-6 py-12">
        <div className="max-w-2xl w-full bg-white rounded-[40px] p-8 md:p-12 text-center shadow-xl border border-gray-105 space-y-8 animate-in fade-in zoom-in-95 duration-300">
          <div>
            <div className="w-20 h-20 bg-green-100 text-green-600 rounded-full flex items-center justify-center mx-auto mb-6">
              <CheckCircle2 size={40} />
            </div>
            <h2 className="text-3xl font-serif font-bold text-primary mb-3">Trial Session Booked!</h2>
            <p className="text-gray-600 leading-relaxed max-w-lg mx-auto text-sm">
              Ameseginalehu! Your <strong>{paymentMethod === 'zelle' ? `$${totalTrialFee.toFixed(2)}` : `${totalTrialFeeBirr} Birr`}</strong> trial booking fee for <strong>{children.map(c => c.name).filter(Boolean).join(' & ') || 'your children'}</strong> has been processed successfully. Our coordinator will contact you via WhatsApp or email within 24 hours to schedule your {trialCount > 1 ? 'children\'s' : 'child\'s'} evaluation sessions.
            </p>
          </div>

          {targetLanguage === 'Both' ? (
            <div className="space-y-4">
              <p className="text-xs text-indigo-700 font-extrabold uppercase tracking-wide">Your Double Pathway Tutors & Slots</p>
              
              {/* Amharic Booking Detail */}
              {(() => {
                const tutorA = bothAmharicTutorId === "auto-assign" ? null : tutors.find(t => t.id === bothAmharicTutorId);
                return (
                  <div className="bg-slate-50/70 rounded-[24px] p-5 text-left border border-slate-100 space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-[9px] uppercase font-bold tracking-widest text-emerald-800 bg-emerald-50 border border-emerald-100 px-2.5 py-0.5 rounded-full font-sans">
                        Pathway 1: Amharic (አማርኛ)
                      </span>
                      <span className="text-[10px] text-slate-400 font-bold">Gold Slot: {bothAmharicTime1}</span>
                    </div>
                    <div className="flex items-center gap-3">
                      {tutorA ? (
                        <img src={tutorA.avatar || "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=260"} className="w-12 h-12 rounded-xl object-cover" />
                      ) : (
                        <div className="w-12 h-12 bg-indigo-50 text-indigo-600 rounded-xl flex items-center justify-center font-bold">A</div>
                      )}
                      <div>
                        <p className="font-bold text-sm text-slate-900">{tutorA ? tutorA.displayName : "Auto-Assigned Lead Speaker"}</p>
                        <p className="text-xs text-slate-550">{tutorA ? tutorA.expertise : "Platform Native Tutoring Board"}</p>
                      </div>
                    </div>
                  </div>
                );
              })()}

              {/* Ge'ez Booking Detail */}
              {(() => {
                const tutorG = bothGeezTutorId === "auto-assign" ? null : tutors.find(t => t.id === bothGeezTutorId);
                return (
                  <div className="bg-slate-50/70 rounded-[24px] p-5 text-left border border-slate-100 space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-[9px] uppercase font-bold tracking-widest text-indigo-705 bg-indigo-50 border border-indigo-100 px-2.5 py-0.5 rounded-full font-sans">
                        Pathway 2: Ge'ez Language (ግዕዝ)
                      </span>
                      <span className="text-[10px] text-slate-400 font-bold">Gold Slot: {bothGeezTime1}</span>
                    </div>
                    <div className="flex items-center gap-3">
                      {tutorG ? (
                        <img src={tutorG.avatar || "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=260"} className="w-12 h-12 rounded-xl object-cover" />
                      ) : (
                        <div className="w-12 h-12 bg-indigo-50 text-indigo-600 rounded-xl flex items-center justify-center font-bold">G</div>
                      )}
                      <div>
                        <p className="font-bold text-sm text-slate-900">{tutorG ? tutorG.displayName : "Auto-Assigned Classical Tutor"}</p>
                        <p className="text-xs text-slate-550">{tutorG ? tutorG.expertise : "Classical Studies Coordinator"}</p>
                      </div>
                    </div>
                  </div>
                );
              })()}
            </div>
          ) : (
            /* Traditional success view for single course selector */
            (() => {
              const chosenTutor = selectedTutorId === "auto-assign" 
                ? (tutors[0] || null)
                : (tutors.find(t => t.id === selectedTutorId) || null);
              return chosenTutor && (
                <div className="bg-slate-50/80 rounded-[32px] p-6 md:p-8 text-left border border-slate-100 space-y-6">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-200/50 pb-4">
                    <div>
                      <span className="text-[10px] uppercase font-bold tracking-widest text-indigo-700 bg-indigo-50 border border-indigo-100 px-2.5 py-1 rounded-full font-sans">
                        {selectedTutorId === "auto-assign" ? "System Class Matching Active" : "Requested Private Tutor"}
                      </span>
                      <h3 className="font-serif text-lg font-bold text-primary mt-2">
                        {selectedTutorId === "auto-assign" ? "Matching Lead Tutor" : "Meet Your Tutor"}
                      </h3>
                    </div>
                    <div className="flex items-center gap-1 text-xs text-amber-500 font-bold bg-white px-3 py-1 rounded-full border border-slate-100 self-start sm:self-center">
                      <Star size={12} className="fill-amber-500" />
                      <span>{chosenTutor.rating || "4.9"}</span>
                      <span className="text-[10px] text-slate-400 font-normal">({chosenTutor.reviewsCount || "120"})</span>
                    </div>
                  </div>

                  <div className="flex flex-col sm:flex-row gap-6 items-start">
                    <div className="relative flex-shrink-0 mx-auto sm:mx-0">
                      <img
                        src={chosenTutor.avatar || "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=260"}
                        alt={chosenTutor.displayName}
                        className="w-24 h-24 rounded-2xl object-cover border-2 border-white shadow-md"
                        referrerPolicy="no-referrer"
                      />
                      <span className="absolute bottom-1 right-1 w-4 h-4 bg-emerald-500 border-2 border-white rounded-full"></span>
                    </div>

                    <div className="space-y-3 text-center sm:text-left flex-1">
                      <div>
                        <h4 className="font-bold text-slate-900 text-lg">
                          {chosenTutor.displayName}
                        </h4>
                        <p className="text-xs text-slate-400 font-medium">
                          {chosenTutor.location || "Addis Ababa Native Speaker"}
                        </p>
                      </div>

                      <button
                        type="button"
                        onClick={() => setVideoModalTutor({
                          ...chosenTutor,
                          videoUrl: chosenTutor.videoUrl && isValidVideoUrl(chosenTutor.videoUrl) ? chosenTutor.videoUrl.trim() : "https://www.youtube.com/watch?v=l_a6aG-WizQ",
                          quote: chosenTutor.quote || "Welcome to HabKids! Click to watch a brief video preview of our interactive teaching process."
                        })}
                        className="w-full flex items-center justify-center gap-2 py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-2xl text-[11px] font-bold transition-all cursor-pointer shadow-md"
                      >
                        <Play size={12} className="fill-current text-white animate-pulse" />
                        <span>Watch Video Intro FIRST</span>
                      </button>

                  <p className="text-xs text-slate-600 leading-relaxed font-sans">
                    {chosenTutor.bio}
                  </p>

                  <div className="flex flex-wrap items-center gap-2 pt-1">
                    <span className="text-[9px] font-bold text-slate-400 uppercase tracking-wider font-sans">Focus:</span>
                    <span className="text-[9px] font-sans font-bold text-indigo-700 bg-indigo-50 border border-indigo-100 rounded-lg px-2.5 py-0.5">
                      {chosenTutor.specializedSyllabus || "Conversational Amharic • Level 1 Foundations"}
                    </span>
                  </div>
                </div>
              </div>

              {chosenTutor.quote && (
                <div className="bg-white border border-slate-100 p-4 rounded-2xl">
                  <p className="text-xs text-slate-500 font-medium italic relative font-sans leading-relaxed">
                    "{chosenTutor.quote}"
                  </p>
                </div>
              )}
            </div>
          );
        })())}

          <div className="space-y-4 pt-4">
            <button 
              onClick={() => navigate('/parent')}
              className="btn-primary w-full py-3.5"
            >
              Go to Parent Dashboard
            </button>
            <button 
              type="button"
              id="book-another-child-btn"
              onClick={() => {
                setIsSuccess(false);
                setTargetLanguage(null);
                setBothWizardStep('amharic_sched');
                setSelectedTutorId('auto-assign');
                setBothAmharicTutorId('auto-assign');
                setBothGeezTutorId('auto-assign');
                setBothAmharicTime1('');
                setBothAmharicTime2('');
                setBothAmharicTime3('');
                setBothGeezTime1('');
                setBothGeezTime2('');
                setBothGeezTime3('');
                setErrorStatus('');
                setChildren([
                  { id: Math.random().toString(), name: '', age: '', subjects: ['Amharic'] }
                ]);
                setValue('preferredTime', '');
                setValue('preferredTime2', '');
                setValue('preferredTime3', '');
                setValue('childName', '');
                setValue('childAge', '');
              }}
              className="w-full py-3.5 bg-indigo-50 border border-indigo-200 text-indigo-700 font-bold rounded-2xl hover:bg-indigo-100/70 transition-colors cursor-pointer text-xs uppercase tracking-wider flex items-center justify-center gap-2"
            >
              ✨ Schedule Trial for Another Child
            </button>
            <p className="text-xs text-slate-400">You'll receive a confirmation email shortly.</p>
          </div>
        </div>
      </div>
    );
  }

  const isBoth = targetLanguage === 'Both';
  const currentTutorId = isBoth 
    ? (bothWizardStep === 'amharic_sched' ? bothAmharicTutorId : bothGeezTutorId)
    : selectedTutorId;
    
  const setCurrentTutorId = (id: string) => {
    if (isBoth) {
      if (bothWizardStep === 'amharic_sched') {
        setBothAmharicTutorId(id);
      } else {
        setBothGeezTutorId(id);
      }
    } else {
      setSelectedTutorId(id);
    }
  };

  const currentSpecializationFilter = isBoth
    ? (bothWizardStep === 'amharic_sched' ? 'Amharic' : "Ge'ez")
    : targetLanguage;

  const filteredTutors = tutors.filter((t: any) => {
    if (!currentSpecializationFilter) return true;
    return t.primarySyllabusSpecialization === currentSpecializationFilter;
  });

  const chosenTutor = currentTutorId === "auto-assign" ? null : tutors.find(t => t.id === currentTutorId);

  const currentPrefTime1 = isBoth
    ? (bothWizardStep === 'amharic_sched' ? bothAmharicTime1 : bothGeezTime1)
    : watch('preferredTime') || "";

  const currentPrefTime2 = isBoth
    ? (bothWizardStep === 'amharic_sched' ? bothAmharicTime2 : bothGeezTime2)
    : watch('preferredTime2') || "";

  const currentPrefTime3 = isBoth
    ? (bothWizardStep === 'amharic_sched' ? bothAmharicTime3 : bothGeezTime3)
    : watch('preferredTime3') || "";

  const setCurrentPrefTimes = (val1: string, val2: string, val3: string) => {
    if (isBoth) {
      if (bothWizardStep === 'amharic_sched') {
        setBothAmharicTime1(val1);
        setBothAmharicTime2(val2 || "");
        setBothAmharicTime3(val3 || "");
      } else {
        setBothGeezTime1(val1);
        setBothGeezTime2(val2 || "");
        setBothGeezTime3(val3 || "");
      }
    } else {
      setValue('preferredTime', val1, { shouldValidate: true });
      setValue('preferredTime2', val2);
      setValue('preferredTime3', val3);
    }
  };

  return (
    <div className="min-h-screen bg-surface flex flex-col">
      {/* Referral Welcome Banner */}
      {showReferralBanner && referralCode && (
        <div className="bg-slate-900 text-white py-2 px-4 text-center relative z-[70] animate-in slide-in-from-top duration-500">
          <div className="max-w-7xl mx-auto flex items-center justify-center gap-3">
            <Gift size={14} className="text-secondary animate-pulse" />
            <p className="text-[11px] md:text-xs font-bold tracking-wide">
              Invitation Active! Your <span className="text-secondary">{referralDiscountPercent}% Heritage Discount</span> will be applied to your future plan.
            </p>
            <button 
              onClick={() => setShowReferralBanner(false)}
              className="ml-4 text-white/50 hover:text-white transition-colors"
            >
              <X size={14} />
            </button>
          </div>
        </div>
      )}

      <div className="flex-1 md:flex">
        {/* Left: Content */}
      <div className="hidden md:flex md:w-1/3 bg-primary p-12 flex-col justify-between items-start text-white sticky top-0 h-screen">
        <Link to="/" className="flex items-center gap-2">
          <div className="w-14 h-14 rounded-xl flex items-center justify-center shrink-0">
            <BrandLogo 
              logoUrl={logoUrl} 
              className="w-full h-full"
            />
          </div>
          <span className="font-serif text-xl font-bold text-white tracking-tight">{academyName}</span>
        </Link>
        
          <div>
            <div className="w-12 h-12 bg-white/10 rounded-2xl flex items-center justify-center mb-6">
              <Globe className="text-secondary" />
            </div>
            <h2 className="text-4xl font-serif font-bold mb-6 italic">Join our global community of proud families abroad.</h2>
            <p className="text-white/60 leading-relaxed">
              Our trial evaluation session is strictly a 25-minute live 1-on-1 diagnostic for a ${trialSessionFee.toFixed(2)} booking fee per session.
            </p>
            {trialCount > 1 && (
              <p className="mt-2 text-secondary font-bold animate-in fade-in slide-in-from-left duration-300">
                Total for {trialCount} sessions: ${totalTrialFee.toFixed(2)}
              </p>
            )}
          </div>
        
        <div className="w-full">
           <div className="flex -space-x-2 mb-4">
              {[1, 2, 3].map(i => <img key={i} src={`https://i.pravatar.cc/100?u=b${i}`} className="w-8 h-8 rounded-full border border-primary" alt="parent" />)}
           </div>
           <p className="text-sm text-white/40">50+ trials booked this week</p>
        </div>
      </div>

      {/* Right: Form */}
      <div className="flex-1 p-6 md:p-20 flex flex-col justify-center">
        <div className="max-w-xl mx-auto w-full">
          <div className="md:hidden flex items-center justify-between mb-8">
            <Link to="/" className="flex items-center gap-2 text-primary">
              <ChevronLeft size={20} />
              <span className="font-medium text-sm">Back to Home</span>
            </Link>
            <div className="flex items-center gap-2 matches-glow">
              <div className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0">
                <BrandLogo 
                  logoUrl={logoUrl} 
                  className="w-full h-full"
                />
              </div>
              <span className="font-serif text-xs font-black text-primary uppercase tracking-tight">{academyName}</span>
            </div>
          </div>

          <header className="mb-12">
            <h1 className="text-4xl font-serif font-bold text-primary mb-2">
              Book a Trial Session {trialCount > 1 ? `($${totalTrialFee})` : `($${trialSessionFee})`}
            </h1>
            <p className="text-gray-500">Provide 3 preferred time options for your {children.length > 1 ? "children's" : "child's"} 25-minute evaluation session.</p>
          </header>

          {loadingTutors ? (
            <div className="flex flex-col items-center justify-center py-20 space-y-4">
              <Loader2 className="w-10 h-10 text-indigo-600 animate-spin" />
              <p className="text-slate-500 font-medium">Preparing your custom booking experience...</p>
            </div>
          ) : targetLanguage === null ? (
            <PathwaySelector
              onSelect={(lang) => {
                setTargetLanguage(lang);
                if (lang === 'Both') {
                  setBothWizardStep('amharic_sched');
                } else {
                  setSelectedTutorId('auto-assign');
                }
              }}
            />
          ) : (
            <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
              {/* Persistent Course Pathway Status Banner */}
              <div className="bg-slate-50/85 rounded-[22px] p-4 flex items-center justify-between border border-slate-100 mb-6">
                <div className="flex items-center gap-3">
                  <span className="w-8 h-8 rounded-full bg-indigo-100 text-indigo-700 flex items-center justify-center font-bold text-xs">
                    {targetLanguage === 'Both' ? '✨' : targetLanguage === 'Amharic' ? 'አ' : 'ግ'}
                  </span>
                  <div>
                    <p className="text-[9px] text-slate-400 font-bold uppercase tracking-wider">Selected Course Pathway</p>
                    <p className="text-xs font-bold text-slate-900">
                      {targetLanguage === 'Both' ? "Double Pathway: Amharic & Ge'ez" : `${targetLanguage} Language Track`}
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setTargetLanguage(null);
                    setBothWizardStep('amharic_sched');
                  }}
                  className="text-[10px] font-bold text-indigo-600 hover:text-indigo-850 bg-indigo-50 border border-indigo-100/30 px-3 py-1.5 rounded-xl cursor-pointer"
                >
                  Change Pathway
                </button>
              </div>

              {/* Both Pathway Step Badge Header */}
              {isBoth && bothWizardStep !== 'details' && (
                <div id="both-step-badge" className="p-4 bg-indigo-50/30 border border-indigo-100/40 rounded-2xl flex items-center justify-between mb-4">
                  <div>
                    <p className="text-[10px] text-indigo-650 uppercase font-black tracking-widest font-sans">
                      {bothWizardStep === 'amharic_sched' ? 'Step 1 of 3: Amharic Slot' : 'Step 2 of 3: Ge\'ez Slot'}
                    </p>
                    <h3 className="text-sm font-bold text-indigo-900 font-sans">
                      {bothWizardStep === 'amharic_sched' ? 'Schedule Your Amharic Trial Session' : 'Schedule Your Ge\'ez Trial Session'}
                    </h3>
                  </div>
                  <span className="text-xs font-extrabold bg-indigo-100 text-indigo-700 px-2.5 py-1 rounded-lg font-sans">
                    {bothWizardStep === 'amharic_sched' ? '1/3' : '2/3'}
                  </span>
                </div>
              )}

              {(!isBoth || bothWizardStep !== 'details') && (
                <>
                  {/* Tutor Selection Block */}
                  {preselectedTutor ? (
                    <div className="bg-white p-6 rounded-3xl border border-indigo-150 bg-gradient-to-br from-indigo-50/10 to-white space-y-4 shadow-sm relative overflow-hidden text-left">
                      <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-100/10 rounded-full blur-2xl -z-10"></div>
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
                        <div>
                          <span className="text-[9px] uppercase font-black tracking-widest text-indigo-700 bg-indigo-50 border border-indigo-150 px-2.5 py-1 rounded-full font-sans">
                            Direct Tutor Match Active
                          </span>
                          <h3 className="text-sm font-black text-slate-900 mt-2 flex items-center gap-1.5 font-sans">
                            Booking with {preselectedTutor.displayName}
                          </h3>
                        </div>
                        <button
                          type="button"
                          onClick={() => {
                            setPreselectedTutor(null);
                            setSelectedTutorId("auto-assign");
                            setBothAmharicTutorId("auto-assign");
                            setBothGeezTutorId("auto-assign");
                          }}
                          className="text-[10px] text-indigo-600 hover:text-indigo-850 font-bold underline cursor-pointer"
                        >
                          Choose another tutor
                        </button>
                      </div>

                      {preselectedTutor.videoUrl && isValidVideoUrl(preselectedTutor.videoUrl) && (
                        <button
                          type="button"
                          onClick={() => setVideoModalTutor({
                            ...preselectedTutor,
                            videoUrl: preselectedTutor.videoUrl && isValidVideoUrl(preselectedTutor.videoUrl) ? preselectedTutor.videoUrl.trim() : "https://www.youtube.com/watch?v=l_a6aG-WizQ",
                            quote: preselectedTutor.quote || "Welcome to HabKids!"
                          })}
                          className="w-full flex items-center justify-center gap-1.5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-[11px] font-bold transition-all cursor-pointer shadow-sm mb-2"
                        >
                          <Play size={10} className="fill-current text-white animate-pulse" />
                          <span>Watch {preselectedTutor.displayName}'s Intro Video FIRST</span>
                        </button>
                      )}

                      <div className="flex gap-4 items-start">
                        <div className="relative shrink-0">
                          <img 
                            src={preselectedTutor.avatar || "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=260"} 
                            alt={preselectedTutor.displayName} 
                            className="w-16 h-16 rounded-xl object-cover border border-slate-200"
                            referrerPolicy="no-referrer"
                          />
                          <span className="absolute bottom-0.5 right-0.5 w-3 h-3 bg-emerald-500 border-2 border-white rounded-full"></span>
                        </div>
                        <div className="space-y-1 flex-1">
                          <p className="text-xs font-bold text-slate-800">{preselectedTutor.displayName}</p>
                          <p className="text-[11px] text-slate-500 font-medium font-sans leading-relaxed">{preselectedTutor.bio || preselectedTutor.expertise}</p>
                          <div className="flex items-center gap-3 text-[10px] text-slate-400 font-bold font-sans">
                            <span className="bg-slate-100 text-slate-700 px-2 py-0.5 rounded-md">{preselectedTutor.location || "Addis Ababa Native Speaker"}</span>
                            {preselectedTutor.rating && (
                              <span className="text-amber-500 font-bold">★ {preselectedTutor.rating}</span>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="bg-white p-6 rounded-3xl border border-slate-100 space-y-4 shadow-sm">
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                        <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2">
                          Select Your Tutor Preference
                        </h3>
                      </div>
                      <p className="text-xs text-slate-500 leading-relaxed font-sans">
                        Choose to select a specific native academic speaker or let us automatically pair you with the best matching tutor for your selected slot.
                      </p>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <button
                          id="tutor-pref-auto-btn"
                          type="button"
                          onClick={() => setCurrentTutorId("auto-assign")}
                          className={cn(
                            "p-5 rounded-[22px] border text-left transition-all cursor-pointer relative overflow-hidden",
                            currentTutorId === "auto-assign"
                              ? "border-indigo-600 bg-indigo-50/10 shadow-sm ring-2 ring-indigo-600/15"
                              : "border-slate-100 bg-slate-50/40 hover:border-slate-300"
                          )}
                        >
                          <div className="flex items-center gap-2 mb-1">
                            <span className="p-1 px-1.5 bg-indigo-100 text-indigo-700 rounded-lg text-[10px] font-bold font-sans">🔍 Auto</span>
                            <p className="font-extrabold text-xs text-slate-955">Fully Auto-Assign</p>
                          </div>
                          <p className="text-[10px] text-slate-500 leading-normal font-sans">
                            Fastest match. Highly optimized for parent's listed time zones. Our system allocates the top available educator matching your slot.
                          </p>
                        </button>

                        <button
                          id="tutor-pref-select-btn"
                          type="button"
                          onClick={() => {
                            const firstTutor = filteredTutors.find(t => t.id !== "auto-assign") || filteredTutors[0];
                            setCurrentTutorId(firstTutor ? firstTutor.id : "auto-assign");
                          }}
                          className={cn(
                            "p-5 rounded-[22px] border text-left transition-all cursor-pointer relative overflow-hidden",
                            currentTutorId !== "auto-assign"
                              ? "border-indigo-600 bg-indigo-50/10 shadow-sm ring-2 ring-indigo-600/15"
                              : "border-slate-100 bg-slate-50/40 hover:border-slate-300"
                          )}
                        >
                          <div className="flex items-center gap-2 mb-1">
                            <span className="p-1 px-1.5 bg-emerald-100 text-emerald-700 rounded-lg text-[10px] font-bold font-sans">👤 Choose</span>
                            <p className="font-extrabold text-xs text-slate-955">Parent-Selected Tutor</p>
                          </div>
                          <p className="text-[10px] text-slate-500 leading-normal font-sans">
                            Review native academic counselors, filter specializations, and request a specific core tutor for your entire study track.
                          </p>
                        </button>
                      </div>

                      {/* Specific tutor picker if manually selected or preferred */}
                      {currentTutorId !== "auto-assign" && (
                        <div className="space-y-4 pt-2 animate-in fade-in duration-300">
                          <div className="flex items-center justify-between border-b pb-1">
                            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                              Available Native HabKids Tutors
                            </p>
                            <span className="text-[9px] text-indigo-600 font-bold font-sans">100% Native Speakers</span>
                          </div>

                          {filteredTutors.length === 0 ? (
                            <div className="p-6 border border-dashed border-slate-100 rounded-2xl bg-slate-50 text-center">
                              <p className="text-xs text-slate-400 font-medium font-sans">
                                No custom tutors listed in directory. Falling back to matching allocation.
                              </p>
                            </div>
                          ) : (
                            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
                              {filteredTutors.map((t) => {
                                const isSelected = currentTutorId === t.id;
                                return (
                                  <div
                                    key={t.id}
                                    className={cn(
                                      "bg-white rounded-[24px] border transition-all overflow-hidden flex flex-col h-full relative group",
                                      isSelected
                                        ? "border-indigo-600 ring-2 ring-indigo-600/15 shadow-sm scale-[1.01]"
                                        : "border-slate-100 hover:border-slate-200 shadow-sm hover:shadow-md"
                                    )}
                                  >
                                    {/* Checkmark indicator */}
                                    {isSelected && (
                                      <div className="absolute top-2.5 right-2.5 bg-indigo-600 text-white p-0.5 rounded-full z-10 shadow-sm">
                                        <CheckCircle2 size={12} className="fill-white text-indigo-600" />
                                      </div>
                                    )}

                                    {/* Header info */}
                                    <div className="p-4 flex gap-3 items-start border-b border-slate-50 bg-slate-50/20">
                                      <div 
                                        className="relative flex-shrink-0 cursor-pointer group"
                                        onClick={() => setVideoModalTutor({
                                          ...t,
                                          videoUrl: t.videoUrl && isValidVideoUrl(t.videoUrl) ? t.videoUrl.trim() : "https://www.youtube.com/watch?v=l_a6aG-WizQ",
                                          quote: t.quote || "Welcome to HabKids! Click to watch a brief video preview of our interactive teaching process."
                                        })}
                                        title="Click to watch self-introduction video"
                                      >
                                        <img
                                          src={t.avatar || "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=260"}
                                          alt={t.displayName || t.email}
                                          className="w-12 h-12 rounded-xl object-cover border border-slate-150 shadow-sm transition-transform duration-250 group-hover:scale-105"
                                          referrerPolicy="no-referrer"
                                        />
                                        {/* Play interactive overlay for parents */}
                                        <div className="absolute inset-0 bg-black/40 rounded-xl flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                                          <Play size={16} className="text-white fill-white animate-pulse" />
                                        </div>
                                        <span className="absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-emerald-500 border-2 border-white rounded-full"></span>
                                      </div>
                                      <div className="space-y-0.5 min-w-0">
                                        <h4 className="font-extrabold text-xs text-slate-900 truncate">
                                          {t.displayName || t.email}
                                        </h4>
                                        <div className="flex flex-wrap items-center gap-1.5 text-[10px] font-bold">
                                          <span className="flex items-center gap-0.5 text-amber-500">
                                            <Star size={10} className="fill-amber-500" />
                                            <span>{t.rating || "5.0"}</span>
                                            <span className="text-[9px] text-slate-400 font-normal">
                                              ({t.reviewsCount || "1"} {Number(t.reviewsCount) === 1 ? "review" : "reviews"})
                                            </span>
                                          </span>
                                          <span className="text-[9px] text-slate-300 font-light">|</span>
                                          <span className="text-[9px] text-indigo-600 font-semibold bg-indigo-50/50 px-1 py-0.5 rounded">
                                            {t.totalBookings || 0} {Number(t.totalBookings) === 1 ? "lesson" : "lessons"} completed
                                          </span>
                                        </div>
                                        <p className="text-[8px] text-slate-400 font-bold tracking-wider uppercase truncate">
                                          {t.location || "ETHIOPIA / REMOTE COACH"}
                                        </p>
                                      </div>
                                    </div>

                                    {/* Body contents */}
                                    <div className="p-4 flex-grow flex flex-col justify-between">
                                      <div className="space-y-1 mb-3">
                                        <p className="text-[8px] font-bold text-slate-400 tracking-wider uppercase font-sans">Course Focus:</p>
                                        <span className="inline-block text-[9px] font-sans font-bold text-indigo-700 bg-indigo-50 border border-indigo-100 rounded px-2 py-0.5 truncate max-w-full">
                                          {t.expertise || "Conversational Amharic"}
                                        </span>
                                      </div>

                                      {/* Actions container inside the card */}
                                      <div className="pt-2.5 border-t border-slate-150/50 flex gap-2 items-center">
                                        {/* See More Button / Profile Link */}
                                        {(() => {
                                          const slug = getTutorSlug(t);
                                          return (
                                            <Link
                                              to={`/tutors/${slug || t.id}`}
                                              className="flex items-center justify-center gap-1 bg-slate-50 hover:bg-slate-100 text-slate-700 rounded-lg text-[10px] font-bold py-1.5 transition-all cursor-pointer flex-1 border border-slate-200 text-center"
                                            >
                                              <span>See Profile</span>
                                              <ChevronRight size={10} />
                                            </Link>
                                          );
                                        })()}

                                        {/* Choose Tutor Button */}
                                        <button
                                          type="button"
                                          onClick={() => setCurrentTutorId(t.id)}
                                          className={cn(
                                            "px-2.5 py-1.5 rounded-lg text-[10px] font-black transition-all cursor-pointer flex-1 text-center border",
                                            isSelected
                                              ? "bg-indigo-600 text-white border-indigo-600 hover:bg-indigo-700 shadow-sm"
                                              : "bg-white text-slate-700 border-slate-200 hover:border-slate-300"
                                          )}
                                        >
                                          {isSelected ? "Select ✓" : "Choose"}
                                        </button>
                                      </div>
                                    </div>
                                  </div>
                                );
                              })}
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  )}
                </>
              )}

              {(!isBoth || bothWizardStep === 'details') && (
                <>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-4 border-t border-slate-100">
              <div className={cn(user ? "col-span-full" : "col-span-1")}>
                <label className="block text-sm font-semibold text-gray-700 mb-2">Parent Full Name</label>
                <input {...register('parentName')} className={cn("input-field", errors.parentName && "border-red-500")} placeholder="e.g. Almaz Bekele" />
                {errors.parentName && <p className="text-red-500 text-xs mt-1">{errors.parentName.message}</p>}
              </div>
              {!user && (
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">Parent Email</label>
                  <input {...register('email')} className={cn("input-field", errors.email && "border-red-500")} placeholder="email@example.com" />
                  {errors.email && <p className="text-red-500 text-xs mt-1">{errors.email.message}</p>}
                </div>
              )}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">WhatsApp Number</label>
                <input {...register('whatsapp')} className={cn("input-field", errors.whatsapp && "border-red-500")} placeholder="+1 234 567 8900" />
                {errors.whatsapp && <p className="text-red-500 text-xs mt-1">{errors.whatsapp.message}</p>}
              </div>
              <div>
                <label className="block text-sm font-semibold text-gray-700 mb-2">Parent's Timezone</label>
                <input {...register('timezone')} className={cn("input-field", errors.timezone && "border-red-500")} placeholder="e.g. London (GMT) or New York (EST)" />
                {errors.timezone && <p className="text-red-500 text-xs mt-1">{errors.timezone.message}</p>}
              </div>
            </div>

            {/* Parent Account Secure Registration */}
            {!user ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 bg-[#ebf3ff]/40 p-6 rounded-[28px] border border-blue-50/50">
                <div>
                  <label className="block text-sm font-semibold text-blue-900 mb-2">Create Parent Dashboard Password</label>
                  <input {...register('password')} type="password" className={cn("input-field focus:border-blue-600 bg-white", errors.password && "border-red-500")} placeholder="••••••••" />
                  {errors.password && <p className="text-red-500 text-xs mt-1">{errors.password.message}</p>}
                </div>
                <div>
                  <label className="block text-sm font-semibold text-blue-900 mb-2">Confirm Password</label>
                  <input {...register('confirmPassword')} type="password" className={cn("input-field focus:border-blue-600 bg-white", errors.confirmPassword && "border-red-500")} placeholder="••••••••" />
                  {errors.confirmPassword && <p className="text-red-500 text-xs mt-1">{errors.confirmPassword.message}</p>}
                </div>
                <p className="col-span-full text-xs text-blue-600/80 -mt-2">Creates your secure parent dashboard instantly to track tutors, lesson schedules, feedback notes, and child milestones.</p>
              </div>
            ) : (
              <div className="bg-[#ebf3ff]/40 p-6 rounded-[28px] border border-blue-50/50 flex items-center gap-3">
                <span className="w-8 h-8 rounded-full bg-green-100 text-green-700 flex items-center justify-center font-bold text-sm">✓</span>
                <div>
                  <h4 className="text-sm font-bold text-blue-900">Secure Parent Session Active</h4>
                  <p className="text-xs text-blue-700/80">Logged in as <span className="font-bold">{user.email}</span>. Your trial request will link automatically to your dashboard.</p>
                </div>
              </div>
            )}

            {errorStatus && (
              <div className="p-4 bg-red-50 border border-red-100 rounded-2xl text-red-600 text-sm font-medium">
                {errorStatus}
              </div>
            )}
                </>
              )}

              {(!isBoth || bothWizardStep !== 'details') && (
                <>
                  <div className="bg-slate-50 p-6 rounded-2xl space-y-4">
              <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2">
                <Globe size={16} className="text-primary" />
                Select 3 Preferred Trial Times (GMT/Your Timezone)
              </h3>

              {/* Dynamic clickable tutor availability list */}
              {selectedTutorId !== "auto-assign" && chosenTutor && (() => {
                const parentTz = watch('timezone') || detectUserTimezone();
                const avail = getFilteredAvailability(
                  chosenTutor.availability,
                  chosenTutor.id,
                  allSessions,
                  chosenTutor.timezone || 'EAT (Addis Ababa)',
                  parentTz
                );
                if (!avail) return null;
                const activeDays = Object.keys(avail).filter(day => avail[day]?.active && avail[day]?.slots?.length > 0);
                
                if (activeDays.length === 0) {
                  return (
                    <div className="p-3.5 bg-amber-50 border border-amber-100 rounded-xl">
                      <p className="text-[10px] text-amber-700 leading-normal font-sans">
                        ⚠️ <strong>{chosenTutor.displayName || "Selected Tutor"}</strong> hasn't configured specific weekly availability slots yet. Feel free to request any times that fit your window, and our coordinator will arrange the session!
                      </p>
                    </div>
                  );
                }

                return (
                  <div className="p-4 bg-indigo-50/50 border border-indigo-100 rounded-2xl space-y-3 animate-in fade-in duration-300">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1.5 pb-2 border-b border-indigo-100/50">
                      <div>
                        <h4 className="text-[11px] font-bold text-indigo-900 flex items-center gap-1.5 uppercase tracking-wider">
                          <Sparkles size={11} className="text-indigo-650 animate-pulse shrink-0" />
                          <span>{chosenTutor.displayName}'s Weekly Open Hours</span>
                        </h4>
                        <p className="text-[9px] text-indigo-750 font-sans">
                          These are the tutor's actual available hours translated into your local timezone.
                        </p>
                      </div>
                      <span className="text-[8px] bg-indigo-600 text-white font-extrabold px-2 py-0.5 rounded-full font-sans self-start sm:self-center">
                        💡 Click slots to auto-fill Option 1, 2, or 3
                      </span>
                    </div>

                    <div className="space-y-2.5 max-h-64 overflow-y-auto pr-1">
                      {activeDays.map(day => (
                        <div key={day} className="space-y-1">
                          <p className="text-[9px] font-extrabold text-slate-700 capitalize flex items-center gap-1">
                            <span className="w-1.5 h-1.5 rounded-full bg-indigo-500"></span>
                            {day}s
                          </p>
                          <div className="flex flex-wrap gap-1.5">
                            {avail[day].slots.map((slotStr: string) => {
                              const matchesOpt1 = watch('preferredTime')?.toLowerCase().includes(slotStr.toLowerCase()) && watch('preferredTime')?.toLowerCase().includes(day);
                              const matchesOpt2 = watch('preferredTime2')?.toLowerCase().includes(slotStr.toLowerCase()) && watch('preferredTime2')?.toLowerCase().includes(day);
                              const matchesOpt3 = watch('preferredTime3')?.toLowerCase().includes(slotStr.toLowerCase()) && watch('preferredTime3')?.toLowerCase().includes(day);
                              const isSelected = matchesOpt1 || matchesOpt2 || matchesOpt3;

                              return (
                                <button
                                  key={slotStr}
                                  type="button"
                                  onClick={() => handleSlotClick(day, slotStr)}
                                  className={cn(
                                    "px-2.5 py-1 text-[9px] rounded-lg font-bold font-sans transition-all border cursor-pointer",
                                    isSelected
                                      ? "bg-indigo-650 text-white border-indigo-655 shadow-sm scale-95"
                                      : "bg-white text-slate-705 border-slate-200 hover:border-indigo-300 hover:text-indigo-750"
                                  )}
                                >
                                  {slotStr} {isSelected && "✓"}
                                </button>
                              );
                            })}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                );
              })()}

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="text-[10px] font-bold text-slate-400 uppercase block mb-1">Option 1 (Gold)</label>
                  {isBoth ? (
                    <input
                      id="opt1-input-both"
                      value={currentPrefTime1}
                      onChange={(e) => {
                        if (bothWizardStep === 'amharic_sched') {
                          setBothAmharicTime1(e.target.value);
                        } else {
                          setBothGeezTime1(e.target.value);
                        }
                      }}
                      className="input-field animate-in fade-in duration-300"
                      placeholder="e.g. Saturday 10am"
                    />
                  ) : (
                    <input id="opt1-input-single" {...register('preferredTime')} className={cn("input-field", errors.preferredTime && "border-red-500")} placeholder="e.g. Saturday 10am" />
                  )}
                  {!isBoth && errors.preferredTime && <p className="text-red-500 text-xs mt-1">{errors.preferredTime.message}</p>}
                </div>
                <div>
                  <label className="text-[10px] font-bold text-slate-400 uppercase block mb-1">Option 2 (Silver)</label>
                  {isBoth ? (
                    <input
                      id="opt2-input-both"
                      value={currentPrefTime2}
                      onChange={(e) => {
                        if (bothWizardStep === 'amharic_sched') {
                          setBothAmharicTime2(e.target.value);
                        } else {
                          setBothGeezTime2(e.target.value);
                        }
                      }}
                      className="input-field animate-in fade-in duration-300"
                      placeholder="e.g. Sunday 2pm"
                    />
                  ) : (
                    <input id="opt2-input-single" {...register('preferredTime2')} className="input-field" placeholder="e.g. Sunday 2pm" />
                  )}
                </div>
                <div>
                  <label className="text-[10px] font-bold text-slate-400 uppercase block mb-1">Option 3 (Bronze)</label>
                  {isBoth ? (
                    <input
                      id="opt3-input-both"
                      value={currentPrefTime3}
                      onChange={(e) => {
                        if (bothWizardStep === 'amharic_sched') {
                          setBothAmharicTime3(e.target.value);
                        } else {
                          setBothGeezTime3(e.target.value);
                        }
                      }}
                      className="input-field animate-in fade-in duration-300"
                      placeholder="e.g. Monday 5pm"
                    />
                  ) : (
                    <input id="opt3-input-single" {...register('preferredTime3')} className="input-field" placeholder="e.g. Monday 5pm" />
                  )}
                </div>
              </div>
            </div>
                </>
              )}

              {/* Wizard Nav Controls on scheduling steps 1 & 2 */}
              {isBoth && bothWizardStep !== 'details' && (
                <div id="both-wizard-nav" className="pt-4 animate-in fade-in duration-350">
                  {bothWizardStep === 'amharic_sched' ? (
                    <button
                      id="wizard-goto-geez-btn"
                      type="button"
                      disabled={!bothAmharicTime1}
                      onClick={() => setBothWizardStep('geez_sched')}
                      className="btn-primary w-full py-4 text-base font-bold flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer"
                    >
                      <span>Next: Schedule Ge'ez Trial (Step 2 of 3) →</span>
                    </button>
                  ) : (
                    <div className="flex flex-col sm:flex-row gap-4">
                      <button
                        id="wizard-backto-amharic-btn"
                        type="button"
                        onClick={() => setBothWizardStep('amharic_sched')}
                        className="flex-1 py-4 text-xs font-bold text-slate-600 border border-slate-200 rounded-2xl hover:bg-slate-50 transition-colors cursor-pointer"
                      >
                        ← Back to Amharic
                      </button>
                      <button
                        id="wizard-goto-details-btn"
                        type="button"
                        disabled={!bothGeezTime1}
                        onClick={() => setBothWizardStep('details')}
                        className="flex-1 btn-primary py-4 text-xs font-bold flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer"
                      >
                        <span>Next: Student Details (Step 3 of 3) →</span>
                      </button>
                    </div>
                  )}
                </div>
              )}

              {(!isBoth || bothWizardStep === 'details') && (
                <>

            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">Learning Motivation & Goals</label>
              <textarea 
                {...register('learningGoal')} 
                className={cn("input-field h-32 resize-none", errors.learningGoal && "border-red-500")} 
                placeholder="What do you want your child to achieve? (e.g. speak with grandparents, read Ge'ez, etc.)" 
              />
              {errors.learningGoal && <p className="text-red-500 text-xs mt-1">{errors.learningGoal.message}</p>}
            </div>

            {/* Dynamic Children / Subject Selection Section */}
            <div className="space-y-6 pt-4 border-t border-slate-100">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-base font-bold text-slate-900">Child Registration</h3>
                  <p className="text-xs text-slate-400">Register all students who will be receiving tutoring under your account.</p>
                </div>
                <button
                  type="button"
                  onClick={addChild}
                  className="bg-primary/5 text-primary hover:bg-primary hover:text-white px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer"
                >
                  <span>+ Add Another Child</span>
                </button>
              </div>

              <div className="space-y-6">
                {children.map((child, index) => (
                  <div key={child.id} className="p-6 bg-slate-50/50 rounded-3xl border border-slate-100 space-y-4 relative animate-in fade-in duration-300">
                    {children.length > 1 && (
                      <button
                        type="button"
                        onClick={() => removeChild(child.id)}
                        className="absolute top-4 right-4 text-xs font-bold text-red-500 hover:text-red-705 bg-red-50 px-2.5 py-1 rounded-xl cursor-pointer hover:bg-red-100/80 transition-colors"
                        title="Remove child"
                      >
                        ✕ Remove
                      </button>
                    )}
                    
                    <h4 className="text-xs font-bold text-primary uppercase tracking-widest">
                      👦 Student #{index + 1} Details
                    </h4>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">Child's Name</label>
                        <input
                          type="text"
                          value={child.name}
                          onChange={(e) => updateChild(child.id, 'name', e.target.value)}
                          className="input-field bg-white focus:border-primary"
                          placeholder="e.g. Samuel Bekele"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">Child's Age</label>
                        <input
                          type="number"
                          value={child.age}
                          onChange={(e) => updateChild(child.id, 'age', e.target.value)}
                          className="input-field bg-white focus:border-primary"
                          placeholder="e.g. 8"
                        />
                      </div>
                    </div>

                    {/* Language Subjects Picker removed - automatically assigned via the selected targetLanguage */}
                  </div>
                ))}
              </div>
            </div>

            {/* Payment & Booking Fee Section */}
            <div className="space-y-5 pt-6 border-t border-slate-100" id="trial-session-payment-block">
              <div>
                <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                  <CreditCard className="text-primary" size={18} />
                  <span>Secure Trial Session Checkout</span>
                </h3>
                <p className="text-xs text-slate-400">Your introductory evaluation is strictly a 25-minute live 1-on-1 trial session.</p>
              </div>

              <div className="bg-amber-50/50 border border-amber-500/20 rounded-2xl p-4 flex justify-between items-center">
                <div className="space-y-0.5 text-left">
                  <p className="text-xs font-bold text-slate-700 font-sans">25-Minute Trial Session Fee</p>
                  <p className="text-[10px] text-slate-500 font-medium">Pre-planned curriculum diagnostic, expert tutor match, and personalized evaluation report.</p>
                </div>
                <div className="text-right shrink-0">
                  <p className="text-lg font-black text-slate-900 font-mono">
                    {paymentMethod === 'zelle' ? `$${trialSessionFee.toFixed(2)}` : `${trialSessionFeeBirr} Birr`}
                  </p>
                  <p className="text-[9px] text-slate-400 font-bold uppercase tracking-wider font-sans">Flat Booking Fee</p>
                </div>
              </div>

              {/* Payment Method Selector Tabs */}
              <div className="grid grid-cols-3 gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setPaymentMethod('telebirr');
                    setErrorStatus('');
                  }}
                  className={cn(
                    "flex flex-col items-center justify-center gap-1.5 p-3 rounded-xl border text-center transition-all cursor-pointer",
                    paymentMethod === 'telebirr'
                      ? "border-blue-500 bg-blue-50 text-blue-700 shadow-sm"
                      : "border-slate-200 hover:bg-slate-50 text-slate-600"
                  )}
                >
                  <span className="text-xs font-bold block font-sans">Telebirr</span>
                  <span className="text-[9px] font-semibold text-slate-400 font-sans">Mobile Money</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setPaymentMethod('zelle');
                    setErrorStatus('');
                  }}
                  className={cn(
                    "flex flex-col items-center justify-center gap-1.5 p-3 rounded-xl border text-center transition-all cursor-pointer",
                    paymentMethod === 'zelle'
                      ? "border-indigo-600 bg-indigo-50/60 text-indigo-700 shadow-sm"
                      : "border-slate-200 hover:bg-slate-50 text-slate-600"
                  )}
                >
                  <span className="text-xs font-bold block font-sans">Zelle</span>
                  <span className="text-[9px] font-semibold text-slate-400 font-sans">USD Direct</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setPaymentMethod('cbe');
                    setErrorStatus('');
                  }}
                  className={cn(
                    "flex flex-col items-center justify-center gap-1.5 p-3 rounded-xl border text-center transition-all cursor-pointer",
                    paymentMethod === 'cbe'
                      ? "border-purple-600 bg-purple-50 text-purple-700 shadow-sm"
                      : "border-slate-200 hover:bg-slate-50 text-slate-600"
                  )}
                >
                  <span className="text-xs font-bold block font-sans">CBE Birr</span>
                  <span className="text-[9px] font-semibold text-slate-400 font-sans">Bank Transfer</span>
                </button>
              </div>

              {/* Step-by-Step Payment Guides */}
              <div className="p-4 bg-slate-50/80 border border-slate-100 rounded-2xl text-left text-xs space-y-3">
                {paymentMethod === 'telebirr' && (
                  <div className="space-y-2">
                    <p className="font-bold text-slate-800 flex items-center gap-1">
                      <span className="text-blue-500">●</span> Telebirr Payment Guide
                    </p>
                    <ol className="list-decimal pl-4 space-y-1.5 text-slate-600 leading-relaxed text-[11px] font-medium">
                      <li>Open your <strong>Telebirr App</strong> or dial <code className="bg-slate-200 px-1 py-0.5 rounded text-xs font-mono font-bold">*127#</code>.</li>
                      <li>Go to <strong>Send Money</strong> or <strong>Payment</strong>.</li>
                      <li>Transfer <strong>{totalTrialFeeBirr} Birr</strong> to our registered merchant line: <strong className="text-blue-600 text-xs font-mono font-bold">{telebirrNumber}</strong> (Account Name: <em className="not-italic font-bold">{telebirrName}</em>).</li>
                      <li>Copy the transaction reference ID received via SMS (e.g. <code className="bg-slate-200 px-1 py-0.5 rounded">FT...</code>) and paste it below.</li>
                    </ol>
                  </div>
                )}

                {paymentMethod === 'zelle' && (
                  <div className="space-y-2">
                    <p className="font-bold text-slate-800 flex items-center gap-1">
                      <span className="text-indigo-600">●</span> Zelle Transfer Guide
                    </p>
                    <ol className="list-decimal pl-4 space-y-1.5 text-slate-600 leading-relaxed text-[11px] font-medium">
                      <li>Open your US/Global banking application and select <strong>Zelle</strong>.</li>
                      <li>Send exactly <strong>${totalTrialFee.toFixed(2)} USD</strong> to our official coordinator email: <strong className="text-indigo-600 text-xs font-mono font-bold">{zelleEmail}</strong> (Account Name: <em className="not-italic font-bold">{zelleName}</em>).</li>
                      <li>Enter your <strong>Zelle account sender name</strong> or the confirmation reference code below.</li>
                    </ol>
                  </div>
                )}

                {paymentMethod === 'cbe' && (
                  <div className="space-y-2">
                    <p className="font-bold text-slate-800 flex items-center gap-1">
                      <span className="text-purple-600">●</span> CBE Bank Direct Transfer Guide
                    </p>
                    <ol className="list-decimal pl-4 space-y-1.5 text-slate-600 leading-relaxed text-[11px] font-medium">
                      <li>Open the <strong>CBE Birr App</strong>, CBE Mobile Banking, or dial CBE USSD code.</li>
                      <li>Transfer <strong>{totalTrialFeeBirr} Birr</strong> to our Commercial Bank of Ethiopia (CBE) Account Number: <strong className="text-purple-700 text-xs font-mono font-bold">{cbeAccountNumber}</strong> (Account Name: <em className="not-italic font-bold">{cbeAccountName}</em>).</li>
                      <li>Paste the transaction reference code or receipt number from your transfer confirmation below.</li>
                    </ol>
                  </div>
                )}

                {/* Shared Reference Input Field */}
                <div className="pt-2 border-t border-slate-200/60">
                  <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1.5 font-sans">
                    Transaction Reference ID / Confirmation Code <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={paymentReference}
                    onChange={(e) => setPaymentReference(e.target.value)}
                    placeholder={
                      paymentMethod === 'telebirr'
                        ? "e.g. FT2317823812"
                        : paymentMethod === 'zelle'
                        ? "e.g. Samuel Bekele / ZLN902148"
                        : "e.g. Ref: CBE-892419 or CBE Birr Code"
                    }
                    className="input-field bg-white focus:border-primary py-2 px-3 text-xs font-mono font-medium"
                  />
                  <p className="text-[9px] text-slate-400 mt-1 font-sans font-semibold">
                    We will instantly match this confirmation code with our gateway feeds to activate your portal.
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2 bg-slate-50 p-3 rounded-xl border border-slate-100">
                <Lock className="text-emerald-600 shrink-0" size={12} />
                <p className="text-[9px] text-slate-400 font-semibold leading-snug text-left font-sans">
                  Payments are processed securely. The 25-minute evaluation session booking is officially locked upon receipt.
                </p>
              </div>

              {trialCount > 1 && (
                <div className="bg-indigo-50/50 rounded-2xl p-4 border border-indigo-100/50 mt-4 animate-in fade-in slide-in-from-bottom-2 duration-500">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[10px] font-bold text-indigo-400 uppercase tracking-widest font-sans">Booking Summary</span>
                    <span className="bg-indigo-600 text-white text-[9px] px-2 py-0.5 rounded-full font-bold uppercase">{trialCount} Sessions</span>
                  </div>
                  <div className="flex items-end justify-between">
                    <div>
                      <p className="text-xs font-bold text-slate-700">Total Trial Fee</p>
                      <p className="text-[10px] text-slate-500">For {children.length} {children.length === 1 ? 'child' : 'children'} • {targetLanguage === 'Both' ? '2 Languages' : '1 Language'}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-2xl font-serif font-black text-indigo-700 leading-none">
                        {paymentMethod === 'zelle' ? `$${totalTrialFee.toFixed(2)}` : `${totalTrialFeeBirr} Birr`}
                      </p>
                      <p className="text-[9px] font-bold text-indigo-400 mt-1 uppercase">Due Now</p>
                    </div>
                  </div>
                </div>
              )}
            </div>

            <button 
              type="submit" 
              disabled={isSubmitting}
              className="btn-primary w-full py-4 text-lg mt-8 shadow-xl shadow-primary/20 flex items-center justify-center gap-2"
            >
              {isSubmitting ? (
                <Loader2 className="animate-spin" size={24} />
              ) : (
                <span>Confirm Payment & Book {trialCount}x Evaluation {trialCount === 1 ? 'Session' : 'Sessions'}</span>
              )}
            </button>

            {isBoth && (
              <div className="text-center pt-3">
                <button
                  id="wizard-backto-geez-btn-details"
                  type="button"
                  onClick={() => setBothWizardStep('geez_sched')}
                  className="text-xs text-indigo-650 hover:underline font-bold cursor-pointer"
                >
                  ← Go Back to Ge'ez Scheduling
                </button>
              </div>
            )}
                </>
              )}
          </form>
          )}
        </div>
      </div>

      {/* Immersive Tutor Introduction Profile Page Overlay */}
      {videoModalTutor && (() => {
        const isShorts = videoModalTutor.videoUrl && videoModalTutor.videoUrl.includes('/shorts/');
        const isSelected = currentTutorId === videoModalTutor.id;
        return (
          <div 
            className="fixed inset-0 bg-slate-900 z-50 overflow-y-auto flex flex-col lg:flex-row animate-in fade-in duration-200"
            onClick={() => setVideoModalTutor(null)}
          >
            {/* Cinema Video Stage Column */}
            <div 
              className="lg:flex-1 bg-slate-950 flex flex-col justify-center items-center p-6 md:p-12 relative min-h-[50vh] lg:min-h-screen"
              onClick={(e) => e.stopPropagation()}
            >
              <button 
                type="button"
                onClick={() => setVideoModalTutor(null)}
                className="absolute top-6 left-6 z-10 flex items-center gap-2 px-4 py-2.5 bg-white/10 hover:bg-white/20 text-white rounded-full text-xs font-bold transition-all backdrop-blur-sm cursor-pointer border border-white/5"
              >
                <ChevronLeft size={16} />
                <span>Back to Booking</span>
              </button>

              <div className="w-full max-w-4xl flex flex-col justify-center items-center h-full space-y-6">
                {/* Responsive Video Presentation Container */}
                <div className={cn(
                  "bg-slate-900 rounded-[28px] relative overflow-hidden shadow-2xl border border-white/10 w-full",
                  isShorts ? "aspect-[9/16] max-w-[360px]" : "aspect-video"
                )}>
                  <iframe
                    src={`${getEmbedUrl(videoModalTutor.videoUrl)}?autoplay=1&mute=0`}
                    title={`${videoModalTutor.displayName} Profile Video`}
                    className="w-full h-full border-0 absolute inset-0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowFullScreen
                  ></iframe>
                </div>

                {/* Floating Ethiopic Language Card Subtitle Overlay */}
                {videoModalTutor.quote && (
                  <div className="max-w-2xl text-center px-4">
                    <p className="text-[10px] text-indigo-400 font-bold uppercase tracking-widest font-sans flex items-center justify-center gap-1.5 mb-2">
                      <Sparkles size={11} className="animate-pulse" /> Language Coach Motto
                    </p>
                    <p className="text-base md:text-lg text-slate-200 font-medium italic leading-relaxed">
                      "{videoModalTutor.quote}"
                    </p>
                  </div>
                )}
              </div>
            </div>

            {/* Profile Detail Desk Column */}
            <div 
              className="w-full max-w-xl mx-auto lg:max-w-none lg:w-[460px] shrink-0 bg-white border-t lg:border-t-0 lg:border-l border-slate-100 flex flex-col h-full lg:h-screen lg:overflow-y-auto"
              onClick={(e) => e.stopPropagation()}
            >
              {/* Profile Header Block */}
              <div className="p-8 border-b border-slate-100 flex flex-col items-center text-center">
                <div className="relative mb-4">
                  <img 
                    src={videoModalTutor.avatar} 
                    alt={videoModalTutor.displayName} 
                    className="w-28 h-28 rounded-[36px] object-cover border-4 border-white shadow-xl"
                    referrerPolicy="no-referrer"
                  />
                  <span className="absolute bottom-1 right-1 w-4 h-4 bg-emerald-500 border-2 border-white rounded-full animate-ping"></span>
                  <span className="absolute bottom-1 right-1 w-4 h-4 bg-emerald-500 border-2 border-white rounded-full"></span>
                </div>

                <div className="flex items-center gap-2 mb-1">
                  <h3 className="font-serif font-black text-slate-900 text-3xl">
                    {videoModalTutor.displayName}
                  </h3>
                </div>

                <div className="inline-flex items-center gap-1 px-3 py-1 bg-emerald-50 text-emerald-850 rounded-full text-[10px] font-black uppercase tracking-wider mb-4">
                  Verified Academic Partner
                </div>

                <div className="text-left w-full max-w-md mx-auto bg-slate-50 p-5 rounded-2xl border border-slate-100">
                  <span className="block text-[9px] text-slate-400 font-bold uppercase tracking-widest font-sans mb-1">About the Tutor</span>
                  <p className="text-sm md:text-base text-slate-700 font-medium font-sans leading-relaxed whitespace-pre-line break-words">
                    {videoModalTutor.bio || 'Native Amharic speaker dedicated to teaching children through immersive, gamified lessons.'}
                  </p>
                </div>
              </div>

              {/* Stats & Curriculum Detail Blocks */}
              <div className="p-8 space-y-6 flex-1">
                {/* High quality stat pills */}
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-slate-50/80 p-4 rounded-2xl border border-slate-150/10">
                    <span className="block text-[9px] text-slate-400 font-bold uppercase tracking-widest font-sans">Student Rating</span>
                    <div className="flex items-center gap-1 mt-1 font-bold text-sm text-slate-800">
                      <Star size={14} className="fill-amber-500 text-amber-500" />
                      <span>{videoModalTutor.rating || '5.0'}</span>
                      <span className="text-slate-400 font-normal">({videoModalTutor.reviewsCount || '15'} {Number(videoModalTutor.reviewsCount) === 1 ? 'review' : 'reviews'})</span>
                    </div>
                  </div>

                  <div className="bg-indigo-50/40 p-4 rounded-2xl border border-indigo-100/40">
                    <span className="block text-[9px] text-indigo-700 font-bold uppercase tracking-widest font-sans">Lessons Completed</span>
                    <span className="block text-sm font-extrabold text-indigo-900 mt-1 font-sans">
                      {videoModalTutor.totalBookings || 0} lessons
                    </span>
                  </div>
                </div>

                {/* Specialties list */}
                <div className="space-y-4">
                  <div className="space-y-1.5">
                    <span className="block text-[9px] text-slate-400 font-bold uppercase tracking-widest font-sans">Syllabus Focus & Methodology</span>
                    <div className="flex flex-wrap gap-2">
                      {(videoModalTutor.specializedSyllabus || videoModalTutor.expertise || 'Conversational Amharic').split('•').map((item: string, idx: number) => (
                        <span key={idx} className="bg-indigo-50 text-indigo-700 text-[11px] font-bold px-3 py-1.5 rounded-xl">
                          {item.trim()}
                        </span>
                      ))}
                    </div>
                  </div>

                  <div className="space-y-1">
                    <span className="block text-[9px] text-slate-400 font-bold uppercase tracking-widest font-sans">Ideal Student Age Range</span>
                    <span className="block text-sm font-bold text-slate-900 font-sans">
                      {videoModalTutor.ageSpecialty || 'All children ages 6-12'}
                    </span>
                  </div>

                  {videoModalTutor.location && (
                    <div className="space-y-1">
                      <span className="block text-[9px] text-slate-400 font-bold uppercase tracking-widest font-sans">Location / Operational Base</span>
                      <span className="block text-xs text-slate-700 font-medium font-sans">
                        {videoModalTutor.location}
                      </span>
                    </div>
                  )}
                </div>
              </div>

              {/* Bottom selection sticky panel */}
              <div className="p-8 bg-slate-50 border-t border-slate-100 flex flex-col gap-3 shrink-0">
                <button
                  type="button"
                  onClick={() => {
                    setCurrentTutorId(videoModalTutor.id);
                    setVideoModalTutor(null);
                  }}
                  className={cn(
                    "w-full py-3.5 rounded-2xl text-sm font-extrabold transition-all cursor-pointer flex items-center justify-center gap-2 shadow-lg shadow-primary/10",
                    isSelected 
                      ? "bg-emerald-600 text-white hover:bg-emerald-700 hover:shadow-emerald-100" 
                      : "bg-indigo-600 text-white hover:bg-indigo-700 hover:shadow-indigo-100"
                  )}
                >
                  <Award size={16} />
                  <span>{isSelected ? "Target Selected" : `Select ${videoModalTutor.displayName}`}</span>
                </button>

                <button
                  type="button"
                  onClick={() => setVideoModalTutor(null)}
                  className="w-full py-2.5 bg-white hover:bg-slate-100 text-slate-650 border border-slate-200 rounded-2xl text-xs font-bold transition-all cursor-pointer text-center"
                >
                  Close & Keep Browsing
                </button>
              </div>
            </div>
          </div>
        );
      })()}
      </div>
    </div>
  );
}

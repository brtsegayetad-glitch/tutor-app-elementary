import React, { useEffect, useState, useRef, useMemo } from "react";
import {
  Calendar,
  CreditCard,
  TrendingUp,
  Clock,
  Settings,
  ShieldCheck,
  ChevronRight,
  MessageCircle,
  Loader2,
  CheckCircle2,
  X,
  CreditCard as CardIcon,
  Check,
  Users,
  BookOpen,
  Sparkles,
  Award,
  Inbox,
  Gift,
  Globe,
  Copy,
  ExternalLink,
  Info,
} from "lucide-react";
import { cn, compressImageToBase64 } from "../../lib/utils";
import LessonViewer from "../../components/LessonViewer";
import SupportWidget from "../../components/SupportWidget";
import { useAuth } from "../../context/AuthContext";
import { useLocation, useNavigate } from "react-router-dom";
import { doc, updateDoc, addDoc, collection, serverTimestamp, query, where, getDocs, getDoc, setDoc, deleteDoc, onSnapshot } from "firebase/firestore";
import { db, auth } from "../../lib/firebase";
import { updateEmail } from "firebase/auth";

const DAYS_ORDER = [
  "sunday",
  "monday",
  "tuesday",
  "wednesday",
  "thursday",
  "friday",
  "saturday",
];

function parseISOTimeAndDay(isoStr: string): { day: string; time: string } {
  try {
    const d = new Date(isoStr);
    if (isNaN(d.getTime())) {
      return { day: "", time: "" };
    }
    const hrs = String(d.getHours()).padStart(2, '0');
    const mins = String(d.getMinutes()).padStart(2, '0');
    const dayNames = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
    const day = dayNames[d.getDay()];
    return { day, time: `${hrs}:${mins}` };
  } catch (e) {
    return { day: "", time: "" };
  }
}

function getSlotTimeString(slot: any): string {
  if (typeof slot === "string") return slot;
  if (slot && typeof slot === "object") {
    if (typeof slot.start === "string") return slot.start;
    if (typeof slot.startTime === "string") return slot.startTime;
    if (typeof slot.slot === "string") return slot.slot;
  }
  return String(slot || "");
}

function utcSlotToLocal(
  dayName: string,
  slotTime: any,
): { day: string; slot: string } {
  const dayIndex = DAYS_ORDER.indexOf(dayName.toLowerCase());
  const str = getSlotTimeString(slotTime);
  if (dayIndex === -1 || !str.includes(":"))
    return { day: dayName, slot: str || "09:00" };

  const [h, m] = str.split(':').map(Number);
  const totalMinutesUTC = dayIndex * 24 * 60 + h * 60 + m;
  
  const now = new Date();
  const offset = now.getTimezoneOffset(); // in minutes (UTC - local)
  
  let totalMinutesLocal = totalMinutesUTC - offset;
  totalMinutesLocal = (totalMinutesLocal + 10080) % 10080;
  
  const localDayIndex = Math.floor(totalMinutesLocal / (24 * 60));
  const remainingMinutes = totalMinutesLocal % (24 * 60);
  
  const localH = String(Math.floor(remainingMinutes / 60)).padStart(2, '0');
  const localM = String(remainingMinutes % 60).padStart(2, '0');
  
  return { day: DAYS_ORDER[localDayIndex], slot: `${localH}:${localM}` };
}

function getLocalAvailability(utcAvail: any): any {
  if (!utcAvail) return null;
  const cloned: any = {};
  Object.entries(utcAvail).forEach(([day, dayData]: [string, any]) => {
    const slots = Array.isArray(dayData?.slots) ? [...dayData.slots].sort() : [];
    cloned[day] = {
      active: slots.length > 0,
      slots
    };
  });
  return cloned;
}

function getFilteredAvailability(utcAvail: any, tutorId: string, sessions: any[]): any {
  const fallbackAvailability = {
    monday: { active: true, slots: ['22:00', '23:00', '00:00', '01:00', '02:00', '03:00', '04:00', '05:00'] },
    tuesday: { active: true, slots: ['22:00', '23:00', '00:00', '01:00', '02:00', '03:00', '04:00', '05:00'] },
    wednesday: { active: true, slots: ['22:00', '23:00', '00:00', '01:00', '02:00', '03:00', '04:00', '05:00'] },
    thursday: { active: true, slots: ['22:00', '23:00', '00:00', '01:00', '02:00', '03:00', '04:00', '05:00'] },
    friday: { active: true, slots: ['22:00', '23:00', '00:00', '01:00', '02:00', '03:00', '04:00', '05:00'] },
    saturday: { active: true, slots: ['14:00', '15:00', '16:00', '17:00', '18:00', '19:00', '20:00', '21:00', '22:00', '23:00', '00:00', '01:00'] },
    sunday: { active: true, slots: ['14:00', '15:00', '16:00', '17:00', '18:00', '19:00', '20:00', '21:00', '22:00', '23:00', '00:00', '01:00'] }
  };
  const resolvedAvail = utcAvail && Object.keys(utcAvail).length > 0 ? utcAvail : fallbackAvailability;
  const localAvail = getLocalAvailability(resolvedAvail);
  if (!localAvail) return null;
  if (!tutorId || !sessions || sessions.length === 0) return localAvail;

  const nowMs = Date.now() - (60 * 60 * 1000); // 60 mins margin

  // Find all active/scheduled sessions for this tutor that are in the future
  const tutorSessions = sessions.filter(s => {
    if (s.tutorId !== tutorId) return false;
    if (s.status === 'completed' || s.status === 'cancelled') return false;
    
    const d = s.startTime?.toDate ? s.startTime.toDate() : new Date(s.startTime);
    return !isNaN(d.getTime()) && d.getTime() > nowMs;
  });

  // For each session, determine its day of week and slot (HH:mm)
  const DAYS_ORDER = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
  
  tutorSessions.forEach(s => {
    const d = s.startTime?.toDate ? s.startTime.toDate() : new Date(s.startTime);
    const dayName = DAYS_ORDER[d.getDay()];
    const hh = String(d.getHours()).padStart(2, '0');
    const mm = String(d.getMinutes()).padStart(2, '0');
    const h_m = `${hh}:${mm}`;

    if (localAvail[dayName]) {
      localAvail[dayName].slots = localAvail[dayName].slots.filter((slotStr: string) => {
        try {
          const [sh, sm] = slotStr.split(':').map(Number);
          const [th, tm] = h_m.split(':').map(Number);
          const diffMins = Math.abs((sh * 60 + sm) - (th * 60 + tm));
          return diffMins >= 60; // if less than 60 mins apart, consider it blocked/taken!
        } catch {
          return slotStr !== h_m;
        }
      });
      localAvail[dayName].active = localAvail[dayName].slots.length > 0;
    }
  });

  return localAvail;
}

import {
  subscribeToSessions,
  subscribeToAllSessions,
  subscribeToParentData,
  subscribeToMyLeads,
  subscribeToTutors,
  createSubscription,
  renewSubscription,
  scheduleRecurringSessions,
  updateLeadStatus,
  subscribeToSettings,
  updateStudentSchedule,
  getOrCreateTutorChat,
  sendTutorChatMessage,
  subscribeToTutorChats,
  subscribeToTutorChatMessages,
  submitSupportTicket,
  subscribeToMySupportTickets,
  addSupportTicketReply,
  subscribeToMessages,
  sendMessage,
  getDeterministicGoogleMeetUrl,
} from "../../services/dataService";

/**
 * Robust helper to format Firestore timestamps, JS Dates, or schedule objects {start, end}
 */
const formatSafeDate = (
  val: any,
  options: Intl.DateTimeFormatOptions = {},
): string => {
  if (!val) return "";

  let date: Date;

  // 1. Handle Firestore Timestamp
  if (val && typeof val.toDate === "function") {
    date = val.toDate();
  }
  // 2. Handle { start, end } object (common in some schedule schemas)
  else if (
    val &&
    typeof val === "object" &&
    ("start" in val || "startTime" in val)
  ) {
    const startVal = val.start || val.startTime;
    if (startVal && typeof startVal.toDate === "function") {
      date = startVal.toDate();
    } else if (typeof startVal === "string" || typeof startVal === "number") {
      const parsed = new Date(startVal);
      date = isNaN(parsed.getTime()) ? new Date() : parsed;
    } else if (startVal instanceof Date) {
      date = startVal;
    } else {
      // If it's still an object or something else, try to stringify
      return typeof startVal === "string" ? startVal : JSON.stringify(startVal);
    }
  }
  // 3. Handle Date object
  else if (val instanceof Date) {
    date = val;
  }
  // 4. Handle string/number
  else if (typeof val === "string" || typeof val === "number") {
    const parsed = new Date(val);
    if (!isNaN(parsed.getTime())) {
      date = parsed;
    } else {
      return String(val);
    }
  }
  // 5. Fallback for other objects
  else if (typeof val === "object") {
    return val.start || val.time || JSON.stringify(val);
  } else {
    return String(val);
  }

  if (isNaN(date.getTime())) return String(val);

  return date.toLocaleString("en-US", options);
};

/**
 * Specifically for rendering slot times which might be objects or strings
 */
const renderSlotTime = (time: any) => {
  if (typeof time === "string") return time;
  if (time && typeof time === "object") {
    if (time.start && typeof time.start === "string") return time.start;
    if (time.startTime && typeof time.startTime === "string")
      return time.startTime;
    return formatSafeDate(time.start || time.startTime || time, {
      hour: "2-digit",
      minute: "2-digit",
    });
  }
  return String(time || "");
};

export default function ParentDashboard() {
  const { user } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();
  const [sessions, setSessions] = useState<any[]>([]);
  const [globalSessions, setGlobalSessions] = useState<any[]>([]);
  const [leads, setLeads] = useState<any[]>([]);
  const [tutors, setTutors] = useState<any[]>([]);
  const [parentData, setParentData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Subscription Modal State
  const [showEnroller, setShowEnroller] = useState(false);
  const [libraryOpen, setLibraryOpen] = useState(false);
  const [selectedPlan, setSelectedPlan] = useState<any>(null);

  // Synchronize URL query parameter 'library' with modal state
  useEffect(() => {
    if (location.search.includes("library=true")) {
      setLibraryOpen(true);
    } else {
      setLibraryOpen(false);
    }
  }, [location.search]);

  // Custom Class Credit bundles states
  const [customCreditQuantity, setCustomCreditQuantity] = useState<number>(4);
  const [customRenewCreditQuantity, setCustomRenewCreditQuantity] =
    useState<number>(4);
  const [useCustomCreditsNew, setUseCustomCreditsNew] =
    useState<boolean>(false);
  const [useCustomCreditsRenew, setUseCustomCreditsRenew] =
    useState<boolean>(false);

  const getCreditPriceNew = () => {
    if (useCustomCreditsNew) {
      return customCreditQuantity * 40;
    }
    return selectedPlan?.price || 0;
  };

  // --- Promo and Referral Codes State Layer ---
  const [promoCodeInput, setPromoCodeInput] = useState("");
  const [promoLoading, setPromoLoading] = useState(false);
  const [promoError, setPromoError] = useState("");
  const [appliedPromo, setAppliedPromo] = useState<any>(null); // { type: 'promo' | 'referral', code: string, discountPercent: number, bonusCredits: number, referrerId?: string }

  // Ambassador & Affiliate referrals states
  const [myReferralCode, setMyReferralCode] = useState("");
  const [copiedReferral, setCopiedReferral] = useState(false);
  const [referralsList, setReferralsList] = useState<any[]>([]);
  const [referralsLoading, setReferralsLoading] = useState(false);

  const getCreditPriceRenew = () => {
    if (useCustomCreditsRenew) {
      return customRenewCreditQuantity * 40;
    }
    return selectedRenewalPlan?.price || 0;
  };

  // Subscription Renewal & Checkout State
  const [selectedRenewalPlan, setSelectedRenewalPlan] = useState<any>(null);
  const [isRenewing, setIsRenewing] = useState(false);
  const [selectedTutorId, setSelectedTutorId] = useState("");
  const [recurringTimes, setRecurringTimes] = useState<string[]>([]);
  const [isSubscribing, setIsSubscribing] = useState(false);
  const [completingTrialId, setCompletingTrialId] = useState<string | null>(null);

  // Premium Permanent Slot Booking State
  const [selectedSlots, setSelectedSlots] = useState<string[]>([]);
  const [isEditingDashboardSchedule, setIsEditingDashboardSchedule] = useState(false);
  const [savingSchedule, setSavingSchedule] = useState(false);
  const [saveScheduleStatus, setSaveScheduleStatus] = useState<
    "idle" | "success" | "error"
  >("idle");

  // Payment Verification Layer (used on both renewal checkout and enrollment setup)
  const [paymentType, setPaymentType] = useState<
    "telebirr" | "cbe" | "international"
  >("international");
  const [transactionRef, setTransactionRef] = useState("");
  const [receiptScreenshotName, setReceiptScreenshotName] = useState("");
  const [receiptScreenshotBase64, setReceiptScreenshotBase64] = useState("");
  const [paymentSenderName, setPaymentSenderName] = useState("");

  // IP Geolocation & Region-Targeting for Capture Abroad
  const [isUSUser, setIsUSUser] = useState<boolean>(() => {
    const cachedOverride = localStorage.getItem("habkids_is_us_user_override");
    if (cachedOverride !== null) {
      return cachedOverride === "true";
    }
    const cachedCountry = localStorage.getItem("habkids_user_country");
    return cachedCountry === "US";
  });
  const [showLocalETB, setShowLocalETB] = useState(false);

  useEffect(() => {
    const cachedOverride = localStorage.getItem("habkids_is_us_user_override");
    if (cachedOverride !== null) {
      setIsUSUser(cachedOverride === "true");
      if (cachedOverride === "true") {
        setPaymentType("international");
      }
      return;
    }

    const cachedCountry = localStorage.getItem("habkids_user_country");
    if (cachedCountry) {
      const isUS = cachedCountry === "US";
      setIsUSUser(isUS);
      if (isUS) {
        setPaymentType("international");
      }
      return;
    }

    const fetchCountry = async () => {
      try {
        const res = await fetch("https://ipapi.co/json/");
        const data = await res.json();
        if (data && data.country_code) {
          localStorage.setItem("habkids_user_country", data.country_code);
          const isUS = data.country_code === "US";
          setIsUSUser(isUS);
          if (isUS) {
            setPaymentType("international");
          }
          return;
        }
      } catch (e) {
        console.warn("ipapi.co failed, trying ipwho.is...", e);
      }

      try {
        const res = await fetch("https://ipwho.is/");
        const data = await res.json();
        if (data && data.country_code) {
          localStorage.setItem("habkids_user_country", data.country_code);
          const isUS = data.country_code === "US";
          setIsUSUser(isUS);
          if (isUS) {
            setPaymentType("international");
          }
          return;
        }
      } catch (e) {
        console.warn("ipwho.is failed...", e);
      }
    };

    fetchCountry();
  }, []);

  // Unified children profiles listing: combining registered students and active (unconverted) trial leads
  const registeredStudents = (parentData?.students || []).filter(
    (s: any) => {
      const nameLower = (s.name || "").trim().toLowerCase();
      return nameLower !== "astur" && nameLower !== "biruk junior";
    }
  );
  
  // Get active unconverted leads, or synthesize one for fallback preview accounts
  let activeLeads = (leads || [])
    .filter((l: any) => {
      const nameLower = (l.childName || "").trim().toLowerCase();
      return nameLower !== "astur" && nameLower !== "biruk junior";
    })
    .filter((l: any) => {
      if (l.status === "converted") return false;
      const childNameLower = (l.childName || "").trim().toLowerCase();
      const isDuplicate = registeredStudents.some(
        (s: any) => (s.name || "").trim().toLowerCase() === childNameLower
      );
      return !isDuplicate;
    });

  // Clean up legacy hardcoded "Astur" and "Biruk Junior" records from Firestore if they exist for a non-demo user
  useEffect(() => {
    if (!user?.email || !user?.uid) return;
    const cleanEmail = user.email.trim().toLowerCase();
    
    // Run cleanup for all accounts
    const runCleanup = async () => {
      try {
        // 1. Delete matching leads for Astur
        const qLeadsAstur = query(
          collection(db, "leads"),
          where("email", "==", cleanEmail),
          where("childName", "==", "Astur")
        );
        const lSnapAstur = await getDocs(qLeadsAstur);
        for (const dSnap of lSnapAstur.docs) {
          await deleteDoc(doc(db, "leads", dSnap.id));
          console.log(`[Cleanup] Deleted legacy test lead doc: ${dSnap.id}`);
        }

        // Delete matching leads for Biruk Junior
        const qLeadsBiruk = query(
          collection(db, "leads"),
          where("email", "==", cleanEmail),
          where("childName", "==", "Biruk Junior")
        );
        const lSnapBiruk = await getDocs(qLeadsBiruk);
        for (const dSnap of lSnapBiruk.docs) {
          await deleteDoc(doc(db, "leads", dSnap.id));
          console.log(`[Cleanup] Deleted legacy test lead doc: ${dSnap.id}`);
        }

        // 2. Delete matching sessions for Astur
        const qSessionsAstur = query(
          collection(db, "sessions"),
          where("parentEmail", "==", cleanEmail),
          where("studentName", "==", "Astur")
        );
        const sSnapAstur = await getDocs(qSessionsAstur);
        for (const dSnap of sSnapAstur.docs) {
          await deleteDoc(doc(db, "sessions", dSnap.id));
          console.log(`[Cleanup] Deleted legacy test session doc: ${dSnap.id}`);
        }

        // Delete matching sessions for Biruk Junior
        const qSessionsBiruk = query(
          collection(db, "sessions"),
          where("parentEmail", "==", cleanEmail),
          where("studentName", "==", "Biruk Junior")
        );
        const sSnapBiruk = await getDocs(qSessionsBiruk);
        for (const dSnap of sSnapBiruk.docs) {
          await deleteDoc(doc(db, "sessions", dSnap.id));
          console.log(`[Cleanup] Deleted legacy test session doc: ${dSnap.id}`);
        }

        // 3. Remove "Astur" or "Biruk Junior" from parent's students array
        if (parentData && parentData.students) {
          const hasLegacy = parentData.students.some((s: any) => {
            const nameLower = (s.name || "").trim().toLowerCase();
            return nameLower === "astur" || nameLower === "biruk junior";
          });
          if (hasLegacy) {
            const updatedStudents = parentData.students.filter((s: any) => {
              const nameLower = (s.name || "").trim().toLowerCase();
              return nameLower !== "astur" && nameLower !== "biruk junior";
            });
            await setDoc(
              doc(db, "users", user.uid),
              { students: updatedStudents },
              { merge: true }
            );
            console.log(`[Cleanup] Removed legacy mock child from student list inside parent user doc`);
          }
        }
      } catch (err) {
        console.warn("[Cleanup] Test data removal failed:", err);
      }
    };

    runCleanup();
  }, [user, parentData]);
  
  const allProfiles = [
    ...registeredStudents.map((s: any) => ({
      id: s.id,
      key: `student-${s.id}`,
      type: "student" as const,
      name: s.name,
      status: s.status,
      subjects: s.subjects || [],
      data: s,
    })),
    ...activeLeads.map((l: any) => ({
      id: l.id,
      key: `lead-${l.id}`,
      type: "lead" as const,
      name: l.childName || "Trial Booking",
      status: l.status,
      subjects: l.subject ? [l.subject] : ["Amharic"],
      data: l,
    })),
  ];

  const [activeProfileIndex, setActiveProfileIndex] = useState(0);
  const safeProfileIndex = activeProfileIndex < allProfiles.length ? activeProfileIndex : 0;
  const activeProfile = allProfiles[safeProfileIndex] || null;

  const activeStudent =
    activeProfile && activeProfile.type === "student" ? activeProfile.data : null;

  const completedTrialLead =
    activeProfile && (
      (activeProfile.type === "lead" && ["trial_completed", "registration_completed"].includes(activeProfile.status || "")) ||
      (activeProfile.type === "student" && ["trial_completed", "registration_completed"].includes(activeProfile.status || ""))
    )
      ? {
          ...activeProfile.data,
          childName: activeProfile.data.childName || activeProfile.data.name,
          childAge: activeProfile.data.childAge || activeProfile.data.age || 8,
          status: activeProfile.data.status || activeProfile.status,
        }
      : null;

  const enrollmentUnits = useMemo(() => {
    if (!completedTrialLead) return 1;
    const childList = Array.isArray(completedTrialLead.children) && completedTrialLead.children.length > 0
      ? completedTrialLead.children
      : [{ name: completedTrialLead.childName, subjects: ['Amharic'] }];
    
    return childList.reduce((acc: number, child: any) => {
      const subjectsCount = Array.isArray(child.subjects) ? child.subjects.length : 1;
      return acc + subjectsCount;
    }, 0);
  }, [completedTrialLead]);

  const scheduledTrialLead =
    activeProfile && activeProfile.type === "lead" && activeProfile.status === "scheduled"
      ? activeProfile.data
      : null;

  const dbTrialSession = sessions.find(
    (s: any) => s.type === "trial" && s.status === "completed" && (
      activeProfile?.type === 'lead' 
        ? s.parentEmail?.toLowerCase() === activeProfile.data.email?.toLowerCase() && s.studentName === activeProfile.data.childName
        : s.studentId === activeProfile?.id
    )
  ) || sessions.find(
    (s: any) => s.type === "trial" && s.status === "completed" && (
      activeProfile?.type === 'lead'
        ? s.studentName === activeProfile.data.childName
        : false
    )
  ) || sessions.find(
    (s: any) => s.type === "trial" && s.status === "completed" && (
      s.parentEmail?.toLowerCase() === user?.email?.toLowerCase()
    )
  );

  const trialSession = dbTrialSession;

  const [settings, setSettings] = useState<any>({
    standardPrice: 160,
    proPrice: 240,
    masteryPrice: 320,
    standardPriceBirr: 2300,
    proPriceBirr: 3500,
    masteryPriceBirr: 5200,
    referralCommissionRate: 9,
    referralDiscountPercent: 10,
    referralBonusCredits: 1,
  });

  const DAYS = [
    "monday",
    "tuesday",
    "wednesday",
    "thursday",
    "friday",
    "saturday",
    "sunday",
  ];

  const currentPath = location.pathname.toLowerCase();
  const activeTab = currentPath.includes("/schedule")
    ? "schedule"
    : currentPath.includes("/billing")
      ? "billing"
      : currentPath.includes("/progress")
        ? "progress"
        : currentPath.includes("/settings")
          ? "settings"
          : currentPath.includes("/support")
            ? "support"
            : currentPath.includes("/referrals")
              ? "referrals"
              : "dashboard";

  // Parent profile settings local states
  const [profileName, setProfileName] = useState("");
  const [profileWhatsApp, setProfileWhatsApp] = useState("");
  const [profileEmail, setProfileEmail] = useState("");
  const [isEditingEmail, setIsEditingEmail] = useState(false);
  const [updatingEmailState, setUpdatingEmailState] = useState(false);
  const [emailUpdateStatus, setEmailUpdateStatus] = useState<"idle" | "success" | "error" | "requires-login">("idle");
  const [emailErrorMessage, setEmailErrorMessage] = useState("");
  const [childNameVal, setChildNameVal] = useState("");
  const [savingSettings, setSavingSettings] = useState(false);
  const [saveStatus, setSaveStatus] = useState<"idle" | "success" | "error">(
    "idle",
  );

  // --- Admin Ticket / Help & Support Section State ---
  const [myTickets, setMyTickets] = useState<any[]>([]);
  const [selectedTicketId, setSelectedTicketId] = useState<string | null>(null);
  const [newTicketTopic, setNewTicketTopic] = useState("Curriculum & Program structure");
  const [newTicketQuestion, setNewTicketQuestion] = useState("");
  const [submittingTicket, setSubmittingTicket] = useState(false);
  const [ticketReplyText, setTicketReplyText] = useState("");
  const [sendingTicketReply, setSendingTicketReply] = useState(false);
  const [activeSupportChannelTab, setActiveSupportChannelTab] = useState<"admin" | "tutor">("admin");

  // --- Tutor Classroom Chat State ---
  const [activeTutorChatId, setActiveTutorChatId] = useState<string | null>(null);
  const [activeTutorChatTutor, setActiveTutorChatTutor] = useState<any | null>(null);
  const [tutorChatMessages, setTutorChatMessages] = useState<any[]>([]);
  const [tutorChatMessageInput, setTutorChatMessageInput] = useState("");
  const [sendingTutorChatMessageState, setSendingTutorChatMessageState] = useState(false);
  const [tutorChatViolationWarning, setTutorChatViolationWarning] = useState<string | null>(null);

  // --- Admin General/Direct Chat State ---
  const [adminSupportSubTab, setAdminSupportSubTab] = useState<'chat' | 'tickets'>('chat');
  const [adminMessages, setAdminMessages] = useState<any[]>([]);
  const [adminChatInput, setAdminChatInput] = useState('');
  const [sendingAdminMessage, setSendingAdminMessage] = useState(false);

  // Subscribe to direct admin messages for active Profile
  const activeProfileId = activeProfile?.id;
  useEffect(() => {
    if (!activeProfileId) {
      setAdminMessages([]);
      return;
    }
    const unsub = subscribeToMessages((allMsgs) => {
      const filtered = allMsgs.filter(m => m.recipientId === activeProfileId || m.senderId === activeProfileId);
      setAdminMessages(filtered);
    });
    return () => unsub();
  }, [activeProfileId]);

  // Subscribe to support tickets
  const userEmail = user?.email;

  // Automatic tab routing fallback for childless ambassador or affiliate accounts
  useEffect(() => {
    if (user?.isAmbassador && allProfiles.length === 0 && !loading && activeTab !== "referrals") {
      navigate("/parent/referrals");
    }
  }, [allProfiles.length, loading, activeTab, user]);

  useEffect(() => {
    if (!user || !userEmail) return;
    const unsub = subscribeToMySupportTickets(userEmail, (tickets) => {
      setMyTickets(tickets);
    });
    return () => unsub();
  }, [user, userEmail]);

  // Subscribe to tutor chat messages
  useEffect(() => {
    if (!activeTutorChatId) {
      setTutorChatMessages([]);
      return;
    }
    const unsub = subscribeToTutorChatMessages(activeTutorChatId, (messages) => {
      setTutorChatMessages(messages);
    });
    return () => unsub();
  }, [activeTutorChatId]);

  // Auto-initialize tutor chat on support tab switch to tutor
  const activeStudentTutorId = activeStudent?.tutorId;
  useEffect(() => {
    if (activeTab === "support" && activeSupportChannelTab === "tutor") {
      const tutor = tutors.find((t) => t.id === activeStudentTutorId);
      if (tutor && !activeTutorChatId) {
        handleOpenTutorChat(tutor);
      }
    }
  }, [activeTab, activeSupportChannelTab, activeStudentTutorId, tutors, activeTutorChatId]);

  // Active student state mapped above from unified allProfiles state

  useEffect(() => {
    if (user) {
      setProfileName(user.fullName || user.displayName || "");
      setProfileWhatsApp((user as any).whatsapp || "");
      setProfileEmail(user.email || "");
    }
  }, [user]);

  const fallbackStudent = parentData?.students?.[0];
  const activeStudentOrFallback = activeStudent || fallbackStudent;
  const derivedChildName = activeStudentOrFallback
    ? (activeStudentOrFallback.name || "")
    : ((completedTrialLead || scheduledTrialLead)?.childName || "");

  useEffect(() => {
    setChildNameVal(derivedChildName);
  }, [derivedChildName]);

  const recurringTimesStr = JSON.stringify(activeStudentOrFallback?.recurringTimes || []);
  useEffect(() => {
    if (activeStudentOrFallback?.recurringTimes) {
      setSelectedSlots(activeStudentOrFallback.recurringTimes);
    }
  }, [recurringTimesStr]);

  const getNextCycleDate = () => {
    let startDate = new Date();
    if (activeStudent?.subscriptionStartDate) {
      const parsed = new Date(activeStudent.subscriptionStartDate);
      if (!isNaN(parsed.getTime())) startDate = parsed;
    } else if (activeStudent?.createdAt) {
      const timestampDate = activeStudent.createdAt?.toDate ? activeStudent.createdAt.toDate() : new Date(activeStudent.createdAt);
      if (!isNaN(timestampDate.getTime())) startDate = timestampDate;
    }
    
    // Calculate next payment cycle in exactly 4 weeks (28 days) from start date
    const nextDate = new Date(startDate.getTime());
    nextDate.setDate(startDate.getDate() + 28);
    
    // If next date is in the past, keep adding 28 days until it is in the future (automatic recurring cycle)
    const today = new Date();
    while (nextDate.getTime() < today.getTime()) {
      nextDate.setDate(nextDate.getDate() + 28);
    }
    
    return nextDate.toLocaleDateString("en-US", {
      month: "long",
      day: "numeric",
      year: "numeric",
    });
  };

  const getCycleSessions = () => {
    if (!activeStudent?.plan) return [];
    
    // 1. Calculate the start date of the current 4-week cycle
    let initialStartDate = new Date();
    if (activeStudent.subscriptionStartDate) {
      const parsed = new Date(activeStudent.subscriptionStartDate);
      if (!isNaN(parsed.getTime())) initialStartDate = parsed;
    } else if (activeStudent.createdAt) {
      const timestampDate = activeStudent.createdAt?.toDate ? activeStudent.createdAt.toDate() : new Date(activeStudent.createdAt);
      if (!isNaN(timestampDate.getTime())) initialStartDate = timestampDate;
    }
    
    const nextDate = new Date(initialStartDate.getTime());
    nextDate.setDate(initialStartDate.getDate() + 28);
    
    const today = new Date();
    while (nextDate.getTime() < today.getTime()) {
      nextDate.setDate(nextDate.getDate() + 28);
    }
    
    const cycleStartDate = new Date(nextDate.getTime());
    cycleStartDate.setDate(nextDate.getDate() - 28);
    const cycleEndDate = nextDate;

    // 2. Check if we have REAL session documents in the database for this student
    const studentSessions = sessions.filter(s => {
      if (!activeStudent?.id) return false;
      
      // Extremely robust matching: ID, or (Email + Name), or (ParentID + Name)
      const matchesStudent = s.studentId === activeStudent.id || 
                             (s.parentEmail?.toLowerCase() === user?.email?.toLowerCase() && (s.studentName === activeStudent.name || s.studentName === activeStudent.childName)) ||
                             (s.parentId === user?.uid && (s.studentName === activeStudent.name || s.studentName === activeStudent.childName));
      
      if (!matchesStudent || s.type === 'trial') return false;
      
      const d = s.startTime?.toDate ? s.startTime.toDate() : new Date(s.startTime);
      // Show sessions from the current cycle start date onwards (including future cycles)
      const bufferMs = 6 * 60 * 60 * 1000; // 6 hours buffer
      return d.getTime() >= (cycleStartDate.getTime() - bufferMs);
    });

    if (studentSessions.length > 0) {
      // Sort them chronologically
      const sorted = [...studentSessions].sort((a, b) => {
        const dA = a.startTime?.toDate ? a.startTime.toDate() : new Date(a.startTime);
        const dB = b.startTime?.toDate ? b.startTime.toDate() : new Date(b.startTime);
        return dA.getTime() - dB.getTime();
      });

      return sorted.map((s, idx) => {
        const d = s.startTime?.toDate ? s.startTime.toDate() : new Date(s.startTime);
        const assocTutor = tutors && s.tutorId ? tutors.find((t) => t.id === s.tutorId) : null;
        
        const meetUrl = s.classroomLink || assocTutor?.classroomLink || getDeterministicGoogleMeetUrl(undefined, s.tutorId);

        // Self-heal: Force update the session document so it's permanent
        const isAnon = s.tutorName === 'Anonymous User' || !s.tutorName;
        if (s.id && (isAnon || !s.classroomLink || !s.tutorEmail) && assocTutor) {
          const updates: any = {};
          if (!s.classroomLink && assocTutor.classroomLink) updates.classroomLink = assocTutor.classroomLink;
          if (!s.tutorEmail && assocTutor.email) updates.tutorEmail = assocTutor.email;
          
          const betterName = assocTutor.displayName || assocTutor.name || assocTutor.fullName;
          if (isAnon && betterName && betterName !== 'Anonymous User') {
            updates.tutorName = betterName;
          }
          
          if (Object.keys(updates).length > 0) {
            updateDoc(doc(db, 'sessions', s.id), updates).catch(e => console.warn("Silent heal failed:", e));
          }
        }

        const betterTutorName = s.tutorName && s.tutorName !== 'Anonymous User' 
          ? s.tutorName 
          : (assocTutor?.displayName || assocTutor?.name || assocTutor?.fullName || "Assigned Tutor");

        return {
          sessionNumber: idx + 1,
          date: d,
          formattedDay: d.toLocaleDateString("en-US", { weekday: "long", month: "short", day: "numeric" }),
          formattedTime: d.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" }),
          originalStr: `${d.toLocaleDateString("en-US", { weekday: "long" })} @ ${d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}`,
          tutorName: betterTutorName,
          meetUrl: meetUrl,
          status: s.status || 'scheduled',
          missedReason: s.missedReason || ''
        };
      });
    }

    // 3. Extract weekly slots for synthetic calculation if no real sessions found
    const slots: { weekday: number; hour: number; minute: number; originalStr?: string }[] = [];
    
    // Try to get from activeStudent.recurringTimes
    if (activeStudent.recurringTimes && activeStudent.recurringTimes.length > 0) {
      activeStudent.recurringTimes.forEach((rt: any) => {
        try {
          const d = new Date(rt);
          if (!isNaN(d.getTime())) {
            slots.push({
              weekday: d.getDay(),
              hour: d.getHours(),
              minute: d.getMinutes(),
              originalStr: d.toLocaleDateString("en-US", { weekday: "long" }) + " @ " + d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
            });
          }
        } catch (e) {
          console.error("Error parsing recurringTimes", e);
        }
      });
    }
    
    // If no slots found from recurringTimes, check schedulePattern
    const rawPattern = activeStudent.schedulePattern;
    let safeSchedulePattern: string[] = [];
    
    if (Array.isArray(rawPattern)) {
      safeSchedulePattern = rawPattern;
    } else if (typeof rawPattern === "string") {
      // Split by comma first
      safeSchedulePattern = rawPattern.split(",").map((s: string) => s.trim()).filter(Boolean);
      
      // If still only 1 string but it looks like multiple (e.g. "Monday @ 3:00 Sunday @ 3:00")
      // regex to find things like "Monday @ 03:00 AM" patterns
      if (safeSchedulePattern.length === 1 && (rawPattern.match(/@/g) || []).length > 1) {
        // Try to split by day names
        const daysRegex = /(sunday|monday|tuesday|wednesday|thursday|friday|saturday)/gi;
        const matches = [...rawPattern.matchAll(daysRegex)];
        if (matches.length > 1) {
          const splitPatterns: string[] = [];
          for (let i = 0; i < matches.length; i++) {
            const start = matches[i].index || 0;
            const end = i < matches.length - 1 ? matches[i+1].index : rawPattern.length;
            splitPatterns.push(rawPattern.substring(start, end).trim());
          }
          safeSchedulePattern = splitPatterns;
        }
      }
    }

    if (slots.length === 0 && safeSchedulePattern.length > 0) {
      safeSchedulePattern.forEach((pattern: string) => {
        const parts = pattern.split(" @ ");
        if (parts.length === 2) {
          const dayName = parts[0].trim().toLowerCase();
          const timeStr = parts[1].trim();
          
          const dayMap: { [key: string]: number } = {
            sunday: 0, monday: 1, tuesday: 2, wednesday: 3, thursday: 4, friday: 5, saturday: 6
          };
          const weekday = dayMap[dayName] !== undefined ? dayMap[dayName] : 1;
          
          let hour = 18;
          let minute = 0;
          try {
            const timeParts = timeStr.match(/(\d+):(\d+)\s*(AM|PM)/i);
            if (timeParts) {
              let h = parseInt(timeParts[1], 10);
              const m = parseInt(timeParts[2], 10);
              const ampm = timeParts[3].toUpperCase();
              if (ampm === "PM" && h < 12) h += 12;
              if (ampm === "AM" && h === 12) h = 0;
              hour = h;
              minute = m;
            } else {
              // fallback for simple HH:mm if no AM/PM
              const simpleParts = timeStr.match(/(\d+):(\d+)/);
              if (simpleParts) {
                hour = parseInt(simpleParts[1], 10);
                minute = parseInt(simpleParts[2], 10);
              }
            }
          } catch (e) {
            console.error("Error parsing schedulePattern time", e);
          }
          
          slots.push({ weekday, hour, minute, originalStr: pattern });
        }
      });
    }
    
    // fallback if absolutely nothing exists
    if (slots.length === 0) {
      slots.push({ weekday: 1, hour: 18, minute: 0, originalStr: "Monday @ 06:00 PM" });
      if (activeStudent.plan === "pro") {
        slots.push({ weekday: 3, hour: 18, minute: 0, originalStr: "Wednesday @ 06:00 PM" });
      } else if (activeStudent.plan === "mastery") {
        slots.push({ weekday: 3, hour: 18, minute: 0, originalStr: "Wednesday @ 06:00 PM" });
        slots.push({ weekday: 5, hour: 18, minute: 0, originalStr: "Friday @ 06:00 PM" });
      }
    }
    
    slots.sort((a, b) => {
      if (a.weekday !== b.weekday) return a.weekday - b.weekday;
      if (a.hour !== b.hour) return a.hour - b.hour;
      return a.minute - b.minute;
    });
    
    const occurrences: { 
      sessionNumber: number; 
      date: Date; 
      formattedDay: string;
      formattedTime: string;
      originalStr: string;
      tutorName: string;
      meetUrl: string;
    }[] = [];
    
    const assocTutor = tutors && activeStudent.tutorId ? tutors.find((t) => t.id === activeStudent.tutorId) : null;
    const meetUrl = assocTutor?.classroomLink || getDeterministicGoogleMeetUrl(assocTutor?.email, activeStudent.tutorId || assocTutor?.id);
    const tutorName = assocTutor?.name || assocTutor?.displayName || "Assigned Tutor";
    
    let count = 1;
    for (let w = 0; w < 4; w++) {
      slots.forEach((s) => {
        const baseDate = new Date(cycleStartDate.getTime());
        baseDate.setDate(cycleStartDate.getDate() + w * 7);
        
        const currentWD = baseDate.getDay();
        let daysDiff = s.weekday - currentWD;
        if (daysDiff < 0) {
          daysDiff += 7;
        }
        
        const targetDate = new Date(baseDate.getTime());
        targetDate.setDate(baseDate.getDate() + daysDiff);
        targetDate.setHours(s.hour, s.minute, 0, 0);
        
        occurrences.push({
          sessionNumber: count++,
          date: targetDate,
          formattedDay: targetDate.toLocaleDateString("en-US", { weekday: "long", month: "short", day: "numeric" }),
          formattedTime: targetDate.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" }),
          originalStr: s.originalStr || `${targetDate.toLocaleDateString("en-US", { weekday: "long" })} @ ${targetDate.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}`,
          tutorName,
          meetUrl
        });
      });
    }
    
    occurrences.sort((a, b) => a.date.getTime() - b.date.getTime());
    occurrences.forEach((occ, idx) => {
      occ.sessionNumber = idx + 1;
    });
    
    return occurrences;
  };

  useEffect(() => {
    const unsub = subscribeToSettings((data) => {
      if (data) {
        setSettings(data);
      }
    });
    return () => unsub();
  }, []);

  const plans = useMemo(() => [
    {
      id: "standard",
      name: "HabKids Standard",
      sessions: 4,
      price: settings.standardPrice || 160,
      description: "1 Session per week",
    },
    {
      id: "pro",
      name: "HabKids Pro",
      sessions: 8,
      price: settings.proPrice || 240,
      description: "2 Sessions per week",
    },
    {
      id: "mastery",
      name: "HabKids Mastery",
      sessions: 12,
      price: settings.masteryPrice || 320,
      description: "3 Sessions per week",
    },
  ], [settings]);

  // Pre-fill enrollment data when the enroller modal is opened or when trial lead changes
  useEffect(() => {
    if (showEnroller) {
      const defaultTutorId = completedTrialLead?.tutorId || "auto-assign";
      setSelectedTutorId((prev) => prev || defaultTutorId);
      setSelectedPlan((prev) => {
        if (!prev && !useCustomCreditsNew) {
          return plans[0] || null;
        }
        return prev;
      });
    }
  }, [showEnroller, completedTrialLead?.id]);

  useEffect(() => {
    if (!user) return;

    let sessionsLoaded = false;
    let parentLoaded = false;

    const checkLoading = () => {
      if (sessionsLoaded && parentLoaded) {
        setLoading(false);
      }
    };

    const unsubscribeSessions = subscribeToSessions(
      "parent",
      user.uid,
      (data) => {
        setSessions(data);
        sessionsLoaded = true;
        checkLoading();
      },
      () => {
        sessionsLoaded = true;
        checkLoading();
      },
      user.email || ""
    );

    const unsubscribeParent = subscribeToParentData(
      user.uid,
      (data) => {
        setParentData(data);
        parentLoaded = true;
        checkLoading();
      },
      () => {
        parentLoaded = true;
        checkLoading();
      },
      user.email || ""
    );

    let unsubLeads = () => {};
    if (user.email) {
      const emailLower = user.email.toLowerCase().trim();
      const qEmail = query(collection(db, "leads"), where("email", "==", emailLower));
      const qParent = query(collection(db, "leads"), where("parentId", "==", user.uid));
      
      let emailLeads: any[] = [];
      let parentLeads: any[] = [];
      
      const handleUpdate = (eL: any[], pL: any[]) => {
        const combined = [...eL, ...pL];
        const unique = Array.from(new Map(combined.map(item => [item.id, item])).values());
        setLeads(unique);
      };
      
      const unsubEmail = onSnapshot(qEmail, (snap) => {
        emailLeads = snap.docs.map(doc => ({ id: doc.id, ...doc.data() }));
        handleUpdate(emailLeads, parentLeads);
      }, (err) => console.error("Error subscribing to leads by email in ParentDashboard:", err));
      
      const unsubParent = onSnapshot(qParent, (snap) => {
        parentLeads = snap.docs.map(doc => ({ id: doc.id, ...doc.data() }));
        handleUpdate(emailLeads, parentLeads);
      }, (err) => console.error("Error subscribing to leads by parentId in ParentDashboard:", err));
      
      unsubLeads = () => {
        unsubEmail();
        unsubParent();
      };
    }

    const unsubscribeTutors = subscribeToTutors((data) => {
      setTutors(data);
    });

    const unsubscribeGlobalSessions = subscribeToAllSessions((data) => {
      setGlobalSessions(data);
    }, () => {
      console.error("Error subscribing to global sessions in ParentDashboard");
    });

    return () => {
      unsubscribeSessions();
      unsubscribeParent();
      unsubLeads();
      unsubscribeTutors();
      unsubscribeGlobalSessions();
    };
  }, [user]);

  // --- Initialize User Referral Code & Sync Ledger ---
  useEffect(() => {
    if (!user) return;

    const setupUserReferrals = async () => {
      setReferralsLoading(true);
      try {
        // 1. Get or create user profile's custom referral code
        const userRef = doc(db, "users", user.uid);
        const userSnap = await getDoc(userRef);
        let refCode = "";

        if (userSnap.exists()) {
          const uData = userSnap.data();
          if (uData.referralCode) {
            refCode = uData.referralCode;
          } else {
            // Generate standard format: HAB-NAME-RANDOM (e.g., HAB-SELA-9831)
            const initials = (uData.fullName || uData.displayName || user.displayName || user.fullName || "AMB")
              .trim()
              .split(" ")[0]
              .replace(/[^a-zA-Z]/g, "")
              .substring(0, 4)
              .toUpperCase();
            const rand = Math.floor(1000 + Math.random() * 9000);
            refCode = `HAB-${initials || "AMB"}-${rand}`;
            
            await setDoc(userRef, { referralCode: refCode }, { merge: true });
          }
        } else {
          // If virtual user is logged in
          const initials = (user.displayName || user.fullName || "PREVIEW").trim().split(" ")[0].replace(/[^a-zA-Z]/g, "").substring(0, 4).toUpperCase();
          refCode = `HAB-${initials || "AMB"}-${Math.floor(1000 + Math.random() * 9000)}`;
          await setDoc(userRef, {
            uid: user.uid,
            email: user.email,
            fullName: user.displayName || user.fullName || "HabKids Ambassador",
            role: "parent",
            isActive: true,
            referralCode: refCode,
            createdAt: serverTimestamp()
          }, { merge: true });
        }
        setMyReferralCode(refCode);

        // 2. Fetch referrals ledger where this user is the referrer
        const qRefs = query(collection(db, "referrals"), where("referrerUid", "==", user.uid));
        const qSnap = await getDocs(qRefs);
        const refList = qSnap.docs.map(doc => ({ id: doc.id, ...doc.data() }));
        setReferralsList(refList);
      } catch (err) {
        console.error("Error setting up user referrals in ParentDashboard:", err);
      } finally {
        setReferralsLoading(false);
      }
    };

    setupUserReferrals();
  }, [user]);

  const handleVerifyPromoCode = async () => {
    if (!promoCodeInput.trim()) return;
    setPromoLoading(true);
    setPromoError("");
    setAppliedPromo(null);

    const checkCode = promoCodeInput.trim().toUpperCase();

    try {
      // 1. Check if it matches a custom promotional code in `promo_codes` collection
      const qPromo = query(collection(db, "promo_codes"), where("code", "==", checkCode));
      const promoSnap = await getDocs(qPromo);

      if (!promoSnap.empty) {
        const promoDoc = promoSnap.docs[0];
        const promoData = promoDoc.data();

        if (promoData.isActive === false) {
          setPromoError("This promo code has been deactivated.");
          setPromoLoading(false);
          return;
        }

        if (promoData.expiryDate) {
          const exp = new Date(promoData.expiryDate);
          if (exp.getTime() < Date.now()) {
            setPromoError("This promo code has expired.");
            setPromoLoading(false);
            return;
          }
        }

        setAppliedPromo({
          type: "promo",
          code: promoData.code,
          discountPercent: Number(promoData.discountPercent) || 0,
          bonusCredits: Number(promoData.addedCredits) || 0,
          description: promoData.description || `Saves ${promoData.discountPercent}% and adds +${promoData.addedCredits || 0} bonus classes!`
        });
        setPromoLoading(false);
        return;
      }

      // 2. Check if it matches a user's referralCode in `/users` collection
      const qUserRef = query(collection(db, "users"), where("referralCode", "==", checkCode));
      const userRefSnap = await getDocs(qUserRef);

      if (!userRefSnap.empty) {
        const referrerDoc = userRefSnap.docs[0];
        const referrerData = referrerDoc.data();

        if (referrerDoc.id === user?.uid) {
          setPromoError("You cannot use your own referral code.");
          setPromoLoading(false);
          return;
        }

        setAppliedPromo({
          type: "referral",
          code: checkCode,
          discountPercent: 10, // Default 10% off for using a referral code
          bonusCredits: 1, // Default 1 bonus credit standard for using a referral
          referrerId: referrerDoc.id,
          referrerName: referrerData.fullName || referrerData.email,
          description: `Referred by ${referrerData.fullName || "friend"}. Lock in a gorgeous 10% discount and get 1 bonus class credited automatically!`
        });
        setPromoLoading(false);
        return;
      }

      setPromoError("Invalid promo or referral code. Please check for spelling.");
    } catch (err) {
      console.error("Error verifying promo or referral code:", err);
      setPromoError("Server validation failed. Proceed without coupon or contact support.");
    } finally {
      setPromoLoading(false);
    }
  };

  // Auto-set selectedRenewalPlan when on billing tab to ensure the "Transmit" button is active
  useEffect(() => {
    if (activeTab === "billing" && activeStudent && !selectedRenewalPlan) {
      const planId = activeStudent.plan?.toLowerCase() || "";
      const currentPlan = plans.find(p => planId.includes(p.id)) || plans[0];
      if (currentPlan) {
        setSelectedRenewalPlan(currentPlan);
      }
    }
  }, [activeTab, activeStudent, plans, selectedRenewalPlan]);

  const handleEnrollment = async (e: React.FormEvent) => {
    e.preventDefault();
    let lead = completedTrialLead || scheduledTrialLead;
    if (!lead && user) {
      // Synthesize fallback lead so parents without active Firestore trial records are never blocked
      lead = {
        id: "synthesized-lead-id-" + Date.now(),
        childName: activeProfile?.name || "Student",
        childAge: 8,
        status: "trial_completed",
        subject: "Amharic",
        parentName: user.displayName || user.fullName || "Parent",
        email: user.email || ""
      };
    }

    if (
      !user ||
      !lead ||
      (!selectedPlan && !useCustomCreditsNew) ||
      !selectedTutorId ||
      recurringTimes.length === 0
    ) {
      console.warn("Enrollment aborted: missing data", {
        user: !!user,
        lead: !!lead,
        plan: !!selectedPlan || useCustomCreditsNew,
        tutor: !!selectedTutorId,
        times: recurringTimes.length,
      });
      alert("Missing required enrollment data. Please make sure you have chosen a subscription plan or custom credit quantity, selected your tutor selection mode, and checked at least one weekly slot.");
      return;
    }

    setIsSubscribing(true);
    try {
      let targetTutor = null;
      if (selectedTutorId === "auto-assign") {
        // Find which tutor has the closest match to the selected times
        const firstTime = recurringTimes[0];
        if (firstTime) {
          const d = new Date(firstTime);
          const dayName = d.toLocaleDateString("en-US", { weekday: "long" }).toLowerCase();
          const hourPart = d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", hour12: false });
          targetTutor = tutors.find(t => {
            const avail = getFilteredAvailability(t.availability, t.id, globalSessions);
            return avail?.[dayName]?.active && avail[dayName].slots?.includes(hourPart);
          });
        }
        if (!targetTutor) {
          targetTutor = tutors[0];
        }
      } else {
        targetTutor = tutors.find((t) => t.id === selectedTutorId);
      }

      if (!targetTutor) {
        alert("Selected tutor options are no longer available. Please select another.");
        setIsSubscribing(false);
        return;
      }
      const tutor = targetTutor;

      const schedulePattern = recurringTimes.map((time) => {
        const d = new Date(time);
        return `${d.toLocaleDateString("en-US", { weekday: "long" })} @ ${d.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" })}`;
      });

      // Handle multi-children and multi-subject enrollment
      const enrollmentItems: Array<{ name: string; age: any; subject: string }> = [];
      if (Array.isArray(lead.children) && lead.children.length > 0) {
        lead.children.forEach((c: any) => {
          const subs = Array.isArray(c.subjects) ? c.subjects : ['Amharic'];
          subs.forEach((s: string) => {
            enrollmentItems.push({ name: c.name, age: c.age, subject: s });
          });
        });
      } else {
        const subs = Array.isArray(lead.subjects) ? lead.subjects : ['Amharic'];
        subs.forEach((s: string) => {
          enrollmentItems.push({ name: lead.childName, age: lead.childAge, subject: s });
        });
      }

      if (enrollmentItems.length === 0) {
        enrollmentItems.push({ name: lead.childName || "Student", age: lead.childAge || "8", subject: "Amharic" });
      }

      let enrolledSome = false;

      // Compute discounted rates and optional bonus credits based on promo code application
      let baseRate = useCustomCreditsNew ? getCreditPriceNew() : (selectedPlan?.price || 0);
      let baseCredits = useCustomCreditsNew ? customCreditQuantity : (selectedPlan?.sessions || 4);

      if (appliedPromo) {
        const discountFactor = (100 - appliedPromo.discountPercent) / 100;
        baseRate = Math.round(baseRate * discountFactor);
        baseCredits += appliedPromo.bonusCredits;
      }

      for (const item of enrollmentItems) {
        const subResult = await createSubscription(
          user.uid,
          useCustomCreditsNew ? "custom" : selectedPlan?.id || "standard",
          item.name,
          tutor.id,
          recurringTimes,
          schedulePattern,
          user.email || "",
          baseRate,
          baseCredits,
          'active',
          receiptScreenshotBase64 || "",
          transactionRef || "N/A",
          paymentSenderName || "N/A",
          paymentType || "N/A"
        );

        if (subResult.success && subResult.studentId) {
          enrolledSome = true;

          // If a friend referred them, register the referral record in Firestore
          if (appliedPromo && appliedPromo.type === "referral") {
            try {
              await addDoc(collection(db, "referrals"), {
                referrerUid: appliedPromo.referrerId,
                referrerName: appliedPromo.referrerName,
                referredUid: user.uid,
                referredParentName: user.displayName || user.fullName || "Parent",
                referredParentEmail: user.email,
                studentName: item.name,
                codeUsed: appliedPromo.code,
                status: "verified",
                discountPercent: appliedPromo.discountPercent,
                bonusCredits: appliedPromo.bonusCredits,
                commissionAmount: typeof settings?.referralCommissionRate === "number" ? settings.referralCommissionRate : 25,
                rewardClaimed: false,
                createdAt: serverTimestamp()
              });
              console.log("[Referral Tracker] Added referral log in Firestore!");
            } catch (refLogErr) {
              console.error("Failed to write referral log in Firestore:", refLogErr);
            }
          }

          // Schedule recurring sessions for each selected slot
          const schedulePromises = recurringTimes.map((time) =>
            scheduleRecurringSessions(
              { id: subResult.studentId, name: item.name },
              { id: tutor.id, name: tutor.displayName || tutor.email },
              new Date(time),
              user.uid,
            ),
          );
          await Promise.all(schedulePromises);

          // Update student record with their subjects & age details and mark status as pending verification
          try {
            const studentRef = doc(db, "students", subResult.studentId);
            await updateDoc(studentRef, {
              subjects: [item.subject],
              age: Number(item.age) || 0,
              status: "pending_verification"
            });
          } catch (stdErr) {
            console.error("Failed to append child subjects to student document:", stdErr);
          }

          // Send confirmation emails for this student
          try {
            await fetch("/api/subscription/confirm", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({
                parentEmail: user.email,
                parentName: user.displayName || user.fullName || "Parent",
                studentName: item.name,
                planName: useCustomCreditsNew ? "Custom Class Package" : (selectedPlan?.name || "Standard Plan"),
                tutorEmail: tutor.email || "",
                tutorName: tutor.displayName || tutor.name || "Assigned Tutor",
                price: baseRate,
                schedulePattern: schedulePattern.join(", "),
                paymentType: paymentType,
                paymentRef: transactionRef || "N/A",
                paymentSenderName: paymentSenderName || "N/A",
                bookingType: selectedTutorId === "auto-assign" ? "auto" : "parent_choose"
              }),
            });
          } catch (mailErr) {
            console.error("Failing silently to send verification subscription emails:", mailErr);
          }
        }
      }

      if (enrolledSome) {
        setShowEnroller(false);
        // Do NOT convert - instead set status to registration_completed and append all payment metadata
        try {
          const leadRef = doc(db, "leads", lead.id);
          await updateDoc(leadRef, {
            status: "registration_completed",
            chosenPlan: useCustomCreditsNew ? "Custom Class Package" : (selectedPlan?.name || "Standard Plan"),
            chosenTutor: tutor.displayName || tutor.name || "Selamawit Kebede",
            chosenSchedule: schedulePattern.join(", "),
            paymentType: paymentType,
            paymentRef: transactionRef || "N/A",
            paymentSenderName: paymentSenderName || "N/A",
            paymentScreenshotName: receiptScreenshotName || "receipt.png",
            paymentScreenshotBase64: receiptScreenshotBase64 || "",
            paymentDate: new Date().toISOString()
          });
        } catch (leadUpdErr) {
          console.error("Failed to update lead with registration fields:", leadUpdErr);
          // Fallback state update in case local preview uses simulated list
          lead.status = "registration_completed";
          lead.chosenPlan = useCustomCreditsNew ? "Custom Class Package" : (selectedPlan?.name || "Standard Plan");
          lead.chosenTutor = tutor.displayName || tutor.name || "Selamawit Kebede";
          lead.chosenSchedule = schedulePattern.join(", ");
          lead.paymentType = paymentType;
          lead.paymentRef = transactionRef || "N/A";
          lead.paymentSenderName = paymentSenderName || "N/A";
          lead.paymentScreenshotName = receiptScreenshotName || "receipt.png";
          lead.paymentScreenshotBase64 = receiptScreenshotBase64 || "";
          lead.paymentDate = new Date().toISOString();
        }
      }
    } catch (err) {
      console.error("Enrollment error:", err);
    }
    setIsSubscribing(false);
  };

  const handleRenewal = async (expiredStudent: any) => {
    if (
      !user ||
      (!selectedRenewalPlan && !useCustomCreditsRenew) ||
      !expiredStudent
    )
      return;
    setIsRenewing(true);
    try {
      const activeTutorId = expiredStudent.tutorId || "";
      const result = await renewSubscription(
        expiredStudent.id,
        user.uid,
        user.email || "",
        useCustomCreditsRenew ? "custom" : selectedRenewalPlan.id,
        getCreditPriceRenew(),
        activeTutorId,
        expiredStudent.schedulePattern || expiredStudent.schedule || [],
        useCustomCreditsRenew
          ? customRenewCreditQuantity
          : selectedRenewalPlan?.sessions || 4,
        receiptScreenshotBase64 || "",
        transactionRef || "N/A",
        paymentSenderName || "N/A",
        paymentType || "N/A"
      );

      if (result.success) {
        const tutor = tutors.find((t) => t.id === activeTutorId);
        // Send dual notification/email
        await fetch("/api/subscription/confirm", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            parentEmail: user.email,
            parentName: user.displayName || user.fullName || "Parent",
            studentName: expiredStudent.name,
            planName: useCustomCreditsRenew
              ? `Renewal - Custom (${customRenewCreditQuantity} Credits)`
              : `Renewal - ${selectedRenewalPlan.name}`,
            tutorEmail: tutor?.email || "",
            tutorName: tutor?.displayName || tutor?.name || "Assigned Tutor",
            price: getCreditPriceRenew(),
            schedulePattern: (expiredStudent.schedulePattern || expiredStudent.schedule || []).join(", "),
            bookingType: "parent_choose"
          }),
        });
      } else {
        alert(
          "Renewal checkout encountered a transient issue. Please try again.",
        );
      }
    } catch (err) {
      console.error(err);
    }
    setIsRenewing(false);
  };

  // --- Admin Support Ticketing Handlers ---
  const handleCreateSupportTicket = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !newTicketQuestion.trim()) return;

    setSubmittingTicket(true);
    const result = await submitSupportTicket({
      parentName: user.fullName || user.displayName || "Parent",
      parentEmail: user.email || "",
      question: newTicketQuestion.trim(),
      topic: newTicketTopic
    });

    setSubmittingTicket(false);

    if (result.success && result.id) {
      setNewTicketQuestion("");
      setSelectedTicketId(result.id);
    } else {
      alert("Something went wrong creating support ticket. Please try again.");
    }
  };

  const handleSendSupportReply = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !selectedTicketId || !ticketReplyText.trim()) return;

    setSendingTicketReply(true);
    const result = await addSupportTicketReply(selectedTicketId, {
      senderRole: 'parent',
      senderName: user.fullName || user.displayName || 'Parent',
      text: ticketReplyText.trim()
    });

    setSendingTicketReply(false);

    if (result.success) {
      setTicketReplyText("");
    } else {
      alert("Something went wrong sending reply. Please try again.");
    }
  };

  // --- Tutor Chat Handlers ---
  const handleOpenTutorChat = async (tutor: any) => {
    if (!user || !tutor) return;
    
    // Create/fetch thread
    const res = await getOrCreateTutorChat({
      parentId: user.uid,
      parentName: user.fullName || user.displayName || "Parent",
      parentEmail: user.email || "",
      tutorId: tutor.id,
      tutorName: tutor.displayName || tutor.name || "Tutor",
      tutorEmail: tutor.email || ""
    });

    if (res.success && res.id) {
      setActiveTutorChatTutor(tutor);
      setActiveTutorChatId(res.id);
      setTutorChatViolationWarning(null);
      setActiveSupportChannelTab("tutor");
      navigate("/parent/support");
    } else {
      alert("Failed to initialize conversation thread with tutor. Please make sure tutor details are complete.");
    }
  };

  const handleSendTutorMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !activeTutorChatId || !activeTutorChatTutor || !tutorChatMessageInput.trim()) return;

    setSendingTutorChatMessageState(true);
    setTutorChatViolationWarning(null);

    const textToSend = tutorChatMessageInput.trim();
    setTutorChatMessageInput("");

    const res = await sendTutorChatMessage({
      chatId: activeTutorChatId,
      parentId: user.uid,
      tutorId: activeTutorChatTutor.id,
      senderId: user.uid,
      senderName: user.fullName || user.displayName || "Parent",
      senderRole: 'parent',
      text: textToSend
    });

    setSendingTutorChatMessageState(false);

    if (res.success) {
      if (res.hasViolation) {
        setTutorChatViolationWarning("Notice: Your message contained contact sharing info, such as a phone number or email, which was redacted for security.");
        setTimeout(() => setTutorChatViolationWarning(null), 6000);
      }
    } else {
      alert("Failed to send message. Please try again.");
    }
  };

  const handleSendAdminMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !activeProfile?.id || !adminChatInput.trim()) return;

    setSendingAdminMessage(true);
    const textToSend = adminChatInput.trim();
    setAdminChatInput('');

    const res = await sendMessage({
      senderId: activeProfile.id,
      senderName: user.fullName || user.displayName || "Parent",
      senderRole: "parent",
      recipientId: "admin",
      text: textToSend
    });

    setSendingAdminMessage(false);
    if (!res.success) {
      alert("Failed to send message. Please try again.");
    }
  };

  if (loading) {
    console.log("ParentDashboard: Loading state active");
    return (
      <div className="h-[60vh] flex flex-col items-center justify-center text-slate-400 gap-3">
        <Loader2 className="animate-spin text-secondary" size={32} />
        <p className="text-sm font-medium">Syncing family portal...</p>
      </div>
    );
  }

  const expiredStudent = parentData?.students?.find(
    (s: any) => s.status === "expired",
  );
  const hasExpiredStudent = !!expiredStudent;

  if (hasExpiredStudent && activeTab === "dashboard") {
    if (!selectedRenewalPlan) {
      setSelectedRenewalPlan(plans[1]); // default to Heritage Pro
    }

    return (
      <div className="max-w-4xl mx-auto space-y-8 animate-in fade-in duration-300">
        <div className="bg-red-50 border border-red-100 p-8 rounded-3xl flex flex-col md:flex-row items-center justify-between gap-6 shadow-sm">
          <div className="flex gap-4 items-center">
            <div className="w-16 h-16 bg-red-600 text-white rounded-2xl flex items-center justify-center shadow-lg shadow-red-200 shrink-0">
              <X size={32} />
            </div>
            <div className="text-left">
              <h3 className="text-xl font-extrabold text-slate-950 font-sans tracking-tight leading-none mb-1.5">
                {expiredStudent?.expireReason === "credits_exhausted"
                  ? "Class Credits Exhausted"
                  : "Family Account Suspended"}
              </h3>
              <p className="text-slate-500 text-xs font-sans">
                {expiredStudent?.expireReason === "credits_exhausted" ? (
                  <span>
                    You have used all available class credits for{" "}
                    <strong className="text-slate-700 font-bold">
                      {expiredStudent?.name}
                    </strong>
                    . Access belongs locked. Please buy a new credit bundle
                    below to resume learning.
                  </span>
                ) : (
                  <span>
                    Your billing cycle has ended for{" "}
                    <strong className="text-slate-705 font-bold">
                      {expiredStudent?.name}
                    </strong>
                    . Access is frozen in compliance with classroom seat ledger
                    records.
                  </span>
                )}
              </p>
            </div>
          </div>
          <div className="text-[10px] font-extrabold text-red-600 uppercase tracking-widest bg-white px-4 py-2 rounded-xl border border-red-100">
            Payment Required
          </div>
        </div>

        <div className="bg-white rounded-[32px] border border-slate-150 shadow-sm p-8 md:p-12 space-y-8">
          <div className="max-w-2xl text-left">
            <h2 className="text-2xl font-bold text-slate-900 mb-2 font-sans tracking-tight">
              Purchase Class Session Credits
            </h2>
            <p className="text-slate-500 text-sm">
              Please select a credit package or customize your purchase below to
              authorize renewal, restore access to tutor calendar, and resume
              standard sessions seamlessly.
            </p>
          </div>

          <div className="flex gap-4 p-1.5 bg-slate-100 rounded-2xl w-fit">
            <button
              type="button"
              onClick={() => {
                setUseCustomCreditsRenew(false);
                setSelectedRenewalPlan(plans[1]); // Default to Pro
              }}
              className={cn(
                "px-5 py-2.5 rounded-xl text-xs font-bold uppercase tracking-wider transition-all cursor-pointer",
                !useCustomCreditsRenew
                  ? "bg-white text-slate-900 shadow-sm"
                  : "text-slate-500 hover:text-slate-900",
              )}
            >
              Subscription Tiers
            </button>
            <button
              type="button"
              onClick={() => {
                setUseCustomCreditsRenew(true);
                setSelectedRenewalPlan(null);
              }}
              className={cn(
                "px-5 py-2.5 rounded-xl text-xs font-bold uppercase tracking-wider transition-all cursor-pointer",
                useCustomCreditsRenew
                  ? "bg-white text-slate-900 shadow-sm"
                  : "text-slate-500 hover:text-slate-900",
              )}
            >
              Custom Credit Package
            </button>
          </div>

          {!useCustomCreditsRenew ? (
            <div className="grid md:grid-cols-2 gap-4 max-w-2xl mx-auto animate-in fade-in duration-200">
              {plans.map((p) => (
                <button
                  key={p.id}
                  type="button"
                  onClick={() => setSelectedRenewalPlan(p)}
                  className={cn(
                    "p-6 rounded-2xl border-2 text-left transition-all relative overflow-hidden cursor-pointer",
                    selectedRenewalPlan?.id === p.id
                      ? "bg-slate-900 border-slate-900 text-white shadow-xl scale-[1.01]"
                      : "bg-white text-slate-900 border-slate-150 hover:border-slate-300",
                  )}
                >
                  <h4
                    className={cn(
                      "font-bold truncate",
                      selectedRenewalPlan?.id === p.id
                        ? "text-white"
                        : "text-slate-905",
                    )}
                  >
                    {p.name}
                  </h4>
                  <p
                    className={cn(
                      "text-[10px] mt-1 font-medium",
                      selectedRenewalPlan?.id === p.id
                        ? "text-slate-300"
                        : "text-slate-400",
                    )}
                  >
                    {p.description}
                  </p>
                  <div className="mt-6 flex items-baseline gap-1">
                    <span className="text-2.5xl font-extrabold font-mono">
                      ${p.price}
                    </span>
                    <span className="text-[10px] font-medium opacity-60">
                      / 4-week cycle
                    </span>
                  </div>
                  {selectedRenewalPlan?.id === p.id && (
                    <div className="absolute top-3 right-3 text-white/20">
                      <CheckCircle2 size={16} />
                    </div>
                  )}
                </button>
              ))}
            </div>
          ) : (
            <div className="bg-slate-50 p-6 md:p-8 rounded-3xl border border-slate-150 space-y-6 animate-in fade-in duration-200 text-left">
              <div>
                <h4 className="font-extrabold text-sm text-slate-900">
                  Configure Custom Credit Package
                </h4>
                <p className="text-xs text-slate-400 mt-1">
                  Purchase multi-month blocks or custom class counts at a
                  flexible rate of $40 per session.
                </p>
              </div>

              <div className="flex flex-col sm:flex-row sm:items-center gap-6">
                <div className="flex items-center gap-3">
                  <button
                    type="button"
                    onClick={() =>
                      setCustomRenewCreditQuantity((q) => Math.max(4, q - 1))
                    }
                    className="w-12 h-12 bg-white rounded-xl border border-slate-200 flex items-center justify-center font-bold text-lg text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer"
                  >
                    -
                  </button>
                  <input
                    type="number"
                    min={4}
                    max={48}
                    value={customRenewCreditQuantity}
                    onChange={(e) => {
                      const val = parseInt(e.target.value) || 4;
                      setCustomRenewCreditQuantity(
                        Math.min(48, Math.max(4, val)),
                      );
                    }}
                    className="w-20 h-12 text-center bg-white border border-slate-200 rounded-xl font-bold text-base focus:outline-none focus:border-slate-400 font-mono"
                  />
                  <button
                    type="button"
                    onClick={() =>
                      setCustomRenewCreditQuantity((q) => Math.min(48, q + 1))
                    }
                    className="w-12 h-12 bg-white rounded-xl border border-slate-200 flex items-center justify-center font-bold text-lg text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer"
                  >
                    +
                  </button>
                </div>

                <div className="flex-1 bg-white px-6 py-4 rounded-2xl border border-slate-100 flex items-center justify-between">
                  <div>
                    <span className="text-[9px] font-bold text-slate-400 uppercase tracking-widest block">
                      Total Cost
                    </span>
                    <span className="text-xl font-black text-slate-900 font-mono">
                      ${customRenewCreditQuantity * 40}.00
                    </span>
                  </div>
                  <div>
                    <span className="text-[9px] font-bold text-slate-400 uppercase tracking-widest block text-right">
                      Included Classes
                    </span>
                    <span className="text-xs font-bold text-indigo-600 block text-right">
                      {customRenewCreditQuantity} Tutoring Sessions
                    </span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Checkout Card Form Fields with CBE, Telebirr, and Zelle/International Options */}
          <div className="bg-slate-50 rounded-[28px] p-6 md:p-8 border border-slate-150 space-y-6">
            <h3 className="font-bold text-slate-900 text-sm flex items-center gap-2">
              <CreditCard size={16} className="text-indigo-600" />
              <span>Checkout Payment & Receipt Submission</span>
            </h3>

            {/* Payment Options Selection Block */}
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <label className="text-[10px] font-extrabold text-slate-400 uppercase tracking-widest block">
                  Select Payment Method
                </label>
                {/* Visual indicator of the region detection with override capability */}
                <div className="flex items-center gap-1.5 text-[10px] font-bold text-slate-500 bg-slate-100/85 px-2.5 py-1 rounded-full border border-slate-200/50 shadow-2xs select-none">
                  <span>🌍 {isUSUser ? "US Region Active" : "Ethiopia Region Active"}</span>
                  <button
                    type="button"
                    onClick={() => {
                      const newOverride = !isUSUser;
                      setIsUSUser(newOverride);
                      localStorage.setItem("habkids_is_us_user_override", String(newOverride));
                      if (newOverride) {
                        setPaymentType("international");
                      } else {
                        setPaymentType("telebirr");
                      }
                    }}
                    className="text-indigo-600 hover:text-indigo-800 transition-colors cursor-pointer underline ml-1 font-sans"
                  >
                    (Simulate {isUSUser ? "ET" : "US"})
                  </button>
                </div>
              </div>

              {isUSUser ? (
                <div className="space-y-4">
                  {/* Primary option is strictly Zelle (USA Abroad) */}
                  <div className="grid grid-cols-1 gap-3">
                    <button
                      type="button"
                      onClick={() => setPaymentType("international")}
                      className={cn(
                        "p-5 rounded-2xl border-2 text-left transition-all flex flex-col justify-between gap-3 cursor-pointer bg-white relative overflow-hidden",
                        paymentType === "international"
                          ? "border-indigo-600 bg-indigo-50/10 shadow-md ring-1 ring-indigo-500/20"
                          : "border-slate-200 hover:border-slate-300",
                      )}
                    >
                      <div className="flex items-center gap-2.5">
                        <span
                          className={cn(
                            "w-4 h-4 rounded-full border flex items-center justify-center shrink-0",
                            paymentType === "international"
                              ? "border-indigo-600 text-indigo-600"
                              : "border-slate-300",
                          )}
                        >
                          {paymentType === "international" && (
                            <span className="w-2 h-2 bg-indigo-600 rounded-full"></span>
                          )}
                        </span>
                        <div>
                          <span className="text-xs font-black text-slate-905 flex items-center gap-1.5">
                            🇺🇸 Zelle (USA Abroad) <span className="text-[9px] font-extrabold text-indigo-600 bg-indigo-50 px-2.5 py-0.5 rounded-full uppercase tracking-wider">Primary</span>
                          </span>
                          <span className="text-[10px] text-slate-400 font-semibold block mt-0.5">
                            Recommended payment gateway for clients residing in the United States and North America.
                          </span>
                        </div>
                      </div>
                      <span className="text-[9px] text-indigo-600 font-extrabold font-mono uppercase tracking-widest bg-indigo-50/50 px-2 py-1 rounded-md w-fit mt-1">
                        Direct USD Gateway ($)
                      </span>
                    </button>
                  </div>

                  {/* Collapsible Local ETB Options pushed below */}
                  <div className="border border-slate-200/60 rounded-2xl overflow-hidden bg-white/50">
                    <button
                      type="button"
                      onClick={() => setShowLocalETB(!showLocalETB)}
                      className="w-full px-4 py-3 text-left flex items-center justify-between text-xs font-bold text-slate-500 hover:text-slate-700 transition-colors bg-white border-b border-slate-100 cursor-pointer"
                    >
                      <span>{showLocalETB ? "▼ Hide local ETB gateways" : "▶ Show local ETB gateways (Telebirr / CBE)"}</span>
                      <span className="text-[9px] bg-slate-100 text-slate-400 px-1.5 py-0.5 rounded-full uppercase">Pushed Down</span>
                    </button>
                    {showLocalETB && (
                      <div className="p-3 grid grid-cols-1 md:grid-cols-2 gap-3 animate-in fade-in slide-in-from-top-1 duration-200">
                        <button
                          type="button"
                          onClick={() => setPaymentType("telebirr")}
                          className={cn(
                            "p-4 rounded-xl border text-left transition-all flex flex-col justify-between gap-2 cursor-pointer bg-white",
                            paymentType === "telebirr"
                              ? "border-indigo-600 bg-indigo-50/20 shadow-xs"
                              : "border-slate-200 hover:border-slate-300",
                          )}
                        >
                          <div className="flex items-center gap-2">
                            <span
                              className={cn(
                                "w-3.5 h-3.5 rounded-full border flex items-center justify-center shrink-0",
                                paymentType === "telebirr"
                                  ? "border-indigo-600 text-indigo-600"
                                  : "border-slate-300",
                              )}
                            >
                              {paymentType === "telebirr" && (
                                <span className="w-1.5 h-1.5 bg-indigo-600 rounded-full"></span>
                              )}
                            </span>
                            <span className="text-xs font-bold text-slate-800">
                              Telebirr (Ethiopia)
                            </span>
                          </div>
                          <span className="text-[9px] text-slate-400 font-bold font-mono uppercase tracking-wider">
                            Mobile Transfer
                          </span>
                        </button>

                        <button
                          type="button"
                          onClick={() => setPaymentType("cbe")}
                          className={cn(
                            "p-4 rounded-xl border text-left transition-all flex flex-col justify-between gap-2 cursor-pointer bg-white",
                            paymentType === "cbe"
                              ? "border-indigo-600 bg-indigo-50/20 shadow-xs"
                              : "border-slate-200 hover:border-slate-300",
                          )}
                        >
                          <div className="flex items-center gap-2">
                            <span
                              className={cn(
                                "w-3.5 h-3.5 rounded-full border flex items-center justify-center shrink-0",
                                paymentType === "cbe"
                                  ? "border-indigo-600 text-indigo-600"
                                  : "border-slate-300",
                              )}
                            >
                              {paymentType === "cbe" && (
                                <span className="w-1.5 h-1.5 bg-indigo-600 rounded-full"></span>
                              )}
                            </span>
                            <span className="text-xs font-bold text-slate-800">
                              CBE Birr / Transfer
                            </span>
                          </div>
                          <span className="text-[9px] text-slate-400 font-bold font-mono uppercase tracking-wider">
                            Bank Gateway
                          </span>
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  <button
                    type="button"
                    onClick={() => setPaymentType("telebirr")}
                    className={cn(
                      "p-4 rounded-2xl border text-left transition-all flex flex-col justify-between gap-2.5 cursor-pointer",
                      paymentType === "telebirr"
                        ? "border-indigo-600 bg-indigo-50/20 shadow-sm"
                        : "border-slate-200 bg-white hover:border-slate-300",
                    )}
                  >
                    <div className="flex items-center gap-2">
                      <span
                        className={cn(
                          "w-3.5 h-3.5 rounded-full border flex items-center justify-center shrink-0",
                          paymentType === "telebirr"
                            ? "border-indigo-600 text-indigo-600"
                            : "border-slate-300",
                        )}
                      >
                        {paymentType === "telebirr" && (
                          <span className="w-1.5 h-1.5 bg-indigo-600 rounded-full"></span>
                        )}
                      </span>
                      <span className="text-xs font-bold text-slate-800">
                        Telebirr (Local Ethiopia)
                      </span>
                    </div>
                    <span className="text-[9px] text-slate-400 font-bold font-mono uppercase tracking-wider">
                      Mobile Transfer
                    </span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setPaymentType("cbe")}
                    className={cn(
                      "p-4 rounded-2xl border text-left transition-all flex flex-col justify-between gap-2.5 cursor-pointer",
                      paymentType === "cbe"
                        ? "border-indigo-600 bg-indigo-50/20 shadow-sm"
                        : "border-slate-200 bg-white hover:border-slate-300",
                    )}
                  >
                    <div className="flex items-center gap-2">
                      <span
                        className={cn(
                          "w-3.5 h-3.5 rounded-full border flex items-center justify-center shrink-0",
                          paymentType === "cbe"
                            ? "border-indigo-600 text-indigo-600"
                            : "border-slate-300",
                        )}
                      >
                        {paymentType === "cbe" && (
                          <span className="w-1.5 h-1.5 bg-indigo-600 rounded-full"></span>
                        )}
                      </span>
                      <span className="text-xs font-bold text-slate-800">
                        CBE Birr / Transfer
                      </span>
                    </div>
                    <span className="text-[9px] text-slate-400 font-bold font-mono uppercase tracking-wider">
                      Bank Gateway
                    </span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setPaymentType("international")}
                    className={cn(
                      "p-4 rounded-2xl border text-left transition-all flex flex-col justify-between gap-2.5 cursor-pointer",
                      paymentType === "international"
                        ? "border-indigo-600 bg-indigo-50/20 shadow-sm"
                        : "border-slate-200 bg-white hover:border-slate-300",
                    )}
                  >
                    <div className="flex items-center gap-2">
                      <span
                        className={cn(
                          "w-3.5 h-3.5 rounded-full border flex items-center justify-center shrink-0",
                          paymentType === "international"
                            ? "border-indigo-600 text-indigo-600"
                            : "border-slate-300",
                        )}
                      >
                        {paymentType === "international" && (
                          <span className="w-1.5 h-1.5 bg-indigo-600 rounded-full"></span>
                        )}
                      </span>
                      <span className="text-xs font-bold text-slate-800">
                        International / Abroad
                      </span>
                    </div>
                    <span className="text-[9px] text-slate-400 font-bold font-mono uppercase tracking-wider">
                      Zelle, Remitly, WorldRemit
                    </span>
                  </button>
                </div>
              )}
            </div>

            {/* Instruction Panels */}
            {(() => {
              const usdAmount = useCustomCreditsRenew 
                ? customRenewCreditQuantity * 40 
                : (selectedRenewalPlan?.price || 240);
              const birrRate = (settings?.proPriceBirr && settings?.proPrice) 
                ? (settings.proPriceBirr / settings.proPrice) 
                : 115;
              const birrAmount = useCustomCreditsRenew 
                ? Math.round(customRenewCreditQuantity * 40 * birrRate) 
                : (selectedRenewalPlan?.id?.toLowerCase().includes('pro') 
                    ? (settings?.proPriceBirr || 3500) 
                    : (selectedRenewalPlan?.id?.toLowerCase().includes('mastery') 
                        ? (settings?.masteryPriceBirr || 5200) 
                        : (settings?.standardPriceBirr || 2300)));

              if (paymentType === "telebirr") {
                return (
                  <div className="p-4 bg-white border border-slate-100 rounded-2xl space-y-2 text-xs text-slate-600 animate-in fade-in duration-200 shadow-sm">
                    <span className="text-[10px] uppercase font-bold text-indigo-600 tracking-wider block">
                      Telebirr Account Instructions:
                    </span>
                    <p className="leading-relaxed">
                      Please issue the tuition total of{" "}
                      {isUSUser ? (
                        <strong className="font-extrabold text-slate-900 font-mono bg-slate-50 px-1.5 py-0.5 rounded">
                          ${usdAmount} USD
                        </strong>
                      ) : (
                        <>
                          <strong className="font-extrabold text-slate-900 font-mono bg-slate-50 px-1.5 py-0.5 rounded">
                            {birrAmount} Birr
                          </strong>{" "}
                          (or ${usdAmount} USD)
                        </>
                      )}{" "}
                      directly to our verified merchant code{" "}
                      <strong className="font-extrabold text-slate-900 font-mono bg-slate-50 px-2 py-0.5 rounded">
                        {settings?.subTelebirrMerchantCode || "882910"}
                      </strong>{" "}
                      or transfer to Telebirr mobile deposit account{" "}
                      <strong className="font-extrabold text-slate-900 font-mono bg-slate-50 px-2 py-0.5 rounded">
                        {settings?.subTelebirrNumber || "+251 912 345 678"}
                      </strong>{" "}
                      (under name: <strong>{settings?.subTelebirrName || "HabKids tutor"}</strong>).
                    </p>
                  </div>
                );
              }

              if (paymentType === "cbe") {
                return (
                  <div className="p-4 bg-white border border-slate-100 rounded-2xl space-y-2 text-xs text-slate-600 animate-in fade-in duration-200 shadow-sm">
                    <span className="text-[10px] uppercase font-bold text-indigo-600 tracking-wider block">
                      CBE Bank Transfer Instructions:
                    </span>
                    <p className="leading-relaxed">
                      Kindly send your payment of{" "}
                      {isUSUser ? (
                        <strong className="font-extrabold text-slate-900 font-mono bg-slate-50 px-1.5 py-0.5 rounded">
                          ${usdAmount} USD
                        </strong>
                      ) : (
                        <>
                          <strong className="font-extrabold text-slate-900 font-mono bg-slate-50 px-1.5 py-0.5 rounded">
                            {birrAmount} Birr
                          </strong>{" "}
                          (or ${usdAmount} USD)
                        </>
                      )}{" "}
                      to our Commercial Bank of Ethiopia (CBE) corporate savings account under name{" "}
                      <strong>{settings?.subCbeAccountName || "HabKids Language School"}</strong>:<br />
                      <strong className="font-extrabold text-slate-900 font-mono text-sm bg-slate-50 px-2.5 py-1 rounded block mt-1.5 w-fit">
                        Acc: {settings?.subCbeAccountNumber || "1000492811726"}
                      </strong>
                    </p>
                  </div>
                );
              }

              if (paymentType === "international") {
                return (
                  <div className="p-5 bg-white border border-slate-100 rounded-2xl space-y-3.5 text-xs text-slate-650 animate-in fade-in duration-200 leading-relaxed shadow-sm">
                    <span className="text-[10px] uppercase font-bold text-indigo-600 tracking-wider block">
                      🇺🇸 Zelle (USA Abroad) Instructions:
                    </span>
                    <div className="space-y-3">
                      <div className="p-3 bg-slate-50/50 rounded-xl space-y-1 border border-slate-100/50">
                        <p className="text-slate-900 font-bold flex items-center gap-1.5">
                          <span>🇺🇸</span>
                          <span>US Parents (Zelle Transfer):</span>
                        </p>
                        <p className="text-slate-500 pl-5">
                          Send your monthly tuition of <strong className="text-slate-900">${usdAmount} USD</strong> directly via Zelle to our phone/email hotline endpoint:
                          <strong className="block font-bold text-slate-800 font-mono mt-0.5">
                            {settings?.subZelleEmail || "payment@heritageacademy.com"}
                          </strong>
                          {settings?.subZelleName && (
                            <span className="text-[10px] text-slate-400 block mt-0.5">
                              Registered under: <strong>{settings.subZelleName}</strong>
                            </span>
                          )}
                        </p>
                      </div>
                      <div className="p-3 bg-slate-50/50 rounded-xl space-y-1 border border-slate-100/50">
                        <p className="text-slate-900 font-bold flex items-center gap-1.5">
                          <span>🌍</span>
                          <span>Canada, UK, Europe, & Australia Parents:</span>
                        </p>
                        <p className="text-slate-500 pl-5">
                          Utilize prominent digital cross-border platforms like{" "}
                          <strong className="text-slate-800">Remitly</strong>,{" "}
                          <strong className="text-slate-850">WorldRemit</strong>, or{" "}
                          <strong className="text-slate-855">Sendwave</strong> to transmit funds directly as a Zelle payment to{" "}
                          <strong className="font-bold text-slate-800 font-mono">
                            {settings?.subZelleEmail || "payment@heritageacademy.com"}
                          </strong>{" "}
                          or as an instant mobile wallet deposit of{" "}
                          {isUSUser ? (
                            <strong className="text-slate-850 font-bold">${usdAmount} USD</strong>
                          ) : (
                            <strong className="text-slate-850 font-bold">{birrAmount} Birr</strong>
                          )}{" "}
                          to our corporate Telebirr number{" "}
                          <strong className="font-bold text-slate-800 font-mono">
                            {settings?.subTelebirrNumber || "+251 912 345 678"}
                          </strong>{" "}
                          (under company: <strong>{settings?.subTelebirrName || "HabKids tutor"}</strong>).
                        </p>
                      </div>
                    </div>
                  </div>
                );
              }

              return null;
            })()}

            {/* Secure Verification Layer */}
            <div className="border-t border-slate-150 pt-5 space-y-4">
              <span className="text-[10px] font-extrabold text-slate-400 uppercase tracking-widest block">
                Secure Payment Verification Receipt
              </span>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-[9px] font-extrabold text-slate-500 uppercase tracking-wider block">
                    Transaction Reference ID{" "}
                    <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. CBE-TXN928102 / Zelle Conf: 8172"
                    value={transactionRef}
                    onChange={(e) => setTransactionRef(e.target.value)}
                    className="w-full bg-white border border-slate-200 rounded-xl px-4 py-2.5 text-xs text-slate-700 font-mono outline-none focus:ring-2 focus:ring-indigo-100 focus:border-indigo-500 transition-all font-bold shadow-sm"
                  />
                  <p className="text-[8px] text-slate-400">
                    Provide the precise transaction payload identifier shown in
                    your banking snapshot.
                  </p>
                </div>

                <div className="space-y-1.5">
                  <label className="text-[9px] font-extrabold text-slate-500 uppercase tracking-wider block">
                    Upload Screenshot Receipt{" "}
                    <span className="text-red-500">*</span>
                  </label>
                  <div className="relative border border-dashed border-slate-200 bg-white rounded-xl hover:bg-slate-50/50 transition-colors cursor-pointer flex items-center justify-between p-2.5 shadow-sm">
                    <input
                      type="file"
                      id="renewal-receipt-upload"
                      accept="image/*,application/pdf"
                      onChange={async (e) => {
                        const file = e.target.files?.[0];
                        if (file) {
                          setReceiptScreenshotName(file.name);
                          try {
                            const base64 = await compressImageToBase64(file, 800 * 1024);
                            setReceiptScreenshotBase64(base64);
                          } catch (err: any) {
                            alert(err.message || "Failed to compress/read receipt screenshot.");
                          }
                        }
                      }}
                      className="absolute inset-0 opacity-0 cursor-pointer h-full w-full"
                    />
                    <div className="flex items-center gap-2 max-w-[210px] truncate">
                      <span className="text-sm">📎</span>
                      <span className="text-[11px] font-bold text-slate-600 truncate">
                        {receiptScreenshotName ||
                          "Attach receipt screenshot..."}
                      </span>
                    </div>
                    <span className="text-[9px] font-extrabold uppercase bg-slate-50 hover:bg-slate-100 px-3 py-1.5 rounded-lg border border-slate-200 text-slate-600 tracking-wider">
                      Browse File
                    </span>
                  </div>
                  <p className="text-[8px] text-slate-400">
                    Accept JPEG, PNG screenshot pictures or PDF documentation.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Submit Checkout Renewal */}
          <div className="flex justify-end items-center gap-6 pt-6 border-t border-slate-100">
            <button
              onClick={() => {
                if (!transactionRef || !receiptScreenshotName) {
                  alert(
                    "Please supply a valid Transaction Reference ID and upload a valid Screenshot Receipt before completing renewal.",
                  );
                  return;
                }
                handleRenewal(expiredStudent);
              }}
              disabled={isRenewing || !transactionRef || !receiptScreenshotName}
              className="btn-primary flex items-center justify-center gap-2 px-12 py-4 shadow-xl shadow-slate-950/10 hover:scale-[1.01] transition-all cursor-pointer font-bold text-xs uppercase tracking-widest bg-slate-900 text-white disabled:opacity-40"
            >
              {isRenewing ? (
                <>
                  <Loader2 className="animate-spin" size={16} />
                  <span>Processing Renewal...</span>
                </>
              ) : (
                <>
                  <Check size={16} />
                  <span>Renew & Restore Access</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    );
  }

  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingSettings(true);
    setSaveStatus("idle");
    try {
      if (user) {
        const userRef = doc(db, "users", user.uid);
        await updateDoc(userRef, {
          fullName: profileName,
          whatsapp: profileWhatsApp,
          displayName: profileName,
        });
      }
      if (activeStudent?.id) {
        const studentRef = doc(db, "students", activeStudent.id);
        await updateDoc(studentRef, {
          name: childNameVal,
        });
      }
      setSaveStatus("success");
      setTimeout(() => setSaveStatus("idle"), 3000);
    } catch (err) {
      console.error("Error saving settings:", err);
      setSaveStatus("error");
    }
    setSavingSettings(false);
  };

  const handleSyncEmail = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!auth.currentUser) {
      setEmailErrorMessage("No authenticated user found.");
      setEmailUpdateStatus("error");
      return;
    }
    const cleanEmail = profileEmail.trim().toLowerCase();
    if (!cleanEmail || !cleanEmail.includes("@")) {
      setEmailErrorMessage("Please enter a valid email address.");
      setEmailUpdateStatus("error");
      return;
    }

    setUpdatingEmailState(true);
    setEmailUpdateStatus("idle");
    setEmailErrorMessage("");

    try {
      // 1. Update Email in Firebase Auth
      await updateEmail(auth.currentUser, cleanEmail);

      // 2. Update Email in Firestore user document
      const userRef = doc(db, "users", auth.currentUser.uid);
      await updateDoc(userRef, {
        email: cleanEmail
      });

      setEmailUpdateStatus("success");
      setIsEditingEmail(false); // Make it read-only again after successful update
      setTimeout(() => setEmailUpdateStatus("idle"), 5000);
    } catch (err: any) {
      console.error("Error updating email:", err);
      if (err?.code === "auth/requires-recent-login" || String(err).includes("requires-recent-login")) {
        setEmailUpdateStatus("requires-login");
        setEmailErrorMessage("Security requires recent login. Please log out and log back in, then try again.");
      } else {
        setEmailUpdateStatus("error");
        setEmailErrorMessage(err?.message || "Could not update email. Please try again.");
      }
    } finally {
      setUpdatingEmailState(false);
    }
  };

  const handleTestCompleteTrial = async (lead: any) => {
    if (!lead || !lead.id) return;
    setCompletingTrialId(lead.id);
    try {
      // 1. Update lead status to trial_completed
      await updateLeadStatus(lead.id, "trial_completed");

      // 2. Prepare evaluation text and level
      const evaluationText = "Fantastic first trial session! The student was highly engaged, demonstrated excellent letter comprehension, and actively practiced pronunciation. We recommend the standard Amharic Heritage Foundation curriculum to continue building steady vocabulary and conversational fluency.";
      
      // 3. Look for existing trial sessions, or create a new one
      const existingSession = sessions.find(
        (s: any) => s.type === "trial" && (
          s.studentName === lead.childName || 
          s.parentEmail?.toLowerCase() === lead.email?.toLowerCase()
        )
      );

      const sessionData = {
        type: "trial",
        status: "completed",
        evaluation: evaluationText,
        recommendedLevel: "2",
        completedAt: new Date(),
        updatedAt: serverTimestamp(),
        parentEmail: lead.email || user?.email || "",
        parentName: lead.parentName || user?.displayName || "Parent",
        studentName: lead.childName || "Student",
        tutorId: lead.tutorId || "heritage-coach-1",
        tutorName: lead.tutorName || "Heritage Senior Tutor",
        scheduledAt: serverTimestamp()
      };

      if (existingSession?.id) {
        await updateDoc(doc(db, 'sessions', existingSession.id), {
          status: "completed",
          evaluation: evaluationText,
          recommendedLevel: "2",
          completedAt: serverTimestamp(),
          updatedAt: serverTimestamp()
        });
      } else {
        await addDoc(collection(db, 'sessions'), sessionData);
      }
      console.log("Successfully completed lead & created session evaluation");
    } catch (err) {
      console.error("Test trial completion error:", err);
    } finally {
      setCompletingTrialId(null);
    }
  };

  const primaryStudent =
    activeStudent ||
    (completedTrialLead || scheduledTrialLead
      ? {
          name: (completedTrialLead || scheduledTrialLead).childName,
          status: (completedTrialLead || scheduledTrialLead).status,
          learningGoal: (completedTrialLead || scheduledTrialLead).learningGoal,
          evaluation: trialSession?.evaluation,
          recommendedLevel: trialSession?.recommendedLevel,
        }
      : null);

  const isTrialPhase =
    !primaryStudent ||
    [
      "trial_pending",
      "trial_scheduled",
      "scheduled",
      "new_lead",
      "contacted",
    ].includes(primaryStudent.status || "");

  const isTrialCompleted =
    !!primaryStudent &&
    ["completed", "trial_completed", "registration_completed", "active", "converted"].includes(
      primaryStudent.status || "",
    );

  const isPremiumActive = !!activeStudent?.plan && !["trial_completed", "registration_completed"].includes(activeStudent.status || "");

  const currentAssignedTutor = (() => {
    const student = activeStudent;
    const tutorId = student?.tutorId;
    return tutors && tutorId ? tutors.find((t) => t.id === tutorId) : null;
  })();

  return (
    <div className="space-y-8 relative">
      {activeTab === "dashboard" && user?.isAmbassador && (
        <div className="space-y-8 animate-in fade-in duration-300">
          <header className="flex flex-col md:flex-row md:items-center justify-between gap-6">
            <div>
              <h1 className="text-3xl font-bold text-primary mb-1 tracking-tight">
                Ambassador & Promoter Portal
              </h1>
              <p className="text-slate-500 text-sm">
                Welcome back, {user?.fullName || "Representative"}. Your promoter channel is performing exceptionally strong.
              </p>
            </div>
            <div className="flex gap-3">
              <button 
                onClick={() => navigate("/parent/referrals")}
                className="btn-primary text-xs px-5 py-3 shadow-none bg-blue-600 hover:bg-blue-700 flex items-center gap-1.5 cursor-pointer font-sans text-white font-bold"
              >
                <TrendingUp size={14} />
                Referral Logs & Payouts
              </button>
            </div>
          </header>

          {/* Stats Overview */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-sm">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">Clicks Tracked</span>
              <h3 className="text-2xl font-bold text-slate-800">142</h3>
              <span className="text-[10px] text-green-600 font-medium font-sans">↑ 12% this week</span>
            </div>
            <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-sm">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">Invited Leads</span>
              <h3 className="text-2xl font-bold text-slate-800">{referralsList.length}</h3>
              <span className="text-[10px] text-slate-450 font-medium font-sans">Pending trials setup</span>
            </div>
            <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-sm">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">Converted Plans</span>
              <h3 className="text-2xl font-bold text-emerald-600">
                {referralsList.filter((r) => r.status === "verified").length}
              </h3>
              <span className="text-[10px] text-emerald-600 font-bold font-sans">
                {referralsList.length > 0 
                  ? Math.round((referralsList.filter((r) => r.status === "verified").length / referralsList.length) * 100) 
                  : 0}% conversion rate
              </span>
            </div>
            <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-sm">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">Commissions</span>
              <h3 className="text-2xl font-bold text-slate-900">
                ${referralsList.reduce((acc, r) => acc + (r.commissionAmount || (settings?.referralCommissionRate ?? 25)), 0)}.00
              </h3>
              <span className="text-[10px] text-blue-600 font-bold font-sans">Direct Payouts Active</span>
            </div>
          </div>

          {/* Quick Start & Link customizer */}
          <div className="bg-gradient-to-r from-slate-900 to-slate-850 p-8 md:p-10 rounded-3xl text-white relative overflow-hidden shadow-xl shadow-slate-950/15">
            <div className="relative z-10 max-w-2xl">
              <span className="text-xs text-secondary font-extrabold uppercase tracking-widest px-3 py-1 bg-white/10 rounded-full inline-block mb-4">Partner Asset Manager</span>
              <h2 className="text-3xl font-serif italic font-bold mb-4">Launch your custom campaign today</h2>
              <p className="text-white/70 text-sm leading-relaxed mb-6">
                Share your unique invitation link or coupon code with families abroad, online circles, or community boards. When a parent requests a trial session or registers a student, they instantly lock in a free first lesson, and you receive ${settings?.referralCommissionRate ?? 25}/referral conversion commission!
              </p>
              <div className="flex flex-col sm:flex-row gap-3">
                <button
                  onClick={() => navigate("/parent/referrals")}
                  className="bg-white hover:bg-slate-100 text-slate-900 px-6 py-3 rounded-xl text-xs font-bold uppercase tracking-wider transition-all cursor-pointer font-sans"
                >
                  Access Promo Link & Assets
                </button>
                <button
                  onClick={() => alert("Creative social asset pack loaded to clipboard. Use these guidelines and pre-written copy to share on WhatsApp or Facebook!")}
                  className="bg-white/10 hover:bg-white/20 text-white border border-white/25 px-6 py-3 rounded-xl text-xs font-bold uppercase tracking-wider transition-all cursor-pointer font-sans"
                >
                  Download Asset Pack
                </button>
              </div>
            </div>
            <div className="absolute top-0 right-0 bottom-0 opacity-10 pointer-events-none hidden md:block">
              <Globe className="w-96 h-96 -mr-20 -mb-20 text-white" />
            </div>
          </div>
        </div>
      )}

      {activeTab === "dashboard" && !user?.isAmbassador && allProfiles.length === 0 && (
        <div className="space-y-8 animate-in fade-in duration-300">
          <header className="flex flex-col md:flex-row md:items-center justify-between gap-6">
            <div>
              <h1 className="text-3xl font-bold text-primary mb-1 tracking-tight">
                Welcome to HabKids, {user?.fullName || "Parent"}! 👋
              </h1>
              <p className="text-slate-500 text-sm">
                Embark your child on a fun, interactive journey to learn Amharic & Ge'ez.
              </p>
            </div>
          </header>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
            {/* Left side: Book Trial Action Card */}
            <div className="lg:col-span-7 bg-white border border-slate-150 rounded-3xl p-8 shadow-sm flex flex-col justify-between">
              <div className="space-y-6">
                <span className="text-xs text-indigo-600 font-extrabold uppercase tracking-widest px-3 py-1 bg-indigo-50 border border-indigo-100 rounded-full inline-block">
                  Step 1: Your Trial Session
                </span>
                <h2 className="text-2xl font-serif italic font-bold text-slate-900">
                  Book Your Child's 1-on-1 Trial Evaluation Session
                </h2>
                <p className="text-slate-500 text-sm leading-relaxed">
                  Experience a live 25-minute Amharic tutoring session customized for your child's age (6-12). Our native tutors use interactive game-based slides, friendly conversational exercises, and fun quizzes.
                </p>
                <div className="space-y-3 pt-2">
                  <div className="flex items-center gap-3 text-slate-700 text-sm">
                    <div className="w-6 h-6 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center font-bold text-xs">✓</div>
                    <span>Interactive games & Amharic alphabet introduction</span>
                  </div>
                  <div className="flex items-center gap-3 text-slate-700 text-sm">
                    <div className="w-6 h-6 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center font-bold text-xs">✓</div>
                    <span>Comprehensive level assessment & tutor feedback</span>
                  </div>
                  <div className="flex items-center gap-3 text-slate-700 text-sm">
                    <div className="w-6 h-6 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center font-bold text-xs">✓</div>
                    <span>$5 Flat rate secure booking fee</span>
                  </div>
                </div>
              </div>

              <div className="pt-8">
                <button
                  onClick={() => navigate("/book-trial")}
                  className="w-full bg-primary hover:bg-opacity-95 text-white px-6 py-4 rounded-xl text-sm font-bold uppercase tracking-wider transition-all cursor-pointer font-sans shadow-lg shadow-primary/20 flex items-center justify-center gap-2"
                >
                  <BookOpen size={16} />
                  Book Trial Session Now
                </button>
              </div>
            </div>

            {/* Right side: Benefits & Onboarding Tips */}
            <div className="lg:col-span-5 space-y-6 flex flex-col justify-between">
              <div className="bg-gradient-to-br from-indigo-900 to-indigo-950 text-white rounded-3xl p-8 shadow-md">
                <span className="text-xs text-secondary font-extrabold uppercase tracking-widest px-2.5 py-0.5 bg-white/10 rounded-full inline-block mb-3">
                  Why Parents Abroad Love Us
                </span>
                <h3 className="text-xl font-serif italic font-bold mb-4">
                  Built for Families Abroad
                </h3>
                <div className="space-y-4">
                  <div>
                    <h4 className="text-xs font-bold text-secondary uppercase tracking-wider">1-on-1 Live Tutoring</h4>
                    <p className="text-xs text-white/75 mt-1 leading-relaxed">
                      Customized attention that guarantees speaking gains on day one.
                    </p>
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-secondary uppercase tracking-wider">Gamified Web Application</h4>
                    <p className="text-xs text-white/75 mt-1 leading-relaxed">
                      Kids earn stars and gems by playing Amharic vocabulary games in class.
                    </p>
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-secondary uppercase tracking-wider">Ge'ez Heritage Hub</h4>
                    <p className="text-xs text-white/75 mt-1 leading-relaxed">
                      24/7 access to worksheets, interactive cards, and pronunciation guides.
                    </p>
                  </div>
                </div>
              </div>

              <div className="bg-slate-50 border border-slate-150 rounded-3xl p-6 text-center">
                <h3 className="font-bold text-sm text-slate-800 mb-1">
                  Have Custom Timing Requirements?
                </h3>
                <p className="text-xs text-slate-500 mb-4">
                  Our coordinator can manually match a tutor for you.
                </p>
                <button
                  onClick={() => navigate("/parent/support")}
                  className="w-full bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 px-4 py-2.5 rounded-lg text-xs font-bold transition-all cursor-pointer"
                >
                  Contact Support Desk
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {activeTab === "dashboard" && !user?.isAmbassador && allProfiles.length > 0 && (
        <>
          {/* Trial Scheduled Banner */}
          {scheduledTrialLead && !isPremiumActive && (
            <div className="bg-blue-50 border border-blue-100 p-6 rounded-2xl flex flex-col md:flex-row items-center justify-between gap-6 shadow-sm animate-in slide-in-from-top duration-500 mb-6">
              <div className="flex gap-4 items-center">
                <div className="w-12 h-12 bg-blue-600 text-white rounded-full flex items-center justify-center shadow-lg shadow-blue-200">
                  <Calendar size={24} />
                </div>
                <div>
                  <h3 className="font-bold text-slate-900 leading-tight">
                    Trial Session Scheduled!
                  </h3>
                  <p className="text-slate-500 text-xs mt-1">
                    Your trial for {scheduledTrialLead.childName} is set for{" "}
                    {formatSafeDate(scheduledTrialLead.scheduledAt) || "soon"}.
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <button
                  onClick={() => handleTestCompleteTrial(scheduledTrialLead)}
                  disabled={completingTrialId === scheduledTrialLead.id}
                  className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold px-4 py-2 rounded-xl text-xs uppercase tracking-wider transition-all shadow-md cursor-pointer flex items-center gap-1.5"
                >
                  {completingTrialId === scheduledTrialLead.id ? (
                    <>
                      <Loader2 size={12} className="animate-spin" />
                      Completing...
                    </>
                  ) : (
                    "✨ Confirm Attendance"
                  )}
                </button>
                <div className="text-[10px] font-bold text-blue-600 uppercase tracking-widest bg-white px-4 py-2 rounded-lg border border-blue-100">
                  Waiting for Session
                </div>
              </div>
            </div>
          )}

          {/* Registration Completed Review Banner */}
          {completedTrialLead && !isPremiumActive && completedTrialLead.status === "registration_completed" && (
            <div className="bg-amber-50/60 border border-amber-100 p-6 md:p-8 rounded-[24px] space-y-6 shadow-sm animate-in slide-in-from-top duration-550 text-left mb-6">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-amber-100">
                <div className="flex gap-3.5 items-center">
                  <div className="w-12 h-12 bg-amber-500 text-white rounded-2xl flex items-center justify-center shadow-md shadow-amber-200 shrink-0">
                    <Clock size={22} className="text-white" />
                  </div>
                  <div>
                    <span className="text-[10px] font-black uppercase text-amber-800 tracking-wider bg-amber-100 px-2.5 py-1 rounded-md">
                      Verification Pending
                    </span>
                    <h3 className="font-bold text-slate-900 mt-1.5 text-lg leading-tight">
                      Registration Successfully Submitted!
                    </h3>
                  </div>
                </div>
                <div className="bg-white border border-amber-200 px-4 py-2.5 rounded-xl text-center self-start md:self-auto shadow-sm">
                  <p className="text-[9px] uppercase font-bold text-slate-400">Remittance Receipt</p>
                  <p className="text-xs font-mono font-black text-slate-700 mt-0.5">Capturing ID: {completedTrialLead.paymentRef || "N/A"}</p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
                <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-sm space-y-2">
                  <span className="text-[9px] font-black uppercase text-slate-400 tracking-widest block">01. Selected Plan</span>
                  <p className="text-sm font-extrabold text-slate-905">{completedTrialLead.chosenPlan || "Heritage Pro Plan"}</p>
                  <p className="text-[11px] text-slate-400 leading-normal">
                    Class credits are allocated provisionally awaiting transfer validation.
                  </p>
                </div>

                <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-sm space-y-2">
                  <span className="text-[9px] font-black uppercase text-slate-400 tracking-widest block">02. Assigned Tutor &amp; Schedule</span>
                  <p className="text-sm font-extrabold text-slate-905">{completedTrialLead.chosenTutor || "Selamawit Kebede"}</p>
                  <p className="text-[11px] text-slate-500 font-medium leading-tight font-mono">
                    {completedTrialLead.chosenSchedule || "Weekly recurring timeslots"}
                  </p>
                </div>

                <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-sm space-y-2">
                  <span className="text-[9px] font-black uppercase text-slate-400 tracking-widest block">03. Electronic Remittance</span>
                  <p className="text-sm font-extrabold text-slate-905 capitalize">
                    {completedTrialLead.paymentType === "telebirr" ? "Telebirr (merchant code 882910)" : completedTrialLead.paymentType === "cbe" ? "CBE Bank Transfer" : "International (Zelle/Remitly)"}
                  </p>
                  <p className="text-[11px] text-slate-550 font-medium font-sans">
                    Depositor: <strong className="text-slate-805">{completedTrialLead.paymentSenderName || user?.displayName || "Parent"}</strong>
                  </p>
                </div>
              </div>

              <div className="p-4 bg-emerald-50/50 border border-emerald-100 rounded-2xl flex gap-3.5 items-start">
                <span className="text-emerald-600 font-bold text-lg leading-none mt-0.5">✓</span>
                <div className="space-y-1">
                  <p className="text-[11px] font-bold text-emerald-950 leading-tight">
                    Professional Confirmation Email Dispatched
                  </p>
                  <p className="text-[11px] text-emerald-800 leading-relaxed">
                    A formal email receipt containing your chosen plans, tutor agenda parameters, and payment confirmation statement has been simulated and dispatched to <strong className="font-bold underline text-emerald-950">{user?.email || "parent email"}</strong>.
                  </p>
                </div>
              </div>

              <div className="bg-slate-50 p-5 rounded-2xl border border-dashed border-slate-200">
                <p className="text-[11px] text-slate-550 leading-relaxed">
                  💡 <strong>Next Steps:</strong> Our administrative board handles validation of international remittances and CBE/Telebirr corporate accounts in under 2 hours. Once checked, your child's permanent virtual classroom links, visual progression matrices, and interactive curriculum will activate immediately.
                </p>
              </div>
            </div>
          )}

          {/* Trial Completed Call-to-Action */}
          {completedTrialLead && !isPremiumActive && completedTrialLead.status === "trial_completed" && (
            <div className="bg-orange-50 border border-orange-100 p-6 rounded-2xl flex flex-col md:flex-row items-center justify-between gap-6 shadow-sm animate-in slide-in-from-top duration-500 mb-6">
              <div className="flex gap-4 items-start w-full">
                <div className="w-14 h-14 bg-gradient-to-br from-orange-400 to-orange-600 text-white rounded-2xl flex items-center justify-center shadow-lg shadow-orange-200 shrink-0">
                  <CheckCircle2 size={24} />
                </div>
                <div className="flex-1">
                  <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div>
                      <h3 className="font-bold text-slate-900 leading-tight text-lg">
                        Trial Session Report: {completedTrialLead.childName}
                      </h3>
                      <p className="text-slate-500 text-xs mt-1">
                        Our tutor has finalized the evaluation. Review the results
                        below to unlock enrollment.
                      </p>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="bg-white px-3 py-2 rounded-xl border border-orange-100 flex flex-col items-center">
                        <span className="text-[9px] font-bold text-slate-400 uppercase">
                          Assessment
                        </span>
                        <span className="text-sm font-bold text-orange-600">
                          Level {trialSession?.recommendedLevel || "1"}
                        </span>
                      </div>
                      <button
                        onClick={() => setShowEnroller(true)}
                        className="bg-slate-900 text-white font-bold px-6 py-3 rounded-xl text-xs uppercase tracking-widest hover:bg-slate-800 transition-all shadow-lg shadow-slate-900/10 shrink-0"
                      >
                        Apply to Heritage Plan
                      </button>
                    </div>
                  </div>

                  {trialSession?.evaluation && (
                    <div className="mt-4 bg-white/80 p-5 rounded-2xl border border-orange-200/50 relative group">
                      <div className="text-[11px] text-slate-600 italic leading-relaxed">
                        "{trialSession.evaluation}"
                      </div>
                      <div className="mt-3 pt-3 border-t border-slate-100 flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <div className="w-6 h-6 bg-slate-100 rounded-full flex items-center justify-center text-slate-400">
                            <Users size={12} />
                          </div>
                          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-tight">
                            Tutor Evaluation Report
                          </span>
                        </div>
                        <p className="text-[10px] text-slate-300 font-medium">
                          Verified by Heritage Academic Team
                        </p>
                      </div>
                      <div className="absolute top-4 right-4 text-orange-200 group-hover:text-orange-300 transition-colors">
                        <BookOpen size={16} />
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}
          <header className="flex flex-col md:flex-row md:items-center justify-between gap-6">
            <div>
              <h1 className="text-3xl font-bold text-primary mb-1 tracking-tight">
                Parent Dashboard
              </h1>
              <p className="text-slate-500 text-sm">
                Welcome back, {user?.fullName || user?.displayName || "Parent"}. Our next session
                is ready.
              </p>
            </div>
            <div className="flex gap-3">
              <button 
                onClick={() => {
                  const student = activeStudent;
                  const tutorId = student?.tutorId || completedTrialLead?.tutorId || trialSession?.tutorId || "preview-tutor-id";
                  let tutor = tutors.find((t) => t.id === tutorId);
                  if (!tutor && trialSession?.tutorName) {
                    tutor = tutors.find((t) => t.name === trialSession.tutorName || t.displayName === trialSession.tutorName);
                  }
                  if (tutor) {
                    handleOpenTutorChat(tutor);
                  } else {
                    alert("No specific tutor is assigned to this profile yet. Once an instructor is assigned, you can message them directly here. In the meantime, feel free to contact our coordinator via WhatsApp support in the sidebar!");
                  }
                }}
                className="btn-secondary text-xs px-4 py-2 bg-white flex items-center gap-1.5 cursor-pointer font-sans"
              >
                <MessageCircle size={14} />
                {(() => {
                  const student = activeStudent;
                  const tutorId = student?.tutorId || completedTrialLead?.tutorId || trialSession?.tutorId || "preview-tutor-id";
                  let tutor = tutors.find((t) => t.id === tutorId);
                  if (!tutor && trialSession?.tutorName) {
                    tutor = tutors.find((t) => t.name === trialSession.tutorName || t.displayName === trialSession.tutorName);
                  }
                  return tutor ? `Message Teacher ${tutor.name || tutor.displayName}` : "Message Tutor";
                })()}
              </button>
              <a 
                href="/parent/billing"
                className="btn-primary text-xs px-4 py-2 shadow-none flex items-center justify-center cursor-pointer font-sans text-white text-center"
              >
                Manage Billing
              </a>
            </div>
          </header>

          {/* Multi-student child selector tabs */}
          {allProfiles.length > 1 && (
            <div className="flex flex-wrap items-center gap-2 p-3 bg-white border border-slate-100 rounded-2xl shadow-sm mt-4 animate-in fade-in duration-300">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest px-2">Active Profile:</span>
              <div className="flex flex-wrap gap-1.5 border-l border-slate-200 pl-3">
                {allProfiles.map((std: any, idx: number) => {
                  const selected = activeProfileIndex === idx;
                  const subjects = Array.isArray(std.subjects) ? std.subjects : ['Amharic'];
                  const isLead = std.type === 'lead';
                  return (
                    <button
                      key={std.key}
                      type="button"
                      onClick={() => setActiveProfileIndex(idx)}
                      className={cn(
                        "px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5",
                        selected
                          ? "bg-primary text-white shadow-md shadow-primary/10"
                          : "bg-slate-50 text-slate-650 hover:bg-slate-100 border border-slate-105"
                      )}
                    >
                      <span>{isLead ? "⌛" : "👦"} {std.name}</span>
                      <span className={cn(
                        "text-[9px] px-1.5 py-0.5 rounded font-extrabold uppercase",
                        selected
                          ? "bg-white/20 text-white"
                          : isLead
                            ? "bg-amber-100 text-amber-800 border border-amber-205"
                            : "bg-primary/5 text-primary"
                      )}>
                        {isLead ? "Trial Phase" : subjects.join(' & ')}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          <div className="grid lg:grid-cols-3 gap-8">
            {/* Kid Profile & Next Session */}
            <div className="lg:col-span-2 space-y-6">
              <div className="bg-white p-6 md:p-10 rounded-2xl border border-slate-100 shadow-sm flex flex-col md:flex-row gap-10 items-center">
                <div className="relative">
                  <div className="w-24 h-24 md:w-32 md:h-32 bg-slate-100 rounded-2xl overflow-hidden ring-4 ring-slate-50 flex items-center justify-center text-slate-300 transition-all group-hover:scale-105">
                    {primaryStudent?.photoUrl ? (
                      <img
                        src={primaryStudent.photoUrl}
                        className="w-full h-full object-cover grayscale-[20%]"
                        alt="child"
                      />
                    ) : (
                      <TrendingUp size={48} />
                    )}
                  </div>
                  <div className="absolute -bottom-2 -right-2 bg-secondary text-white px-2 py-1 rounded-md text-[10px] font-bold shadow-lg ring-2 ring-white uppercase">
                    {primaryStudent?.level
                      ? `Level ${primaryStudent.level}`
                      : "Assessment Pending"}
                  </div>
                </div>

                <div className="flex-1 text-center md:text-left">
                  <div className="flex flex-col md:flex-row md:items-center gap-3 mb-3">
                    <h2 className="text-2xl font-bold text-slate-900 tracking-tight">
                      {primaryStudent?.name || "Your Child"}
                    </h2>
                    <span
                      className={cn(
                        "text-[10px] font-bold px-2 py-0.5 rounded-full uppercase tracking-widest border",
                        parentData
                          ? "bg-emerald-50 text-emerald-600 border-emerald-100"
                          : "bg-orange-50 text-orange-600 border-orange-100",
                      )}
                    >
                      {parentData
                        ? "Verified Enrollment"
                        : completedTrialLead
                          ? "Trial Completed"
                          : "Lead Status"}
                    </span>
                  </div>
                  <p className="text-slate-500 text-sm mb-6 max-w-md leading-relaxed">
                    {primaryStudent?.learningGoal ||
                      "The initial evaluation is pending. Our academic team is reviewing the child's trial performance to finalize the heritage language focus areas."}
                  </p>

                  <div className="flex flex-wrap justify-center md:justify-start gap-8">
                    <div className="flex items-center gap-2">
                      <div className="w-10 h-10 bg-slate-50 rounded-lg flex items-center justify-center text-primary">
                        <TrendingUp size={18} />
                      </div>
                      <div>
                        <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">
                          Attendance
                        </p>
                        <p className="font-bold text-sm text-slate-900">
                          {primaryStudent?.attendance || "0%"} Weekly
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-10 h-10 bg-slate-50 rounded-lg flex items-center justify-center text-primary">
                        <Clock size={18} />
                      </div>
                      <div>
                        <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">
                          Completed
                        </p>
                        <p className="font-bold text-sm text-slate-900">
                          {primaryStudent?.sessionsCompleted || 0} Sessions
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Premium Phase Sections */}
              {isPremiumActive && (
                <>
                  {/* Unified Academic 4-Week Class Ledger */}
                  {(() => {
                    const cycleSessions = getCycleSessions();
                    return (
                      <div className="bg-white p-6 md:p-8 rounded-3xl border border-slate-100 shadow-sm space-y-6 text-left animate-in fade-in duration-300">
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-50 pb-5">
                          <div>
                            <h3 className="font-bold text-slate-900 text-lg flex items-center gap-2.5 tracking-tight">
                              <span className="text-xl">👩‍💻</span>
                              <span>My Active 4-Week Class Ledger</span>
                            </h3>
                            <p className="text-slate-400 text-xs mt-1">
                              All classes for your current 4-week billing cycle are tracked here in real-time.
                            </p>
                          </div>
                          <div className="flex items-center gap-2 bg-emerald-50 text-emerald-800 border border-emerald-100/60 px-3 py-1.5 rounded-xl">
                            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                            <span className="text-[10px] font-black uppercase tracking-wider">
                              Active Cycle Progress
                            </span>
                          </div>
                        </div>

                        {/* Progress Bar / Course Completion details */}
                        {(() => {
                          const now = new Date();
                          const completedCount = cycleSessions.filter(s => s.date.getTime() < now.getTime()).length;
                          const totalSessions = cycleSessions.length;
                          const percent = totalSessions > 0 ? Math.round((completedCount / totalSessions) * 100) : 0;
                          
                          return (
                            <div className="bg-slate-50 rounded-2xl p-5 space-y-3.5">
                              <div className="flex justify-between items-center text-xs">
                                <span className="font-bold text-slate-600">Course Completion Progress</span>
                                <span className="font-mono font-black text-indigo-600">{completedCount} / {totalSessions} Classes ({percent}%)</span>
                              </div>
                              <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
                                <div className="bg-indigo-600 h-full rounded-full transition-all duration-500" style={{ width: `${percent}%` }} />
                              </div>
                              <div className="flex justify-between text-[10px] text-slate-400 font-semibold font-sans">
                                <span>Cycle Start: {cycleSessions[0] ? cycleSessions[0].date.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" }) : "N/A"}</span>
                                <span>Next Automatic Renewal: {getNextCycleDate()}</span>
                              </div>
                            </div>
                          );
                        })()}

                        {/* Sessions Grid */}
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          {cycleSessions.map((s) => {
                            const now = new Date().getTime();
                            const startTime = s.date.getTime();
                            const durationMs = 50 * 60 * 1000;
                            const endTime = startTime + durationMs;
                            
                            const isPast = now > endTime;
                            const isLive = now >= (startTime - 15 * 60 * 1000) && now <= endTime;
                            const isFuture = now < (startTime - 15 * 60 * 1000);

                            return (
                              <div
                                key={s.sessionNumber}
                                className={cn(
                                  "flex flex-col justify-between p-5 rounded-2xl border transition-all space-y-4",
                                  isPast 
                                    ? "bg-slate-50 border-slate-100 opacity-70" 
                                    : isLive 
                                      ? "bg-white border-emerald-200 ring-2 ring-emerald-500/10 shadow-lg shadow-emerald-500/5"
                                      : "bg-white border-slate-100 hover:border-indigo-150 hover:shadow-md hover:shadow-indigo-50/20"
                                )}
                              >
                                <div className="flex items-start justify-between">
                                  <div className="flex gap-3">
                                    <div className={cn(
                                      "w-10 h-10 rounded-xl flex items-center justify-center font-black text-sm shrink-0 font-mono",
                                      isPast ? "bg-slate-200/60 text-slate-400" : isLive ? "bg-emerald-50 text-emerald-700 animate-pulse" : "bg-indigo-50 text-indigo-700"
                                    )}>
                                      #{String(s.sessionNumber).padStart(2, '0')}
                                    </div>
                                    <div className="text-left font-sans">
                                      <p className="font-extrabold text-slate-900 text-sm leading-tight">
                                        Class {s.sessionNumber} of {cycleSessions.length}
                                      </p>
                                      <p className="text-slate-400 text-xs mt-2 font-semibold flex items-center gap-1.5">
                                        <span>🗓️</span>
                                        <span>{s.formattedDay}</span>
                                      </p>
                                      <p className="text-slate-500 text-xs mt-1 font-extrabold font-mono flex items-center gap-1.5">
                                        <span>⏰</span>
                                        <span>{s.formattedTime} ({Intl.DateTimeFormat().resolvedOptions().timeZone})</span>
                                      </p>
                                    </div>
                                  </div>
                                  
                                  <span className={cn(
                                    "text-[9px] font-black uppercase tracking-wider px-2.5 py-1 rounded-md border",
                                    s.status === 'missed'
                                      ? "bg-amber-50 text-amber-600 border-amber-100"
                                      : isPast 
                                        ? "bg-slate-150 text-slate-400 border-slate-200" 
                                        : isLive
                                          ? "bg-emerald-500 text-white border-emerald-500 animate-bounce"
                                          : "bg-emerald-50 text-emerald-600 border-emerald-100"
                                  )}>
                                    {s.status === 'missed' ? "Missed" : isPast ? "Completed" : isLive ? "Live Now" : "Scheduled"}
                                  </span>
                                </div>

                                {s.status === 'missed' && s.missedReason && (
                                  <p className="text-[9px] text-amber-700 bg-amber-50/50 px-2 py-1 rounded mt-1 font-medium border border-amber-50 italic">
                                    Reason: {s.missedReason}
                                  </p>
                                )}

                                <div className="pt-3.5 border-t border-slate-100 flex items-center justify-between gap-2">
                                  <div className="text-left">
                                    <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest leading-none">Instructor</p>
                                    <p className="text-xs font-bold text-slate-700 mt-1">{s.tutorName}</p>
                                  </div>

                                  {isPast || s.status === 'missed' ? (
                                    <span className="text-[10px] text-slate-400 font-bold italic">
                                      {s.status === 'missed' ? "Missed Session" : "Passed"}
                                    </span>
                                  ) : (
                                    <a
                                      href={s.meetUrl}
                                      target="_blank"
                                      rel="noopener noreferrer"
                                      className="inline-flex items-center gap-1 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-[10px] py-2 px-4 rounded-xl uppercase tracking-widest shadow-md transition-all cursor-pointer font-sans"
                                    >
                                      <span>Enter Class</span>
                                      <ChevronRight size={11} />
                                    </a>
                                  )}
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    );
                  })()}

                  {/* Confirmed Class Schedule displaying locked slots & Contact block */}
                  {(() => {
                    const student = activeStudent;
                    if (!student) return null;
                    const tutorId = student.tutorId;
                    const tutor = tutors.find((t) => t.id === tutorId);
                    const rawPattern = student.schedulePattern;
                    const schedulePatterns: string[] = Array.isArray(rawPattern)
                      ? rawPattern
                      : (typeof rawPattern === "string"
                         ? rawPattern.split(",").map((s: string) => s.trim()).filter(Boolean)
                         : []);
                    
                    return (
                      <div className="bg-white p-6 md:p-8 rounded-3xl border border-slate-100 shadow-sm space-y-5 text-left animate-in fade-in duration-300">
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-50 pb-4">
                          <div>
                            <h3 className="font-bold text-slate-900 flex items-center gap-2 text-base tracking-tight">
                              <Calendar size={18} className="text-indigo-600" />
                              <span>My Confirmed Weekly Class Slots</span>
                            </h3>
                            <p className="text-slate-400 text-[11px] mt-1.5 leading-relaxed">
                              Weekly recurring class schedule structured with Amharic instructor ({tutor?.name || tutor?.displayName || "Assigned Tutor"}).
                            </p>
                          </div>
                          <a
                            href="https://wa.me/251940651491"
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-[10px] font-bold text-slate-650 bg-slate-50 hover:bg-slate-100 border border-slate-200 px-4 py-2.5 rounded-xl uppercase tracking-wide cursor-pointer flex items-center gap-1.5 font-sans self-start sm:self-center"
                          >
                            <MessageCircle size={13} className="text-slate-500" />
                            <span>Contact Coordinator</span>
                          </a>
                        </div>

                        {schedulePatterns.length > 0 ? (
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                            {schedulePatterns.map((pattern: string, pIdx: number) => (
                              <div key={pIdx} className="bg-indigo-50/30 border border-indigo-100/40 rounded-xl p-4 flex items-center justify-between text-left font-sans">
                                <div className="flex items-center gap-3">
                                  <span className="text-lg">🗓️</span>
                                  <div>
                                    <p className="text-xs font-bold text-slate-900 capitalize">
                                      {pattern.split(' @ ')[0] || "Weekly Class"}
                                    </p>
                                    <p className="text-sm font-black text-indigo-700 font-mono mt-0.5">
                                      {pattern.split(' @ ')[1] || pattern}
                                    </p>
                                  </div>
                                </div>
                                <span className="text-[10px] font-black uppercase text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-md">
                                  LOCKED
                                </span>
                              </div>
                            ))}
                          </div>
                        ) : (
                          <div className="p-4 bg-indigo-50/10 border border-dashed border-indigo-100 rounded-xl">
                            <p className="text-xs text-slate-500 leading-relaxed font-sans">
                              💡 <strong>Schedule Design Active:</strong> Our admin team is currently mapping your recurring permanent schedule timeslots with your assigned tutor. We will lock your schedule pattern below shortly!
                            </p>
                          </div>
                        )}
                      </div>
                    );
                  })()}
                </>
              )}

              {!isPremiumActive && (
                <div className="bg-white p-6 md:p-8 rounded-2xl border border-slate-100 shadow-sm flex flex-col">
                  <div className="flex items-center justify-between mb-8">
                    <h3 className="font-bold text-slate-900">
                      Upcoming Sessions
                    </h3>
                    <button className="text-[10px] font-bold text-secondary flex items-center gap-1 hover:underline uppercase tracking-widest">
                      Full Calendar
                      <ChevronRight size={14} />
                    </button>
                  </div>

                  <div className="grid gap-4">
                    {sessions.map((s, i) => (
                      <div
                        key={i}
                        className="flex items-center justify-between p-5 bg-slate-50 rounded-xl border border-transparent hover:border-slate-200 transition-all group"
                      >
                        <div className="flex items-center gap-4">
                          <div className="w-12 h-12 bg-white border border-slate-100 rounded-lg flex items-center justify-center font-bold text-slate-900 shadow-sm text-sm">
                            {formatSafeDate(s.startTime, { weekday: "short" }) ||
                              "Day"}
                          </div>
                          <div>
                            <p className="font-bold text-slate-900 leading-tight">
                              {formatSafeDate(s.startTime, { weekday: "long" }) ||
                                  "Scheduled"}
                            </p>
                            <p className="text-[11px] text-slate-400 font-medium">
                              {formatSafeDate(s.startTime, {
                                hour: "2-digit",
                                minute: "2-digit",
                              }) || "00:00"}{" "}
                              • with {s.tutorName || "Teacher"}
                              {s.status === 'missed' && (
                                <span className="ml-2 text-amber-600 font-bold bg-amber-50 px-1.5 py-0.5 rounded text-[9px] uppercase tracking-wider">
                                  Missed
                                </span>
                              )}
                            </p>
                          </div>
                        </div>
                        {s.status === "scheduled" && (
                          (() => {
                            const now = new Date().getTime();
                            const startTime = s.startTime?.toDate ? s.startTime.toDate().getTime() : new Date(s.startTime).getTime();
                            const isLive = now >= (startTime - 15 * 60 * 1000) && now <= (startTime + 50 * 60 * 1000);

                            const studentDoc = parentData?.students?.find((item: any) => item.id === s.studentId);
                            const isExpired = studentDoc?.status === "expired" || (studentDoc && studentDoc.remainingClassCredits !== undefined && studentDoc.remainingClassCredits <= 0);
                            
                            if (isExpired) {
                              return (
                                <span className="text-[9px] font-black uppercase text-red-650 bg-red-50 border border-red-100 px-3 py-1.5 rounded-lg tracking-wider flex items-center gap-1">
                                  🔐 Expired / Locked
                                </span>
                              );
                            }

                            const assocTutor = tutors && s.tutorId ? tutors.find((t) => t.id === s.tutorId) : null;
                            const meetUrl = s.classroomLink || assocTutor?.classroomLink || getDeterministicGoogleMeetUrl(undefined, s.tutorId);
                            
                            // Self-heal
                            if (s.id && (!s.classroomLink || !s.tutorEmail) && assocTutor) {
                              const updates: any = {};
                              if (!s.classroomLink && assocTutor.classroomLink) updates.classroomLink = assocTutor.classroomLink;
                              if (!s.tutorEmail && assocTutor.email) updates.tutorEmail = assocTutor.email;
                              
                              if (Object.keys(updates).length > 0) {
                                updateDoc(doc(db, 'sessions', s.id), updates).catch(e => console.warn("Silent heal (Upcoming) failed:", e));
                              }
                            }

                            return (
                              <div className="flex flex-col gap-2 w-full">
                                <a 
                                  href={meetUrl}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="bg-emerald-600 text-white hover:bg-emerald-700 text-[10px] py-2 px-5 font-bold uppercase tracking-widest rounded-lg shadow-md transition-all cursor-pointer text-center flex items-center justify-center gap-2"
                                >
                                  <span>Enter Class</span>
                                  <ExternalLink size={12} />
                                </a>
                                <button 
                                  onClick={() => {
                                    navigator.clipboard.writeText(meetUrl);
                                    alert("Link copied! You can now send it via WhatsApp.");
                                  }}
                                  className="text-[9px] text-slate-500 hover:text-indigo-600 flex items-center justify-center gap-1.5 font-bold uppercase tracking-tighter py-1 transition-colors"
                                >
                                  <Copy size={10} />
                                  <span>Copy Class Link</span>
                                </button>
                                <div className="mt-1 px-3 py-2 bg-amber-50 border border-amber-100 rounded-md flex gap-2 items-start">
                                  <Info size={10} className="text-amber-600 mt-0.5 shrink-0" />
                                  <p className="text-[9px] text-amber-800 leading-tight">
                                    <strong>Connectivity Tip:</strong> If you see an empty room, ensure you and the tutor are using the exact same link above.
                                  </p>
                                </div>
                              </div>
                            );
                          })()
                        )}
                      </div>
                    ))}
                    {sessions.length === 0 && (
                      <div className="py-12 text-center text-slate-400 text-xs italic font-medium bg-slate-50 rounded-xl border border-dashed border-slate-200">
                        No upcoming sessions found.
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* Scheduler Component Gate for premium families */}
              {isTrialCompleted &&
                isPremiumActive &&
                (() => {
                  const student = activeStudent;
                  if (!student) return null;
                  const tutorId = student.tutorId;
                  const tutor = tutors.find((t) => t.id === tutorId);
                  const currentPlan = plans.find((p) => p.id === student.plan);
                  const requiredSlotsCount = currentPlan
                    ? currentPlan.sessions / 4
                    : 1;

                  if (student.recurringTimes && student.recurringTimes.length > 0 && !isEditingDashboardSchedule) {
                    return (
                      <div className="bg-white p-6 md:p-8 rounded-2xl border border-slate-100 shadow-sm space-y-4 animate-in fade-in duration-350">
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-4">
                          <div className="text-left">
                            <h3 className="font-bold text-slate-900 flex items-center gap-2 text-base leading-none">
                              <Calendar size={18} className="text-indigo-600" />
                              <span>Your Confirmed Weekly Class Slots</span>
                            </h3>
                            <p className="text-slate-400 text-[11px] mt-1.5 leading-relaxed">
                              Your child's recurring weekly class schedule is active and locked with your tutor ({tutor?.name || tutor?.displayName || "Assigned Tutor"}).
                            </p>
                          </div>
                          <a
                            href="https://wa.me/251940651491"
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-[10px] font-bold text-slate-650 bg-slate-50 hover:bg-slate-100 border border-slate-200 px-4 py-2.5 rounded-xl uppercase tracking-wide cursor-pointer transition-all self-start sm:self-center flex items-center gap-1.5 whitespace-nowrap font-sans"
                          >
                            <MessageCircle size={13} className="text-slate-500" />
                            <span>Contact Us to Change</span>
                          </a>
                        </div>
                        
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                          {(Array.isArray(student.schedulePattern)
                            ? student.schedulePattern
                            : (typeof student.schedulePattern === "string"
                               ? student.schedulePattern.split(",").map((s: string) => s.trim()).filter(Boolean)
                               : []
                          )).map((pattern: string, pIdx: number) => (
                            <div key={pIdx} className="bg-indigo-50/50 border border-indigo-100/60 rounded-xl p-4 flex items-center justify-between text-left font-sans shadow-sm">
                              <div className="flex items-center gap-3">
                                <span className="text-lg">🗓️</span>
                                <div>
                                  <p className="text-xs font-bold text-slate-900 capitalize">{pattern.split(' @ ')[0] || "Weekly Class"}</p>
                                  <p className="text-sm font-black text-indigo-700 font-mono mt-0.5">{pattern.split(' @ ')[1] || pattern}</p>
                                </div>
                              </div>
                              <span className="text-[10px] font-black uppercase text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-md">
                                Active Locked
                              </span>
                            </div>
                          ))}
                        </div>
                      </div>
                    );
                  }

                  const avail = getFilteredAvailability(tutor?.availability, tutor?.id, globalSessions);
                  if (!avail) {
                    return (
                      <div
                        id="scheduler-calendar-card"
                        className="bg-white p-6 md:p-8 rounded-2xl border border-slate-100 shadow-sm space-y-4"
                      >
                        <h3 className="font-bold text-slate-900 flex items-center gap-2">
                          <Calendar size={18} className="text-indigo-600" />
                          <span>Permanent Slot Scheduler</span>
                        </h3>
                        <p className="text-slate-500 text-xs italic">
                          Tutor's weekly accessibility configuration is
                          currently empty. Please coordinate with
                          Administration.
                        </p>
                      </div>
                    );
                  }

                  const activeDays = DAYS.filter(
                    (day) =>
                      avail[day]?.active && avail[day]?.slots?.length > 0,
                  );

                  const handleSaveSchedule = async () => {
                    setSavingSchedule(true);
                    setSaveScheduleStatus("idle");
                    const schedulePattern = selectedSlots.map((time) => {
                      const d = new Date(time);
                      return `${d.toLocaleDateString("en-US", { weekday: "long" })} @ ${d.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" })}`;
                    });

                    const res = await updateStudentSchedule(
                      student.id,
                      selectedSlots,
                      schedulePattern,
                    );
                    if (res.success) {
                      setSaveScheduleStatus("success");
                      setIsEditingDashboardSchedule(false);
                      setTimeout(() => setSaveScheduleStatus("idle"), 3000);
                    } else {
                      setSaveScheduleStatus("error");
                    }
                    setSavingSchedule(false);
                  };

                  return (
                    <div
                      id="scheduler-calendar-card"
                      className="bg-white p-6 md:p-8 rounded-2xl border border-slate-100 shadow-sm space-y-6 animate-in slide-in-from-bottom duration-300"
                    >
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-4">
                        <div>
                          <h3 className="font-bold text-slate-900 flex items-center gap-2 text-base">
                            <Calendar size={18} className="text-indigo-600" />
                            <span>Permanent Weekly Class Scheduler</span>
                          </h3>
                          <p className="text-slate-400 text-[11px] mt-1">
                            Book recurring weekly slots matching your assigned
                            tutor's setup.
                          </p>
                        </div>
                        <div className="px-3 py-1 bg-indigo-50 text-indigo-700 rounded-xl text-[10px] uppercase font-bold tracking-wider self-start">
                          {selectedSlots.length} / {requiredSlotsCount} Slots
                          Chosen
                        </div>
                      </div>

                      {/* Local Time Zone Context Indicator */}
                      <div className="bg-slate-50 border border-slate-150 p-3.5 rounded-2xl flex items-center justify-between text-[11px] text-slate-500 font-medium">
                        <div className="flex items-center gap-2">
                          <span className="text-sm">🌐</span>
                          <span>
                            All class hours are shown in:{" "}
                            <strong className="text-slate-800 font-bold">
                              {Intl.DateTimeFormat().resolvedOptions().timeZone}
                            </strong>
                          </span>
                        </div>
                        <span className="text-[10px] text-indigo-650 bg-indigo-50 font-bold px-2 py-0.5 rounded-md uppercase tracking-wide">
                          Local Context
                        </span>
                      </div>

                      <div className="space-y-6">
                        {activeDays.length === 0 ? (
                          <p className="text-xs text-slate-400 italic">
                            This tutor has not configured checked hours in their
                            availability grid yet.
                          </p>
                        ) : (
                          activeDays.map((day) => {
                            const standardHours = ['09:00', '11:00', '13:00', '15:00', '17:00', '19:00', '21:00', '22:00', '23:00', '00:00', '01:00', '02:00', '03:00', '04:00', '05:00'];
                            const dailySlotsToRender = Array.from(new Set([...standardHours, ...(avail[day]?.slots || [])])).sort();

                            return (
                              <div key={day} className="space-y-2">
                                <span className="text-[10px] font-extrabold text-slate-900 uppercase tracking-widest block capitalize">
                                  {day}s
                                </span>
                                <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-2">
                                  {dailySlotsToRender.map((slotTime: string, idx: number) => {
                                    const isTutorFree = avail[day]?.slots?.includes(slotTime);
                                    const isSelected = selectedSlots.some(
                                      (rt) => {
                                        const parsed = parseISOTimeAndDay(rt);
                                        return parsed.time === slotTime && parsed.day === day;
                                      },
                                    );

                                    if (!isTutorFree) {
                                      return (
                                        <button
                                          key={idx}
                                          type="button"
                                          disabled={true}
                                          className="px-3 py-2 rounded-xl text-xs font-semibold border border-slate-100 bg-slate-50 text-slate-400 line-through text-center flex flex-col justify-center items-center gap-0.5 opacity-40 cursor-not-allowed"
                                        >
                                          <span className="text-[7.5px] uppercase tracking-wider text-slate-400 font-extrabold">🔒 Blocked</span>
                                          {parseInt(slotTime.split(":")[0] || "9") >= 12
                                            ? `${parseInt(slotTime.split(":")[0] || "12") === 12 ? 12 : parseInt(slotTime.split(":")[0] || "12") - 12}:00 PM`
                                            : `${parseInt(slotTime.split(":")[0] || "9")}:00 AM`}
                                        </button>
                                      );
                                    }

                                    return (
                                      <button
                                        key={idx}
                                        type="button"
                                        onClick={() => {
                                          const now = new Date();
                                          const daysMap: any = {
                                            sunday: 0,
                                            monday: 1,
                                            tuesday: 2,
                                            wednesday: 3,
                                            thursday: 4,
                                            friday: 5,
                                            saturday: 6,
                                          };
                                          const targetDay = daysMap[day];
                                          const today = now.getDay();
                                          const daysUntil =
                                            (targetDay + 7 - today) % 7 || 7;
                                          const date = new Date(now);
                                          date.setDate(
                                            now.getDate() + daysUntil,
                                          );
                                          const [h, m] = slotTime
                                            .split(":")
                                            .map(Number);
                                          date.setHours(h, m, 0, 0);
                                          const iso = date.toISOString();

                                          if (isSelected) {
                                            setSelectedSlots(
                                              selectedSlots.filter((rt) => {
                                                const parsed = parseISOTimeAndDay(rt);
                                                return !(parsed.time === slotTime && parsed.day === day);
                                              }),
                                            );
                                          } else {
                                            if (
                                              selectedSlots.length <
                                              requiredSlotsCount
                                            ) {
                                              setSelectedSlots([
                                                ...selectedSlots,
                                                iso,
                                              ]);
                                            } else if (
                                              requiredSlotsCount === 1
                                            ) {
                                              setSelectedSlots([iso]);
                                            }
                                          }
                                        }}
                                        className={cn(
                                          "px-3 py-2 rounded-xl text-xs font-bold transition-all border text-center flex flex-col justify-center items-center gap-0.5 shadow-sm",
                                          isSelected
                                            ? "bg-indigo-650 border-indigo-650 text-white shadow-md shadow-indigo-600/10 scale-102"
                                            : "bg-white border-emerald-250 text-emerald-800 hover:border-emerald-400 hover:bg-emerald-50/40",
                                        )}
                                      >
                                        <span className={cn(
                                          "text-[8px] uppercase tracking-wider font-extrabold",
                                          isSelected ? "text-white" : "text-emerald-600"
                                        )}>
                                          {isSelected
                                            ? "Selected"
                                            : "Free Slot"}
                                        </span>
                                        {parseInt(
                                          slotTime.split(":")[0] || "9",
                                        ) >= 12
                                          ? `${parseInt(slotTime.split(":")[0] || "12") === 12 ? 12 : parseInt(slotTime.split(":")[0] || "12") - 12}:00 PM`
                                          : `${parseInt(slotTime.split(":")[0] || "9")}:00 AM`}
                                      </button>
                                    );
                                  })}
                                </div>
                              </div>
                            );
                          })
                        )}
                      </div>

                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pt-4 border-t border-slate-100">
                        <p className="text-[9px] text-slate-400 max-w-sm">
                          Select exactly {requiredSlotsCount} permanent{" "}
                          {requiredSlotsCount === 1 ? "slot" : "slots"} matching
                          your current <strong>{currentPlan?.name}</strong>{" "}
                          plan.
                        </p>
                        <button
                          type="button"
                          disabled={
                            savingSchedule ||
                            selectedSlots.length !== requiredSlotsCount
                          }
                          onClick={handleSaveSchedule}
                          className="btn-primary self-end flex items-center gap-2 px-6 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs disabled:opacity-50 font-bold shadow-md"
                        >
                          {savingSchedule ? (
                            <Loader2 className="animate-spin" size={14} />
                          ) : (
                            <CheckCircle2 size={14} />
                          )}
                          <span>Save Permanent Slots</span>
                        </button>
                      </div>

                      {saveScheduleStatus === "success" && (
                        <div className="bg-emerald-50 border border-emerald-100 p-3 rounded-xl flex items-center gap-2 text-emerald-800 text-[11px] font-semibold animate-in slide-in-from-top duration-300">
                          <span>✅</span>
                          <span>
                            Permanent schedule updated successfully. Invitation
                            alerts dispatched inside live ledger databases.
                          </span>
                        </div>
                      )}
                      {saveScheduleStatus === "error" && (
                        <div className="bg-red-50 border border-red-100 p-3 rounded-xl flex items-center gap-2 text-red-800 text-[11px] font-semibold">
                          <span>⚠️</span>
                          <span>
                            Failed to synchronize permanent calendar bookings.
                            Please contact admin.
                          </span>
                        </div>
                      )}
                    </div>
                  );
                })()}
            </div>

            {/* Subscription Sidebar */}
            <div className="space-y-6">
              <div className="bg-slate-900 text-white p-8 rounded-2xl relative overflow-hidden shadow-xl">
                <div className="relative z-10">
                  <ShieldCheck className="text-secondary mb-8" size={32} />
                  <div className="flex justify-between items-start mb-2">
                    <h3 className="text-xl font-bold tracking-tight">
                      {activeStudent?.plan
                        ? `Plan: ${plans.find((p) => p.id === activeStudent.plan)?.name || activeStudent.plan}`
                        : "Heritage Enrollment"}
                    </h3>
                    <span
                      className={cn(
                        "text-[10px] font-bold px-2 py-0.5 rounded-md uppercase border",
                        activeStudent
                          ? "bg-emerald-500/20 text-emerald-400 border-emerald-500/30"
                          : "bg-orange-500/20 text-orange-400 border-orange-500/30",
                      )}
                    >
                      {activeStudent
                        ? "Active"
                        : completedTrialLead
                          ? "Ready"
                          : "Inactive"}
                    </span>
                  </div>
                  <p className="text-slate-400 mb-8 text-xs">
                    {activeStudent
                      ? `Active enrollment for ${activeStudent.name}. View full billing details in portal.`
                      : completedTrialLead
                        ? "Trial complete! Unlock full features by subscribing to a plan."
                        : "Please complete your evaluation to start regular sessions."}
                  </p>

                  {activeStudent?.plan && (
                    <div className="space-y-3 mb-8">
                      <div className="flex justify-between text-xs py-2 border-b border-white/5">
                        <span className="text-slate-400 font-medium">
                          Frequency
                        </span>
                        <span className="font-bold">Weekly Sessions</span>
                      </div>
                      <div className="flex justify-between text-xs py-2 border-b border-white/5">
                        <span className="text-slate-400 font-medium">
                          Billed On
                        </span>
                        <span className="font-bold">Next cycle: {getNextCycleDate()}</span>
                      </div>
                    </div>
                  )}

                  {!activeStudent && !isTrialPhase && (
                    <button
                      onClick={() => setShowEnroller(true)}
                      className="btn-secondary w-full text-xs font-bold uppercase tracking-widest text-slate-900 border-none animate-bounce shadow-lg shadow-secondary/20"
                    >
                      Complete Enrollment
                    </button>
                  )}
                </div>
                <div className="absolute top-0 right-0 p-8 transform rotate-12 opacity-[0.03]">
                  <CreditCard size={120} />
                </div>
              </div>

              {/* Learning library card */}
              <div className="bg-gradient-to-br from-primary/10 via-primary/5 to-transparent p-6 rounded-2xl border border-primary/20 relative overflow-hidden shadow-sm">
                <div className="relative z-10 flex flex-col items-start text-left">
                  <div className="p-2 bg-primary/20 text-primary-950 rounded-xl mb-3">
                    <BookOpen size={18} />
                  </div>
                  <h4 className="font-extrabold text-slate-900 text-sm mb-1.5 font-sans">
                    Heritage Curriculum & Global Library
                  </h4>
                  <p className="text-[11px] text-slate-550 mb-4 leading-relaxed">
                    Access our complete 120-lesson conversational Amharic curriculum, interactive spelling games, quizzes, worksheets, and ancient Ge'ez Hub!
                  </p>
                  <button
                    onClick={() => setLibraryOpen(true)}
                    className="w-full py-2.5 rounded-xl bg-primary hover:bg-primary/95 text-white text-[10px] font-bold uppercase tracking-widest transition-all shadow-md shadow-primary/10 flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <BookOpen size={13} />
                    <span>Open Library & Curriculum</span>
                  </button>
                </div>
              </div>

              <div className="bg-white p-6 rounded-2xl border border-slate-100 text-center shadow-sm">
                <h4 className="font-bold text-slate-900 mb-2">
                  Need to reschedule?
                </h4>
                <p className="text-[11px] text-slate-400 mb-6 leading-relaxed">
                  Can't make it to a session? Request a make-up session 12h in
                  advance via private parent WhatsApp.
                </p>
                <button className="w-full py-2.5 rounded-lg border border-dashed border-slate-200 text-[10px] font-bold text-slate-400 hover:text-slate-900 hover:border-slate-400 transition-all uppercase tracking-widest">
                  Contact WhatsApp Support
                </button>
              </div>
            </div>
          </div>
        </>
      )}

      {/* VIEW B: SCHEDULE / CALENDAR SLOT BOOKING VIEW */}
      {activeTab === "schedule" && (
        <div className="space-y-6 animate-in fade-in duration-300">
          <header className="flex flex-col md:flex-row md:items-center justify-between gap-6">
            <div className="text-left font-sans">
              <h1 className="text-3xl font-bold text-primary mb-1 tracking-tight">
                Class Scheduler
              </h1>
              <p className="text-slate-500 text-sm">
                Reserve and modify your localized recurring weekly calendar
                slots.
              </p>
            </div>
          </header>

          <div className="grid lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 space-y-6">
              {isTrialCompleted && isPremiumActive ? (
                (() => {
                  const student = activeStudent;
                  if (!student) return null;
                  const tutorId = student.tutorId;
                  const tutor = tutors.find((t) => t.id === tutorId);
                  const currentPlan = plans.find((p) => p.id === student.plan);
                  const requiredSlotsCount = currentPlan
                    ? currentPlan.sessions / 4
                    : 1;

                  const avail = getFilteredAvailability(tutor?.availability, tutor?.id, globalSessions);
                  if (!avail) {
                    return (
                      <div className="bg-white p-8 rounded-2xl border border-slate-105 shadow-sm space-y-4 text-center py-12">
                        <Calendar
                          size={32}
                          className="text-slate-350 mx-auto"
                        />
                        <p className="text-slate-500 text-xs italic font-sans text-center">
                          Tutor's weekly accessibility configuration is
                          currently empty. Please coordinate with
                          Administration.
                        </p>
                      </div>
                    );
                  }

                  const activeDays = DAYS.filter(
                    (day) =>
                      avail[day]?.active && avail[day]?.slots?.length > 0,
                  );

                  const handleSaveScheduleCombined = async () => {
                    setSavingSchedule(true);
                    setSaveScheduleStatus("idle");
                    const schedulePattern = selectedSlots.map((time) => {
                      const d = new Date(time);
                      return `${d.toLocaleDateString("en-US", { weekday: "long" })} @ ${d.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" })}`;
                    });

                    const res = await updateStudentSchedule(
                      student.id,
                      selectedSlots,
                      schedulePattern,
                    );
                    if (res.success) {
                      setSaveScheduleStatus("success");
                      setTimeout(() => setSaveScheduleStatus("idle"), 3000);
                    } else {
                      setSaveScheduleStatus("error");
                    }
                    setSavingSchedule(false);
                  };

                  return (
                    <div className="bg-white p-6 md:p-8 rounded-2xl border border-slate-100 shadow-sm space-y-6">
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-4">
                        <div className="text-left">
                          <h3 className="font-bold text-slate-900 flex items-center gap-2 text-base font-sans">
                            <Calendar size={18} className="text-indigo-600" />
                            <span>Permanent Weekly Class Scheduler</span>
                          </h3>
                          <p className="text-slate-400 text-[11px] mt-1 font-sans">
                            Book recurring weekly slots matching your assigned
                            tutor's setup.
                          </p>
                        </div>
                        <div className="px-3 py-1 bg-indigo-50 text-indigo-700 rounded-xl text-[10px] uppercase font-bold tracking-wider self-start font-sans">
                          {selectedSlots.length} / {requiredSlotsCount} Slots
                          Chosen
                        </div>
                      </div>

                      {/* Local Time Zone Context Indicator */}
                      <div className="bg-slate-50 border border-slate-150 p-3.5 rounded-2xl flex items-center justify-between text-[11px] text-slate-500 font-medium">
                        <div className="flex items-center gap-2 font-sans text-left">
                          <span className="text-sm">🌐</span>
                          <span>
                            All class hours are shown in:{" "}
                            <strong className="text-slate-800 font-bold">
                              {Intl.DateTimeFormat().resolvedOptions().timeZone}
                            </strong>
                          </span>
                        </div>
                        <span className="text-[10px] text-indigo-650 bg-indigo-50 font-bold px-2 py-0.5 rounded-md uppercase tracking-wide font-mono">
                          Local Context
                        </span>
                      </div>

                      <div className="space-y-6">
                        {activeDays.length === 0 ? (
                          <p className="text-xs text-slate-400 italic font-sans text-left">
                            This tutor has not configured checked hours in their
                            availability grid yet.
                          </p>
                        ) : (
                          activeDays.map((day) => (
                            <div key={day} className="space-y-2 text-left">
                              <span className="text-[10px] font-extrabold text-slate-900 uppercase tracking-widest block capitalize font-sans">
                                {day}s
                              </span>
                              <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                                {avail[day].slots.map(
                                  (sVal: any, idx: number) => {
                                    const slotTime =
                                      typeof sVal === "string"
                                        ? sVal
                                        : sVal?.time || "09:00";
                                    const isSelected = selectedSlots.some(
                                      (rt) => {
                                        const parsed = parseISOTimeAndDay(rt);
                                        return parsed.time === slotTime && parsed.day === day;
                                      },
                                    );

                                    return (
                                      <button
                                        key={idx}
                                        type="button"
                                        onClick={() => {
                                          const now = new Date();
                                          const daysMap: any = {
                                            sunday: 0,
                                            monday: 1,
                                            tuesday: 2,
                                            wednesday: 3,
                                            thursday: 4,
                                            friday: 5,
                                            saturday: 6,
                                          };
                                          const targetDay = daysMap[day];
                                          const today = now.getDay();
                                          const daysUntil =
                                            (targetDay + 7 - today) % 7 || 7;
                                          const date = new Date(now);
                                          date.setDate(
                                            now.getDate() + daysUntil,
                                          );
                                          const [h, m] = slotTime
                                            .split(":")
                                            .map(Number);
                                          date.setHours(h, m, 0, 0);
                                          const iso = date.toISOString();

                                          if (isSelected) {
                                            setSelectedSlots(
                                              selectedSlots.filter((rt) => {
                                                const parsed = parseISOTimeAndDay(rt);
                                                return !(parsed.time === slotTime && parsed.day === day);
                                              }),
                                            );
                                          } else {
                                            if (
                                              selectedSlots.length <
                                              requiredSlotsCount
                                            ) {
                                              setSelectedSlots([
                                                ...selectedSlots,
                                                iso,
                                              ]);
                                            } else if (
                                              requiredSlotsCount === 1
                                            ) {
                                              setSelectedSlots([iso]);
                                            }
                                          }
                                        }}
                                        className={cn(
                                          "px-3 py-2.5 rounded-xl text-xs font-bold transition-all border text-center flex flex-col justify-center items-center gap-0.5 font-sans cursor-pointer",
                                          isSelected
                                            ? "bg-indigo-600 border-indigo-600 text-white shadow-md shadow-indigo-600/10 scale-102"
                                            : "bg-slate-50 border-slate-100 text-slate-700 hover:border-slate-300 hover:bg-slate-100/50",
                                        )}
                                      >
                                        <span className="text-[8px] uppercase tracking-wider opacity-60">
                                          {isSelected
                                            ? "Selected"
                                            : "Click to Book"}
                                        </span>
                                        {parseInt(
                                          slotTime.split(":")[0] || "9",
                                        ) >= 12
                                          ? `${parseInt(slotTime.split(":")[0] || "12") === 12 ? 12 : parseInt(slotTime.split(":")[0] || "12") - 12}:00 PM`
                                          : `${parseInt(slotTime.split(":")[0] || "9")}:00 AM`}
                                      </button>
                                    );
                                  },
                                )}
                              </div>
                            </div>
                          ))
                        )}
                      </div>

                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pt-4 border-t border-slate-100">
                        <p className="text-[9px] text-slate-400 max-w-sm text-left font-sans">
                          Select exactly {requiredSlotsCount} permanent{" "}
                          {requiredSlotsCount === 1 ? "slot" : "slots"} matching
                          your current <strong>{currentPlan?.name}</strong>{" "}
                          plan.
                        </p>
                        <button
                          type="button"
                          disabled={
                            savingSchedule ||
                            selectedSlots.length !== requiredSlotsCount
                          }
                          onClick={handleSaveScheduleCombined}
                          className="btn-primary flex items-center gap-2 px-6 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs disabled:opacity-50 font-bold shadow-md font-sans cursor-pointer"
                        >
                          {savingSchedule ? (
                            <Loader2 className="animate-spin" size={14} />
                          ) : (
                            <CheckCircle2 size={14} />
                          )}
                          <span>Save Permanent Slots</span>
                        </button>
                      </div>

                      {saveScheduleStatus === "success" && (
                        <div className="bg-emerald-50 border border-emerald-100 p-3 rounded-xl flex items-center gap-2 text-emerald-800 text-[11px] font-semibold animate-in slide-in-from-top duration-300 font-sans text-left">
                          <span>✅</span>
                          <span>
                            Permanent schedule updated successfully. Invitation
                            alerts dispatched inside live ledger databases.
                          </span>
                        </div>
                      )}
                      {saveScheduleStatus === "error" && (
                        <div className="bg-red-50 border border-red-100 p-3 rounded-xl flex items-center gap-2 text-red-800 text-[11px] font-semibold font-sans text-left">
                          <span>⚠️</span>
                          <span>
                            Failed to synchronize permanent calendar bookings.
                            Please contact admin.
                          </span>
                        </div>
                      )}
                    </div>
                  );
                })()
              ) : (
                <div className="bg-white p-8 rounded-3xl border border-slate-100 shadow-sm text-center py-16 space-y-6">
                  <div className="w-16 h-16 bg-indigo-50 text-indigo-600 rounded-2xl flex items-center justify-center mx-auto shadow-md">
                    <Calendar size={32} />
                  </div>
                  <div className="space-y-2">
                    <h3 className="text-xl font-bold text-slate-900 tracking-tight font-sans text-center">
                      Scheduler Deactivated
                    </h3>
                    <p className="text-slate-500 text-xs leading-relaxed max-w-sm mx-auto font-sans text-center">
                      Once you completed your trial and subscribed to an active
                      plan (Heritage Pro/Standard/Mastery), your
                      timezone-sensitive recurring slot matrix will unlock here.
                    </p>
                  </div>
                  <div className="pt-2">
                    <button
                      onClick={() => setShowEnroller(true)}
                      className="bg-slate-900 text-white font-bold px-6 py-3 rounded-xl text-xs uppercase tracking-widest hover:bg-slate-800 transition-all shadow-lg font-sans cursor-pointer"
                    >
                      Complete Academy Enrollment
                    </button>
                  </div>
                </div>
              )}
            </div>

            <div className="space-y-6">
              {/* Classroom Channel: Live Tutor Messaging Card */}
              {(() => {
                const student = activeStudent;
                const tutorId = student?.tutorId;
                const tutor = tutors.find((t) => t.id === tutorId);
                if (!tutor) return null;
                return (
                  <div className="bg-white p-6 rounded-2xl border border-slate-150 shadow-sm space-y-4 text-left font-sans animate-in fade-in duration-300">
                    <h4 className="font-extrabold text-slate-900 text-sm font-sans flex items-center gap-2">
                      <Sparkles size={16} className="text-primary" />
                      <span>Classroom Tutor</span>
                    </h4>
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-primary/10 text-primary flex items-center justify-center font-bold text-sm select-none">
                        {tutor.name?.charAt(0) || "T"}
                      </div>
                      <div>
                        <h5 className="font-bold text-slate-800 text-sm">{tutor.name}</h5>
                        <p className="text-[10px] text-slate-400 font-semibold">{tutor.specializedSyllabus || "Amharic & Ge'ez Language Coach"}</p>
                      </div>
                    </div>
                    <p className="text-xs text-slate-500 font-medium leading-relaxed italic line-clamp-2">
                      {tutor.bio || "Enthusiastic educator teaching Amharic to families abroad."}
                    </p>
                    <button
                      onClick={() => handleOpenTutorChat(tutor)}
                      className="w-full bg-primary hover:bg-opacity-95 text-white rounded-xl py-2.5 text-xs font-bold transition-all shadow-sm flex items-center justify-center gap-1.5 cursor-pointer font-sans"
                    >
                      <MessageCircle size={14} />
                      <span>Message Teacher {tutor.name}</span>
                    </button>
                  </div>
                );
              })()}

              <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm space-y-4 animate-in fade-in duration-300">
                <h4 className="font-extrabold text-slate-900 text-sm text-left font-sans">
                  Upcoming Calendar Items
                </h4>
                <div className="space-y-3">
                  {sessions.slice(0, 3).map((s, i) => (
                    <div
                      key={i}
                      className="p-3 bg-slate-50 rounded-xl border border-slate-101 text-xs flex justify-between items-center font-sans text-left"
                    >
                      <div>
                        <p className="font-bold text-slate-805">
                          {formatSafeDate(s.startTime, { weekday: "long" })}
                        </p>
                        <p className="text-[10px] text-slate-400 font-mono mt-0.5">
                          {formatSafeDate(s.startTime, {
                            hour: "2-digit",
                            minute: "2-digit",
                          })}
                        </p>
                      </div>
                      <span className="text-[9px] bg-indigo-50 text-indigo-600 font-bold px-2 py-0.5 rounded uppercase font-mono">
                        Regular
                      </span>
                    </div>
                  ))}
                  {sessions.length === 0 && (
                    <p className="text-slate-400 text-xs italic font-sans text-left">
                      No items scheduled.
                    </p>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* VIEW C: BILLING / TUITION FEES PORTAL */}
      {activeTab === "billing" && (
        <div className="space-y-8 animate-in fade-in duration-300">
          <header className="flex flex-col md:flex-row md:items-center justify-between gap-6">
            <div className="text-left font-sans">
              <h1 className="text-3xl font-bold text-primary mb-1 tracking-tight">
                Tuition & Billing
              </h1>
              <p className="text-slate-500 text-sm">
                Submit monthly remittance receipts and manage your active
                subscriptions.
              </p>
            </div>
          </header>

          <div className="bg-white rounded-3xl border border-slate-150 shadow-sm p-8 space-y-8">
            <div className="max-w-2xl text-left">
              <h2 className="text-2xl font-bold text-slate-900 mb-2 font-sans tracking-tight">
                Manual Payment Verification Center
              </h2>
              <p className="text-slate-500 text-xs font-sans">
                Please pay your tuition using one of our verified local or
                international options below, then provide your secure
                transaction reference receipt.
              </p>
            </div>

            <div className="p-6 bg-slate-900 text-white rounded-2xl relative overflow-hidden flex flex-col md:flex-row justify-between gap-6 text-left animate-in slide-in-from-top duration-300">
              <div>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-md uppercase bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 font-sans">
                  Current Plan Status
                </span>
                <h4 className="text-lg font-bold mt-2 font-sans text-white">
                  {activeStudent?.plan
                    ? `Heritage ${activeStudent.plan.toUpperCase()} Tier`
                    : "Unsubscribed"}
                </h4>
                <p className="text-xs text-slate-400 mt-1 font-sans">
                  Heritage Private Studio sessions with native Amharic speakers
                </p>
              </div>
              <div className="flex items-baseline gap-1 md:self-end font-mono text-white">
                <span className="text-2xl font-black">
                  $
                  {activeStudent?.plan
                    ? plans.find((p) => p.id === activeStudent.plan)
                        ?.price || "160"
                    : "0"}
                </span>
                <span className="text-xs opacity-60 font-sans">/ month</span>
              </div>
            </div>

            {/* CBE, Telebirr, and Abroad Receipt Form */}
            <div className="bg-slate-50 rounded-[28px] p-6 border border-slate-150 space-y-6 text-left border-dashed">
              <h3 className="font-bold text-slate-900 text-sm flex items-center gap-2 font-sans">
                <CreditCard size={16} className="text-primary" />
                <span>Submit Monthly Payment Screenshot</span>
              </h3>

              {/* Payment Type Buttons */}
              <div className="space-y-3">
                <label className="text-[10px] font-extrabold text-slate-500 uppercase tracking-widest block text-left font-sans">
                  Select Remit Channel
                </label>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  <button
                    type="button"
                    onClick={() => setPaymentType("telebirr")}
                    className={cn(
                      "p-3.5 rounded-xl border text-left transition-all flex flex-col justify-between gap-1.5 cursor-pointer bg-white font-sans",
                      paymentType === "telebirr"
                        ? "border-primary bg-primary/5 shadow-sm ring-1 ring-primary/10"
                        : "border-slate-150 hover:border-slate-300",
                    )}
                  >
                    <div className="flex items-center gap-1.5">
                      <span
                        className={cn(
                          "w-3 h-3 rounded-full border flex items-center justify-center shrink-0",
                          paymentType === "telebirr"
                            ? "border-primary text-primary"
                            : "border-slate-300",
                        )}
                      >
                        {paymentType === "telebirr" && (
                          <span className="w-1.5 h-1.5 bg-primary rounded-full"></span>
                        )}
                      </span>
                      <span className="text-[11px] font-bold text-slate-800">
                        Telebirr (Ethiopia)
                      </span>
                    </div>
                    <span className="text-[8px] text-slate-400 font-bold font-mono uppercase tracking-wider">
                      Mobile wallet
                    </span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setPaymentType("cbe")}
                    className={cn(
                      "p-3.5 rounded-xl border text-left transition-all flex flex-col justify-between gap-1.5 cursor-pointer bg-white font-sans",
                      paymentType === "cbe"
                        ? "border-primary bg-primary/5 shadow-sm ring-1 ring-primary/10"
                        : "border-slate-150 hover:border-slate-300",
                    )}
                  >
                    <div className="flex items-center gap-1.5">
                      <span
                        className={cn(
                          "w-3 h-3 rounded-full border flex items-center justify-center shrink-0",
                          paymentType === "cbe"
                            ? "border-primary text-primary"
                            : "border-slate-300",
                        )}
                      >
                        {paymentType === "cbe" && (
                          <span className="w-1.5 h-1.5 bg-primary rounded-full"></span>
                        )}
                      </span>
                      <span className="text-[11px] font-bold text-slate-800">
                        CBE Birr / Bank
                      </span>
                    </div>
                    <span className="text-[8px] text-slate-400 font-bold font-mono uppercase tracking-wider">
                      Bank Transfer
                    </span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setPaymentType("international")}
                    className={cn(
                      "p-3.5 rounded-xl border text-left transition-all flex flex-col justify-between gap-1.5 cursor-pointer bg-white font-sans",
                      paymentType === "international"
                        ? "border-primary bg-primary/5 shadow-sm ring-1 ring-primary/10"
                        : "border-slate-150 hover:border-slate-300",
                    )}
                  >
                    <div className="flex items-center gap-1.5">
                      <span
                        className={cn(
                          "w-3 h-3 rounded-full border flex items-center justify-center shrink-0",
                          paymentType === "international"
                            ? "border-primary text-primary"
                            : "border-slate-300",
                        )}
                      >
                        {paymentType === "international" && (
                          <span className="w-1.5 h-1.5 bg-primary rounded-full"></span>
                        )}
                      </span>
                      <span className="text-[11px] font-bold text-slate-800">
                        International
                      </span>
                    </div>
                    <span className="text-[8px] text-slate-400 font-bold font-mono uppercase tracking-wider">
                      Zelle, Remitly, etc.
                    </span>
                  </button>
                </div>
              </div>

              {/* Instructions text */}
              {(() => {
                const planId = activeStudent?.plan?.toLowerCase() || "";
                const matchedPlan = plans.find((p) => planId.includes(p.id)) || plans[0];
                const usdAmount = matchedPlan?.price || 160;

                const birrAmount = planId.includes("pro")
                  ? settings?.proPriceBirr || 3500
                  : planId.includes("mastery")
                    ? settings?.masteryPriceBirr || 5200
                    : settings?.standardPriceBirr || 2300;

                if (paymentType === "telebirr") {
                  return (
                    <div className="p-4 bg-white border border-slate-150 rounded-xl space-y-1.5 text-xs text-slate-600 animate-in fade-in duration-205 text-left font-sans">
                      <span className="text-[9px] uppercase font-bold text-primary tracking-wider block">
                        Telebirr Account Instructions:
                      </span>
                      <p className="leading-relaxed text-[11px]">
                        Send the subscription fee of{" "}
                        {isUSUser ? (
                          <strong className="text-slate-900 font-extrabold font-mono">
                            ${usdAmount} USD
                          </strong>
                        ) : (
                          <>
                            <strong className="text-slate-900 font-extrabold font-mono">
                              {birrAmount} Birr
                            </strong>{" "}
                            (or ${usdAmount} USD)
                          </>
                        )}{" "}
                        directly to our verified merchant code:{" "}
                        <strong className="font-extrabold text-slate-900 font-mono bg-slate-50 px-1.5 py-0.5 rounded">
                          {settings?.subTelebirrMerchantCode || "882910"}
                        </strong>{" "}
                        or transfer to Telebirr mobile number{" "}
                        <strong className="font-extrabold text-slate-900 font-mono bg-slate-50 px-1.5 py-0.5 rounded">
                          {settings?.subTelebirrNumber || "+251 912 345 678"}
                        </strong>{" "}
                        (under company name: <strong>{settings?.subTelebirrName || "HabKids tutor"}</strong>).
                      </p>
                    </div>
                  );
                }

                if (paymentType === "cbe") {
                  return (
                    <div className="p-4 bg-white border border-slate-150 rounded-xl space-y-1.5 text-xs text-slate-600 animate-in fade-in duration-205 text-left font-sans">
                      <span className="text-[9px] uppercase font-bold text-primary tracking-wider block font-sans">
                        CBE Account Bank Instructions:
                      </span>
                      <p className="leading-relaxed text-[11px]">
                        Deposit or wire transfer your subscription fee of{" "}
                        {isUSUser ? (
                          <strong className="font-extrabold text-slate-900 font-mono bg-slate-50 px-1.5 py-0.5 rounded">
                            ${usdAmount} USD
                          </strong>
                        ) : (
                          <>
                            <strong className="font-extrabold text-slate-900 font-mono bg-slate-50 px-1.5 py-0.5 rounded">
                              {birrAmount} Birr
                            </strong>{" "}
                            (or ${usdAmount} USD)
                          </>
                        )}{" "}
                        directly to CBE corporate account name{" "}
                        <strong>{settings?.subCbeAccountName || "HabKids Language School"}</strong>:<br />
                        <strong className="font-extrabold text-slate-900 font-mono bg-slate-50 px-2.5 py-0.5 rounded mt-1 inline-block">
                          ID: {settings?.subCbeAccountNumber || "1000492811726"}
                        </strong>
                      </p>
                    </div>
                  );
                }

                if (paymentType === "international") {
                  return (
                    <div className="p-4 bg-white border border-slate-150 rounded-xl space-y-3 text-xs text-slate-600 animate-in fade-in duration-205 text-left font-sans">
                      <span className="text-[9px] uppercase font-bold text-primary tracking-wider block font-sans font-black">
                        🇺🇸 Zelle (USA Abroad) Instructions:
                      </span>
                      <div className="space-y-2.5 leading-relaxed text-[11px]">
                        <div>
                          <p className="font-bold text-slate-900">🔹 US Parents:</p>
                          <p className="text-slate-500 pl-4">
                            Zelle payments can be dispatched directly to our secure US payment endpoint:{" "}
                            <strong className="font-bold text-slate-800 font-mono">
                              {settings?.subZelleEmail || "payment@heritageacademy.com"}
                            </strong>
                            {settings?.subZelleName && (
                              <span className="text-[10px] text-slate-400 block mt-0.5">
                                Account Name: <strong>{settings.subZelleName}</strong>
                              </span>
                            )}
                          </p>
                        </div>
                        <div>
                          <p className="font-bold text-slate-900">
                            🔹 Canada, UK, Europe, & Australia Parents:
                          </p>
                          <p className="text-slate-500 pl-4">
                            Submit via reliable global transaction systems such as{" "}
                            <strong className="text-slate-850 font-bold">
                              Remitly
                            </strong>{" "}
                            or{" "}
                            <strong className="text-slate-850 font-bold">
                              Sendwave
                            </strong>{" "}
                            directly to our US Zelle address (
                            <strong className="text-slate-800 font-mono">
                              {settings?.subZelleEmail || "payment@heritageacademy.com"}
                            </strong>
                            ) or as a mobile envelope deposit of{" "}
                            {isUSUser ? (
                              <strong className="text-slate-900 font-bold">${usdAmount} USD</strong>
                            ) : (
                              <strong className="text-slate-900 font-bold">{birrAmount} Birr</strong>
                            )}{" "}
                            to corporate Telebirr number (
                            <strong className="text-slate-800 font-mono">
                              {settings?.subTelebirrNumber || "+251 912 345 678"}
                            </strong>
                            ).
                          </p>
                        </div>
                      </div>
                    </div>
                  );
                }

                return null;
              })()}

              {/* Secure Inputs */}
              <div className="border-t border-slate-150 pt-4 space-y-3">
                <span className="text-[9px] font-extrabold text-slate-400 uppercase tracking-widest block text-left font-sans">
                  Secure Payment Verification Details
                </span>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5 text-left">
                  <div className="space-y-1">
                    <label className="text-[9px] font-bold text-slate-500 uppercase tracking-wider block text-left font-sans">
                      Transaction Reference ID{" "}
                      <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. CBE-TXN-9817 / Zelle ID 182"
                      value={transactionRef}
                      onChange={(e) => setTransactionRef(e.target.value)}
                      className="w-full bg-white border border-slate-205 rounded-lg px-3 py-2 text-xs text-slate-850 font-mono outline-none focus:ring-1 focus:ring-primary focus:border-primary transition-all font-bold"
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-[9px] font-bold text-slate-500 uppercase tracking-wider block text-left font-sans">
                      Uploader Screenshot{" "}
                      <span className="text-red-500">*</span>
                    </label>
                    <div className="relative border border-dashed border-slate-205 bg-white rounded-lg hover:bg-slate-50/50 transition-colors cursor-pointer flex items-center justify-between p-2">
                      <input
                        type="file"
                        id="billing-receipt-upload"
                        accept="image/*,application/pdf"
                        onChange={async (e) => {
                          const file = e.target.files?.[0];
                          if (file) {
                            setReceiptScreenshotName(file.name);
                            try {
                              const base64 = await compressImageToBase64(file, 800 * 1024);
                              setReceiptScreenshotBase64(base64);
                            } catch (err: any) {
                              alert(err.message || "Failed to compress/read receipt screenshot.");
                            }
                          }
                        }}
                        className="absolute inset-0 opacity-0 cursor-pointer h-full w-full"
                      />
                      <div className="flex items-center gap-1.5 max-w-[170px] truncate">
                        <span className="text-xs">📎</span>
                        <span className="text-[10px] font-bold text-slate-500 truncate font-sans">
                          {receiptScreenshotName || "Attach snapshot..."}
                        </span>
                      </div>
                      <span className="text-[8px] font-bold uppercase bg-slate-50 hover:bg-slate-100 px-2 py-1.5 rounded-md border text-slate-700 tracking-wider font-sans">
                        Browse
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Submit Monthly receipt */}
            <div className="flex justify-end pt-4">
              <button
                type="button"
                onClick={() => {
                  if (!transactionRef || !receiptScreenshotName) {
                    alert(
                      "Please fill in the Transaction Reference ID and attach a valid Screenshot Receipt.",
                    );
                    return;
                  }
                  if (activeStudent) {
                    handleRenewal(activeStudent);
                  } else {
                    alert(
                      "No enrolled student found to credit payment to. Contact support.",
                    );
                  }
                }}
                disabled={
                  isRenewing || !transactionRef || !receiptScreenshotName
                }
                className="bg-primary text-white font-bold px-10 py-3.5 rounded-2xl text-xs uppercase tracking-widest hover:bg-primary/95 disabled:opacity-50 transition-all flex items-center gap-2 shadow-lg font-sans cursor-pointer"
              >
                {isRenewing ? (
                  <Loader2 className="animate-spin" size={16} />
                ) : (
                  <CheckCircle2 size={16} />
                )}
                <span>Transmit Monthly Remittance</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* VIEW D: ACADEMIC PROGRESS */}
      {activeTab === "progress" && (
        <div className="space-y-6 animate-in fade-in duration-300">
          <header className="flex flex-col md:flex-row md:items-center justify-between gap-6 font-sans">
            <div className="text-left">
              <h1 className="text-3xl font-bold text-primary mb-1 tracking-tight">
                Academic Progress
              </h1>
              <p className="text-slate-500 text-sm">
                Review vocabulary milestones and teacher session comments.
              </p>
            </div>
          </header>

          <div className="grid lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 space-y-6">
              <div className="bg-white p-6 md:p-8 rounded-2xl border border-slate-100 shadow-sm space-y-6 text-left">
                <h3 className="font-bold text-slate-900 text-base font-sans">
                  Tutor Classroom Remarks
                </h3>

                {/* Official trial session remarks from Firestore document */}
                {trialSession?.evaluation ? (
                  <div className="bg-orange-50/50 border border-orange-100 p-5 rounded-xl space-y-3 text-left">
                    <p className="text-[10px] uppercase font-black text-orange-600 tracking-wider font-sans">
                      Trial Session Assessment
                    </p>
                    <p className="text-slate-700 italic text-xs leading-relaxed font-sans">
                      "{trialSession.evaluation}"
                    </p>
                    <div className="flex items-center gap-2 text-[10px] text-slate-400 font-sans">
                      <span>
                        👤 Tutor: {trialSession.tutorName || "Assigned Tutor"}
                      </span>
                      <span>
                        • Recommendation: Level{" "}
                        {trialSession.recommendedLevel || "1"}
                      </span>
                    </div>
                  </div>
                ) : (
                  <div className="p-4 bg-slate-50 rounded-xl text-center text-slate-400 italic text-xs font-sans">
                    No standardized evaluation posted for this active profile.
                  </div>
                )}

                {/* Class Lesson logs placeholder feedback queue */}
                <div className="space-y-4">
                  <span className="text-[10px] font-extrabold text-slate-400 uppercase tracking-widest block font-sans">
                    Class Remarks History
                  </span>
                  <div className="border border-slate-100 rounded-xl divide-y divide-slate-100 overflow-hidden bg-slate-50/20">
                    <div className="p-5 space-y-2 text-left">
                      <div className="flex justify-between items-start font-sans">
                        <p className="font-bold text-slate-905 text-xs text-indigo-700">
                          Ge'ez Alphabets & Vowel Reading
                        </p>
                        <span className="text-[8px] font-bold font-mono text-slate-400">
                          MAY 18, 2026
                        </span>
                      </div>
                      <p className="text-xs text-slate-500 leading-relaxed font-sans">
                        "Your child performed exceptionally today! Correctly
                        pronounced all vowel sounds and identified 10 baseline
                        Amharic consonants. We practiced greeting structures
                        with excellent engagement. Recommendation: Please review
                        Consonant flashcards."
                      </p>
                      <p className="text-[10px] text-slate-400 font-semibold font-sans">
                        • Logged by{" "}
                        {sessions[0]?.tutorName || "Heritage Native Speaker"}
                      </p>
                    </div>

                    <div className="p-5 space-y-2 text-left">
                      <div className="flex justify-between items-start font-sans">
                        <p className="font-bold text-slate-905 text-xs">
                          Sentence Structures & Possessive Pronouns
                        </p>
                        <span className="text-[8px] font-bold font-mono text-slate-400">
                          MAY 11, 2026
                        </span>
                      </div>
                      <p className="text-xs text-slate-500 leading-relaxed font-sans">
                        "Great lesson focus on personal pronouns (I, You, He,
                        She) and possessive terminology. Excellent pronunciation
                        clarity displayed during oral quizzes. Participation and
                        focus metrics remain at 100%!"
                      </p>
                      <p className="text-[10px] text-slate-400 font-semibold font-sans">
                        • Logged by{" "}
                        {sessions[0]?.tutorName || "Heritage Native Speaker"}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="space-y-6">
              <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm space-y-4 text-left">
                <h4 className="font-extrabold text-slate-900 text-sm font-sans font-black">
                  Roster Summary
                </h4>
                <div className="space-y-3.5 font-sans">
                  <div className="flex justify-between text-xs py-1 border-b border-slate-50">
                    <span className="text-slate-400">Assigned Level</span>
                    <span className="font-bold text-slate-800">
                      Level{" "}
                      {primaryStudent?.level ||
                        trialSession?.recommendedLevel ||
                        "1"}
                    </span>
                  </div>
                  <div className="flex justify-between text-xs py-1 border-b border-slate-50">
                    <span className="text-slate-400">Total Completed</span>
                    <span className="font-bold text-slate-800">
                      {primaryStudent?.sessionsCompleted || 0} Lessons
                    </span>
                  </div>
                  <div className="flex justify-between text-xs py-1">
                    <span className="text-slate-400">Attendance Index</span>
                    <span className="font-bold text-slate-800">
                      {primaryStudent?.attendance || "100%"}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* VIEW F: HELP & SUPPORT TICKETS */}
      {activeTab === "support" && (
        <div className="max-w-6xl mx-auto space-y-6 animate-in fade-in duration-300">
          <header className="mb-2 text-left font-sans">
            <h1 className="text-3xl font-bold text-primary mb-1 tracking-tight text-left font-sans">
              Help & Support Center
            </h1>
            <p className="text-slate-500 text-sm text-left font-sans font-medium">
              Dual Private Communication Portal. Choose the direct administrative helpdesk or your child's classroom educator below.
            </p>
          </header>

          {/* Dual Channel Choice Panel */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Channel 1 Card */}
            <button
              onClick={() => setActiveSupportChannelTab("admin")}
              className={cn(
                "p-5 rounded-2xl border-2 text-left transition-all hover:scale-[1.01] flex items-start gap-4 cursor-pointer shadow-sm relative overflow-hidden",
                activeSupportChannelTab === "admin"
                  ? "border-primary bg-primary/5 ring-1 ring-primary/20"
                  : "border-slate-150 bg-white hover:border-slate-350"
              )}
            >
              <div className="w-10 h-10 rounded-xl bg-orange-100 text-orange-600 flex items-center justify-center shrink-0">
                <ShieldCheck size={20} />
              </div>
              <div className="space-y-1">
                <h3 className="font-extrabold text-slate-900 text-sm flex items-center gap-2 font-sans">
                  <span>Channel 1: Contact Support</span>
                  <span className="text-[9px] font-extrabold bg-orange-50 text-orange-600 px-1.5 py-0.5 rounded border border-orange-100 uppercase tracking-widest block font-sans">
                    Goes to Admin
                  </span>
                </h3>
                <p className="text-xs text-slate-500 font-medium leading-relaxed font-sans mt-1">
                  Billing issues, schedule changes, plan upgrades, and direct feedback. This thread is kept completely private between you and Admin. The tutor has zero access.
                </p>
              </div>
            </button>

            {/* Channel 2 Card */}
            <button
              onClick={() => setActiveSupportChannelTab("tutor")}
              className={cn(
                "p-5 rounded-2xl border-2 text-left transition-all hover:scale-[1.01] flex items-start gap-4 cursor-pointer shadow-sm relative overflow-hidden",
                activeSupportChannelTab === "tutor"
                  ? "border-primary bg-primary/5 ring-1 ring-primary/20"
                  : "border-slate-150 bg-white hover:border-slate-350"
              )}
            >
              <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-600 flex items-center justify-center shrink-0">
                <BookOpen size={20} />
              </div>
              <div className="space-y-1">
                <h3 className="font-extrabold text-slate-900 text-sm flex items-center gap-2 font-sans">
                  <span>Channel 2: Message Tutor</span>
                  <span className="text-[9px] font-extrabold bg-emerald-50 text-emerald-600 px-1.5 py-0.5 rounded border border-emerald-100 uppercase tracking-widest block font-sans font-sans">
                    {currentAssignedTutor ? `Teacher ${currentAssignedTutor.name}` : "Goes to Tutor"}
                  </span>
                </h3>
                <p className="text-xs text-slate-500 font-medium leading-relaxed font-sans mt-1">
                  Direct line to your child's educator. Discuss syllabus focus, coordinates, and homework. Security filters protect contact files, and conversation logs sync with Admin.
                </p>
              </div>
            </button>
          </div>

          {activeSupportChannelTab === "admin" ? (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start font-sans">
            
            {/* Left Hand: Create / Ticket list */}
            <div className="lg:col-span-4 space-y-4">
              {/* Ticket Creator Card */}
              <div className="bg-white border border-slate-150 rounded-2xl p-5 shadow-sm text-left">
                <h3 className="font-extrabold text-slate-900 text-sm mb-3">
                  Submit a Query
                </h3>
                <form onSubmit={handleCreateSupportTicket} className="space-y-3 font-sans">
                  <div className="space-y-1">
                    <label className="text-[10px] font-extrabold text-slate-500 uppercase tracking-wider block font-sans">
                      Topic
                    </label>
                    <select
                      value={newTicketTopic}
                      onChange={(e) => setNewTicketTopic(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs font-semibold text-slate-800 outline-none focus:ring-1 focus:ring-primary focus:bg-white"
                    >
                      <option>Curriculum & Program structure</option>
                      <option>Schedule & Availability shifts</option>
                      <option>Billing, Plans & Payment Methods</option>
                      <option>Software, Audio or Connection issues</option>
                      <option>Other queries</option>
                    </select>
                  </div>

                  <div className="space-y-1">
                    <label className="text-[10px] font-extrabold text-slate-500 uppercase tracking-wider block font-sans">
                      Your Question
                    </label>
                    <textarea
                      required
                      placeholder="Describe your inquiry in detail..."
                      value={newTicketQuestion}
                      onChange={(e) => setNewTicketQuestion(e.target.value)}
                      rows={4}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-800 outline-none focus:ring-1 focus:ring-primary focus:bg-white transition-all font-medium"
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={submittingTicket}
                    className="w-full bg-primary hover:bg-opacity-95 text-white rounded-xl py-2 text-xs font-bold transition-all shadow-sm flex items-center justify-center gap-1 cursor-pointer"
                  >
                    {submittingTicket ? (
                      <>
                        <Loader2 className="animate-spin text-white" size={14} />
                        <span>Sending ticket...</span>
                      </>
                    ) : (
                      <span>Submit Ticket</span>
                    )}
                  </button>
                </form>
              </div>

              {/* Existing Tickets Card */}
              <div className="bg-white border border-slate-150 rounded-2xl p-5 shadow-sm text-left">
                <h3 className="font-extrabold text-slate-900 text-sm mb-3">
                  Your Recent Support Tickets
                </h3>
                {myTickets.length === 0 ? (
                  <p className="text-xs text-slate-400 font-medium py-2">
                    No support tickets submitted yet.
                  </p>
                ) : (
                  <div className="space-y-2 max-h-[300px] overflow-y-auto pr-1">
                    {myTickets.map((tc) => {
                      const isSelected = selectedTicketId === tc.id;
                      const dateStr = formatSafeDate(tc.createdAt, { month: 'short', day: 'numeric' });
                      const replyCount = tc.replies?.length || 0;
                      return (
                        <button
                          key={tc.id}
                          onClick={() => setSelectedTicketId(tc.id)}
                          className={cn(
                            "w-full text-left p-3 rounded-xl border text-xs transition-all flex flex-col gap-1 cursor-pointer",
                            isSelected
                              ? "bg-slate-50 border-primary shadow-sm"
                              : "bg-white border-slate-200 hover:bg-slate-50/50"
                          )}
                        >
                          <div className="flex justify-between items-start gap-1">
                            <span className="font-extrabold text-slate-800 truncate block max-w-[150px]">
                              {tc.topic || "Support Ticket"}
                            </span>
                            <span className={cn(
                              "px-1.5 py-0.5 rounded text-[9px] font-bold uppercase tracking-wider shrink-0",
                              tc.status === "resolved" 
                                ? "bg-emerald-100 text-emerald-700" 
                                : "bg-blue-100 text-blue-700 font-bold"
                            )}>
                              {tc.status || "open"}
                            </span>
                          </div>
                          <p className="text-slate-500 font-medium line-clamp-1">
                            {tc.question}
                          </p>
                          <div className="flex justify-between items-center text-[10px] text-slate-400 mt-1 font-semibold">
                            <span>{dateStr}</span>
                            <span>{replyCount} {replyCount === 1 ? 'reply' : 'replies'}</span>
                          </div>
                        </button>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>

            {/* Right Hand: Ticket Detail Thread */}
            <div className="lg:col-span-8 bg-white border border-slate-150 rounded-2xl shadow-sm p-6 flex flex-col min-h-[480px]">
              {selectedTicketId ? (() => {
                const activeTicket = myTickets.find(t => t.id === selectedTicketId);
                if (!activeTicket) {
                  return (
                    <div className="flex-1 flex flex-col items-center justify-center text-slate-400">
                      <Loader2 className="animate-spin text-secondary mb-2" size={32} />
                      <p className="text-sm font-semibold">Loading ticket details...</p>
                    </div>
                  );
                }
                const docDateStr = formatSafeDate(activeTicket.createdAt, { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
                return (
                  <div className="flex-1 flex flex-col">
                    {/* Header */}
                    <div className="border-b border-slate-100 pb-4 mb-4 flex justify-between items-center text-left">
                      <div>
                        <span className="text-[10px] font-extrabold text-primary uppercase tracking-widest block font-extrabold mb-0.5">
                          {activeTicket.topic || "Support Ticket"}
                        </span>
                        <h2 className="text-lg font-bold text-slate-900 tracking-tight">
                          Ticket Inquiry
                        </h2>
                        <span className="text-[10px] text-slate-400 font-semibold block mt-0.5">
                          Submitted on {docDateStr}
                        </span>
                      </div>
                      <span className={cn(
                        "px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider shrink-0",
                        activeTicket.status === "resolved" 
                          ? "bg-emerald-100 text-emerald-700" 
                          : "bg-blue-100 text-blue-700 font-bold"
                      )}>
                        {activeTicket.status || "open"}
                      </span>
                    </div>

                    {/* Original Question */}
                    <div className="bg-slate-50 border border-slate-100 rounded-2xl p-4 text-left mb-6">
                      <div className="flex items-center gap-2 mb-1.5 font-sans">
                        <div className="w-5 h-5 rounded-full bg-primary/10 text-primary flex items-center justify-center font-bold text-[10px]">
                          P
                        </div>
                        <span className="text-xs font-bold text-slate-800">
                          {activeTicket.parentName} <span className="font-medium text-slate-400">({activeTicket.parentEmail})</span>
                        </span>
                      </div>
                      <p className="text-xs text-slate-600 font-medium leading-relaxed whitespace-pre-wrap pl-7">
                        {activeTicket.question}
                      </p>
                    </div>

                    {/* Replies Log */}
                    <h4 className="font-extrabold text-slate-900 text-xs text-left mb-3">
                      Dialogue & Resolution Log ({activeTicket.replies?.length || 0})
                    </h4>
                    <div className="flex-1 space-y-4 overflow-y-auto max-h-[250px] mb-4 pr-1">
                      {(!activeTicket.replies || activeTicket.replies.length === 0) ? (
                        <div className="text-center py-6">
                          <p className="text-xs text-slate-400 font-medium">
                            Our administration team was notified. An administrator will respond shortly.
                          </p>
                        </div>
                      ) : (
                        activeTicket.replies.map((reply: any, rId: number) => {
                          const isAdminRole = reply.senderRole === "admin";
                          return (
                            <div
                              key={rId}
                              className={cn(
                                "flex flex-col gap-1 p-3 rounded-2xl border text-xs text-left max-w-[85%] leading-relaxed",
                                isAdminRole
                                  ? "bg-secondary/5 border-secondary/15 ml-auto text-slate-800"
                                  : "bg-slate-50/50 border-slate-100 mr-auto text-slate-700"
                              )}
                            >
                              <div className="flex items-center gap-2 mb-1 font-sans">
                                <span className={cn(
                                  "font-extrabold text-[10px] uppercase tracking-wider",
                                  isAdminRole ? "text-secondary" : "text-slate-600"
                                )}>
                                  {isAdminRole ? "🛡️ Administrator" : reply.senderName || "Parent"}
                                </span>
                              </div>
                              <p className="font-medium whitespace-pre-wrap">
                                {reply.text}
                              </p>
                            </div>
                          );
                        })
                      )}
                    </div>

                    {/* Reply Input Form */}
                    {activeTicket.status !== "resolved" ? (
                      <form onSubmit={handleSendSupportReply} className="mt-auto border-t border-slate-100 pt-4 flex gap-2 font-sans">
                        <input
                          type="text"
                          placeholder="Type reply or additional inquiry detail..."
                          value={ticketReplyText}
                          onChange={(e) => setTicketReplyText(e.target.value)}
                          className="flex-1 bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-xs text-slate-800 outline-none focus:ring-1 focus:ring-primary focus:bg-white focus:border-primary font-medium"
                        />
                        <button
                          type="submit"
                          disabled={sendingTicketReply || !ticketReplyText.trim()}
                          className="bg-primary hover:bg-opacity-95 text-white rounded-xl px-5 text-xs font-bold transition-all shadow-none flex items-center justify-center gap-1 shrink-0 cursor-pointer disabled:opacity-50"
                        >
                          {sendingTicketReply ? (
                            <Loader2 className="animate-spin text-white" size={14} />
                          ) : (
                            <span>Send</span>
                          )}
                        </button>
                      </form>
                    ) : (
                      <div className="mt-auto border-t border-slate-100 pt-4 bg-emerald-50 border border-emerald-100 rounded-xl p-3 text-center font-sans">
                        <p className="text-xs text-emerald-700 font-semibold mb-0.5">
                          🛡️ This inquiry has been resolved.
                        </p>
                        <p className="text-[10px] text-emerald-600 font-medium">
                          If you have a follow-up query, please submit a new ticket on the left panel.
                        </p>
                      </div>
                    )}
                  </div>
                );
              })() : (
                <div className="flex-1 flex flex-col items-center justify-center text-slate-400 py-12 font-sans">
                  <div className="w-12 h-12 rounded-full bg-slate-50 text-slate-400 flex items-center justify-center mb-3">
                    <Inbox size={24} className="stroke-[1.5]" />
                  </div>
                  <h3 className="font-bold text-slate-700 text-sm mb-1">
                    No ticket selected
                  </h3>
                  <p className="text-xs text-slate-400 font-medium max-w-sm leading-relaxed text-center">
                    Select an existing support ticket on the left pane to view its dialogue logs, or create a brand new ticket to summon help.
                  </p>
                </div>
              )}
            </div>
          </div>
        ) : !currentAssignedTutor ? (
            <div className="bg-white border border-slate-150 rounded-3xl p-10 py-12 text-center max-w-xl mx-auto space-y-4 shadow-sm animate-in fade-in duration-300">
              <div className="w-14 h-14 rounded-full bg-slate-50 text-slate-450 flex items-center justify-center mx-auto ring-4 ring-slate-100">
                <BookOpen size={24} />
              </div>
              <div className="space-y-1.5">
                <h3 className="font-extrabold text-slate-850 text-base font-sans">Tutor Pairing In Progress</h3>
                <p className="text-xs text-slate-550 leading-relaxed font-semibold font-sans">
                  HabKids matching directors are currently pairing your child with one of our native educators. Once the matching review completes, you'll see a direct classroom message line right here.
                </p>
              </div>
              <div className="pt-2">
                <button
                  onClick={() => setActiveSupportChannelTab("admin")}
                  className="bg-primary hover:bg-opacity-95 text-white font-bold px-6 py-2.5 rounded-xl text-xs transition-all shadow cursor-pointer font-sans"
                >
                  Need assistance? Send message
                </button>
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start font-sans animate-in fade-in duration-300">
              
              {/* Left: Tutor Profile info */}
              <div className="lg:col-span-4 bg-white border border-slate-150 rounded-2xl p-5 shadow-sm text-left space-y-4">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-full bg-primary/10 text-primary flex items-center justify-center font-bold text-lg border border-primary/20 shrink-0">
                    {currentAssignedTutor.name?.charAt(0) || "T"}
                  </div>
                  <div>
                    <h4 className="font-extrabold text-slate-900 text-sm leading-tight font-sans">
                      Instructor Profile
                    </h4>
                    <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider mt-0.5 font-sans">
                      Heritage Language Team
                    </p>
                  </div>
                </div>

                <div className="border-t border-slate-100 pt-3.5 space-y-2">
                  <h5 className="font-bold text-slate-800 text-xs font-sans">Teacher {currentAssignedTutor.name}</h5>
                  <p className="text-[11px] text-slate-505 font-medium leading-relaxed leading-5">
                    {currentAssignedTutor.bio || "Certified native tutor dedicated to teaching heritage Amharic and Ge'ez alphabet reading, speech and phonetic blend skills to children abroad."}
                  </p>
                </div>

                <div className="border-t border-slate-100 pt-3.5 space-y-2 text-xs">
                  <div className="flex justify-between font-semibold font-sans">
                    <span className="text-slate-400">Specialization:</span>
                    <span className="font-bold text-slate-800">{currentAssignedTutor.specializedSyllabus || "Amharic & Ge'ez"}</span>
                  </div>
                  <div className="flex justify-between font-semibold font-sans">
                    <span className="text-slate-400">Rating Index:</span>
                    <span className="font-bold text-slate-800">5.0 / 5.0 ⭐</span>
                  </div>
                </div>

                <div className="bg-amber-50 border border-amber-100 rounded-xl p-3 text-[10px] text-amber-950 font-semibold leading-normal font-sans">
                  ⚠️ Security Warning: For child safety and communication transparency, exchange of passwords, external Zoom lines, WhatsApp numbers, or emails is strictly blocked.
                </div>
              </div>

              {/* Right: Embedded Live Chat Room */}
              <div className="lg:col-span-8 bg-white border border-slate-150 rounded-2xl shadow-sm flex flex-col min-h-[500px]">
                {/* Chat Room Header */}
                <div className="p-4 border-b border-slate-100 flex items-center justify-between text-left">
                  <div>
                    <span className="text-[10px] font-extrabold text-primary uppercase tracking-widest block mb-0.5 font-extrabold">
                      Real-Time Classroom Channel
                    </span>
                    <h3 className="font-extrabold text-slate-900 text-sm font-sans">
                      Direct Line to {currentAssignedTutor.name}
                    </h3>
                  </div>
                  <div className="flex items-center gap-1.5 shrink-0">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                    <span className="text-[9px] font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-100 uppercase tracking-widest">
                      Connected
                    </span>
                  </div>
                </div>

                {/* Message Bubbles Container */}
                <div className="flex-1 p-5 overflow-y-auto max-h-[350px] space-y-4 bg-slate-50/20 text-left min-h-[300px]">
                  {tutorChatMessages.length === 0 ? (
                    <div className="h-[200px] flex flex-col items-center justify-center text-slate-400 text-center font-sans">
                      <div className="w-10 h-10 rounded-full bg-primary/5 text-primary flex items-center justify-center mb-2.5 font-sans">
                        <MessageCircle size={18} className="stroke-[1.5]" />
                      </div>
                      <h5 className="font-bold text-slate-705 text-xs mb-1 font-sans">Start of Dialogue</h5>
                      <p className="text-[10px] text-slate-450 font-semibold leading-relaxed max-w-sm mx-auto font-sans">
                        Welcome to your private classroom communication channel with Teacher {currentAssignedTutor.name}. Type your message below to send directly to your teacher.
                      </p>
                    </div>
                  ) : (
                    tutorChatMessages.map((msg: any) => {
                      const isMe = msg.senderId === user?.uid;
                      const dateStr = formatSafeDate(msg.createdAt, { hour: '2-digit', minute: '2-digit' });
                      return (
                        <div
                          key={msg.id}
                          className={cn(
                            "flex flex-col max-w-[80%] gap-0.5 text-xs text-left",
                            isMe ? "ml-auto items-end" : "mr-auto items-start"
                          )}
                        >
                          <span className="text-[9px] font-bold text-slate-400 uppercase tracking-wider">
                            {isMe ? "You (Parent)" : msg.senderName}
                          </span>
                          <div
                            className={cn(
                              "px-3 py-2 rounded-2xl border font-semibold whitespace-pre-wrap leading-relaxed",
                              isMe
                                ? "bg-primary border-primary text-white rounded-tr-none shadow-xs"
                                : "bg-white border-slate-200 text-slate-800 rounded-tl-none shadow-xs"
                            )}
                          >
                            {msg.text}
                          </div>
                          <span className="text-[9px] text-slate-400 font-semibold">
                            {dateStr}
                          </span>
                        </div>
                      );
                    })
                  )}
                  <div ref={messagesEndRef} />
                </div>

                {/* Interactive Warning banner */}
                {tutorChatViolationWarning && (
                  <div className="bg-rose-50 border-y border-rose-100 p-2.5 text-left text-rose-800 text-[10px] font-extrabold flex items-center gap-2">
                    <span>⚠️</span>
                    <span>{tutorChatViolationWarning}</span>
                  </div>
                )}

                {/* Chat Input form */}
                <form onSubmit={handleSendTutorMessage} className="p-4 border-t border-slate-100 bg-white flex gap-2">
                  <input
                    type="text"
                    placeholder={`Type classroom message details for Teacher ${currentAssignedTutor.name}...`}
                    value={tutorChatMessageInput}
                    disabled={sendingTutorChatMessageState}
                    onChange={(e) => setTutorChatMessageInput(e.target.value)}
                    className="flex-1 bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-xs text-slate-800 outline-none focus:ring-1 focus:ring-primary focus:bg-white focus:border-primary font-medium"
                  />
                  <button
                    type="submit"
                    disabled={sendingTutorChatMessageState || !tutorChatMessageInput.trim()}
                    className="bg-primary hover:bg-opacity-95 text-white rounded-xl px-5 text-xs font-bold transition-all shadow-none flex items-center justify-center gap-1 shrink-0 cursor-pointer disabled:opacity-50 font-sans"
                  >
                    {sendingTutorChatMessageState ? (
                      <Loader2 className="animate-spin text-white" size={14} />
                    ) : (
                      <span>Send</span>
                    )}
                  </button>
                </form>
              </div>

            </div>
          )}

        </div>
      )}

      {/* VIEW F: REFERRAL & LOYALTY AMBASSADOR PLATFORM */}
      {activeTab === "referrals" && (
        <div className="max-w-4xl mx-auto space-y-8 animate-in fade-in duration-300 text-left font-sans">
          
          {/* Header Billboard */}
          <div className="bg-slate-900 rounded-[32px] p-8 md:p-12 text-white relative overflow-hidden shadow-xl border border-slate-800">
            <div className="absolute right-0 top-0 w-96 h-96 bg-primary/10 rounded-full blur-3xl -z-10" />
            <div className="absolute left-1/3 bottom-0 w-72 h-72 bg-secondary/15 rounded-full blur-3xl -z-10" />
            
            <div className="max-w-2xl text-left">
              <span className="bg-primary hover:bg-primary/90 text-white text-[10px] font-extrabold uppercase tracking-widest px-3 py-1.5 rounded-full font-sans mb-4 inline-block shadow-sm">
                🏆 HabKids Partnership Club
              </span>
              <h1 className="text-3xl md:text-4xl font-black tracking-tight leading-tight mb-3 font-sans">
                Earn Cash & Free Classes as a HabKids Ambassador!
              </h1>
              <p className="text-slate-400 text-sm leading-relaxed mb-6 font-sans">
                Whether you are a supportive parent, educator, custom affiliate marketer, or friend, join HabKids in introducing children abroad to Amharic and Ge'ez. Share your custom ambassador link to grant invited families <strong className="text-white">{settings?.referralDiscountPercent ?? 10}% off</strong> their plan, while you unlock <strong className="text-white">${settings?.referralCommissionRate ?? 9}.00 USD cash</strong> or <strong className="text-white">{settings?.referralBonusCredits ?? 1} free bonus class</strong> for every enrollment!
              </p>
              
              <div className="flex flex-wrap items-center gap-3">
                <a
                  href={`https://wa.me/251940651491?text=Hi%20HabKids%20Tutors!%20I%20am%20interested%20in%20scaling%20my%20ambassador%20influence...`}
                  target="_blank"
                  referrerPolicy="no-referrer"
                  className="bg-emerald-500 hover:bg-emerald-600 px-5 py-3 rounded-2xl text-xs font-bold text-white tracking-widest transition-all shadow-md flex items-center gap-2"
                >
                  💬 WhatsApp Support Liaison
                </a>
                <button
                  type="button"
                  onClick={() => {
                    const el = document.getElementById("commission-box");
                    el?.scrollIntoView({ behavior: 'smooth' });
                  }}
                  className="bg-slate-800 hover:bg-slate-755 border border-slate-700 px-5 py-3 rounded-2xl text-xs font-bold text-slate-200 tracking-widest transition-all"
                >
                  💰 Claim Payout Earnings
                </button>
              </div>
            </div>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            
            {/* Column 1: Custom Code & Direct Sharing Card */}
            <div className="md:col-span-2 space-y-6">
              
              <div className="bg-white rounded-3xl border border-slate-150 p-6 md:p-8 space-y-6 shadow-sm">
                <div className="border-b border-rose-50/50 pb-4">
                  <h3 className="text-base font-extrabold text-slate-900 tracking-tight text-left flex items-center gap-2">
                    <Gift size={18} className="text-primary" />
                    <span>Your Unique Referral Credentials</span>
                  </h3>
                  <p className="text-[11px] text-slate-400 font-medium font-sans">
                    Instantly copy or personalize your code below to begin sharing immediately.
                  </p>
                </div>
                
                <div className="space-y-4 font-sans">
                  <div>
                    <label className="text-[10px] font-extrabold text-slate-500 uppercase tracking-widest block mb-2 font-sans">
                      Active Shareable Coupon Code
                    </label>
                    <div className="flex items-center gap-2 font-sans">
                      <div className="flex-1 bg-slate-50 border border-slate-150 hover:border-slate-200 px-4 py-3 rounded-2xl text-base font-bold font-mono text-center text-slate-800 tracking-widest shadow-inner select-all">
                        {myReferralCode || "Generating code..."}
                      </div>
                      <button
                        type="button"
                        onClick={() => {
                          const referralLink = `${window.location.protocol}//${window.location.host}/?ref=${myReferralCode}`;
                          navigator.clipboard.writeText(referralLink);
                          setCopiedReferral(true);
                          setTimeout(() => setCopiedReferral(false), 2500);
                        }}
                        className="bg-primary hover:bg-primary/95 text-white font-bold p-3.5 rounded-2xl text-xs transition-all shadow-md hover:scale-[1.03] active:scale-[0.97]"
                      >
                        {copiedReferral ? "✓ Link Copied!" : "📋 Copy Refer Link"}
                      </button>
                    </div>
                  </div>

                  {/* Customizable Code Area */}
                  <div className="bg-slate-50/70 p-4 rounded-2xl border border-slate-100/100 space-y-3 font-sans">
                    <p className="text-xs font-bold text-slate-800 leading-relaxed font-sans">
                      ✍_ Custom Ambassador Code Personalization
                    </p>
                    <p className="text-[11px] text-slate-500 leading-normal font-sans">
                      Would you like to customize your referral code word? Instead of a randomized code, pick a punchy custom identifier (e.g. <strong className="font-bold text-slate-700">ETHIO-ABROAD</strong> or your family surname).
                    </p>
                    <div className="flex gap-2 font-sans">
                      <input
                        id="customCodeRequest"
                        type="text"
                        placeholder="e.g. AMHARIC-ABROAD"
                        className="flex-1 bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-700 uppercase font-mono font-bold tracking-wider outline-none focus:ring-1 focus:ring-primary"
                      />
                      <button
                        type="button"
                        onClick={async () => {
                          const inputVal = (document.getElementById("customCodeRequest") as HTMLInputElement)?.value.trim().toUpperCase();
                          if (!inputVal) return;
                          if (inputVal.length < 3 || inputVal.length > 30) {
                            alert("Please enter a custom name between 3 and 30 characters.");
                            return;
                          }
                          try {
                            const userRef = doc(db, "users", user!.uid);
                            await setDoc(userRef, { referralCode: inputVal }, { merge: true });
                            setMyReferralCode(inputVal);
                            (document.getElementById("customCodeRequest") as HTMLInputElement).value = "";
                            alert("✨ Congratulations! Your custom referral code is now globally active!");
                          } catch (err) {
                            alert("Something went wrong requesting your custom code. Please try again.");
                          }
                        }}
                        className="bg-slate-900 text-white rounded-xl px-4 py-2 text-xs font-bold hover:bg-slate-800 transition-all shadow-sm font-sans"
                      >
                        Register Custom Code
                      </button>
                    </div>
                  </div>
                </div>

                {/* Shared Link Details */}
                <div className="p-4 bg-indigo-50/50 rounded-2xl border border-indigo-100/50 flex gap-4 md:items-center text-left font-sans">
                  <div className="text-2xl bg-indigo-100/60 w-12 h-12 rounded-xl flex items-center justify-center text-indigo-700 shrink-0">
                    💡
                  </div>
                  <div>
                    <h5 className="text-xs font-bold text-slate-900 mb-0.5 font-sans">Where can I share my referral code?</h5>
                    <p className="text-[11px] text-slate-500 leading-normal font-sans">
                      Copy your code or link and paste it into family WhatsApp groups, Facebook communities, school newsletters, or share it directly with friends. Newly enrolling students can enter your code directly into their checkout page!
                    </p>
                  </div>
                </div>

              </div>
              
              {/* referrals ledger list */}
              <div className="bg-white rounded-3xl border border-slate-150 p-6 md:p-8 space-y-6 shadow-sm font-sans">
                <div className="border-b border-rose-50/50 pb-4 text-left">
                  <h4 className="text-base font-extrabold text-slate-900 tracking-tight font-sans">
                    👥 Your Invited Referrals Log
                  </h4>
                  <p className="text-[11px] text-slate-400 font-sans">
                    Real-time status tracking showing families you brought onboard.
                  </p>
                </div>
                
                {referralsLoading ? (
                  <div className="py-12 flex flex-col items-center justify-center text-slate-300 gap-2 font-sans">
                    <Loader2 className="animate-spin text-primary" size={24} />
                    <span className="text-xs font-bold text-slate-400 font-sans">Querying live logs...</span>
                  </div>
                ) : referralsList.length === 0 ? (
                  <div className="py-12 border-2 border-dashed border-slate-100 rounded-2xl flex flex-col items-center justify-center text-slate-350 bg-slate-50/30 font-sans">
                    <Gift size={32} strokeWidth={1} className="text-slate-300 mb-3" />
                    <p className="text-xs font-bold text-slate-500 font-sans">No referrals processed yet</p>
                    <p className="text-[10px] text-slate-400 mt-1 max-w-sm text-center font-sans">
                      Copy your credentials and invite people. When they subscribe, they lock in a 10% discount, and you will see their progress right here!
                    </p>
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-xs text-slate-650 min-w-[500px] font-sans">
                      <thead>
                        <tr className="border-b border-slate-100 text-[10px] uppercase text-slate-400 font-extrabold tracking-wider">
                          <th className="py-3 px-2 font-sans">Invited Family</th>
                          <th className="py-3 px-2 font-sans">Student Name</th>
                          <th className="py-3 px-2 text-center font-sans">Cash Reward</th>
                          <th className="py-3 px-2 text-center font-sans">Status</th>
                          <th className="py-3 px-2 text-right font-sans">Date</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-50 font-sans">
                        {referralsList.map((item: any, idx: number) => {
                          const date = item.createdAt ? new Date(item.createdAt.seconds * 1000).toLocaleDateString() : "Pending";
                          return (
                            <tr key={item.id || idx} className="hover:bg-slate-50/40 transition-colors font-sans">
                              <td className="py-3 px-2 font-bold text-slate-800 font-sans">
                                {item.referredParentName || "HabKids Parent"}
                                <span className="block text-[9px] font-mono text-slate-400 font-normal">{item.referredParentEmail || "N/A"}</span>
                              </td>
                              <td className="py-3 px-2 font-medium text-slate-650 font-sans">{item.studentName || "N/A"}</td>
                              <td className="py-3 px-2 font-mono text-center font-bold text-emerald-600 font-sans">+${item.commissionAmount || (settings?.referralCommissionRate ?? 25)}.00</td>
                              <td className="py-3 px-2 text-center font-sans">
                                <span className="bg-emerald-50 text-emerald-700 border border-emerald-100 text-[9px] font-extrabold uppercase px-2 py-0.5 rounded-full font-sans">
                                  {item.status || "verified"}
                                </span>
                              </td>
                              <td className="py-3 px-2 text-right font-mono text-slate-400 text-[11px] font-sans">{date}</td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>

            </div>

            {/* Column 2: Stats & Claim Cash Widget */}
            <div className="space-y-6">
              
              {/* Stats Bento */}
              <div className="bg-white border border-slate-150 rounded-3xl p-6 space-y-6 shadow-sm text-left font-sans">
                <h4 className="text-xs font-extrabold text-slate-400 uppercase tracking-widest block mb-1 font-sans">
                  Ambassador Ledger Summary
                </h4>
                
                <div className="space-y-4 font-sans">
                  <div className="p-3 bg-slate-50 rounded-2xl border border-slate-100 text-left font-sans">
                    <span className="text-[10px] uppercase font-bold text-slate-400 block font-sans">Invited families</span>
                    <span className="text-2xl font-black text-slate-900 font-mono select-none">
                      {referralsList.length}
                    </span>
                  </div>
                  
                  <div className="p-3 bg-slate-50 rounded-2xl border border-slate-100 text-left font-sans">
                    <span className="text-[10px] uppercase font-bold text-slate-400 block font-sans">Bonus Classes Unlocked</span>
                    <span className="text-2xl font-black text-slate-900 font-mono select-none">
                      {referralsList.reduce((acc, r) => acc + (r.bonusCredits || 0), 0)}
                    </span>
                  </div>

                  <div className="p-3 bg-emerald-50/50 rounded-2xl border border-emerald-100/50 text-left font-sans">
                    <span className="text-[10px] uppercase font-bold text-emerald-700 block font-sans">Total Cash Commissions</span>
                    <span className="text-2xl font-black text-emerald-600 font-mono select-none">
                      ${referralsList.reduce((acc, r) => acc + (r.commissionAmount || (settings?.referralCommissionRate ?? 25)), 0)}.00
                    </span>
                  </div>
                </div>
              </div>

              {/* Claim Cash Checkout Form */}
              <div id="commission-box" className="bg-white border border-slate-150 rounded-3xl p-6 space-y-5 shadow-sm text-left font-sans">
                <div>
                  <h4 className="text-sm font-extrabold text-slate-900 tracking-tight flex items-center gap-1.5 font-sans">
                    💸 Claim Payout Rewards
                  </h4>
                  <p className="text-[11px] text-slate-405 leading-relaxed mt-1 font-sans">
                    Directly claim your accrued cash rewards. Choose your payout option, enter account details, and our local team will wire your rewards immediately!
                  </p>
                </div>

                <div className="space-y-3.5 font-sans">
                  <div className="space-y-1 font-sans">
                    <label className="text-[9px] uppercase font-extrabold text-slate-500 tracking-wider font-sans">
                      Payout Option Selection
                    </label>
                    <select
                      id="payoutType"
                      className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-700 font-sans outline-none focus:ring-1 focus:ring-primary"
                    >
                      <option value="telebirr">Telebirr Mobile Payout</option>
                      <option value="cbe">CBE Local Bank Wire</option>
                      <option value="paypal">Zelle / PayPal Account</option>
                    </select>
                  </div>

                  <div className="space-y-1 font-sans">
                    <label className="text-[9px] uppercase font-extrabold text-slate-500 tracking-wider font-sans">
                      Account / Mobile Number
                    </label>
                    <input
                      id="payoutAccount"
                      type="text"
                      required
                      placeholder="e.g. +251940651491 / 1000..."
                      className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-700 font-sans outline-none focus:ring-1 focus:ring-primary font-bold"
                    />
                  </div>

                  <div className="space-y-1 font-sans">
                    <label className="text-[9px] uppercase font-extrabold text-slate-500 tracking-wider font-sans">
                      Claim Amount (USD)
                    </label>
                    <input
                      id="payoutAmount"
                      type="number"
                      required
                      defaultValue={referralsList.reduce((acc, r) => acc + (r.commissionAmount || (settings?.referralCommissionRate ?? 25)), 0) || 50}
                      className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-700 font-sans outline-none focus:ring-1 focus:ring-primary font-bold font-mono"
                    />
                  </div>

                  <button
                    type="button"
                    onClick={async () => {
                      const type = (document.getElementById("payoutType") as HTMLSelectElement)?.value;
                      const acct = (document.getElementById("payoutAccount") as HTMLInputElement)?.value.trim();
                      const amt = (document.getElementById("payoutAmount") as HTMLInputElement)?.value.trim();

                      if (!acct || !amt) {
                        alert("Please fill in your account details and claim amount.");
                        return;
                      }

                      try {
                        await addDoc(collection(db, "payout_requests"), {
                          parentId: user!.uid,
                          parentEmail: user!.email,
                          payoutType: type,
                          accountDetails: acct,
                          claimedAmountUsd: Number(amt),
                          status: "pending",
                          createdAt: serverTimestamp()
                        });
                        alert("🎉 Payout request received successfully! Our finance liaison team will wire the rewards within 24-48 business hours.");
                        (document.getElementById("payoutAccount") as HTMLInputElement).value = "";
                      } catch (err) {
                        console.error("Payout submission failure:", err);
                        alert("Payment channel currently busy. Please retry shortly or contact whatsapp support.");
                      }
                    }}
                    className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold tracking-widest uppercase rounded-2xl shadow-md transition-all border border-emerald-500 hover:border-emerald-600"
                  >
                    🚀 Dispatch Commission Request
                  </button>
                  
                  <p className="text-[9.5px] text-slate-400 block text-center mt-1 font-sans">
                    📞 Need assistance? Support number: <strong className="font-bold text-slate-650">+251940651491</strong> (whatsapp)
                  </p>
                </div>
              </div>

            </div>

          </div>

        </div>
      )}

      {/* VIEW E: PRIVATE SETTINGS / PARENT PROFILE MANAGEMENT */}
      {activeTab === "settings" && (
        <div className="max-w-3xl mx-auto space-y-6 animate-in fade-in duration-300">
          <header className="mb-2 text-left font-sans">
            <h1 className="text-3xl font-bold text-primary mb-1 tracking-tight text-left font-sans">
              Parent Settings
            </h1>
            <p className="text-slate-505 text-sm text-left">
              Review your local contact information, child registration, and
              class tier.
            </p>
          </header>

          <form
            id="parent-profile-settings-form"
            onSubmit={handleSaveSettings}
            className="bg-white rounded-3xl border border-slate-150 shadow-sm p-8 space-y-8 font-sans"
          >
            <h3 className="font-semibold text-slate-900 text-sm border-b border-slate-100 pb-3 flex items-center gap-2 text-left font-sans">
              <Settings size={16} className="text-primary animate-spin-slow" />
              <span>Parent Profile Management</span>
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-1.5 text-left">
                <label className="text-[10px] font-extrabold text-slate-500 uppercase tracking-widest block font-sans">
                  Parent Contact Name
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Almaz Bekele"
                  value={profileName}
                  onChange={(e) => setProfileName(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-xs text-slate-800 outline-none focus:ring-1 focus:ring-primary focus:bg-white focus:border-primary transition-all font-bold shadow-none"
                />
              </div>

              <div className="space-y-1.5 text-left">
                <label className="text-[10px] font-extrabold text-slate-500 uppercase tracking-widest block font-sans">
                  WhatsApp Phone Number
                </label>
                <input
                  type="tel"
                  required
                  placeholder="e.g. +251 911 223 344"
                  value={profileWhatsApp}
                  onChange={(e) => setProfileWhatsApp(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-xs text-slate-800 outline-none focus:ring-1 focus:ring-primary focus:bg-white focus:border-primary transition-all font-bold shadow-none"
                />
                <p className="text-[9px] text-slate-400 mt-1 pl-1">
                  Crucial for receiving lesson rescheduling agreements and
                  classroom alerts.
                </p>
              </div>

              <div className="space-y-1.5 text-left font-sans">
                <label className="text-[10px] font-extrabold text-slate-500 uppercase tracking-widest block font-sans">
                  Child / Student's Name
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Martha Bekele"
                  value={childNameVal}
                  onChange={(e) => setChildNameVal(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-xs text-slate-800 outline-none focus:ring-1 focus:ring-primary focus:bg-white focus:border-primary transition-all font-bold shadow-none"
                />
              </div>

              <div className="space-y-1.5 text-left font-sans">
                <label className="text-[10px] font-extrabold text-slate-500 uppercase tracking-widest block">
                  Academy Subscription Level
                </label>
                <div className="px-4 py-3 bg-indigo-50 border border-indigo-100 rounded-xl text-xs font-bold text-indigo-700 flex items-center justify-between shadow-none">
                  <span>
                    {activeStudent?.plan
                      ? `Heritage ${activeStudent.plan.toUpperCase()} Plan`
                      : "Unenrolled Roster"}
                  </span>
                  <span className="text-[9px] bg-indigo-200 text-indigo-800 px-2 py-0.5 rounded-md uppercase tracking-wider">
                    Read-Only Tier
                  </span>
                </div>
              </div>

              <div className="space-y-1.5 text-left font-sans">
                <label className="text-[10px] font-extrabold text-slate-500 uppercase tracking-widest block font-sans">
                  Account Email Address
                </label>
                <div className="relative">
                  <input
                    type="email"
                    disabled
                    value={profileEmail || user?.email || ""}
                    className="w-full bg-slate-100 border border-slate-200 rounded-xl px-4 py-2.5 text-xs text-slate-400 cursor-not-allowed font-bold"
                  />
                  <span className="absolute right-3.5 top-1/2 -translate-y-1/2 text-[9px] bg-slate-200 text-slate-600 px-2 py-0.5 rounded-md font-extrabold uppercase tracking-wider">
                    Read-Only
                  </span>
                </div>
              </div>
            </div>

            {/* Error/success banners inside Settings */}
            {saveStatus === "success" && (
              <div className="bg-emerald-50 border border-emerald-100 p-3.5 rounded-xl flex items-center gap-2 text-emerald-850 text-xs font-bold animate-in slide-in-from-top duration-200 text-left font-sans">
                <span>✅</span>
                <span>
                  Parent Account Details and child registrations updated
                  successfully. Database synchronized in real time.
                </span>
              </div>
            )}
            {saveStatus === "error" && (
              <div className="bg-red-50 border border-red-100 p-3.5 rounded-xl flex items-center gap-2 text-red-00 text-xs font-bold animate-in slide-in-from-top duration-200 text-left font-sans">
                <span>⚠️</span>
                <span>
                  Encountered an issue synchronizing user properties. Please try
                  again.
                </span>
              </div>
            )}

            <div className="pt-4 border-t border-slate-100 flex justify-end">
              <button
                type="submit"
                disabled={savingSettings}
                className="bg-primary text-white font-semibold px-8 py-3 rounded-xl text-xs uppercase tracking-widest hover:bg-primary/95 disabled:opacity-50 transition-all flex items-center gap-2 shadow-lg cursor-pointer font-sans"
              >
                {savingSettings ? (
                  <Loader2 className="animate-spin" size={14} />
                ) : (
                  <Check size={14} />
                )}
                <span>Save Profile Settings</span>
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Enrollment & Subscription Modal */}
      {showEnroller && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-sm flex items-start justify-center p-4 md:p-10 animate-in fade-in duration-200">
          <div className="bg-white w-full max-w-4xl rounded-3xl shadow-2xl overflow-hidden flex flex-col md:flex-row my-auto">
            {/* Sidebar Info */}
            <div className="md:w-72 bg-slate-50 p-8 border-r border-slate-100 shrink-0">
              <div className="mb-8">
                <div className="w-12 h-12 bg-primary text-white rounded-xl flex items-center justify-center mb-4">
                  <CardIcon size={24} />
                </div>
                <h3 className="font-bold text-xl text-slate-900 tracking-tight">
                  Family Enrollment
                </h3>
                <p className="text-slate-500 text-xs mt-2 leading-relaxed">
                  Finalize your child's subscription and lock in your preferred
                  weekly session time.
                </p>
              </div>

              <div className="space-y-6">
                <div className="flex gap-3">
                  <div className="w-6 h-6 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center shrink-0">
                    <Check size={14} />
                  </div>
                  <p className="text-[11px] text-slate-600 font-medium">
                    Professional Heritage Curriculum
                  </p>
                </div>
                <div className="flex gap-3">
                  <div className="w-6 h-6 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center shrink-0">
                    <Check size={14} />
                  </div>
                  <p className="text-[11px] text-slate-600 font-medium">
                    1-on-1 Dedicated Native Tutor
                  </p>
                </div>
                <div className="flex gap-3">
                  <div className="w-6 h-6 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center shrink-0">
                    <Check size={14} />
                  </div>
                  <p className="text-[11px] text-slate-600 font-medium">
                    Progress Reports & Evaluations
                  </p>
                </div>
              </div>
            </div>{" "}
            {/* Form Content */}
            <div className="flex-1 p-8 md:p-12 relative">
              <button
                onClick={() => setShowEnroller(false)}
                className="absolute top-8 right-8 p-2 hover:bg-slate-100 rounded-full transition-colors text-slate-400"
              >
                <X size={20} />
              </button>

              {loading ? (
                <div className="h-full flex flex-col items-center justify-center gap-4">
                  <Loader2 className="animate-spin text-secondary" size={32} />
                  <p className="text-sm text-slate-400 font-medium">
                    Syncing schedules...
                  </p>
                </div>
              ) : (
                <form onSubmit={handleEnrollment} className="space-y-10">
                  {/* Step 1: Select Plan */}
                  <div className="space-y-4">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block text-left">
                      Step 1: Choose Subscription Plan or Credits Package
                    </label>
                    <div className="flex gap-4 p-1.5 bg-slate-100 rounded-2xl w-fit">
                      <button 
                        type="button"
                        onClick={() => {
                          setUseCustomCreditsNew(false);
                          setSelectedPlan(plans[1]); // Default to Pro
                        }}
                        className={cn(
                          "px-5 py-2.5 rounded-xl text-xs font-bold uppercase tracking-wider transition-all cursor-pointer",
                          !useCustomCreditsNew ? "bg-white text-slate-900 shadow-sm" : "text-slate-500 hover:text-slate-900"
                        )}
                      >
                        Subscription Tiers
                      </button>
                      <button 
                        type="button"
                        onClick={() => {
                          setUseCustomCreditsNew(true);
                          setSelectedPlan(null);
                        }}
                        className={cn(
                          "px-5 py-2.5 rounded-xl text-xs font-bold uppercase tracking-wider transition-all cursor-pointer",
                          useCustomCreditsNew ? "bg-white text-slate-900 shadow-sm" : "text-slate-500 hover:text-slate-900"
                        )}
                      >
                        Custom Credit Package
                      </button>
                    </div>

                    {!useCustomCreditsNew ? (
                      <div className="grid md:grid-cols-2 gap-4 max-w-2xl mx-auto animate-in fade-in duration-200">
                        {plans.map((plan) => (
                          <button
                            key={plan.id}
                            type="button"
                            onClick={() => setSelectedPlan(plan)}
                            className={cn(
                              "p-4 rounded-2xl border-2 text-left transition-all relative overflow-hidden cursor-pointer",
                              selectedPlan?.id === plan.id
                                ? "bg-primary text-white border-primary shadow-xl shadow-primary/20 scale-[1.02]"
                                : "bg-white text-slate-900 border-slate-100 hover:border-slate-200"
                            )}
                          >
                            <h4 className="font-bold text-sm truncate">
                              {plan.name}
                            </h4>
                            <p
                              className={cn(
                                "text-[10px] mt-1 font-medium",
                                selectedPlan?.id === plan.id
                                  ? "text-white/60"
                                  : "text-slate-400"
                              )}
                            >
                              {plan.description}
                            </p>
                            <div className="mt-4 flex items-baseline gap-1">
                              <span className="text-lg font-bold">
                                ${plan.price}
                              </span>
                              <span
                                className={cn(
                                  "text-[9px] font-medium opacity-60"
                                )}
                              >
                                /mo
                              </span>
                            </div>
                            {selectedPlan?.id === plan.id && (
                              <div className="absolute top-2 right-2 text-white/20">
                                <CheckCircle2 size={16} />
                              </div>
                            )}
                          </button>
                        ))}
                      </div>
                    ) : (
                      <div className="bg-slate-50 p-6 md:p-8 rounded-3xl border border-slate-150 space-y-6 animate-in fade-in duration-200 text-left">
                        <div>
                          <h4 className="font-extrabold text-sm text-slate-900">Configure Custom Credit Package</h4>
                          <p className="text-xs text-slate-400 mt-1">Purchase multi-month blocks or custom class counts at a flexible rate of $40 per session.</p>
                        </div>

                        <div className="flex flex-col sm:flex-row sm:items-center gap-6">
                          <div className="flex items-center gap-3">
                            <button 
                              type="button"
                              onClick={() => setCustomCreditQuantity(q => Math.max(4, q - 1))}
                              className="w-12 h-12 bg-white rounded-xl border border-slate-200 flex items-center justify-center font-bold text-lg text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer"
                            >
                              -
                            </button>
                            <input 
                              type="number"
                              min={4}
                              max={48}
                              value={customCreditQuantity}
                              onChange={(e) => {
                                const val = parseInt(e.target.value) || 4;
                                setCustomCreditQuantity(Math.min(48, Math.max(4, val)));
                              }}
                              className="w-20 h-12 text-center bg-white border border-slate-200 rounded-xl font-bold text-base focus:outline-none focus:border-slate-400 font-mono"
                            />
                            <button 
                              type="button"
                              onClick={() => setCustomCreditQuantity(q => Math.min(48, q + 1))}
                              className="w-12 h-12 bg-white rounded-xl border border-slate-200 flex items-center justify-center font-bold text-lg text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer"
                            >
                              +
                            </button>
                          </div>

                          <div className="flex-1 bg-white px-6 py-4 rounded-2xl border border-slate-100 flex items-center justify-between font-sans">
                            <div>
                              <span className="text-[9px] font-bold text-slate-400 uppercase tracking-widest block font-sans">Total Cost</span>
                              <span className="text-xl font-black text-slate-900 font-mono">${customCreditQuantity * 40}.00</span>
                            </div>
                            <div>
                              <span className="text-[9px] font-bold text-slate-400 uppercase tracking-widest block text-right font-sans">Included Classes</span>
                              <span className="text-xs font-bold text-indigo-600 block text-right font-sans">{customCreditQuantity} Tutoring Sessions</span>
                            </div>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Step 2: Schedule & Tutor */}
                  <div className="grid md:grid-cols-1 gap-8">
                    <div className="space-y-4">
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                        <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                          Step 2: Tutor Selection Mode
                        </label>
                      </div>

                      {/* Choice Cards */}
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <button
                          type="button"
                          onClick={() => {
                            setSelectedTutorId("auto-assign");
                            setRecurringTimes([]);
                          }}
                          className={cn(
                            "p-5 rounded-3xl border text-left transition-all relative overflow-hidden cursor-pointer",
                            selectedTutorId === "auto-assign"
                              ? "border-indigo-600 bg-indigo-50/10 shadow-md ring-2 ring-indigo-600/20"
                              : "border-slate-100 bg-white hover:border-slate-300"
                          )}
                        >
                          <div className="flex items-center gap-2 mb-1.5">
                            <span className="p-1 px-1.5 bg-indigo-100 text-indigo-700 rounded-lg text-xs font-bold">
                              🔍 Auto
                            </span>
                            <span className="font-bold text-sm text-slate-900">Let HabKids Assign Best Tutor</span>
                          </div>
                          <p className="text-[11px] text-slate-500 leading-relaxed font-sans">
                            Aggregates slots across all tutors for maximum calendar flexibility. Smart matching assigns the ultimate expert matching your preferred slot.
                          </p>
                          {selectedTutorId === "auto-assign" && (
                            <div className="absolute top-3 right-3 w-2 h-2 bg-indigo-600 rounded-full"></div>
                          )}
                        </button>

                        <button
                          type="button"
                          onClick={() => {
                            const firstTutor = tutors.find(t => t.id !== "auto-assign");
                            setSelectedTutorId(firstTutor ? firstTutor.id : "");
                            setRecurringTimes([]);
                          }}
                          className={cn(
                            "p-5 rounded-3xl border text-left transition-all relative overflow-hidden cursor-pointer",
                            selectedTutorId !== "auto-assign" && selectedTutorId !== ""
                              ? "border-indigo-600 bg-indigo-50/10 shadow-md ring-2 ring-indigo-600/20"
                              : "border-slate-100 bg-white hover:border-slate-300"
                          )}
                        >
                          <div className="flex items-center gap-2 mb-1.5">
                            <span className="p-1 px-1.5 bg-emerald-100 text-emerald-700 rounded-lg text-xs font-bold">
                              👤 Select
                            </span>
                            <span className="font-bold text-sm text-slate-900">Manually Choose My Tutor</span>
                          </div>
                          <p className="text-[11px] text-slate-500 leading-relaxed font-sans">
                            Select a specific designated tutor. Perfect if you prefer a single dedicated guide for your child's entire learning track.
                          </p>
                          {selectedTutorId !== "auto-assign" && selectedTutorId !== "" && (
                            <div className="absolute top-3 right-3 w-2 h-2 bg-indigo-600 rounded-full"></div>
                          )}
                        </button>
                      </div>

                      {/* Specific native speaker list if manually selected */}
                      {selectedTutorId !== "auto-assign" && selectedTutorId !== "" && (
                        <div className="space-y-3 pt-2 animate-in fade-in slide-in-from-top-1 duration-200">
                          <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                            Available Native Speakers
                          </p>
                          {tutors.length === 0 ? (
                            <div className="p-8 border-2 border-dashed border-slate-100 rounded-2xl text-center">
                              <p className="text-xs text-slate-400 font-medium font-sans">
                                No tutors available at the moment. Please contact support.
                              </p>
                            </div>
                          ) : (
                            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                              {tutors.map((t) => (
                                <button
                                  key={t.id}
                                  type="button"
                                  onClick={() => {
                                    setSelectedTutorId(t.id);
                                    setRecurringTimes([]);
                                  }}
                                  className={cn(
                                    "p-4 rounded-2xl border text-left transition-all cursor-pointer relative",
                                    selectedTutorId === t.id
                                      ? "border-primary bg-primary/5 shadow-md ring-2 ring-primary/20 scale-[0.99]"
                                      : "border-slate-100 bg-white hover:border-slate-200"
                                  )}
                                >
                                  <p className="font-bold text-sm text-slate-900">
                                    {t.displayName || t.email}
                                  </p>
                                  <p className="text-[10px] text-slate-400 font-medium mb-2 font-sans">
                                    Native Heritage Speaker
                                  </p>
                                  {t.specializedSyllabus && (
                                    <span className="text-[9px] font-sans font-bold text-indigo-700 bg-indigo-50 border border-indigo-100 rounded-lg px-2 py-0.5">
                                      {t.specializedSyllabus}
                                    </span>
                                  )}
                                </button>
                              ))}
                            </div>
                          )}
                        </div>
                      )}
                    </div>{" "}
                    {selectedTutorId ? (
                      <>
                        <div className="space-y-6 animate-in fade-in slide-in-from-top-2 duration-300">
                          <div className="flex items-center justify-between">
                            <div>
                              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                                Step 3: Select Weekly Schedule
                              </label>
                              <p className="text-[10px] text-slate-400 font-medium whitespace-nowrap font-sans">
                                Choose{" "}
                                {selectedPlan ? selectedPlan.sessions / 4 : 1}{" "}
                                regular times each week.
                              </p>
                            </div>
                            <div className="bg-secondary/10 text-secondary px-3 py-1.5 rounded-xl text-[10px] font-bold flex items-center gap-2">
                              <div className="w-1.5 h-1.5 bg-secondary rounded-full animate-pulse"></div>
                              {recurringTimes.length} /{" "}
                              {selectedPlan ? selectedPlan.sessions / 4 : 1}{" "}
                              Selected
                            </div>
                          </div>
                          <div className="space-y-6">
                            {(() => {
                              let localAvail: any = null;
                              if (selectedTutorId === "auto-assign") {
                                // Aggregate availability days and slots across ALL active tutors
                                const aggregated: any = {};
                                const days = ["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"];
                                days.forEach((d) => {
                                  aggregated[d] = { active: false, slots: [] };
                                });

                                tutors.forEach((t) => {
                                  const singleAvail = getFilteredAvailability(t.availability, t.id, globalSessions);
                                  if (singleAvail) {
                                    days.forEach((d) => {
                                      if (singleAvail[d]?.active) {
                                        aggregated[d].active = true;
                                        if (Array.isArray(singleAvail[d].slots)) {
                                          singleAvail[d].slots.forEach((slot: string) => {
                                            if (!aggregated[d].slots.includes(slot)) {
                                              aggregated[d].slots.push(slot);
                                            }
                                          });
                                        }
                                      }
                                    });
                                  }
                                });

                                // Sort the slot times chronologically
                                days.forEach((d) => {
                                  aggregated[d].slots.sort();
                                });
                                localAvail = aggregated;
                              } else {
                                const tutor = tutors.find((t) => t.id === selectedTutorId);
                                localAvail = getFilteredAvailability(tutor?.availability, tutor?.id, globalSessions);
                              }
                              if (!localAvail)
                                return (
                                  <div className="p-8 border-2 border-dashed border-slate-100 rounded-[32px] text-center text-slate-400 italic text-xs">
                                    No automated slots available. Please contact
                                    admin.
                                  </div>
                                );

                              const daysOrder = [
                                "monday",
                                "tuesday",
                                "wednesday",
                                "thursday",
                                "friday",
                                "saturday",
                                "sunday",
                              ];
                              const activeDays = daysOrder.filter(
                                (day) =>
                                  localAvail[day]?.active &&
                                  localAvail[day]?.slots?.length > 0,
                              );

                              if (activeDays.length === 0)
                                return (
                                  <div className="p-8 border-2 border-dashed border-slate-100 rounded-[32px] text-center text-slate-400 italic text-xs">
                                    This tutor has not published their weekly
                                    availability yet.
                                  </div>
                                );

                              return activeDays.map((day) => {
                                const standardHours = ['09:00', '11:00', '13:00', '15:00', '17:00', '19:00', '21:00', '22:00', '23:00', '00:00', '01:00', '02:00', '03:00', '04:00', '05:00'];
                                const dailySlotsToRender = Array.from(new Set([...standardHours, ...(localAvail[day]?.slots || [])])).sort();

                                return (
                                  <div key={day} className="space-y-3">
                                    <h5 className="text-[11px] font-bold text-slate-900 capitalize flex items-center gap-2">
                                      <span className="w-2 h-2 bg-secondary rounded-full"></span>
                                      {day}s
                                    </h5>
                                    <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-5 gap-3">
                                      {dailySlotsToRender.map((slotTime: string, idx: number) => {
                                        const isTutorFree = localAvail[day]?.slots?.includes(slotTime);
                                        const isSelected = recurringTimes.some(
                                          (rt) => {
                                            const parsed = parseISOTimeAndDay(rt);
                                            return parsed.time === slotTime && parsed.day === day;
                                          },
                                        );

                                        if (!isTutorFree) {
                                          return (
                                            <button
                                              key={idx}
                                              type="button"
                                              disabled={true}
                                              className="px-3 py-2.5 rounded-xl border border-slate-100 bg-slate-50 text-slate-400 line-through text-[11px] font-medium flex flex-col items-center justify-center gap-0.5 opacity-40 cursor-not-allowed"
                                            >
                                              <span className="text-[7.5px] uppercase tracking-wider text-slate-400 font-extrabold flex items-center gap-0.5">🔒 Blocked</span>
                                              {renderSlotTime(slotTime)}
                                            </button>
                                          );
                                        }

                                        return (
                                          <button
                                            key={idx}
                                            type="button"
                                            onClick={() => {
                                              const now = new Date();
                                              const daysMap: any = {
                                                sunday: 0,
                                                monday: 1,
                                                tuesday: 2,
                                                wednesday: 3,
                                                thursday: 4,
                                                friday: 5,
                                                saturday: 6,
                                              };
                                              const targetDay = daysMap[day];
                                              const today = now.getDay();
                                              const daysUntil =
                                                (targetDay + 7 - today) % 7 ||
                                                7;
                                              const date = new Date(now);
                                              date.setDate(
                                                now.getDate() + daysUntil,
                                              );
                                              const [h, m] = slotTime
                                                .split(":")
                                                .map(Number);
                                              date.setHours(h, m, 0, 0);
                                              const iso = date.toISOString();
                                              const requiredSlots = useCustomCreditsNew
                                                ? Math.max(1, Math.floor(customCreditQuantity / 4))
                                                : (selectedPlan ? selectedPlan.sessions / 4 : 1);

                                              if (isSelected) {
                                                setRecurringTimes(
                                                  recurringTimes.filter(
                                                    (rt) => {
                                                      const parsed = parseISOTimeAndDay(rt);
                                                      return !(parsed.time === slotTime && parsed.day === day);
                                                    },
                                                  ),
                                                );
                                              } else {
                                                if (
                                                  recurringTimes.length <
                                                  requiredSlots
                                                ) {
                                                  setRecurringTimes([
                                                    ...recurringTimes,
                                                    iso,
                                                  ]);
                                                } else if (
                                                  requiredSlots === 1
                                                ) {
                                                  setRecurringTimes([iso]);
                                                }
                                              }
                                            }}
                                            className={cn(
                                              "px-3 py-2.5 rounded-xl border text-[11px] font-bold transition-all flex flex-col items-center justify-center gap-0.5 shadow-sm",
                                              isSelected
                                                ? "bg-secondary text-white border-secondary shadow-lg shadow-secondary/20 scale-[1.05]"
                                                : "bg-white text-emerald-805 border-emerald-250 hover:border-emerald-400 hover:bg-emerald-50/40",
                                            )}
                                          >
                                            <span
                                              className={cn(
                                                "opacity-65 text-[8px] uppercase",
                                                isSelected
                                                  ? "text-white font-extrabold"
                                                  : "text-emerald-600 font-extrabold",
                                              )}
                                            >
                                              {isSelected
                                                ? "Selected"
                                                : "Free Slot"}
                                            </span>
                                            {renderSlotTime(slotTime)}
                                          </button>
                                        );
                                      })}
                                    </div>
                                  </div>
                                );
                              });
                            })()}
                          </div>

                          {recurringTimes.length > 0 && (
                            <div className="bg-emerald-50 border border-emerald-100 p-4 rounded-2xl animate-in zoom-in-95 duration-200">
                              <p className="text-[10px] font-bold text-emerald-700 uppercase tracking-widest mb-3 flex items-center gap-2">
                                <CheckCircle2 size={14} />
                                Confirmed Weekly Schedule
                              </p>
                              <div className="flex flex-wrap gap-2">
                                {recurringTimes.map((rt, i) => (
                                  <div
                                    key={i}
                                    className="bg-white border border-emerald-100 px-3 py-1.5 rounded-lg text-[10px] font-bold text-emerald-600 shadow-sm"
                                  >
                                    {new Date(rt).toLocaleDateString([], {
                                      weekday: "long",
                                    })}
                                    s @{" "}
                                    {new Date(rt).toLocaleTimeString([], {
                                      hour: "2-digit",
                                      minute: "2-digit",
                                    })}
                                  </div>
                                ))}
                              </div>
                            </div>
                          )}
                        </div>
                        {useCustomCreditsNew ? (
                          <p className="text-[9px] text-slate-400 font-medium mt-4">
                            Please select at least 1 weekly tutor session slot (you have selected {recurringTimes.length}).
                          </p>
                        ) : (
                          <p className="text-[9px] text-slate-400 font-medium mt-4">
                            Please select exactly{" "}
                            {selectedPlan ? selectedPlan.sessions / 4 : 1} slots
                            to match your {selectedPlan?.name || "plan"}.
                          </p>
                        )}

                        {/* Step 4: Secure Checkout Payment & Receipt Submission */}
                        {((useCustomCreditsNew && recurringTimes.length >= 1) ||
                          (!useCustomCreditsNew && selectedPlan && recurringTimes.length === selectedPlan.sessions / 4)) && (
                          <div className="space-y-6 pt-6 border-t border-slate-100 animate-in fade-in slide-in-from-top-2 duration-300">
                            <div className="space-y-1">
                              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">
                                Step 4: Secure Checkout Payment
                              </label>
                              <p className="text-[10px] text-slate-400 font-medium">
                                To activate your enrollment, remit your first
                                month's payment and supply your receipt info
                                below.
                              </p>
                            </div>

                            {/* Checkout Card Form Fields with CBE, Telebirr, and Zelle/International Options */}
                            <div className="bg-slate-50 rounded-2xl p-5 md:p-6 border border-slate-150 space-y-6 text-left">
                              {/* Payment Options Selection Block */}
                              <div className="space-y-3">
                                <label className="text-[10px] font-extrabold text-slate-400 uppercase tracking-widest block text-left">
                                  Select Payment Method
                                </label>
                                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                                  <button
                                    type="button"
                                    onClick={() => setPaymentType("telebirr")}
                                    className={cn(
                                      "p-3.5 rounded-xl border text-left transition-all flex flex-col justify-between gap-1.5 cursor-pointer bg-white",
                                      paymentType === "telebirr"
                                        ? "border-primary bg-primary/5 shadow-sm ring-1 ring-primary/10"
                                        : "border-slate-150 hover:border-slate-300",
                                    )}
                                  >
                                    <div className="flex items-center gap-1.5">
                                      <span
                                        className={cn(
                                          "w-3 h-3 rounded-full border flex items-center justify-center shrink-0",
                                          paymentType === "telebirr"
                                            ? "border-primary text-primary"
                                            : "border-slate-300",
                                        )}
                                      >
                                        {paymentType === "telebirr" && (
                                          <span className="w-1.5 h-1.5 bg-primary rounded-full"></span>
                                        )}
                                      </span>
                                      <span className="text-[11px] font-bold text-slate-850">
                                        Telebirr (Ethiopia)
                                      </span>
                                    </div>
                                    <span className="text-[8px] text-slate-400 font-bold font-mono uppercase tracking-wider">
                                      Mobile wallet
                                    </span>
                                  </button>

                                  <button
                                    type="button"
                                    onClick={() => setPaymentType("cbe")}
                                    className={cn(
                                      "p-3.5 rounded-xl border text-left transition-all flex flex-col justify-between gap-1.5 cursor-pointer bg-white",
                                      paymentType === "cbe"
                                        ? "border-primary bg-primary/5 shadow-sm ring-1 ring-primary/10"
                                        : "border-slate-150 hover:border-slate-300",
                                    )}
                                  >
                                    <div className="flex items-center gap-1.5">
                                      <span
                                        className={cn(
                                          "w-3 h-3 rounded-full border flex items-center justify-center shrink-0",
                                          paymentType === "cbe"
                                            ? "border-primary text-primary"
                                            : "border-slate-300",
                                        )}
                                      >
                                        {paymentType === "cbe" && (
                                          <span className="w-1.5 h-1.5 bg-primary rounded-full"></span>
                                        )}
                                      </span>
                                      <span className="text-[11px] font-bold text-slate-855">
                                        CBE Birr / Bank
                                      </span>
                                    </div>
                                    <span className="text-[8px] text-slate-400 font-bold font-mono uppercase tracking-wider">
                                      Bank Transfer
                                    </span>
                                  </button>

                                  <button
                                    type="button"
                                    onClick={() =>
                                      setPaymentType("international")
                                    }
                                    className={cn(
                                      "p-3.5 rounded-xl border text-left transition-all flex flex-col justify-between gap-1.5 cursor-pointer bg-white",
                                      paymentType === "international"
                                        ? "border-primary bg-primary/5 shadow-sm ring-1 ring-primary/10"
                                        : "border-slate-150 hover:border-slate-300",
                                    )}
                                  >
                                    <div className="flex items-center gap-1.5">
                                      <span
                                        className={cn(
                                          "w-3 h-3 rounded-full border flex items-center justify-center shrink-0",
                                          paymentType === "international"
                                            ? "border-primary text-primary"
                                            : "border-slate-300",
                                        )}
                                      >
                                        {paymentType === "international" && (
                                          <span className="w-1.5 h-1.5 bg-primary rounded-full"></span>
                                        )}
                                      </span>
                                      <span className="text-[11px] font-bold text-slate-855">
                                        International
                                      </span>
                                    </div>
                                    <span className="text-[8px] text-slate-400 font-bold font-mono uppercase tracking-wider">
                                      Zelle, Remitly, etc.
                                    </span>
                                  </button>
                                </div>
                              </div>

                              {/* Instruction Panels */}
                              {(() => {
                                const baseUsd = selectedPlan?.price || 240;
                                const planId = selectedPlan?.id?.toLowerCase() || "";
                                const baseBirr = planId.includes('pro')
                                  ? (settings?.proPriceBirr || 3500)
                                  : (planId.includes('mastery')
                                      ? (settings?.masteryPriceBirr || 5200)
                                      : (settings?.standardPriceBirr || 2300));
                                
                                const usdAmount = baseUsd * enrollmentUnits;
                                const birrAmount = baseBirr * enrollmentUnits;

                                if (paymentType === "telebirr") {
                                  return (
                                    <div className="p-4 bg-white border border-slate-100 rounded-xl space-y-1.5 text-xs text-slate-600 animate-in fade-in duration-200 text-left">
                                      <div className="flex items-center justify-between mb-1 border-b border-slate-50 pb-1.5">
                                        <span className="text-[9px] uppercase font-black text-primary tracking-wider">
                                          Order Total ({enrollmentUnits} {enrollmentUnits === 1 ? 'Slot' : 'Slots'})
                                        </span>
                                        <span className="text-[11px] font-black text-slate-900 font-mono">
                                          {isUSUser ? `$${usdAmount}` : `${birrAmount} Birr`}
                                        </span>
                                      </div>
                                      <span className="text-[9px] uppercase font-bold text-slate-400 tracking-wider block">
                                        Telebirr Account Instructions:
                                      </span>
                                      <p className="leading-relaxed text-[11px]">
                                        Send the subscription fee of{" "}
                                        {isUSUser ? (
                                          <strong className="text-slate-900 font-extrabold font-mono">
                                            ${usdAmount} USD
                                          </strong>
                                        ) : (
                                          <>
                                            <strong className="text-slate-900 font-extrabold font-mono">
                                              {birrAmount} Birr
                                            </strong>{" "}
                                            (or ${usdAmount} USD)
                                          </>
                                        )}{" "}
                                        to our verified merchant code:{" "}
                                        <strong className="font-extrabold text-slate-900 font-mono bg-slate-50 px-1.5 py-0.5 rounded">
                                          {settings?.subTelebirrMerchantCode || "882910"}
                                        </strong>{" "}
                                        or transfer to mobile number{" "}
                                        <strong className="font-extrabold text-slate-900 font-mono bg-slate-50 px-1.5 py-0.5 rounded">
                                          {settings?.subTelebirrNumber || "+251 912 345 678"}
                                        </strong>{" "}
                                        (Company Name:{" "}
                                        <strong>{settings?.subTelebirrName || "HabKids tutor"}</strong>).
                                      </p>
                                    </div>
                                  );
                                }

                                if (paymentType === "cbe") {
                                  return (
                                    <div className="p-4 bg-white border border-slate-100 rounded-xl space-y-1.5 text-xs text-slate-600 animate-in fade-in duration-200 text-left">
                                      <div className="flex items-center justify-between mb-1 border-b border-slate-50 pb-1.5">
                                        <span className="text-[9px] uppercase font-black text-primary tracking-wider">
                                          Order Total ({enrollmentUnits} {enrollmentUnits === 1 ? 'Slot' : 'Slots'})
                                        </span>
                                        <span className="text-[11px] font-black text-slate-900 font-mono">
                                          {isUSUser ? `$${usdAmount}` : `${birrAmount} Birr`}
                                        </span>
                                      </div>
                                      <span className="text-[9px] uppercase font-bold text-slate-400 tracking-wider block">
                                        CBE Account Bank Instructions:
                                      </span>
                                      <p className="leading-relaxed text-[11px]">
                                        Deposit or wire transfer your subscription fee of{" "}
                                        {isUSUser ? (
                                          <strong className="font-extrabold text-slate-900 font-mono bg-slate-50 px-1.5 py-0.5 rounded">
                                            ${usdAmount} USD
                                          </strong>
                                        ) : (
                                          <>
                                            <strong className="font-extrabold text-slate-900 font-mono bg-slate-50 px-1.5 py-0.5 rounded">
                                              {birrAmount} Birr
                                            </strong>{" "}
                                            (or ${usdAmount} USD)
                                          </>
                                        )}{" "}
                                        directly to CBE corporate account name{" "}
                                        <strong>{settings?.subCbeAccountName || "HabKids Language School"}</strong>:
                                        <br />
                                        <strong className="font-extrabold text-slate-900 font-mono bg-slate-50 px-2.5 py-0.5 rounded mt-1 inline-block">
                                          ID: {settings?.subCbeAccountNumber || "1000492811726"}
                                        </strong>
                                      </p>
                                    </div>
                                  );
                                }

                                if (paymentType === "international") {
                                  return (
                                    <div className="p-4 bg-white border border-slate-100 rounded-xl space-y-3 text-xs text-slate-600 animate-in fade-in duration-200 text-left">
                                      <div className="flex items-center justify-between mb-1 border-b border-slate-50 pb-1.5">
                                        <span className="text-[9px] uppercase font-black text-primary tracking-wider">
                                          Order Total ({enrollmentUnits} {enrollmentUnits === 1 ? 'Slot' : 'Slots'})
                                        </span>
                                        <span className="text-[11px] font-black text-slate-900 font-mono">
                                          ${usdAmount}
                                        </span>
                                      </div>
                                      <span className="text-[9px] uppercase font-bold text-slate-400 tracking-wider block font-sans">
                                        🇺🇸 Zelle (USA Abroad) Instructions:
                                      </span>
                                      <div className="space-y-2.5 leading-relaxed text-[11px]">
                                        <div>
                                          <p className="font-bold text-slate-900">
                                            🔹 US Parents:
                                          </p>
                                          <p className="text-slate-500 pl-4">
                                            Zelle payments can be dispatched directly to our secure US payment endpoint:{" "}
                                            <strong className="font-bold text-slate-800 font-mono">
                                              {settings?.subZelleEmail || "payment@heritageacademy.com"}
                                            </strong>
                                            {settings?.subZelleName && (
                                              <span className="text-[10px] text-slate-400 block mt-0.5">
                                                Account Name: <strong>{settings.subZelleName}</strong>
                                              </span>
                                            )}
                                          </p>
                                        </div>
                                        <div>
                                          <p className="font-bold text-slate-900">
                                            🔹 Canada, UK, Europe, & Australia Parents:
                                          </p>
                                          <p className="text-slate-500 pl-4">
                                            Submit via reliable global transaction systems such as{" "}
                                            <strong className="text-slate-855">
                                              Remitly
                                            </strong>
                                            ,{" "}
                                            <strong className="text-slate-855">
                                              WorldRemit
                                            </strong>
                                            , or{" "}
                                            <strong className="text-slate-855">
                                              Sendwave
                                            </strong>{" "}
                                            directly to our US Zelle address (
                                            <strong className="text-slate-800 font-mono">
                                              {settings?.subZelleEmail || "payment@heritageacademy.com"}
                                            </strong>
                                            ) or as a mobile deposit payout of{" "}
                                            {isUSUser ? (
                                              <strong className="text-slate-900 font-bold">${usdAmount} USD</strong>
                                            ) : (
                                              <strong className="text-slate-900 font-bold">{birrAmount} Birr</strong>
                                            )}{" "}
                                            to Telebirr mobile number (
                                            <strong className="text-slate-808 font-mono">
                                              {settings?.subTelebirrNumber || "+251 912 345 678"}
                                            </strong>
                                            ).
                                          </p>
                                        </div>
                                      </div>
                                    </div>
                                  );
                                }

                                return null;
                              })()}

                              {/* Promo Code & Referral Input Layer */}
                              <div className="border-t border-slate-100 pt-4 text-left">
                                <label className="text-[9px] font-extrabold text-slate-400 uppercase tracking-widest block text-left mb-1.5">
                                  🏷️ Have a Promo or Referral Code?
                                </label>
                                <div className="bg-slate-50/70 p-3 rounded-xl border border-slate-100/100 space-y-2 mb-4">
                                  <div className="flex gap-2">
                                    <input
                                      type="text"
                                      placeholder="e.g. SELAM20 or Ambassador Code"
                                      value={promoCodeInput}
                                      onChange={(e) => setPromoCodeInput(e.target.value)}
                                      className="flex-1 bg-white border border-slate-200 rounded-lg px-3 py-1.5 text-xs text-slate-700 font-mono font-bold uppercase tracking-wider outline-none focus:ring-1 focus:ring-primary focus:border-primary transition-all"
                                      disabled={promoLoading || !!appliedPromo}
                                    />
                                    {appliedPromo ? (
                                      <button
                                        type="button"
                                        onClick={() => {
                                          setAppliedPromo(null);
                                          setPromoCodeInput("");
                                          setPromoError("");
                                        }}
                                        className="text-[10px] font-bold text-red-600 bg-red-50 hover:bg-red-100 px-3 py-1.5 rounded-lg transition-all"
                                      >
                                        Remove
                                      </button>
                                    ) : (
                                      <button
                                        type="button"
                                        onClick={handleVerifyPromoCode}
                                        disabled={promoLoading || !promoCodeInput.trim()}
                                        className="px-4 py-1.5 bg-primary hover:bg-primary/95 text-white text-xs font-bold rounded-lg disabled:opacity-50 disabled:cursor-not-allowed transition-all shadow-sm flex items-center gap-1 shrink-0"
                                      >
                                        {promoLoading ? (
                                          <Loader2 className="animate-spin" size={12} />
                                        ) : (
                                          "Apply"
                                        )}
                                      </button>
                                    )}
                                  </div>

                                  {promoError && (
                                    <p className="text-[10px] font-bold text-red-500 text-left font-sans">
                                      ⚠️ {promoError}
                                    </p>
                                  )}

                                  {appliedPromo && (
                                    <div className="bg-emerald-50 border border-emerald-100 p-2.5 rounded-lg text-left space-y-1 animate-in fade-in zoom-in-95 duration-200">
                                      <div className="flex items-center gap-1.5 text-emerald-800 text-xs font-bold font-sans">
                                        <CheckCircle2 size={13} className="text-emerald-600" />
                                        <span>Coupon Applied successfully: {appliedPromo.code}</span>
                                      </div>
                                      <p className="text-[10px] text-emerald-700 leading-snug font-medium font-sans">
                                        {appliedPromo.description}
                                      </p>
                                    </div>
                                  )}

                                  {!appliedPromo && !promoError && (
                                    <p className="text-[9px] text-slate-400 font-medium tracking-wide">
                                      💡 Enter custom ambassador codes or promo code <strong className="font-bold text-slate-500">SELAM20</strong>, <strong className="font-bold text-slate-500">HABKIDS30</strong> or <strong className="font-bold text-slate-500">FREECLASS</strong> to apply discounts.
                                    </p>
                                  )}
                                </div>
                              </div>

                              {/* Secure Verification Layer */}
                              <div className="border-t border-slate-100 pt-4 space-y-3">
                                <div className="flex items-center justify-between gap-4">
                                  <span className="text-[9px] font-extrabold text-slate-400 uppercase tracking-widest block text-left">
                                    Secure Payment Verification Details
                                  </span>
                                  <button
                                    type="button"
                                    onClick={() => {
                                      setTransactionRef("CBE-TXN-" + Math.floor(100000 + Math.random() * 900000));
                                      setPaymentSenderName(user?.displayName || user?.fullName || "Abebe Kebede");
                                      setReceiptScreenshotName("habkids_payment_receipt.png");
                                      setReceiptScreenshotBase64("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=");
                                    }}
                                    className="text-[9px] font-bold text-indigo-600 bg-indigo-50 hover:bg-indigo-100 px-2.5 py-1.5 rounded-lg transition-all cursor-pointer shadow-sm hover:scale-[1.02] active:scale-[0.98]"
                                  >
                                    ✨ Quick-Fill Receipt Details
                                  </button>
                                </div>
                                <div className="grid grid-cols-1 md:grid-cols-3 gap-3.5 text-left">
                                  <div className="space-y-1">
                                    <label className="text-[9px] font-bold text-slate-500 uppercase tracking-wider block text-left">
                                      Transaction ID / Ref <span className="text-red-500">*</span>
                                    </label>
                                    <input
                                      type="text"
                                      required
                                      placeholder="e.g. CBE-TXN-9817 / Zelle ID 182"
                                      value={transactionRef}
                                      onChange={(e) =>
                                        setTransactionRef(e.target.value)
                                      }
                                      className="w-full bg-white border border-slate-200 rounded-lg px-3 py-2 text-xs text-slate-700 font-mono outline-none focus:ring-1 focus:ring-primary focus:border-primary transition-all font-bold"
                                    />
                                  </div>

                                  <div className="space-y-1">
                                    <label className="text-[9px] font-bold text-slate-500 uppercase tracking-wider block text-left">
                                      Depositor / Sender Full Name <span className="text-red-500">*</span>
                                    </label>
                                    <input
                                      type="text"
                                      required
                                      placeholder="e.g. Biruk Tsegaye"
                                      value={paymentSenderName}
                                      onChange={(e) =>
                                        setPaymentSenderName(e.target.value)
                                      }
                                      className="w-full bg-white border border-slate-200 rounded-lg px-3 py-2 text-xs text-slate-700 outline-none focus:ring-1 focus:ring-primary focus:border-primary transition-all font-bold"
                                    />
                                  </div>

                                  <div className="space-y-1">
                                    <label className="text-[9px] font-bold text-slate-500 uppercase tracking-wider block text-left">
                                      Uploader Screenshot <span className="text-red-500">*</span>
                                    </label>
                                    <div className="relative border border-dashed border-slate-200 bg-white rounded-lg hover:bg-slate-50/50 transition-colors cursor-pointer flex items-center justify-between p-1.5 px-2">
                                      <input
                                        type="file"
                                        id="enrollment-receipt-upload"
                                        accept="image/*,application/pdf"
                                        onChange={async (e) => {
                                          const file = e.target.files?.[0];
                                          if (file) {
                                            setReceiptScreenshotName(file.name);
                                            try {
                                              const base64 = await compressImageToBase64(file, 800 * 1024);
                                              setReceiptScreenshotBase64(base64);
                                            } catch (err: any) {
                                              alert(err.message || "Failed to compress/read receipt screenshot.");
                                            }
                                          }
                                        }}
                                        className="absolute inset-0 opacity-0 cursor-pointer h-full w-full"
                                      />
                                      <div className="flex items-center gap-1.5 max-w-[170px] truncate">
                                        <span className="text-xs">📎</span>
                                        <span className="text-[10px] font-bold text-slate-500 truncate">
                                          {receiptScreenshotName || "Attach snapshot..."}
                                        </span>
                                      </div>
                                      <span className="text-[8px] font-bold uppercase bg-slate-50 hover:bg-slate-100 px-2 py-1 rounded border text-slate-500 tracking-wider shrink-0">
                                        Browse
                                      </span>
                                    </div>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        )}
                      </>
                    ) : (
                      <div className="p-8 border-2 border-dashed border-slate-100 rounded-[32px] flex flex-col items-center justify-center text-slate-300">
                        <Users size={32} strokeWidth={1} />
                        <p className="text-xs mt-3 font-medium">
                          Select a tutor to view available session times
                        </p>
                      </div>
                    )}
                  </div>

                  <div className="pt-4 border-t border-slate-100 flex items-center justify-between gap-8">
                    <div>
                      <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mb-1">
                        Total Subscription
                      </p>
                      <p className="text-xl font-bold text-slate-900">
                        {appliedPromo ? (
                          <>
                            <span className="text-slate-300 line-through text-xs mr-2 font-mono">
                              ${useCustomCreditsNew ? (customCreditQuantity * 40) : (selectedPlan?.price || 0)}.00
                            </span>
                            <span className="text-emerald-600 font-extrabold font-mono">
                              ${Math.round((useCustomCreditsNew ? (customCreditQuantity * 40) : (selectedPlan?.price || 0)) * ((100 - appliedPromo.discountPercent) / 100))}.00
                            </span>
                          </>
                        ) : (
                          `$${useCustomCreditsNew ? (customCreditQuantity * 40) : (selectedPlan?.price || 0)}.00`
                        )}
                        {" "}
                        <span className="text-xs text-slate-400 font-medium font-mono uppercase tracking-wider">
                          {useCustomCreditsNew ? "/ pack" : "/ month"}
                        </span>
                      </p>
                    </div>
                    <button
                      disabled={
                        isSubscribing ||
                        (!selectedPlan && !useCustomCreditsNew) ||
                        !selectedTutorId ||
                        recurringTimes.length < (useCustomCreditsNew ? 1 : (selectedPlan ? selectedPlan.sessions / 4 : 1)) ||
                        !transactionRef ||
                        !receiptScreenshotName ||
                        !paymentSenderName
                      }
                      type="submit"
                      className="bg-primary text-white font-bold px-10 py-4 rounded-2xl text-xs uppercase tracking-widest hover:bg-primary/90 disabled:opacity-50 disabled:cursor-not-allowed transition-all shadow-xl shadow-primary/20 flex items-center gap-3"
                    >
                      {isSubscribing ? (
                        <Loader2 className="animate-spin" size={18} />
                      ) : (
                        <>
                          <CardIcon size={18} />
                          Enroll Student
                        </>
                      )}
                    </button>
                  </div>
                </form>
              )}
            </div>
          </div>
        </div>
      )}

      {/* CLASSROOM CHANNEL: TUTOR CHAT OVERLAY DRAWER */}
      {activeTutorChatId && activeTutorChatTutor && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm flex items-center justify-end z-50 font-sans animate-in fade-in duration-300">
          <div className="w-full max-w-md bg-white h-full shadow-2xl flex flex-col animate-in slide-in-from-right duration-500">
            {/* Header */}
            <div className="p-4 border-b border-slate-100 flex items-center justify-between bg-primary text-white text-left">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-full bg-white/20 text-white flex items-center justify-center font-bold text-sm">
                  {activeTutorChatTutor.name?.charAt(0) || "T"}
                </div>
                <div>
                  <h3 className="font-bold text-sm leading-tight">{activeTutorChatTutor.name}</h3>
                  <span className="text-[10px] text-white/80 font-medium">Classroom Tutor Channel</span>
                </div>
              </div>
              <button
                onClick={() => {
                  setActiveTutorChatId(null);
                  setActiveTutorChatTutor(null);
                  setTutorChatViolationWarning(null);
                }}
                className="p-1 text-white/80 hover:text-white rounded-full hover:bg-white/10 transition-colors cursor-pointer"
              >
                <X size={18} />
              </button>
            </div>

            {/* Chat Messages */}
            <div className="flex-1 p-4 overflow-y-auto space-y-4 bg-slate-50/50">
              {tutorChatMessages.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-slate-400 p-8 text-center font-sans">
                  <div className="w-12 h-12 rounded-full bg-primary/5 text-primary flex items-center justify-center mb-3">
                    <MessageCircle size={22} className="stroke-[1.5]" />
                  </div>
                  <h5 className="font-bold text-slate-700 text-xs mb-1">
                    Start of Conversation
                  </h5>
                  <p className="text-[10px] text-slate-400 font-medium leading-relaxed max-w-xs">
                    Welcome to your private classroom messenger with {activeTutorChatTutor.name}. Type security-compliant messages below to begin coaching coordinates.
                  </p>
                </div>
              ) : (
                tutorChatMessages.map((msg: any) => {
                  const isMe = msg.senderId === user?.uid;
                  const dateStr = formatSafeDate(msg.createdAt, { hour: '2-digit', minute: '2-digit' });
                  return (
                    <div
                      key={msg.id}
                      className={cn(
                        "flex flex-col max-w-[80%] leading-relaxed gap-0.5 text-xs text-left",
                        isMe ? "ml-auto items-end" : "mr-auto items-start"
                      )}
                    >
                      <span className="text-[9px] font-bold text-slate-400 uppercase tracking-wider">
                        {isMe ? "You" : msg.senderName}
                      </span>
                      <div
                        className={cn(
                          "px-3 py-2 rounded-2xl border font-medium whitespace-pre-wrap",
                          isMe
                            ? "bg-primary border-primary text-white"
                            : "bg-white border-slate-200 text-slate-800"
                        )}
                      >
                        {msg.text}
                      </div>
                      <span className="text-[9px] text-slate-400 font-semibold">
                        {dateStr}
                      </span>
                    </div>
                  );
                })
              )}
            </div>

            {/* Warning Area */}
            {tutorChatViolationWarning && (
              <div className="px-4 py-2 bg-amber-50 border-t border-b border-amber-100 text-left">
                <p className="text-[10px] text-amber-705 font-bold leading-relaxed">
                  ⚠️ {tutorChatViolationWarning}
                </p>
              </div>
            )}

            {/* Input Form */}
            <form onSubmit={handleSendTutorMessage} className="p-4 border-t border-slate-100 flex gap-2 font-sans">
              <input
                type="text"
                placeholder="Type lesson coordinates / inquiry..."
                value={tutorChatMessageInput}
                onChange={(e) => setTutorChatMessageInput(e.target.value)}
                disabled={sendingTutorChatMessageState}
                className="flex-1 bg-slate-50 border border-slate-200 outline-none focus:ring-1 focus:ring-primary focus:bg-white focus:border-primary px-3 py-2 text-xs rounded-xl text-slate-800 font-medium disabled:opacity-50"
              />
              <button
                type="submit"
                disabled={sendingTutorChatMessageState || !tutorChatMessageInput.trim()}
                className="bg-primary hover:bg-opacity-95 text-white p-2.5 rounded-xl text-xs font-bold transition-all disabled:opacity-50 cursor-pointer"
              >
                {sendingTutorChatMessageState ? (
                  <Loader2 className="animate-spin text-white" size={14} />
                ) : (
                  <span>Send</span>
                )}
              </button>
            </form>
          </div>
        </div>
      )}

      {/* LessonViewer container modal */}
      <LessonViewer isOpen={libraryOpen} onClose={() => setLibraryOpen(false)} isSubscribed={!!activeStudent?.plan && activeStudent?.status !== "expired"} />
      <SupportWidget 
        assignedTutor={(() => {
          const student = activeStudent;
          const tutorId = student?.tutorId;
          return tutors.find((t) => t.id === tutorId);
        })()} 
        onOpenTutorChat={handleOpenTutorChat} 
      />
    </div>
  );
}

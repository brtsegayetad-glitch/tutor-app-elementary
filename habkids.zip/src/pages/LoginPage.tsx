import { useAuth } from '../context/AuthContext';
import { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { Loader2, Globe, ShieldCheck, Mail, Lock, Eye, EyeOff } from 'lucide-react';
import { sendPasswordResetEmail } from 'firebase/auth';
import { auth, db } from '../lib/firebase';
import { collection, query, where, getDocs } from 'firebase/firestore';
import { subscribeToSettings } from '../services/dataService';
import BrandLogo from '../components/BrandLogo';

export default function LoginPage() {
  const { signInWithGoogle, signInWithEmail, user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [errorMsg, setErrorMsg] = useState('');
  const [emailLoading, setEmailLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [resetSent, setResetSent] = useState(false);
  const [resetLoading, setResetLoading] = useState(false);
  const [activeLogoUrl, setActiveLogoUrl] = useState('/reallogo2.png');
  const navigate = useNavigate();

  // Watch for user changes and navigate automatically
  useEffect(() => {
    if (user) {
      const searchParams = new URLSearchParams(window.location.search);
      const redirectPath = searchParams.get('redirect');
      if (redirectPath) {
        navigate(redirectPath, { replace: true });
      } else {
        if (user.role) {
          navigate(`/${user.role}`);
        } else {
          navigate('/parent'); // Fallback default
        }
      }
    }
  }, [user, navigate]);

  // Subscribe to settings for dynamic brand logo
  useEffect(() => {
    const unsubscribe = subscribeToSettings((data) => {
      if (data && data.activeLogoUrl) {
        setActiveLogoUrl(data.activeLogoUrl);
      }
    });
    return () => unsubscribe();
  }, []);

  const handleLogin = async () => {
    setLoading(true);
    setErrorMsg('');
    try {
      await signInWithGoogle();
    } catch (error: any) {
      const errCode = error?.code || '';
      const errMsg = error?.message || '';
      if (
        errCode === 'auth/cancelled-popup-request' ||
        errCode === 'auth/popup-blocked' ||
        errCode === 'auth/popup-closed-by-user' ||
        errMsg.toLowerCase().includes('popup') ||
        errMsg.toLowerCase().includes('cancel')
      ) {
        console.warn("Login popup was blocked or cancelled:", error);
        setErrorMsg("Google Sign-In popup was blocked or closed. Because this app runs inside an iframe-based editor, browsers often restrict authenticating popups. Tip: Click 'Open in New Tab' in the top right to use secure Google Auth.");
      } else {
        console.error("Login failed", error);
        setErrorMsg(errMsg || 'Google Sign-In failed. Please check your network and try again.');
      }
    } finally {
      setLoading(false);
    }
  };

  const handleEmailLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setEmailLoading(true);
    
    try {
      await signInWithEmail(email, password);
    } catch (error: any) {
      console.error("Credentials login failed", error);
      if (error.code === 'auth/operation-not-allowed') {
        setErrorMsg("Email/Password Sign-In is not yet enabled in your Firebase Console. Please open your Firebase Console, navigate to 'Authentication' > 'Sign-in method', and enable 'Email/Password' to start using email credentials!");
      } else {
        setErrorMsg(error.message || 'Login failed. Please check your credentials.');
      }
    } finally {
      setEmailLoading(false);
    }
  };

  const handleForgotPassword = async () => {
    setErrorMsg('');
    setResetSent(false);
    if (!email) {
      setErrorMsg('Please enter your email address in the email field first, then click "Forgot Password" to receive a password reset link.');
      return;
    }
    setResetLoading(true);
    try {
      await sendPasswordResetEmail(auth, email.trim().toLowerCase());
      setResetSent(true);
    } catch (error: any) {
      console.error("Password reset error:", error);
      const errCode = error.code;
      if (errCode === 'auth/user-not-found' || errCode === 'auth/invalid-email') {
        try {
          const cleanEmail = email.trim().toLowerCase();
          const qUsers = query(collection(db, 'users'), where('email', '==', cleanEmail));
          const usersSnap = await getDocs(qUsers);
          
          const qTutors = query(collection(db, 'tutors'), where('email', '==', cleanEmail));
          const tutorsSnap = await getDocs(qTutors);

          const qApps = query(collection(db, 'tutor_applications'), where('email', '==', cleanEmail));
          const appsSnap = await getDocs(qApps);

          if (!usersSnap.empty || !tutorsSnap.empty || !appsSnap.empty) {
            setErrorMsg("We found your registered profile in our records! Since you don't have a portal password set yet, please log in once on this page using your email and any password of your choice to activate and secure your account.");
            return;
          }
        } catch (dbErr) {
          console.error("Failed to query Firestore for legacy user:", dbErr);
        }
      }
      setErrorMsg(error.message || 'Could not send reset link. Please check the email and try again.');
    } finally {
      setResetLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-surface flex md:items-center justify-center p-6">
      <div className="max-w-4xl w-full bg-white rounded-[40px] shadow-2xl overflow-hidden flex flex-col md:flex-row border border-gray-100">
        
        {/* Left: Brand */}
        <div className="md:w-1/2 bg-primary p-12 text-white flex flex-col justify-between relative overflow-hidden">
          <Link to="/" className="flex items-center gap-2 relative z-10">
            <div className="w-10 h-10 flex items-center justify-center bg-white rounded-xl p-1 overflow-hidden">
              <BrandLogo logoUrl={activeLogoUrl} className="max-h-full max-w-full object-contain" />
            </div>
            <span className="font-serif text-2xl font-bold text-white tracking-tight">HabKids</span>
          </Link>
          
          <div className="relative z-10">
            <h1 className="text-5xl font-serif font-bold italic mb-6 leading-tight">Welcome back to Heritage Learning.</h1>
            <p className="text-white/60 text-lg leading-relaxed">
              Access your personalized learning portal to track progress, manage sessions, and connect with your tutor.
            </p>
          </div>

          <div className="flex items-center gap-4 relative z-10">
            <div className="flex -space-x-3">
              {[1, 2, 3].map(i => <img key={i} src={`https://i.pravatar.cc/100?u=l${i}`} className="w-8 h-8 rounded-full border-2 border-primary" alt="user" />)}
            </div>
            <span className="text-sm text-white/40">Trusted by families abroad.</span>
          </div>
          
          <div className="absolute -bottom-20 -left-20 w-64 h-64 bg-white/5 rounded-full blur-3xl"></div>
        </div>

        {/* Right: Login Content */}
        <div className="md:w-1/2 p-12 md:p-16 flex flex-col justify-center">
          <div className="mb-8">
            <h2 className="text-3xl font-serif font-bold text-primary mb-1">Portal Sign In</h2>
            <p className="text-gray-500 text-xs">Access your personalized Amharic learning dashboard.</p>
          </div>

          <div className="space-y-6">
            <button 
              onClick={handleLogin}
              disabled={loading}
              className="w-full flex items-center justify-center gap-4 p-4 bg-white border border-gray-200 rounded-2xl hover:bg-surface transition-all shadow-sm font-bold text-gray-700"
            >
              <svg className="w-6 h-6" viewBox="0 0 48 48">
                <path fill="#FFC107" d="M43.611,20.083H42V20H24v8h11.303c-1.64,4.657-6.08,8-11.303,8c-6.627,0-12-5.373-12-12c0-6.627,5.373-12,12-12c3.059,0,5.842,1.154,7.961,3.039l5.657-5.657C34.046,6.053,29.268,4,24,4C12.955,4,4,12.955,4,24c0,11.045,8.955,20,20,20c11.045,0,20-8.955,20-20C44,22.659,43.862,21.35,43.611,20.083z" />
                <path fill="#FF3D00" d="M6.306,14.691l6.571,4.819C14.655,15.108,18.961,12,24,12c3.059,0,5.842,1.154,7.961,3.039l5.657-5.657C34.046,6.053,29.268,4,24,4C16.318,4,9.656,8.337,6.306,14.691z" />
                <path fill="#4CAF50" d="M24,44c5.166,0,9.86-1.977,13.409-5.192l-6.19-5.238C29.211,35.091,26.715,36,24,36c-5.202,0-9.619-3.317-11.283-7.946l-6.522,5.025C9.505,39.556,16.227,44,24,44z" />
                <path fill="#1976D2" d="M43.611,20.083H42V20H24v8h11.303c-0.792,2.251-2.221,4.155-4.067,5.551l6.232,5.274C39.69,35.048,44,29.897,44,24C44,22.659,43.862,21.35,43.611,20.083z" />
              </svg>
              Sign in with Google
            </button>

            <div className="flex items-center gap-4 text-gray-300">
               <div className="h-px bg-gray-100 flex-1"></div>
               <span className="text-xs font-bold whitespace-nowrap">OR SIGN IN WITH PASSWORD</span>
               <div className="h-px bg-gray-100 flex-1"></div>
            </div>

            {errorMsg && (
              <div className="p-3.5 bg-red-50 text-red-700 text-xs rounded-[14px] border border-red-100 font-medium">
                {errorMsg}
              </div>
            )}

            {resetSent && (
              <div className="p-3.5 bg-emerald-50 text-emerald-800 text-xs rounded-[14px] border border-emerald-100 font-medium">
                📬 Password reset link sent! Please check your email inbox (and spam folder) for instructions.
              </div>
            )}

            <form onSubmit={handleEmailLogin} className="space-y-4">
              <div>
                <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-1.5">Email Address</label>
                <div className="relative">
                  <Mail size={16} className="absolute left-4 top-3 text-gray-400" />
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full pl-11 pr-4 py-2.5 bg-white border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/5 focus:border-primary transition-all text-sm"
                    placeholder="name@example.com"
                    required
                  />
                </div>
              </div>

              <div>
                <div className="flex justify-between items-center mb-1.5">
                  <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-wider">Password</label>
                  <button
                    type="button"
                    onClick={handleForgotPassword}
                    disabled={resetLoading}
                    className="text-[10px] font-bold text-primary hover:underline transition-all outline-none"
                  >
                    {resetLoading ? 'Sending Reset...' : 'Forgot Password?'}
                  </button>
                </div>
                <div className="relative">
                  <Lock size={16} className="absolute left-4 top-3 text-gray-400" />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full pl-11 pr-12 py-2.5 bg-white border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary/5 focus:border-primary transition-all text-sm font-mono placeholder:font-sans"
                    placeholder="••••••••"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-4 top-3 text-gray-400 hover:text-gray-600 focus:outline-none"
                  >
                    {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                  </button>
                </div>
              </div>

              <button
                type="submit"
                disabled={emailLoading}
                className="w-full bg-primary hover:bg-opacity-95 text-white py-3 rounded-xl font-bold text-sm shadow-md transition-all flex items-center justify-center gap-2"
              >
                {emailLoading ? <Loader2 size={16} className="animate-spin" /> : 'Portal Sign In'}
              </button>
            </form>
          </div>

          <div className="mt-12 pt-8 border-t border-gray-50 text-center flex flex-col sm:flex-row items-center justify-center gap-2 sm:gap-6 text-sm text-gray-400">
            <p>
              New to HabKids? <Link to="/book-trial" className="text-primary font-bold hover:underline">Book a trial session</Link>
            </p>
            <span className="hidden sm:inline text-gray-200">|</span>
            <p>
              Create accounts <Link to="/signup" className="text-primary font-bold hover:underline">Sign up here</Link>
            </p>
          </div>
        </div>
      </div>

      {loading && (
        <div className="fixed inset-0 bg-white/60 backdrop-blur-sm z-50 flex items-center justify-center">
          <Loader2 className="w-12 h-12 text-primary animate-spin" />
        </div>
      )}
    </div>
  );
}

function ChevronRight(props: any) {
  return (
    <svg 
      {...props}
      xmlns="http://www.w3.org/2000/svg" 
      width="24" 
      height="24" 
      viewBox="0 0 24 24" 
      fill="none" 
      stroke="currentColor" 
      strokeWidth="2" 
      strokeLinecap="round" 
      strokeLinejoin="round" 
    >
      <path d="m9 18 6-6-6-6"/>
    </svg>
  );
}

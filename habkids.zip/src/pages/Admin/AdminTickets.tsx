import React, { useState, useEffect, useRef } from 'react';
import { 
  Send, 
  Search, 
  User, 
  MessageSquare,
  Shield,
  Clock,
  CheckCircle,
  HelpCircle,
  Filter,
  Check,
  ArrowUpRight,
  Inbox,
  Sparkles,
  AlertCircle,
  Loader2
} from 'lucide-react';
import { 
  subscribeToSupportTickets, 
  addSupportTicketReply, 
  updateSupportTicketStatus 
} from '../../services/dataService';
import { useAuth } from '../../context/AuthContext';
import { cn } from '../../lib/utils';

export default function AdminTickets() {
  const { user } = useAuth();
  const [tickets, setTickets] = useState<any[]>([]);
  const [activeTicket, setActiveTicket] = useState<any | null>(null);
  const [textInput, setTextInput] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'open' | 'resolved'>('open');
  const [loading, setLoading] = useState(true);
  const [replying, setReplying] = useState(false);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Load real-time tickets stream
  useEffect(() => {
    const unsubscribe = subscribeToSupportTickets(
      (data) => {
        setTickets(data);
        setLoading(false);
        
        // If we have an active ticket, update it from the live feed to retain reactive updates (e.g. parent replies)
        if (activeTicket) {
          const updated = data.find(t => t.id === activeTicket.id);
          if (updated) {
            setActiveTicket(updated);
          }
        }
      },
      () => {
        setLoading(false);
      }
    );

    return () => unsubscribe();
  }, [activeTicket?.id]);

  // Scroll details to bottom on updates
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [activeTicket?.replies]);

  // Filter & Search Tickets list
  const filteredTickets = tickets.filter(ticket => {
    const search = searchTerm.toLowerCase();
    const matchesSearch = 
      ticket.parentName?.toLowerCase().includes(search) ||
      ticket.parentEmail?.toLowerCase().includes(search) ||
      ticket.question?.toLowerCase().includes(search) ||
      ticket.topic?.toLowerCase().includes(search);
      
    if (statusFilter === 'all') return matchesSearch;
    return ticket.status === statusFilter && matchesSearch;
  });

  const handleSendReply = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!textInput.trim() || !activeTicket) return;

    setReplying(true);
    const result = await addSupportTicketReply(activeTicket.id, {
      senderRole: 'admin',
      senderName: user?.fullName || 'Heritage Admin',
      text: textInput.trim()
    });
    setReplying(false);
    
    if (result.success) {
      setTextInput('');
    }
  };

  const handleToggleResolve = async () => {
    if (!activeTicket) return;
    const nextStatus = activeTicket.status === 'resolved' ? 'open' : 'resolved';
    const result = await updateSupportTicketStatus(activeTicket.id, nextStatus);
    if (result.success) {
      // Direct local update to prevent any flicker while Firestore snapshot streams
      setActiveTicket(prev => prev ? { ...prev, status: nextStatus } : null);
    }
  };

  const getTopicBadgeStyle = (topic: string) => {
    const t = topic?.toLowerCase() || '';
    if (t.includes('curriculum')) {
      return 'bg-purple-50 text-purple-700 border-purple-100';
    }
    if (t.includes('schedule') || t.includes('time')) {
      return 'bg-secondary/10 text-secondary border-secondary/20';
    }
    if (t.includes('billing') || t.includes('price') || t.includes('payment')) {
      return 'bg-emerald-50 text-emerald-800 border-emerald-100';
    }
    if (t.includes('language') || t.includes('tutor')) {
      return 'bg-blue-50 text-blue-700 border-blue-105';
    }
    return 'bg-slate-50 text-slate-650 border-slate-200';
  };

  const formatTicketTime = (createdAt: any) => {
    if (!createdAt) return 'Recent';
    const date = createdAt.toDate ? createdAt.toDate() : new Date(createdAt);
    return date.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <div className="space-y-6">
      {/* Header section */}
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-4 text-left">
        <div>
          <h1 className="text-3xl font-bold text-primary mb-1 tracking-tight flex items-center gap-2">
            <Inbox className="text-secondary" size={28} />
            <span>Support Tickets</span>
          </h1>
          <p className="text-slate-500 text-sm">Review, respond, and resolve general parent questions immediately.</p>
        </div>
        
        {/* Statistics highlights */}
        <div className="flex gap-4">
          <div className="bg-white border border-slate-100 shadow-sm p-4 rounded-xl flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-amber-50 text-amber-600 flex items-center justify-center font-bold">
              {tickets.filter(t => t.status === 'open').length}
            </div>
            <div className="text-left">
              <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Open Tickets</p>
              <p className="text-xs font-semibold text-slate-700">Awaiting Feedback</p>
            </div>
          </div>
          <div className="bg-white border border-slate-100 shadow-sm p-4 rounded-xl flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center font-bold">
              {tickets.filter(t => t.status === 'resolved').length}
            </div>
            <div className="text-left">
              <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Resolved Cases</p>
              <p className="text-xs font-semibold text-slate-700">Fully Addressed</p>
            </div>
          </div>
        </div>
      </header>

      {/* Main Container Grid */}
      <div className="h-[calc(100vh-14rem)] bg-white rounded-2xl border border-slate-150 shadow-xs flex overflow-hidden">
        
        {/* Left Side: Tickets list panel */}
        <div className="w-80 border-r border-slate-150 flex flex-col bg-slate-50/20 shrink-0">
          {/* List Search & Navigation Filters */}
          <div className="p-4 border-b border-slate-150 space-y-3 bg-white text-left">
            <div className="flex items-center justify-between">
              <h2 className="text-xs font-extrabold text-slate-400 uppercase tracking-wider">Parent Queries</h2>
              <span className="text-[10px] font-bold bg-slate-100 text-slate-500 px-2.5 py-0.5 rounded-full">
                {filteredTickets.length} found
              </span>
            </div>

            <div className="flex items-center bg-slate-100 rounded-lg px-2.5 py-1.5 border border-slate-200 focus-within:ring-2 focus-within:ring-primary/5 focus-within:border-primary transition-all">
              <Search size={14} className="text-slate-400 mr-2 shrink-0" />
              <input 
                type="text" 
                placeholder="Search ticket content..." 
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="bg-transparent border-none focus:outline-none text-xs w-full text-slate-650" 
              />
            </div>

            {/* Filter buttons */}
            <div className="grid grid-cols-3 gap-1 pt-1">
              {(['open', 'resolved', 'all'] as const).map((filter) => (
                <button
                  key={filter}
                  onClick={() => setStatusFilter(filter)}
                  className={cn(
                    "text-[10px] font-bold uppercase py-1.5 rounded-lg transition-colors cursor-pointer border",
                    statusFilter === filter
                      ? "bg-slate-900 border-slate-900 text-white"
                      : "bg-white border-slate-200 text-slate-500 hover:text-slate-800"
                  )}
                >
                  {filter}
                </button>
              ))}
            </div>
          </div>

          {/* Actual list scrolling */}
          <div className="flex-1 overflow-y-auto divide-y divide-slate-100" id="tickets-list">
            {filteredTickets.map((ticket) => {
              const isSelected = activeTicket?.id === ticket.id;
              const hasReplied = ticket.replies && ticket.replies.length > 0;
              const lastReplierRole = hasReplied ? ticket.replies[ticket.replies.length-1].senderRole : null;
              
              return (
                <button
                  key={ticket.id}
                  onClick={() => setActiveTicket(ticket)}
                  className={cn(
                    "w-full text-left p-4 flex flex-col gap-1.5 transition-colors cursor-pointer border-l-4 relative",
                    isSelected 
                      ? "bg-slate-50 border-l-secondary" 
                      : "border-l-transparent hover:bg-slate-50/50"
                  )}
                >
                  <div className="flex items-center justify-between gap-2 w-full">
                    <p className="text-xs font-bold text-slate-900 truncate max-w-[150px]">
                      {ticket.parentName}
                    </p>
                    <span className="text-[9px] text-slate-400 font-mono shrink-0">
                      {ticket.createdAt ? new Date(ticket.createdAt.toDate ? ticket.createdAt.toDate() : ticket.createdAt).toLocaleDateString() : 'Just now'}
                    </span>
                  </div>

                  <span className={cn(
                    "px-2 py-0.5 rounded text-[8px] font-bold uppercase tracking-wider border mr-auto max-w-[190px] truncate",
                    getTopicBadgeStyle(ticket.topic)
                  )}>
                    {ticket.topic || "General support"}
                  </span>

                  <p className="text-xs text-slate-500 truncate leading-tight w-full">
                    {ticket.question}
                  </p>

                  <div className="flex items-center gap-1.5 mt-1 w-full justify-between">
                    <span className={cn(
                      "text-[9px] font-bold uppercase px-1.5 py-0.5 rounded-md",
                      ticket.status === 'resolved' 
                        ? 'bg-emerald-50 text-emerald-700' 
                        : 'bg-amber-50 text-amber-700'
                    )}>
                      ● {ticket.status}
                    </span>
                    
                    {hasReplied && (
                      <span className={cn(
                        "text-[8px] font-semibold uppercase tracking-wide",
                        lastReplierRole === 'admin' ? "text-slate-400" : "text-secondary font-bold"
                      )}>
                        {lastReplierRole === 'admin' ? "You Replied" : "New Parent Reply ↩"}
                      </span>
                    )}
                  </div>
                </button>
              );
            })}

            {filteredTickets.length === 0 && !loading && (
              <div className="p-8 text-center text-slate-400 text-xs italic">
                No tickets matching current filters.
              </div>
            )}

            {loading && (
              <div className="p-8 flex items-center justify-center text-slate-400 text-xs gap-2">
                <span className="w-4 h-4 rounded-full border border-secondary border-t-transparent animate-spin shrink-0"></span>
                <span>Fetching ticket database...</span>
              </div>
            )}
          </div>
        </div>

        {/* Right Side: Conversation workspace thread */}
        <div className="flex-1 flex flex-col bg-slate-50/25">
          {activeTicket ? (
            <>
              {/* Ticket Workspace Header */}
              <div className="p-4 border-b border-slate-100 bg-white flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-left">
                <div>
                  <div className="flex items-center gap-2 flex-wrap mb-1">
                    <span className={cn(
                      "px-2.5 py-0.5 rounded-full text-[9px] font-bold uppercase tracking-wider border",
                      getTopicBadgeStyle(activeTicket.topic)
                    )}>
                      {activeTicket.topic || "General Enquiry"}
                    </span>
                    <span className={cn(
                      "px-2.5 py-0.5 rounded-full text-[9px] font-bold uppercase tracking-wider border",
                      activeTicket.status === 'resolved' ? "bg-emerald-50 text-emerald-700 border-emerald-100" : "bg-amber-50 text-amber-700 border-amber-100"
                    )}>
                      {activeTicket.status === 'resolved' ? "resolved" : "open"}
                    </span>
                  </div>
                  
                  <h3 className="text-sm font-bold text-slate-900 leading-tight">
                    Inquiry from {activeTicket.parentName}
                  </h3>
                  <p className="text-[10px] text-slate-400 mt-0.5 font-medium">
                    Primary Contact Email: <span className="font-semibold text-slate-600">{activeTicket.parentEmail}</span>
                  </p>
                </div>

                <button
                  onClick={handleToggleResolve}
                  className={cn(
                    "btn-secondary text-[10px] py-2 px-3.5 shadow-sm font-bold uppercase flex items-center gap-1.5 shrink-0 cursor-pointer text-center",
                    activeTicket.status === 'resolved' 
                      ? "bg-slate-100 border-slate-200 text-slate-650 hover:bg-slate-200 hover:text-slate-800" 
                      : "bg-emerald-50 border-emerald-200 text-emerald-700 hover:bg-emerald-600 hover:text-white"
                  )}
                >
                  <CheckCircle size={14} />
                  <span>{activeTicket.status === 'resolved' ? "Reopen Ticket" : "Mark as Resolved"}</span>
                </button>
              </div>

              {/* Chat Thread Container */}
              <div className="flex-1 overflow-y-auto p-6 space-y-4">
                
                {/* 1. Parent's Original Inquiry (Anchored at the start of conversation) */}
                <div className="bg-white p-5 rounded-2xl border border-slate-150 shadow-sm text-left space-y-3 max-w-2xl mx-auto">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2 text-slate-650">
                      <HelpCircle size={18} className="text-secondary" />
                      <span className="text-xs font-bold uppercase tracking-wider text-slate-500">Original Inquiry</span>
                    </div>
                    <span className="text-[10px] font-bold text-slate-400 font-mono">
                      {formatTicketTime(activeTicket.createdAt)}
                    </span>
                  </div>
                  
                  <p className="text-xs font-bold text-slate-800 leading-relaxed bg-slate-50/50 p-4 rounded-xl border border-slate-100">
                    "{activeTicket.question}"
                  </p>
                  
                  <div className="border-t border-slate-50 pt-3 flex items-center justify-between text-[10px] text-slate-400 font-medium font-sans">
                    <span>Contact Person: {activeTicket.parentName}</span>
                    <span>Email Address: {activeTicket.parentEmail}</span>
                  </div>
                </div>

                {/* Separator line */}
                <div className="relative py-2 flex items-center justify-center max-w-2xl mx-auto">
                  <div className="absolute inset-0 flex items-center" aria-hidden="true">
                    <div className="w-full border-t border-slate-200"></div>
                  </div>
                  <span className="relative px-3 bg-slate-50/45 text-[9px] font-extrabold uppercase text-slate-400 tracking-widest">
                    Response History
                  </span>
                </div>

                {/* 2. Interactive replies stream */}
                <div className="space-y-4 max-w-2xl mx-auto">
                  {activeTicket.replies?.map((reply: any, idx: number) => {
                    const isAdmin = reply.senderRole === 'admin';
                    return (
                      <div 
                        key={idx} 
                        className={cn(
                          "flex flex-col max-w-[80%] space-y-1 text-left",
                          isAdmin ? "ml-auto items-end" : "mr-auto items-start"
                        )}
                      >
                        <div className="flex items-center gap-1.5 text-[10px] text-slate-400 font-medium px-1">
                          <span>{isAdmin ? "You" : reply.senderName}</span>
                          <span>•</span>
                          <span>{reply.createdAt ? new Date(reply.createdAt).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }) : 'Recent'}</span>
                        </div>

                        <div className={cn(
                          "p-3 rounded-2xl text-xs leading-relaxed",
                          isAdmin 
                            ? "bg-slate-905 bg-primary text-white rounded-tr-none shadow-xs" 
                            : "bg-white text-slate-800 rounded-tl-none border border-slate-150 shadow-xs"
                        )}>
                          {reply.text}
                        </div>
                      </div>
                    );
                  })}

                  {(!activeTicket.replies || activeTicket.replies.length === 0) && (
                    <div className="p-10 text-center text-slate-400 text-xs italic bg-white/50 border border-dashed border-slate-200 rounded-2xl shadow-xs">
                      No replies recorded yet. Type an educational response below to connect with this parent immediately!
                    </div>
                  )}
                  
                  {/* Anchor */}
                  <div ref={messagesEndRef} />
                </div>
              </div>

              {/* Message Reply Form (Footer) */}
              <form onSubmit={handleSendReply} className="p-4 border-t border-slate-100 bg-white flex gap-3">
                <input 
                  type="text" 
                  placeholder={`Reply to ${activeTicket.parentName}...`}
                  value={textInput}
                  onChange={(e) => setTextInput(e.target.value)}
                  className="flex-1 bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-primary/10 focus:border-primary transition-all" 
                />
                <button 
                  type="submit" 
                  id="send-ticket-reply-btn"
                  disabled={replying || !textInput.trim()}
                  className="bg-primary hover:bg-primary/95 text-white rounded-xl px-5 py-2.5 flex items-center justify-center transition-colors cursor-pointer shrink-0 shadow-sm disabled:opacity-40"
                >
                  {replying ? (
                    <Loader2 className="animate-spin" size={14} />
                  ) : (
                    <>
                      <Send size={14} className="mr-1.5" />
                      <span className="text-xs font-bold">Reply</span>
                    </>
                  )}
                </button>
              </form>
            </>
          ) : (
            /* Empty/Welcome View */
            <div className="flex-1 flex flex-col items-center justify-center p-8 text-center max-w-sm mx-auto space-y-4">
              <div className="w-16 h-16 bg-slate-100 rounded-2xl flex items-center justify-center text-slate-400">
                <Inbox size={28} />
              </div>
              <div>
                <h3 className="text-sm font-bold text-slate-800">Support Workspace Empty</h3>
                <p className="text-[11px] text-slate-400 leading-relaxed mt-2 mt-1">
                  Select a parent's support ticket from the left sidebar feed to respond directly, update its status, or review parent details in real-time.
                </p>
              </div>
            </div>
          )}
        </div>

      </div>
    </div>
  );
}

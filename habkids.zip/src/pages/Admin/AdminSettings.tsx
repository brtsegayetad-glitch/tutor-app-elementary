import React, { useState, useEffect } from 'react';
import { 
  Settings, 
  DollarSign, 
  Globe, 
  Mail, 
  Phone, 
  Sparkles, 
  Loader2, 
  CheckCircle2, 
  HelpCircle,
  AlertCircle,
  Activity,
  Send,
  RefreshCw,
  Database,
  Check,
  X,
  Gift,
  Download
} from 'lucide-react';
import { subscribeToSettings, saveSettings, subscribeToEmailLogs, customFetch } from '../../services/dataService';
import { useAuth } from '../../context/AuthContext';
import BrandLogo from '../../components/BrandLogo';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import { db } from '../../lib/firebase';

export default function AdminSettings() {
  const { user } = useAuth();
  const isAdmin = user?.role === 'admin';

  const [formSettings, setFormSettings] = useState({
    standardPrice: 160,
    proPrice: 240,
    masteryPrice: 320,
    tutorHourlyRate: 25,
    academyName: 'HabKids',
    supportEmail: 'info@habkids.com',
    supportPhone: '+1 (555) 019-2834',
    welcomeMotto: 'Expanding heritage language tutoring and curriculum worldwide',
    founderName: 'Biruk Tadesse',
    founderLinkedIn: 'https://www.linkedin.com/in/biruk-tadesse-1750a3223/',
    instagramUrl: 'https://www.instagram.com/abyssiniatutors',
    whatsappUrl: 'https://wa.me/251940651491',
    facebookUrl: 'https://www.facebook.com/abyssiniatutors',
    youtubeUrl: 'https://www.youtube.com/@abyssiniatutors',
    fidelFundamentalsUrl: 'https://brtsegayetad-glitch.github.io/fidel-fundamentals/',
    fidelFundamentalsGit: 'https://github.com/brtsegayetad-glitch/fidel-fundamentals',
    activeLogoUrl: '',
    referralCommissionRate: 9,
    referralDiscountPercent: 10,
    referralBonusCredits: 1,
    trialSessionFee: 5,
    trialSessionFeeBirr: 280,
    telebirrNumber: '0940651491',
    telebirrName: 'HabKids Tutor Admin',
    zelleEmail: 'billing@habkids.com',
    zelleName: 'HabKids Inc.',
    cbeAccountNumber: '1000349204910',
    cbeAccountName: 'HabKids Tutor Registry',
    // Subscription payment details & prices in Birr
    proPriceBirr: 3500,
    masteryPriceBirr: 5200,
    standardPriceBirr: 2300,
    subTelebirrNumber: '+251 912 345 678',
    subTelebirrName: 'HabKids tutor',
    subTelebirrMerchantCode: '882910',
    subZelleEmail: 'payment@heritageacademy.com',
    subZelleName: 'HabKids Inc.',
    subCbeAccountNumber: '1000492811726',
    subCbeAccountName: 'HabKids Language School'
  });

  const [loading, setLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  const [saveStatus, setSaveStatus] = useState<'idle' | 'success' | 'error'>('idle');

  // SMTP Diagnostics states
  const [smtpStatus, setSmtpStatus] = useState<{
    configured: boolean;
    host: string;
    port: string | number;
    user: string;
    simulationFallback: boolean;
  } | null>(null);
  const [smtpChecking, setSmtpChecking] = useState(false);
  const [testEmailAddress, setTestEmailAddress] = useState('');
  const [testSending, setTestSending] = useState(false);
  const [testResult, setTestResult] = useState<{ success: boolean; message: string } | null>(null);
  const [emailLogs, setEmailLogs] = useState<any[]>([]);
  const [logsLoading, setLogsLoading] = useState(true);

  // Dynamic SMTP Override states
  const [useOverride, setUseOverride] = useState(false);
  const [overrideUser, setOverrideUser] = useState('');
  const [overridePass, setOverridePass] = useState('');
  const [overrideHost, setOverrideHost] = useState('smtp.gmail.com');
  const [overridePort, setOverridePort] = useState('587');
  const [overrideProvider, setOverrideProvider] = useState('smtp');
  const [savingOverrides, setSavingOverrides] = useState(false);
  const [overrideError, setOverrideError] = useState('');
  const [overrideSuccess, setOverrideSuccess] = useState(false);

  const fetchSmtpStatus = async () => {
    setSmtpChecking(true);
    try {
      const res = await fetch('/api/notify/status');
      if (res.ok) {
        const data = await res.json();
        setSmtpStatus(data);
      }
    } catch (e) {
      console.error("Failed to fetch SMTP status", e);
    } finally {
      setSmtpChecking(false);
    }
  };

  useEffect(() => {
    if (isAdmin) {
      fetchSmtpStatus();

      // Read current dynamic settings/smtp doc
      const loadSmtpOverrides = async () => {
        // Fast, reliable client-side hydration from local storage
        try {
          const stored = localStorage.getItem('smtp_override_credentials');
          if (stored) {
            const val = JSON.parse(stored);
            setOverrideUser(val.user || '');
            setOverridePass(val.pass || '');
            setOverrideHost(val.host || 'smtp.gmail.com');
            setOverridePort(val.port ? String(val.port) : '587');
            setOverrideProvider(val.provider || 'smtp');
            setUseOverride(val.user || val.pass ? true : false);
          }
        } catch (_) {}

        // Backup Firestore validation (helps fetch saved credentials across browsers)
        try {
          const docRef = doc(db, 'settings', 'smtp');
          const docSnap = await getDoc(docRef);
          if (docSnap.exists()) {
            const val = docSnap.data();
            setOverrideUser(val.user || '');
            setOverridePass(val.pass || '');
            setOverrideHost(val.host || 'smtp.gmail.com');
            setOverridePort(val.port ? String(val.port) : '587');
            setOverrideProvider(val.provider || 'smtp');
            setUseOverride(val.user || val.pass ? true : false);
            
            localStorage.setItem('smtp_override_credentials', JSON.stringify({
              user: val.user || '',
              pass: val.pass || '',
              host: val.host || 'smtp.gmail.com',
              port: val.port ? String(val.port) : '587',
              provider: val.provider || 'smtp'
            }));
          }
        } catch (err) {
          console.warn("Failed to load settings/smtp backup from Firestore (falling back entirely to browser localStorage):", err);
        }
      };
      loadSmtpOverrides();
      
      const unsubscribeLogs = subscribeToEmailLogs((logs) => {
        setEmailLogs(logs);
        setLogsLoading(false);
      }, () => {
        setLogsLoading(false);
      });
      
      return () => unsubscribeLogs();
    } else {
      setLogsLoading(false);
    }
  }, [isAdmin]);

  const handleSaveSmtpOverrides = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingOverrides(true);
    setOverrideError('');
    setOverrideSuccess(false);
    try {
      const payload = {
        user: useOverride ? overrideUser.trim() : '',
        pass: useOverride ? overridePass.trim() : '',
        host: useOverride ? overrideHost.trim() : 'smtp.gmail.com',
        port: useOverride ? String(overridePort).trim() : '587',
        provider: useOverride ? overrideProvider : 'smtp'
      };

      // Safely persist to local storage for automatic on-the-fly request injection
      if (useOverride && (payload.user || payload.pass)) {
        localStorage.setItem('smtp_override_credentials', JSON.stringify(payload));
      } else {
        localStorage.removeItem('smtp_override_credentials');
      }

      // Fix: Direct frontend write to Firestore settings/smtp document using client SDK
      const docRef = doc(db, 'settings', 'smtp');
      await setDoc(docRef, {
        ...payload,
        updatedAt: new Date().toISOString()
      }, { merge: true });
      
      setOverrideSuccess(true);
      await fetchSmtpStatus();
      setTimeout(() => setOverrideSuccess(false), 5000);
    } catch (err: any) {
      setOverrideError(err.message || String(err));
    } finally {
      setSavingOverrides(false);
    }
  };

  const handleTestSmtp = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!testEmailAddress.trim()) return;
    
    setTestSending(true);
    setTestResult(null);
    try {
      // Allow raw direct testing using current on-screen inputs directly, even before clicking save
      const currentConfigOverhead = {
        user: overrideUser.trim(),
        pass: overridePass.trim(),
        host: overrideHost.trim(),
        port: String(overridePort).trim(),
        provider: overrideProvider
      };

      const res = await customFetch('/api/notify/test-smtp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          toEmail: testEmailAddress,
          smtpConfig: useOverride ? currentConfigOverhead : undefined
        })
      });
      const text = await res.text();
      let data: any = {};
      try {
        data = JSON.parse(text);
      } catch (parseErr) {
        if (text.includes('<!DOCTYPE') || text.includes('<html')) {
          throw new Error("SMTP server took too long to respond, or the platform serverless function timed out. Please check your outbound SMTP ports.");
        } else {
          throw new Error(text.substring(0, 200) || "Received an invalid non-JSON response from server.");
        }
      }
      if (res.ok && data.success) {
        setTestResult({ success: true, message: data.message });
      } else {
        setTestResult({ success: false, message: data.error || "Failed to establish SMTP session connection" });
      }
    } catch (err: any) {
      setTestResult({ success: false, message: err?.message || "Internal diagnostic query failed" });
    } finally {
      setTestSending(false);
    }
  };

  useEffect(() => {
    const unsubscribe = subscribeToSettings((data) => {
      if (data) {
        const rawName = data.founderName || '';
        const rawLink = data.founderLinkedIn || '';
        setFormSettings({
          standardPrice: typeof data.standardPrice === 'number' ? data.standardPrice : 160,
          proPrice: typeof data.proPrice === 'number' ? data.proPrice : 240,
          masteryPrice: typeof data.masteryPrice === 'number' ? data.masteryPrice : 320,
          tutorHourlyRate: typeof data.tutorHourlyRate === 'number' ? data.tutorHourlyRate : (typeof data.tutorHourlyRate === 'string' ? parseInt(data.tutorHourlyRate) : 25),
          academyName: data.academyName || 'HabKids',
          supportEmail: data.supportEmail || 'info@habkids.com',
          supportPhone: data.supportPhone || '+1 (555) 019-2834',
          welcomeMotto: data.welcomeMotto || 'Expanding heritage language tutoring and curriculum worldwide',
          founderName: (!rawName || rawName === 'Brtsegaye Tad') ? 'Biruk Tadesse' : rawName,
          founderLinkedIn: (!rawLink || rawLink.includes('brtsegayetad')) ? 'https://www.linkedin.com/in/biruk-tadesse-1750a3223/' : rawLink,
          instagramUrl: data.instagramUrl || 'https://www.instagram.com/abyssiniatutors',
          whatsappUrl: data.whatsappUrl || 'https://wa.me/251940651491',
          facebookUrl: data.facebookUrl || 'https://www.facebook.com/abyssiniatutors',
          youtubeUrl: data.youtubeUrl || 'https://www.youtube.com/@abyssiniatutors',
          fidelFundamentalsUrl: data.fidelFundamentalsUrl || '',
          fidelFundamentalsGit: data.fidelFundamentalsGit || '',
          activeLogoUrl: data.activeLogoUrl || '',
          referralCommissionRate: typeof data.referralCommissionRate === 'number' ? data.referralCommissionRate : 9,
          referralDiscountPercent: typeof data.referralDiscountPercent === 'number' ? data.referralDiscountPercent : 10,
          referralBonusCredits: typeof data.referralBonusCredits === 'number' ? data.referralBonusCredits : 1,
          trialSessionFee: typeof data.trialSessionFee === 'number' ? data.trialSessionFee : 5,
          trialSessionFeeBirr: typeof data.trialSessionFeeBirr === 'number' ? data.trialSessionFeeBirr : 280,
          telebirrNumber: data.telebirrNumber || '0940651491',
          telebirrName: data.telebirrName || 'HabKids Tutor Admin',
          zelleEmail: data.zelleEmail || 'billing@habkids.com',
          zelleName: data.zelleName || 'HabKids Inc.',
          cbeAccountNumber: data.cbeAccountNumber || '1000349204910',
          cbeAccountName: data.cbeAccountName || 'HabKids Tutor Registry',
          proPriceBirr: typeof data.proPriceBirr === 'number' ? data.proPriceBirr : 3500,
          masteryPriceBirr: typeof data.masteryPriceBirr === 'number' ? data.masteryPriceBirr : 5200,
          standardPriceBirr: typeof data.standardPriceBirr === 'number' ? data.standardPriceBirr : 2300,
          subTelebirrNumber: data.subTelebirrNumber || '+251 912 345 678',
          subTelebirrName: data.subTelebirrName || 'HabKids tutor',
          subTelebirrMerchantCode: data.subTelebirrMerchantCode || '882910',
          subZelleEmail: data.subZelleEmail || 'payment@heritageacademy.com',
          subZelleName: data.subZelleName || 'HabKids Inc.',
          subCbeAccountNumber: data.subCbeAccountNumber || '1000492811726',
          subCbeAccountName: data.subCbeAccountName || 'HabKids Language School'
        });
      }
      setLoading(false);
    }, () => {
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    setSaveStatus('idle');

    const result = await saveSettings(formSettings);

    setIsSaving(false);
    if (result.success) {
      setSaveStatus('success');
      setTimeout(() => setSaveStatus('idle'), 3000);
    } else {
      setSaveStatus('error');
    }
  };

  const handleDownloadLogo = (conceptId: 1 | 2 | 3 | 4, event: React.MouseEvent) => {
    event.stopPropagation();
    event.preventDefault();

    if (conceptId === 4) {
      // Create element to trigger download of the new tutor logo directly
      const link = document.createElement('a');
      link.href = '/icon-512.jpg';
      link.download = 'HabKids_Tutor_Logo.jpg';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      
      // Open the downloaded logo in a new tab for instant high-quality viewing
      const newWindow = window.open();
      if (newWindow) {
        newWindow.document.write(`
          <html>
            <head>
              <title>HabKids_Tutor_Logo.jpg</title>
              <style>
                body {
                  margin: 0;
                  background-color: #f8fafc;
                  display: flex;
                  flex-direction: column;
                  align-items: center;
                  justify-content: center;
                  min-height: 100vh;
                  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
                }
                .container {
                  text-align: center;
                  background: white;
                  padding: 40px;
                  border-radius: 24px;
                  box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.05), 0 8px 10px -6px rgba(0, 0, 0, 0.05);
                  max-width: 500px;
                  width: 90%;
                }
                img {
                  width: 250px;
                  height: 250px;
                  object-fit: contain;
                  filter: drop-shadow(0 10px 15px rgba(0,0,0,0.08));
                  margin-bottom: 24px;
                  border-radius: 24px;
                }
                h1 {
                  font-size: 20px;
                  color: #0f172a;
                  margin: 0 0 8px 0;
                }
                p {
                  font-size: 14px;
                  color: #64748b;
                  margin: 0 0 24px 0;
                  line-height: 1.5;
                }
                .btn {
                  display: inline-block;
                  background: #4f46e5;
                  color: white;
                  padding: 12px 24px;
                  border-radius: 10px;
                  text-decoration: none;
                  font-weight: 600;
                  font-size: 14px;
                  transition: background 0.15s ease;
                }
                .btn:hover {
                  background: #4338ca;
                }
              </style>
            </head>
            <body>
              <div class="container">
                <img src="/icon-512.jpg" alt="HabKids tutor Logo" />
                <h1>HabKids_Tutor_Logo.jpg</h1>
                <p>Your new professional HabKids tutor brand logo is ready and has been downloaded! You can use this custom high-resolution file on your website and social media platforms.</p>
                <a href="/icon-512.jpg" download="HabKids_Tutor_Logo.jpg" class="btn">Download Again</a>
              </div>
            </body>
          </html>
        `);
        newWindow.document.close();
      }
      return;
    }
    
    if (conceptId === 2) {
      // Create element to trigger download of the custom logo2 directly
      const link = document.createElement('a');
      link.href = '/reallogo2.png';
      link.download = 'HabKids_Custom_Logo_2.png';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      
      // Open the downloaded logo in a new tab for instant high-quality viewing
      const newWindow = window.open();
      if (newWindow) {
        newWindow.document.write(`
          <html>
            <head>
              <title>HabKids_Custom_Logo_2.png</title>
              <style>
                body {
                  margin: 0;
                  background-color: #f8fafc;
                  display: flex;
                  flex-direction: column;
                  align-items: center;
                  justify-content: center;
                  min-height: 100vh;
                  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
                }
                .container {
                  text-align: center;
                  background: white;
                  padding: 40px;
                  border-radius: 24px;
                  box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.05), 0 8px 10px -6px rgba(0, 0, 0, 0.05);
                  max-width: 500px;
                  width: 90%;
                }
                img {
                  width: 250px;
                  height: 250px;
                  object-fit: contain;
                  filter: drop-shadow(0 10px 15px rgba(0,0,0,0.08));
                  margin-bottom: 24px;
                  border-radius: 24px;
                }
                h1 {
                  font-size: 20px;
                  color: #0f172a;
                  margin: 0 0 8px 0;
                }
                p {
                  font-size: 14px;
                  color: #64748b;
                  margin: 0 0 24px 0;
                  line-height: 1.5;
                }
                .btn {
                  display: inline-block;
                  background: #4f46e5;
                  color: white;
                  padding: 12px 24px;
                  border-radius: 10px;
                  text-decoration: none;
                  font-weight: 600;
                  font-size: 14px;
                  transition: background 0.15s ease;
                }
                .btn:hover {
                  background: #4338ca;
                }
              </style>
            </head>
            <body>
              <div class="container">
                <img src="/reallogo2.png" alt="HabKids Custom Logo 2" />
                <h1>HabKids_Custom_Logo_2.png</h1>
                <p>Your high-resolution HabKids brand logo is ready and has been downloaded! You can use this custom file on your website and social media platforms.</p>
                <a href="/reallogo2.png" download="HabKids_Custom_Logo_2.png" class="btn">Download Again</a>
              </div>
            </body>
          </html>
        `);
        newWindow.document.close();
      }
      return;
    }

    if (conceptId === 3) {
      // Create element to trigger download of the PNG logo directly
      const link = document.createElement('a');
      link.href = '/finallogo.png';
      link.download = 'HabKids_Final_Logo.png';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      
      // Open the downloaded logo in a new tab for instant high-quality viewing
      const newWindow = window.open();
      if (newWindow) {
        newWindow.document.write(`
          <html>
            <head>
              <title>HabKids_Final_Logo.png</title>
              <style>
                body {
                  margin: 0;
                  background-color: #f8fafc;
                  display: flex;
                  flex-direction: column;
                  align-items: center;
                  justify-content: center;
                  min-height: 100vh;
                  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
                }
                .container {
                  text-align: center;
                  background: white;
                  padding: 40px;
                  border-radius: 24px;
                  box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.05), 0 8px 10px -6px rgba(0, 0, 0, 0.05);
                  max-width: 500px;
                  width: 90%;
                }
                img {
                  width: 250px;
                  height: 250px;
                  object-fit: contain;
                  filter: drop-shadow(0 10px 15px rgba(0,0,0,0.08));
                  margin-bottom: 24px;
                  border-radius: 24px;
                }
                h1 {
                  font-size: 20px;
                  color: #0f172a;
                  margin: 0 0 8px 0;
                }
                p {
                  font-size: 14px;
                  color: #64748b;
                  margin: 0 0 24px 0;
                  line-height: 1.5;
                }
                .btn {
                  display: inline-block;
                  background: #4f46e5;
                  color: white;
                  padding: 12px 24px;
                  border-radius: 10px;
                  text-decoration: none;
                  font-weight: 600;
                  font-size: 14px;
                  transition: background 0.15s ease;
                }
                .btn:hover {
                  background: #4338ca;
                }
              </style>
            </head>
            <body>
              <div class="container">
                <img src="/finallogo.png" alt="HabKids Final Logo" />
                <h1>HabKids_Final_Logo.png</h1>
                <p>Your high-resolution HabKids brand logo is ready and has been downloaded! You can use this custom PNG file on your website and social media platforms.</p>
                <a href="/finallogo.png" download="HabKids_Final_Logo.png" class="btn">Download Again</a>
              </div>
            </body>
          </html>
        `);
        newWindow.document.close();
      }
      return;
    }

    let svgContent = '';
    let fileName = '';
    
    if (conceptId === 1) {
      svgContent = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100">
  <defs>
    <linearGradient id="indigoGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#1e1b4b" />
      <stop offset="100%" stop-color="#311042" />
    </linearGradient>
  </defs>
  <rect width="100%" height="100%" rx="24" fill="url(#indigoGrad)" />
  <path d="M 20 80 Q 50 72 80 80 L 80 45 Q 50 37 20 45 Z" fill="none" stroke="#FDF6E2" stroke-width="3.5" stroke-opacity="0.25" />
  <path d="M 50 37 L 50 76" stroke="#FDF6E2" stroke-width="2.5" stroke-opacity="0.25" />
  <path d="M 22 18 L 24 23 L 29 23 L 25 26 L 27 31 L 22 28 L 17 31 L 19 26 L 15 23 L 20 23 Z" fill="#F59E0B" />
  
  <!-- High-resolution vector representation of Ge'ez Numeral ፪ (Two) for 100% converter-safe rendering -->
  <g style="filter: drop-shadow(1px 1.5px 3px rgba(0,0,0,0.4))">
    <path d="M 32,32 L 68,32" stroke="#FDF6E2" stroke-width="5" stroke-linecap="round" />
    <path d="M 38,50 L 62,50" stroke="#FDF6E2" stroke-width="4" stroke-linecap="round" />
    <path d="M 44,50 L 44,58 M 56,50 L 56,58" stroke="#FDF6E2" stroke-width="3.5" stroke-linecap="round" />
    <path d="M 32,68 L 68,68" stroke="#FDF6E2" stroke-width="5" stroke-linecap="round" />
  </g>

  <rect x="6" y="6" width="88" height="88" rx="18" fill="none" stroke="#F55F0B" stroke-width="1.5" stroke-opacity="0.1" />
</svg>`;
      fileName = 'HabKids_Logo_Traditional_Connection.svg';
    } else if (conceptId === 2) {
      svgContent = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100">
  <defs>
    <linearGradient id="slateGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#0f172a" />
      <stop offset="100%" stop-color="#1e293b" />
    </linearGradient>
    <linearGradient id="goldGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#fbbf24" />
      <stop offset="50%" stop-color="#f59e0b" />
      <stop offset="100%" stop-color="#d97706" />
    </linearGradient>
  </defs>
  <rect width="100%" height="100%" rx="24" fill="url(#slateGrad)" />
  <rect x="8" y="8" width="84" height="84" rx="16" fill="none" stroke="url(#goldGrad)" stroke-width="2.5" stroke-opacity="0.85" />
  <rect x="13" y="13" width="74" height="74" rx="11" fill="none" stroke="url(#goldGrad)" stroke-width="1" stroke-opacity="0.3" />
  
  <!-- High-resolution vector representation of Ge'ez Numeral ፻ (One Hundred) for 100% converter-safe rendering -->
  <g style="filter: drop-shadow(0px 2px 4px rgba(0,0,0,0.5))">
    <path d="M 32,32 L 68,32" stroke="url(#goldGrad)" stroke-width="5" stroke-linecap="round" />
    <path d="M 32,68 L 68,68" stroke="url(#goldGrad)" stroke-width="5" stroke-linecap="round" />
    <path d="M 50,32 L 50,68" stroke="url(#goldGrad)" stroke-width="4.5" stroke-linecap="round" />
    <path d="M 38,42 L 62,58" stroke="url(#goldGrad)" stroke-width="4" stroke-linecap="round" />
  </g>
</svg>`;
      fileName = 'HabKids_Logo_Century_of_Brilliance.svg';
    }
    
    // Create blob from the SVG content
    const blob = new Blob([svgContent], { type: 'image/svg+xml;charset=utf-8' });
    const blobUrl = URL.createObjectURL(blob);
    
    // Create element to trigger download
    const link = document.createElement('a');
    link.href = blobUrl;
    link.download = fileName;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    // Open in a new tab so they see it instantly!
    const newWindow = window.open();
    if (newWindow) {
      newWindow.document.write(`
        <html>
          <head>
            <title>${fileName}</title>
            <style>
              body {
                margin: 0;
                background-color: #f8fafc;
                display: flex;
                flex-direction: column;
                align-items: center;
                justify-content: center;
                min-height: 100vh;
                font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
              }
              .container {
                text-align: center;
                background: white;
                padding: 40px;
                border-radius: 24px;
                box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.05), 0 8px 10px -6px rgba(0, 0, 0, 0.05);
                max-width: 500px;
                width: 90%;
              }
              svg {
                width: 250px;
                height: 250px;
                filter: drop-shadow(0 10px 15px rgba(0,0,0,0.08));
                margin-bottom: 24px;
              }
              h1 {
                font-size: 20px;
                color: #0f172a;
                margin: 0 0 8px 0;
              }
              p {
                font-size: 14px;
                color: #64748b;
                margin: 0 0 24px 0;
                line-height: 1.5;
              }
              .btn {
                display: inline-block;
                background: #4f46e5;
                color: white;
                padding: 12px 24px;
                border-radius: 10px;
                text-decoration: none;
                font-weight: 600;
                font-size: 14px;
                transition: background 0.15s ease;
              }
              .btn:hover {
                background: #4338ca;
              }
            </style>
          </head>
          <body>
            <div class="container">
              ${svgContent}
              <h1>${fileName}</h1>
              <p>Your high-resolution vector logo is ready and has been downloaded! You can use this infinitely scalable SVG file on your website and social media platforms.</p>
              <a href="data:image/svg+xml;utf8,${encodeURIComponent(svgContent)}" download="${fileName}" class="btn">Download Again</a>
            </div>
          </body>
        </html>
      `);
      newWindow.document.close();
    }
  };

  if (loading) {
    return (
      <div className="h-[60vh] flex flex-col items-center justify-center text-slate-400 gap-3">
        <Loader2 className="animate-spin text-primary" size={32} />
        <p className="text-sm font-medium">Syncing system settings...</p>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-in fade-in duration-300 text-left">
      <header className="border-b border-slate-150 pb-6">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-indigo-50 text-indigo-600 rounded-2xl">
            <Settings size={28} />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-slate-950 tracking-tight font-sans">
              {isAdmin ? "Global Platform Configuration" : "HabKids Platform Information"}
            </h1>
            <p className="text-slate-400 text-sm mt-1">
              {isAdmin 
                ? "Adjust academy brand identity metrics, custom pricing tiers, and messaging constants of the system." 
                : "View brand contact metrics, subscription price limits, and academic parameters."}
            </p>
          </div>
        </div>
      </header>

      <form onSubmit={handleSave} className="space-y-8" id="admin-settings-form">
        {!isAdmin && (
          <div className="bg-slate-50 border border-slate-200/80 p-4 rounded-xl flex items-center gap-3 text-slate-600" id="settings-readonly-alert">
            <AlertCircle size={20} className="text-slate-550 shrink-0" />
            <div className="text-xs font-semibold">
              <strong>Read-Only Access:</strong> You are viewing global platform configurations. Modifying variables is restricted to Administrators only.
            </div>
          </div>
        )}

        {saveStatus === 'success' && (
          <div className="bg-emerald-50 border border-emerald-250 p-4 rounded-xl flex items-center gap-3 text-emerald-800 animate-in slide-in-from-top-4 duration-300" id="settings-success-alert">
            <CheckCircle2 size={20} className="text-emerald-600 shrink-0" />
            <div className="text-xs font-semibold">
              Platform variables securely committed across Firestore state! Pricing cards are updated on parent flows dynamically.
            </div>
          </div>
        )}

        {saveStatus === 'error' && (
          <div className="bg-rose-50 border border-rose-200 p-4 rounded-xl flex items-center gap-3 text-rose-800 animate-in slide-in-from-top-4 duration-300" id="settings-error-alert">
            <AlertCircle size={20} className="text-rose-600 shrink-0" />
            <div className="text-xs font-semibold">
              Permission denied. Make sure you are authenticated with proper system permissions to commit variables.
            </div>
          </div>
        )}

        {/* Pricing Tiers Card */}
        <div className="bg-white rounded-2xl border border-slate-150/85 p-8 shadow-xs space-y-6">
          <div className="flex items-center justify-between border-b border-slate-50 pb-4">
            <div>
              <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                <DollarSign size={20} className="text-slate-400" />
                Subscription Pricing Tiers
              </h2>
              <p className="text-xs text-slate-400 mt-1">Modify monthly costs of active membership tiers. Propagates dynamically to clients.</p>
            </div>
            <span className="text-[10px] font-bold text-indigo-600 bg-indigo-50 px-2.5 py-1 rounded-full uppercase tracking-wider">USD / Month</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Pro Cost */}
            <div className="space-y-2">
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Pro Plan Price</label>
              <div className="relative rounded-xl shadow-xs">
                <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-4 text-slate-400 text-sm font-semibold">
                  $
                </div>
                <input
                  required
                  disabled={!isAdmin}
                  type="number"
                  min="0"
                  value={formSettings.proPrice}
                  onChange={(e) => setFormSettings({...formSettings, proPrice: parseInt(e.target.value) || 0})}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-9 pr-14 py-3 text-sm focus:ring-2 focus:ring-primary/10 transition-all outline-none font-bold text-slate-800 disabled:opacity-75 disabled:cursor-not-allowed"
                />
                <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center pr-4 text-[10px] text-slate-400 font-bold uppercase">
                  /mo
                </div>
              </div>
              <p className="text-[9px] text-slate-400 font-medium">Flagship biweekly coaching choice</p>
            </div>

            {/* Mastery Cost */}
            <div className="space-y-2">
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Mastery Plan Price</label>
              <div className="relative rounded-xl shadow-xs">
                <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-4 text-slate-400 text-sm font-semibold">
                  $
                </div>
                <input
                  required
                  disabled={!isAdmin}
                  type="number"
                  min="0"
                  value={formSettings.masteryPrice}
                  onChange={(e) => setFormSettings({...formSettings, masteryPrice: parseInt(e.target.value) || 0})}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-9 pr-14 py-3 text-sm focus:ring-2 focus:ring-primary/10 transition-all outline-none font-bold text-slate-800 disabled:opacity-75 disabled:cursor-not-allowed"
                />
                <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center pr-4 text-[10px] text-slate-400 font-bold uppercase">
                  /mo
                </div>
              </div>
              <p className="text-[9px] text-slate-400 font-medium">Optimal fluency speed tracking plan</p>
            </div>
          </div>
        </div>

        {/* Tutor Financial & Onboarding Benchmarks */}
        <div className="bg-white rounded-2xl border border-slate-150/85 p-8 shadow-xs space-y-6" id="constant-tutor-rate-section">
          <div className="flex items-center justify-between border-b border-slate-50 pb-4">
            <div>
              <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                <DollarSign size={20} className="text-indigo-600" />
                Constant Tutor Hourly Rate
              </h2>
              <p className="text-xs text-slate-400 mt-1">Configure the global hourly instructional rate required. This number is controlled entirely by the administration, guaranteeing consistent compensation parameters across all approved language expert rosters.</p>
            </div>
            <span className="text-[10px] font-bold text-indigo-600 bg-indigo-50 px-2.5 py-1 rounded-full uppercase tracking-wider">USD / Hour (Constant)</span>
          </div>

          <div className="max-w-md space-y-2">
            <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Constant Tutor Hourly Rate Requirement</label>
            <div className="relative rounded-xl shadow-xs">
              <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-4 text-slate-400 text-sm font-semibold">
                $
              </div>
              <input
                required
                disabled={!isAdmin}
                type="number"
                min="1"
                value={formSettings.tutorHourlyRate}
                onChange={(e) => setFormSettings({...formSettings, tutorHourlyRate: parseInt(e.target.value) || 0})}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-9 pr-14 py-3 text-sm focus:ring-2 focus:ring-primary/10 transition-all outline-none font-extrabold text-slate-800 disabled:opacity-75 disabled:cursor-not-allowed"
              />
              <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center pr-4 text-[10px] text-slate-400 font-bold uppercase">
                /hr
              </div>
            </div>
            <p className="text-[10px] text-slate-450 leading-relaxed font-sans font-medium">
              Note: Changing this automatically locks all tutor profiles to this exact constant rate, overriding any previously proposed or local pricing parameters. Tutors cannot edit or customize this rate.
            </p>
          </div>
        </div>

        {/* Trial Session Booking & Payment Gateways Configuration */}
        <div className="bg-white rounded-2xl border border-slate-150/85 p-8 shadow-xs space-y-6" id="trial-session-payments-config">
          <div className="flex items-center justify-between border-b border-slate-50 pb-4">
            <div>
              <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2 font-serif">
                <Settings size={20} className="text-blue-600" />
                Trial Session Booking & Payment Gateways
              </h2>
              <p className="text-xs text-slate-400 mt-1">Configure evaluation session pricing and the specific account/merchant destinations for secure mobile money and direct transfers.</p>
            </div>
            <span className="text-[10px] font-bold text-blue-600 bg-blue-50 px-2.5 py-1 rounded-full uppercase tracking-wider font-sans">Payment Gateways</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Trial Session Fee USD */}
            <div className="space-y-2 text-left">
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block font-sans">Trial Session Fee (USD)</label>
              <div className="relative rounded-xl shadow-xs">
                <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-4 text-slate-400 text-sm font-semibold">
                  $
                </div>
                <input
                  required
                  disabled={!isAdmin}
                  type="number"
                  min="0"
                  step="0.01"
                  value={formSettings.trialSessionFee}
                  onChange={(e) => setFormSettings({...formSettings, trialSessionFee: parseFloat(e.target.value) || 0})}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-9 pr-4 py-3 text-sm focus:ring-2 focus:ring-primary/10 transition-all outline-none font-bold text-slate-800 disabled:opacity-75 disabled:cursor-not-allowed"
                />
              </div>
              <p className="text-[9px] text-slate-400 font-medium">Fee in USD for international cards/Zelle users</p>
            </div>

            {/* Trial Session Fee Birr */}
            <div className="space-y-2 text-left">
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block font-sans">Trial Session Fee (Birr)</label>
              <div className="relative rounded-xl shadow-xs">
                <input
                  required
                  disabled={!isAdmin}
                  type="number"
                  min="0"
                  value={formSettings.trialSessionFeeBirr}
                  onChange={(e) => setFormSettings({...formSettings, trialSessionFeeBirr: parseInt(e.target.value) || 0})}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-primary/10 transition-all outline-none font-bold text-slate-800 disabled:opacity-75 disabled:cursor-not-allowed"
                />
                <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center pr-4 text-[10px] text-slate-400 font-bold uppercase">
                  Birr
                </div>
              </div>
              <p className="text-[9px] text-slate-400 font-medium">Equivalent Birr amount for Telebirr and CBE transfers</p>
            </div>
          </div>

          <div className="border-t border-slate-100 pt-6 space-y-6">
            <h3 className="text-sm font-bold text-slate-800 flex items-center gap-1.5 font-sans">
              <span>●</span> Telebirr Gateway Parameters
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2 text-left">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block font-sans">Merchant / Phone Number</label>
                <input
                  required
                  disabled={!isAdmin}
                  type="text"
                  value={formSettings.telebirrNumber}
                  onChange={(e) => setFormSettings({...formSettings, telebirrNumber: e.target.value})}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-primary/10 transition-all outline-none font-medium text-slate-850 disabled:opacity-75"
                />
              </div>
              <div className="space-y-2 text-left">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block font-sans">Merchant / Account Name</label>
                <input
                  required
                  disabled={!isAdmin}
                  type="text"
                  value={formSettings.telebirrName}
                  onChange={(e) => setFormSettings({...formSettings, telebirrName: e.target.value})}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-primary/10 transition-all outline-none font-medium text-slate-850 disabled:opacity-75"
                />
              </div>
            </div>
          </div>

          <div className="border-t border-slate-100 pt-6 space-y-6">
            <h3 className="text-sm font-bold text-slate-800 flex items-center gap-1.5 font-sans">
              <span>●</span> Zelle USD Direct Parameters
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2 text-left">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block font-sans">Zelle Email Address</label>
                <input
                  required
                  disabled={!isAdmin}
                  type="email"
                  value={formSettings.zelleEmail}
                  onChange={(e) => setFormSettings({...formSettings, zelleEmail: e.target.value})}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-primary/10 transition-all outline-none font-medium text-slate-850 disabled:opacity-75"
                />
              </div>
              <div className="space-y-2 text-left">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block font-sans">Recipient Account Name</label>
                <input
                  required
                  disabled={!isAdmin}
                  type="text"
                  value={formSettings.zelleName}
                  onChange={(e) => setFormSettings({...formSettings, zelleName: e.target.value})}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-primary/10 transition-all outline-none font-medium text-slate-850 disabled:opacity-75"
                />
              </div>
            </div>
          </div>

          <div className="border-t border-slate-100 pt-6 space-y-6">
            <h3 className="text-sm font-bold text-slate-800 flex items-center gap-1.5 font-sans">
              <span>●</span> Commercial Bank of Ethiopia (CBE) Parameters
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2 text-left">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block font-sans">CBE Account Number</label>
                <input
                  required
                  disabled={!isAdmin}
                  type="text"
                  value={formSettings.cbeAccountNumber}
                  onChange={(e) => setFormSettings({...formSettings, cbeAccountNumber: e.target.value})}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-primary/10 transition-all outline-none font-medium text-slate-850 disabled:opacity-75"
                />
              </div>
              <div className="space-y-2 text-left">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block font-sans">CBE Account Name</label>
                <input
                  required
                  disabled={!isAdmin}
                  type="text"
                  value={formSettings.cbeAccountName}
                  onChange={(e) => setFormSettings({...formSettings, cbeAccountName: e.target.value})}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-primary/10 transition-all outline-none font-medium text-slate-850 disabled:opacity-75"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Subscription Billing & Payment Gateways Configuration */}
        <div className="bg-white rounded-2xl border border-slate-150/85 p-8 shadow-xs space-y-6" id="subscription-payments-config">
          <div className="flex items-center justify-between border-b border-slate-50 pb-4">
            <div>
              <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2 font-serif">
                <Settings size={20} className="text-indigo-600" />
                Subscription Billing & Payment Gateways
              </h2>
              <p className="text-xs text-slate-400 mt-1">Configure plan pricing in Birr and the specific merchant/account destinations for monthly student subscriptions.</p>
            </div>
            <span className="text-[10px] font-bold text-indigo-600 bg-indigo-50 px-2.5 py-1 rounded-full uppercase tracking-wider font-sans">Subscription Gateways</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Pro Plan Price Birr */}
            <div className="space-y-2 text-left">
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block font-sans">Pro Plan (Birr)</label>
              <div className="relative rounded-xl shadow-xs">
                <input
                  required
                  disabled={!isAdmin}
                  type="number"
                  min="0"
                  value={formSettings.proPriceBirr}
                  onChange={(e) => setFormSettings({...formSettings, proPriceBirr: parseInt(e.target.value) || 0})}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-primary/10 transition-all outline-none font-bold text-slate-800 disabled:opacity-75 disabled:cursor-not-allowed"
                />
                <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center pr-4 text-[10px] text-slate-400 font-bold uppercase">
                  Birr
                </div>
              </div>
              <p className="text-[9px] text-slate-400 font-medium">Monthly fee in Birr for HabKids Pro plan (${formSettings.proPrice} USD)</p>
            </div>

            {/* Mastery Plan Price Birr */}
            <div className="space-y-2 text-left">
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block font-sans">Mastery Plan (Birr)</label>
              <div className="relative rounded-xl shadow-xs">
                <input
                  required
                  disabled={!isAdmin}
                  type="number"
                  min="0"
                  value={formSettings.masteryPriceBirr}
                  onChange={(e) => setFormSettings({...formSettings, masteryPriceBirr: parseInt(e.target.value) || 0})}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-primary/10 transition-all outline-none font-bold text-slate-800 disabled:opacity-75 disabled:cursor-not-allowed"
                />
                <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center pr-4 text-[10px] text-slate-400 font-bold uppercase">
                  Birr
                </div>
              </div>
              <p className="text-[9px] text-slate-400 font-medium">Monthly fee in Birr for HabKids Mastery plan (${formSettings.masteryPrice} USD)</p>
            </div>

            {/* Standard Plan Price Birr */}
            <div className="space-y-2 text-left">
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block font-sans">Standard Plan (Birr)</label>
              <div className="relative rounded-xl shadow-xs">
                <input
                  required
                  disabled={!isAdmin}
                  type="number"
                  min="0"
                  value={formSettings.standardPriceBirr}
                  onChange={(e) => setFormSettings({...formSettings, standardPriceBirr: parseInt(e.target.value) || 0})}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-primary/10 transition-all outline-none font-bold text-slate-800 disabled:opacity-75 disabled:cursor-not-allowed"
                />
                <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center pr-4 text-[10px] text-slate-400 font-bold uppercase">
                  Birr
                </div>
              </div>
              <p className="text-[9px] text-slate-400 font-medium">Monthly fee in Birr for HabKids Standard plan (${formSettings.standardPrice} USD)</p>
            </div>
          </div>

          <div className="border-t border-slate-100 pt-6 space-y-6">
            <h3 className="text-sm font-bold text-indigo-900 flex items-center gap-1.5 font-sans">
              <span>●</span> Subscription Telebirr Gateway Parameters
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="space-y-2 text-left">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block font-sans">Merchant Code</label>
                <input
                  required
                  disabled={!isAdmin}
                  type="text"
                  value={formSettings.subTelebirrMerchantCode}
                  onChange={(e) => setFormSettings({...formSettings, subTelebirrMerchantCode: e.target.value})}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-primary/10 transition-all outline-none font-medium text-slate-850 disabled:opacity-75"
                />
              </div>
              <div className="space-y-2 text-left">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block font-sans">Mobile Number / Deposit ID</label>
                <input
                  required
                  disabled={!isAdmin}
                  type="text"
                  value={formSettings.subTelebirrNumber}
                  onChange={(e) => setFormSettings({...formSettings, subTelebirrNumber: e.target.value})}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-primary/10 transition-all outline-none font-medium text-slate-850 disabled:opacity-75"
                />
              </div>
              <div className="space-y-2 text-left">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block font-sans">Merchant / Account Name</label>
                <input
                  required
                  disabled={!isAdmin}
                  type="text"
                  value={formSettings.subTelebirrName}
                  onChange={(e) => setFormSettings({...formSettings, subTelebirrName: e.target.value})}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-primary/10 transition-all outline-none font-medium text-slate-850 disabled:opacity-75"
                />
              </div>
            </div>
          </div>

          <div className="border-t border-slate-100 pt-6 space-y-6">
            <h3 className="text-sm font-bold text-indigo-900 flex items-center gap-1.5 font-sans">
              <span>●</span> Subscription Zelle USD Direct Parameters
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2 text-left">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block font-sans">Zelle Email Address</label>
                <input
                  required
                  disabled={!isAdmin}
                  type="email"
                  value={formSettings.subZelleEmail}
                  onChange={(e) => setFormSettings({...formSettings, subZelleEmail: e.target.value})}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-primary/10 transition-all outline-none font-medium text-slate-850 disabled:opacity-75"
                />
              </div>
              <div className="space-y-2 text-left">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block font-sans">Recipient Account Name</label>
                <input
                  required
                  disabled={!isAdmin}
                  type="text"
                  value={formSettings.subZelleName}
                  onChange={(e) => setFormSettings({...formSettings, subZelleName: e.target.value})}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-primary/10 transition-all outline-none font-medium text-slate-850 disabled:opacity-75"
                />
              </div>
            </div>
          </div>

          <div className="border-t border-slate-100 pt-6 space-y-6">
            <h3 className="text-sm font-bold text-indigo-900 flex items-center gap-1.5 font-sans">
              <span>●</span> Subscription CBE Bank Transfer Parameters
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2 text-left">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block font-sans">CBE Account Number</label>
                <input
                  required
                  disabled={!isAdmin}
                  type="text"
                  value={formSettings.subCbeAccountNumber}
                  onChange={(e) => setFormSettings({...formSettings, subCbeAccountNumber: e.target.value})}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-primary/10 transition-all outline-none font-medium text-slate-850 disabled:opacity-75"
                />
              </div>
              <div className="space-y-2 text-left">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block font-sans">CBE Account Name</label>
                <input
                  required
                  disabled={!isAdmin}
                  type="text"
                  value={formSettings.subCbeAccountName}
                  onChange={(e) => setFormSettings({...formSettings, subCbeAccountName: e.target.value})}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-primary/10 transition-all outline-none font-medium text-slate-850 disabled:opacity-75"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Global Variables Card */}
        <div className="bg-white rounded-2xl border border-slate-150/85 p-8 shadow-xs space-y-6">
          <div className="border-b border-slate-50 pb-4">
            <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
              <Globe size={20} className="text-slate-400" />
              Global Brand & platform settings
            </h2>
            <p className="text-xs text-slate-400 mt-1">Manage system constants used in automated emails and customer facing portals.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pb-2">
            {/* Academy Name */}
            <div className="space-y-2">
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Academy Brand Name</label>
              <input
                required
                disabled={!isAdmin}
                type="text"
                value={formSettings.academyName}
                onChange={(e) => setFormSettings({...formSettings, academyName: e.target.value})}
                placeholder="HabKids"
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-primary/10 transition-all outline-none font-medium text-slate-850 disabled:opacity-75 disabled:cursor-not-allowed"
              />
            </div>

            {/* Support Email */}
            <div className="space-y-2">
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Support Email Contacts</label>
              <div className="relative rounded-xl shadow-xs">
                <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
                <input
                  required
                  disabled={!isAdmin}
                  type="email"
                  value={formSettings.supportEmail}
                  onChange={(e) => setFormSettings({...formSettings, supportEmail: e.target.value})}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-12 pr-4 py-3 text-sm focus:ring-2 focus:ring-primary/10 transition-all outline-none text-slate-800 disabled:opacity-75 disabled:cursor-not-allowed"
                />
              </div>
            </div>

            {/* Support Phone */}
            <div className="space-y-2">
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Global Contact Line</label>
              <div className="relative rounded-xl shadow-xs">
                <Phone className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
                <input
                  required
                  disabled={!isAdmin}
                  type="text"
                  value={formSettings.supportPhone}
                  onChange={(e) => setFormSettings({...formSettings, supportPhone: e.target.value})}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-12 pr-4 py-3 text-sm focus:ring-2 focus:ring-primary/10 transition-all outline-none text-slate-800 disabled:opacity-75 disabled:cursor-not-allowed"
                />
              </div>
            </div>

            {/* Welcome Motto */}
            <div className="space-y-2">
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Welcome Mission Subtitle</label>
              <div className="relative rounded-xl shadow-xs">
                <Sparkles className="absolute left-4 top-14 -translate-y-1/2 text-slate-400" size={16} />
                <textarea
                  required
                  disabled={!isAdmin}
                  rows={2}
                  value={formSettings.welcomeMotto}
                  onChange={(e) => setFormSettings({...formSettings, welcomeMotto: e.target.value})}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-12 pr-4 py-3 text-sm focus:ring-2 focus:ring-primary/10 transition-all outline-none text-slate-800 resize-none disabled:opacity-75 disabled:cursor-not-allowed"
                />
              </div>
            </div>

            {/* Founder Profile Info */}
            <div className="space-y-2">
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Founder Name</label>
              <input
                required
                disabled={!isAdmin}
                type="text"
                value={formSettings.founderName}
                onChange={(e) => setFormSettings({...formSettings, founderName: e.target.value})}
                placeholder="Biruk Tadesse"
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-primary/10 transition-all outline-none font-medium text-slate-800 disabled:opacity-75 disabled:cursor-not-allowed"
              />
            </div>

            {/* Founder LinkedIn URL */}
            <div className="space-y-2">
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Founder's LinkedIn URL</label>
              <input
                required
                disabled={!isAdmin}
                type="url"
                value={formSettings.founderLinkedIn}
                onChange={(e) => setFormSettings({...formSettings, founderLinkedIn: e.target.value})}
                placeholder="e.g. https://www.linkedin.com/in/yourprofile"
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-primary/10 transition-all outline-none font-medium text-slate-800 disabled:opacity-75 disabled:cursor-not-allowed"
              />
            </div>

            {/* Instagram Link */}
            <div className="space-y-2">
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Instagram Page URL</label>
              <input
                required
                disabled={!isAdmin}
                type="url"
                value={formSettings.instagramUrl}
                onChange={(e) => setFormSettings({...formSettings, instagramUrl: e.target.value})}
                placeholder="e.g. https://www.instagram.com/yourbrand"
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-primary/10 transition-all outline-none font-medium text-slate-800 disabled:opacity-75 disabled:cursor-not-allowed"
              />
            </div>

            {/* WhatsApp Link */}
            <div className="space-y-2">
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">WhatsApp Business / Chat URL</label>
              <input
                required
                disabled={!isAdmin}
                type="url"
                value={formSettings.whatsappUrl}
                onChange={(e) => setFormSettings({...formSettings, whatsappUrl: e.target.value})}
                placeholder="e.g. https://wa.me/251940651491"
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-primary/10 transition-all outline-none font-medium text-slate-800 disabled:opacity-75 disabled:cursor-not-allowed"
              />
            </div>

            {/* Facebook Link */}
            <div className="space-y-2">
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Facebook Page URL</label>
              <input
                required
                disabled={!isAdmin}
                type="url"
                value={formSettings.facebookUrl}
                onChange={(e) => setFormSettings({...formSettings, facebookUrl: e.target.value})}
                placeholder="e.g. https://www.facebook.com/yourpage"
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-primary/10 transition-all outline-none font-medium text-slate-800 disabled:opacity-75 disabled:cursor-not-allowed"
              />
            </div>

            {/* YouTube Link */}
            <div className="space-y-2">
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">YouTube Channel URL</label>
              <input
                required
                disabled={!isAdmin}
                type="url"
                value={formSettings.youtubeUrl}
                onChange={(e) => setFormSettings({...formSettings, youtubeUrl: e.target.value})}
                placeholder="e.g. https://www.youtube.com/@yourchannel"
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-primary/10 transition-all outline-none font-medium text-slate-800 disabled:opacity-75 disabled:cursor-not-allowed"
              />
            </div>
          </div>
        </div>

        {/* Companion App Integration (Fidel Fundamentals) */}
        <div className="bg-white rounded-2xl border border-slate-150/85 p-8 shadow-xs space-y-6" id="settings-companion-app-section">
          <div className="border-b border-slate-50 pb-4">
            <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
              <Sparkles className="text-secondary" size={20} />
              <span>Companion App: Fidel Fundamentals</span>
            </h2>
            <p className="text-xs text-slate-400 font-semibold uppercase tracking-wider mt-1">
              Configure and integrate external interactive learning apps for your students
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Hosted Web App URL */}
            <div className="space-y-2">
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Deployed Application URL (or Iframe Embed Link)</label>
              <input
                disabled={!isAdmin}
                type="url"
                value={formSettings.fidelFundamentalsUrl}
                onChange={(e) => setFormSettings({...formSettings, fidelFundamentalsUrl: e.target.value})}
                placeholder="e.g. https://yourbrand.github.io/fidel-fundamentals"
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-primary/10 transition-all outline-none font-medium text-slate-800 disabled:opacity-75 disabled:cursor-not-allowed"
              />
              <p className="text-[10px] text-slate-400 font-semibold leading-relaxed">
                Provide a hosted live URL of Fidel Fundamentals to allow instant inline previewing and game-play inside the Global Library's interactive iframe player.
              </p>
            </div>

            {/* GitHub Repository URL */}
            <div className="space-y-2">
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">GitHub Repository URL</label>
              <input
                disabled={!isAdmin}
                type="url"
                value={formSettings.fidelFundamentalsGit}
                onChange={(e) => setFormSettings({...formSettings, fidelFundamentalsGit: e.target.value})}
                placeholder="e.g. https://github.com/yourusername/fidel-fundamentals"
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-primary/10 transition-all outline-none font-medium text-slate-800 disabled:opacity-75 disabled:cursor-not-allowed"
              />
              <p className="text-[10px] text-slate-400 font-semibold leading-relaxed">
                Provide the link to your exported GitHub code so that educators and parents can view progress, download repositories, or study integration templates.
              </p>
            </div>
          </div>
        </div>

        {/* Ambassador & Referral Rewards Program Settings */}
        <div className="bg-white rounded-2xl border border-slate-150/85 p-8 shadow-xs space-y-6" id="settings-ambassador-section">
          <div className="border-b border-slate-50 pb-4">
            <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
              <Gift className="text-secondary animate-bounce" size={20} />
              <span>Ambassador & Referral Rewards Program</span>
            </h2>
            <p className="text-xs text-slate-400 font-semibold uppercase tracking-wider mt-1">
              Configure commission rewards, friend discount rates, and bonus class perks
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Referral Commission Rate */}
            <div className="space-y-2">
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Ambassador Commission Rate ($ USD Cash)</label>
              <div className="relative">
                <span className="absolute left-4 top-3 text-sm font-bold text-slate-400">$</span>
                <input
                  disabled={!isAdmin}
                  type="number"
                  value={formSettings.referralCommissionRate}
                  onChange={(e) => setFormSettings({...formSettings, referralCommissionRate: parseInt(e.target.value) || 0})}
                  placeholder="e.g. 9"
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-8 pr-4 py-3 text-sm focus:ring-2 focus:ring-primary/10 transition-all outline-none font-medium text-slate-800 disabled:opacity-75 disabled:cursor-not-allowed"
                />
              </div>
              <p className="text-[10px] text-slate-400 font-semibold leading-relaxed">
                Cash commission paid to the referring ambassador for each student enrollment.
              </p>
            </div>

            {/* Friend Discount Percent */}
            <div className="space-y-2">
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Invited Friend Discount Rate (%)</label>
              <div className="relative">
                <input
                  disabled={!isAdmin}
                  type="number"
                  value={formSettings.referralDiscountPercent}
                  onChange={(e) => setFormSettings({...formSettings, referralDiscountPercent: parseInt(e.target.value) || 0})}
                  placeholder="e.g. 10"
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-primary/10 transition-all outline-none font-medium text-slate-800 disabled:opacity-75 disabled:cursor-not-allowed"
                />
                <span className="absolute right-4 top-3 text-sm font-bold text-slate-400">%</span>
              </div>
              <p className="text-[10px] text-slate-400 font-semibold leading-relaxed">
                Percentage discount instantly credited to the invited friend's subscription.
              </p>
            </div>

            {/* Referral Bonus Credits */}
            <div className="space-y-2">
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Alternative Bonus Classes Reward</label>
              <div className="relative">
                <input
                  disabled={!isAdmin}
                  type="number"
                  value={formSettings.referralBonusCredits}
                  onChange={(e) => setFormSettings({...formSettings, referralBonusCredits: parseInt(e.target.value) || 0})}
                  placeholder="e.g. 1"
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-primary/10 transition-all outline-none font-medium text-slate-800 disabled:opacity-75 disabled:cursor-not-allowed"
                />
                <span className="absolute right-4 top-3 text-xs font-bold text-slate-400">Class(es)</span>
              </div>
              <p className="text-[10px] text-slate-400 font-semibold leading-relaxed">
                Number of free 1-on-1 private tutoring classes awarded instead of cash.
              </p>
            </div>
          </div>
        </div>

        {/* Brand Logo Laboratory Segment */}
        <div className="bg-white rounded-2xl border border-slate-150/85 p-8 shadow-xs space-y-6">
          <div className="border-b border-slate-50 pb-4">
            <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
              <Sparkles size={20} className="text-secondary animate-pulse" />
              Brand Identity & Logo Concept Lab
            </h2>
            <p className="text-xs text-slate-400 mt-1">
              Select one of our newly generated professional vector logos. Choosing a concept binds the asset instantly across your main landing page, navigations, and global portal headers! Hover over any logo to download the high-resolution asset to use on your social platforms!
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {/* New Tutor Logo */}
            <div 
              onClick={() => isAdmin && setFormSettings({ ...formSettings, activeLogoUrl: '/icon-512.jpg' })}
              className={`group relative rounded-2xl border-2 p-5 cursor-pointer transition-all duration-350 flex flex-col justify-between h-full bg-slate-50/50 hover:bg-white hover:shadow-md ${
                formSettings.activeLogoUrl === '/icon-512.jpg' 
                  ? 'border-sky-500 bg-white ring-4 ring-sky-50 shadow-sm' 
                  : 'border-slate-150/80 hover:border-slate-350'
              }`}
            >
              <div className="space-y-4">
                <div className="aspect-square w-full rounded-xl overflow-hidden bg-white border border-slate-100 flex items-center justify-center p-4 relative group-hover:scale-[1.02] transition-transform duration-300">
                  <BrandLogo 
                    logoUrl="/icon-512.jpg" 
                    className="max-h-full max-w-full object-contain"
                  />
                  {formSettings.activeLogoUrl === '/icon-512.jpg' && (
                    <span className="absolute top-3 right-3 bg-sky-500 text-white text-[9px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider shadow-sm">
                      Active
                    </span>
                  )}
                  <button
                    type="button"
                    onClick={(e) => handleDownloadLogo(4, e)}
                    className="absolute bottom-3 right-3 bg-slate-900/85 hover:bg-sky-600 text-white rounded-lg px-2.5 py-1.5 flex items-center gap-1 text-[10px] font-bold shadow-md transition-all backdrop-blur-xs opacity-0 group-hover:opacity-100 duration-200 cursor-pointer z-10"
                    title="Download New HabKids tutor Logo"
                  >
                    <Download size={12} />
                    <span>Download</span>
                  </button>
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-900 flex items-center gap-1.5">
                    Concept — HabKids tutor Official
                  </h3>
                  <p className="text-[11px] text-slate-500 font-medium leading-relaxed mt-1">
                    The new official <strong>HabKids tutor</strong> logo, optimized for app icons and high-visibility branding. Features the vibrant symbolic elements representing our heritage and modern learning.
                  </p>
                </div>
              </div>
              <div className="mt-4 pt-3 border-t border-slate-100/80 flex items-center justify-between">
                <span className="text-[10px] font-mono text-slate-400">PWA / Official Asset</span>
                <span className={`text-[10px] font-bold uppercase tracking-wider ${
                  formSettings.activeLogoUrl === '/icon-512.jpg' ? 'text-sky-600' : 'text-slate-400 group-hover:text-sky-600'
                }`}>
                  {formSettings.activeLogoUrl === '/icon-512.jpg' ? '✓ Applied' : 'Select'}
                </span>
              </div>
            </div>

            {/* Logo 1 */}
            <div 
              onClick={() => isAdmin && setFormSettings({ ...formSettings, activeLogoUrl: '/logo_option_one.png' })}
              className={`group relative rounded-2xl border-2 p-5 cursor-pointer transition-all duration-300 flex flex-col justify-between h-full bg-slate-50/50 hover:bg-white hover:shadow-md ${
                formSettings.activeLogoUrl === '/logo_option_one.png' 
                  ? 'border-indigo-600 bg-white ring-4 ring-indigo-50 shadow-sm' 
                  : 'border-slate-150/80 hover:border-slate-350'
              }`}
            >
              <div className="space-y-4">
                <div className="aspect-square w-full rounded-xl overflow-hidden bg-white border border-slate-100 flex items-center justify-center p-4 relative group-hover:scale-[1.02] transition-transform duration-300">
                  <BrandLogo 
                    logoUrl="/logo_option_one.png" 
                    className="max-h-full max-w-full object-contain"
                  />
                  {formSettings.activeLogoUrl === '/logo_option_one.png' && (
                    <span className="absolute top-3 right-3 bg-indigo-600 text-white text-[9px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider shadow-sm">
                      Active
                    </span>
                  )}
                  <button
                    type="button"
                    onClick={(e) => handleDownloadLogo(1, e)}
                    className="absolute bottom-3 right-3 bg-slate-900/85 hover:bg-indigo-600 text-white rounded-lg px-2.5 py-1.5 flex items-center gap-1 text-[10px] font-bold shadow-md transition-all backdrop-blur-xs opacity-0 group-hover:opacity-100 duration-200 cursor-pointer z-10"
                    title="Download and Open Traditional Connection Logo"
                  >
                    <Download size={12} />
                    <span>Download</span>
                  </button>
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-900 flex items-center gap-1.5">
                    Concept ፪ — Traditional Connection
                  </h3>
                  <p className="text-[11px] text-slate-500 font-medium leading-relaxed mt-1">
                    Features the Ge'ez numeral <strong>፪ (number 2)</strong>, elegantly integrated with a stylized book of wisdom and a bright warm orange star representing children's potential.
                  </p>
                </div>
              </div>
              <div className="mt-4 pt-3 border-t border-slate-100/80 flex items-center justify-between">
                <span className="text-[10px] font-mono text-slate-400">Indigo / Cream / Orange</span>
                <span className={`text-[10px] font-bold uppercase tracking-wider ${
                  formSettings.activeLogoUrl === '/logo_option_one.png' ? 'text-indigo-650' : 'text-slate-400 group-hover:text-indigo-600'
                }`}>
                  {formSettings.activeLogoUrl === '/logo_option_one.png' ? '✓ Applied' : 'Select'}
                </span>
              </div>
            </div>

            {/* Logo 2 */}
            <div 
              onClick={() => isAdmin && setFormSettings({ ...formSettings, activeLogoUrl: '/reallogo2.png' })}
              className={`group relative rounded-2xl border-2 p-5 cursor-pointer transition-all duration-350 flex flex-col justify-between h-full bg-slate-50/50 hover:bg-white hover:shadow-md ${
                formSettings.activeLogoUrl === '/reallogo2.png' 
                  ? 'border-indigo-600 bg-white ring-4 ring-indigo-50 shadow-sm' 
                  : 'border-slate-150/80 hover:border-slate-350'
              }`}
            >
              <div className="space-y-4">
                <div className="aspect-square w-full rounded-xl overflow-hidden bg-white border border-slate-100 flex items-center justify-center p-4 relative group-hover:scale-[1.02] transition-transform duration-300">
                  <BrandLogo 
                    logoUrl="/reallogo2.png" 
                    className="max-h-full max-w-full object-contain"
                  />
                  {formSettings.activeLogoUrl === '/reallogo2.png' && (
                    <span className="absolute top-3 right-3 bg-indigo-600 text-white text-[9px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider shadow-sm">
                      Active
                    </span>
                  )}
                  <button
                    type="button"
                    onClick={(e) => handleDownloadLogo(2, e)}
                    className="absolute bottom-3 right-3 bg-slate-900/85 hover:bg-indigo-600 text-white rounded-lg px-2.5 py-1.5 flex items-center gap-1 text-[10px] font-bold shadow-md transition-all backdrop-blur-xs opacity-0 group-hover:opacity-100 duration-200 cursor-pointer z-10"
                    title="Download and Open HabKids Second Custom Logo"
                  >
                    <Download size={12} />
                    <span>Download</span>
                  </button>
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-900 flex items-center gap-1.5">
                    Concept ፻ — Custom Logo 2
                  </h3>
                  <p className="text-[11px] text-slate-500 font-medium leading-relaxed mt-1">
                    Your custom-uploaded logo (<strong>reallogo2.png</strong>). Selecting this option applies this official, personalized logo globally across the main platform portal, landing page, and navigation headers.
                  </p>
                </div>
              </div>
              <div className="mt-4 pt-3 border-t border-slate-100/80 flex items-center justify-between">
                <span className="text-[10px] font-mono text-slate-400">Custom Uploaded Asset</span>
                <span className={`text-[10px] font-bold uppercase tracking-wider ${
                  formSettings.activeLogoUrl === '/reallogo2.png' ? 'text-indigo-650' : 'text-slate-400 group-hover:text-indigo-600'
                }`}>
                  {formSettings.activeLogoUrl === '/reallogo2.png' ? '✓ Applied' : 'Select'}
                </span>
              </div>
            </div>

            {/* Logo 3 */}
            <div 
              onClick={() => isAdmin && setFormSettings({ ...formSettings, activeLogoUrl: '/finallogo.png' })}
              className={`group relative rounded-2xl border-2 p-5 cursor-pointer transition-all duration-300 flex flex-col justify-between h-full bg-slate-50/50 hover:bg-white hover:shadow-md ${
                formSettings.activeLogoUrl === '/finallogo.png' 
                  ? 'border-indigo-600 bg-white ring-4 ring-indigo-50 shadow-sm' 
                  : 'border-slate-150/80 hover:border-slate-350'
              }`}
            >
              <div className="space-y-4">
                <div className="aspect-square w-full rounded-xl overflow-hidden bg-white border border-slate-100 flex items-center justify-center p-4 relative group-hover:scale-[1.02] transition-transform duration-300">
                  <BrandLogo 
                    logoUrl="/finallogo.png" 
                    className="max-h-full max-w-full object-contain"
                  />
                  {formSettings.activeLogoUrl === '/finallogo.png' && (
                    <span className="absolute top-3 right-3 bg-indigo-600 text-white text-[9px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider shadow-sm">
                      Active
                    </span>
                  )}
                  <button
                    type="button"
                    onClick={(e) => handleDownloadLogo(3, e)}
                    className="absolute bottom-3 right-3 bg-slate-900/85 hover:bg-indigo-600 text-white rounded-lg px-2.5 py-1.5 flex items-center gap-1 text-[10px] font-bold shadow-md transition-all backdrop-blur-xs opacity-0 group-hover:opacity-100 duration-200 cursor-pointer z-10"
                    title="Download and Open HabKids Final Logo"
                  >
                    <Download size={12} />
                    <span>Download</span>
                  </button>
                </div>
                <div>
                  <h3 className="text-sm font-bold text-slate-900 flex items-center gap-1.5">
                    Concept ሀ — Custom Final Logo
                  </h3>
                  <p className="text-[11px] text-slate-500 font-medium leading-relaxed mt-1">
                    Your custom-uploaded logo (<strong>finallogo.png</strong>). Selecting this option applies this official, personalized logo globally across the main platform portal, landing page, and navigation headers.
                  </p>
                </div>
              </div>
              <div className="mt-4 pt-3 border-t border-slate-100/80 flex items-center justify-between">
                <span className="text-[10px] font-mono text-slate-400">Custom Uploaded Asset</span>
                <span className={`text-[10px] font-bold uppercase tracking-wider ${
                  formSettings.activeLogoUrl === '/finallogo.png' ? 'text-indigo-650' : 'text-slate-400 group-hover:text-indigo-600'
                }`}>
                  {formSettings.activeLogoUrl === '/finallogo.png' ? '✓ Applied' : 'Select'}
                </span>
              </div>
            </div>
          </div>

          {formSettings.activeLogoUrl && (
            <div className="bg-indigo-50/60 border border-indigo-100 p-4 rounded-xl flex items-center gap-3">
              <Sparkles size={16} className="text-indigo-650 shrink-0" />
              <p className="text-[11px] text-indigo-900 font-semibold leading-relaxed">
                You have staged a dynamic logo. Click <strong>"Commit System Config"</strong> below to write this branding across our central databases permanently!
              </p>
            </div>
          )}
        </div>

        {/* Form Actions */}
        {isAdmin && (
          <div className="flex items-center justify-end gap-4 border-t border-slate-100 pt-6">
            <button
               type="submit"
               disabled={isSaving}
               id="commit-settings-btn"
               className="btn-primary flex items-center justify-center gap-2 px-8 py-3.5 rounded-xl shadow-lg shadow-indigo-600/10 hover:scale-[1.01] transition-all cursor-pointer font-bold text-sm"
            >
              {isSaving ? (
                <>
                  <Loader2 className="animate-spin" size={18} />
                  <span>Saving Credentials...</span>
                </>
              ) : (
                <span>Commit System Config</span>
              )}
            </button>
          </div>
        )}
      </form>

      {/* SMTP Security & E-mail Diagnostics Board */}
      {isAdmin && (
        <div className="space-y-8 mt-12 pt-8 border-t border-slate-100 text-left">
          <div>
            <h2 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
              <Activity className="text-indigo-600 animate-pulse" size={20} />
              <span>SMTP Diagnostics & E-mail Log System</span>
            </h2>
            <p className="text-slate-500 text-xs mt-1">
              Verify real-time e-mail connection parameters and inspect automated trial lesson delivery logs below.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {/* SMTP Status Tracker Card */}
            <div className="bg-white border border-slate-150 rounded-2xl p-6 shadow-sm flex flex-col justify-between">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2">
                    <Database size={16} className="text-slate-400" />
                    <span>Nodemailer Transport Node</span>
                  </h3>
                  <button
                    type="button"
                    onClick={fetchSmtpStatus}
                    disabled={smtpChecking}
                    className="p-1.5 text-slate-400 hover:text-slate-600 hover:bg-slate-50 rounded-lg transition-colors cursor-pointer"
                    title="Refresh connection state"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${smtpChecking ? 'animate-spin' : ''}`} />
                  </button>
                </div>

                {smtpStatus?.configured ? (
                  <div className="bg-emerald-50/60 border border-emerald-100 rounded-xl p-4 flex items-start gap-3">
                    <CheckCircle2 size={18} className="text-emerald-500 shrink-0 mt-0.5" />
                    <div>
                      <h4 className="text-xs font-bold text-emerald-950">SMTP Server Active</h4>
                      <p className="text-[11px] text-emerald-700 leading-relaxed mt-0.5">
                        Your production SMTP credentials are active. Real emails are triggered instantly to both parents and tutors.
                      </p>
                    </div>
                  </div>
                ) : (
                  <div className="bg-amber-50/60 border border-amber-100 rounded-xl p-4 flex items-start gap-3">
                    <AlertCircle size={18} className="text-amber-500 shrink-0 mt-0.5" />
                    <div>
                      <h4 className="text-xs font-bold text-amber-950">Emails Simulating (Fallback Mode)</h4>
                      <p className="text-[11px] text-amber-700 leading-relaxed mt-0.5">
                        No active custom dynamic overrides or environment values found. Core operations use transient system notifications.
                      </p>
                    </div>
                  </div>
                )}

                <div className="space-y-2.5 pt-2">
                  <div className="flex justify-between text-xs border-b border-dashed border-slate-100 pb-1.5">
                    <span className="text-slate-450 font-semibold">Relay Server Host</span>
                    <span className="font-mono text-slate-800">{smtpStatus?.host || 'smtp.gmail.com'}</span>
                  </div>
                  <div className="flex justify-between text-xs border-b border-dashed border-slate-100 pb-1.5">
                    <span className="text-slate-450 font-semibold">Server Port</span>
                    <span className="font-mono text-slate-800">{smtpStatus?.port || '587'}</span>
                  </div>
                  <div className="flex justify-between text-xs pb-1">
                    <span className="text-slate-450 font-semibold">Primary SMTP Account</span>
                    <span className="font-mono text-slate-800 text-right truncate max-w-[200px]" title={smtpStatus?.user || ''}>
                      {smtpStatus?.user || 'None Configured'}
                    </span>
                  </div>
                </div>
              </div>

              <div className="bg-slate-50 border border-slate-100 rounded-xl p-3.5 mt-4">
                <span className="text-[10px] text-slate-450 font-bold block uppercase tracking-wider mb-1">PRO-TIP FOR DELIVERY</span>
                <p className="text-[10px] text-slate-500 leading-normal">
                  To stream real emails, configure your SMTP server parameters. If utilizing Gmail, create an <strong>App Password</strong> through your Google Account Security tab.
                </p>
              </div>
            </div>

            {/* Custom Dynamic SMTP Configuration Card */}
            <div className="bg-white border border-slate-150 rounded-2xl p-6 shadow-sm flex flex-col justify-between">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2">
                    <Mail size={16} className="text-slate-400" />
                    <span>Dynamic Credentials</span>
                  </h3>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input 
                      type="checkbox" 
                      className="sr-only peer" 
                      checked={useOverride} 
                      onChange={(e) => setUseOverride(e.target.checked)} 
                    />
                    <div className="w-9 h-5 bg-slate-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-indigo-600"></div>
                    <span className="ml-2 text-[10px] font-bold text-slate-500 uppercase tracking-wider">{useOverride ? 'Active' : 'Disabled'}</span>
                  </label>
                </div>

                <p className="text-xs text-slate-500 leading-relaxed">
                  Override default or fallback SMTP settings dynamically on the fly. This config is read instantly by the server.
                </p>

                <form onSubmit={handleSaveSmtpOverrides} className="space-y-3 pt-1">
                  <div>
                    <label className="text-[10px] font-bold text-slate-650 block mb-1.5 uppercase tracking-wide">Email Delivery Protocol</label>
                    <select
                      disabled={!useOverride}
                      value={overrideProvider}
                      onChange={(e) => {
                        const val = e.target.value;
                        setOverrideProvider(val);
                        if (val === 'resend') {
                          setOverrideHost('api.resend.com');
                          setOverridePort('443');
                        } else if (val === 'brevo') {
                          setOverrideHost('api.brevo.com');
                          setOverridePort('443');
                        } else {
                          setOverrideHost('smtp.gmail.com');
                          setOverridePort('587');
                        }
                      }}
                      className="w-full text-xs border border-slate-200 bg-white rounded-xl px-3 py-2 focus:outline-none focus:ring-1 focus:ring-indigo-500 text-slate-850 disabled:bg-slate-100 disabled:text-slate-400 font-semibold"
                    >
                      <option value="smtp">Standard SMTP (TCP Socket - Gmail, etc.)</option>
                      <option value="resend">Resend API (HTTPS Web Request - Port 443)</option>
                      <option value="brevo">Brevo API (HTTPS Web Request - Port 443)</option>
                    </select>
                  </div>

                  <div>
                    <label className="text-[10px] font-bold text-slate-650 block mb-1 uppercase tracking-wide">
                      {overrideProvider === 'smtp' ? 'SMTP Username (Email)' : 'Sender Email Address'}
                    </label>
                    <input
                      type="email"
                      disabled={!useOverride}
                      required={useOverride}
                      value={overrideUser}
                      onChange={(e) => setOverrideUser(e.target.value)}
                      placeholder={overrideProvider === 'resend' ? "e.g. onboarding@resend.dev" : "e.g. brtsegayetad@gmail.com"}
                      className="w-full text-xs border border-slate-200 rounded-xl px-3.5 py-2.5 focus:outline-none focus:ring-1 focus:ring-indigo-500 text-slate-850 disabled:bg-slate-50 disabled:text-slate-400"
                    />
                  </div>

                  <div>
                    <label className="text-[10px] font-bold text-slate-650 block mb-1 uppercase tracking-wide">
                      {overrideProvider === 'smtp' ? 'Gmail App Password' : `${overrideProvider === 'resend' ? 'Resend' : 'Brevo'} Secret API Key`}
                    </label>
                    <input
                      type="password"
                      disabled={!useOverride}
                      required={useOverride}
                      value={overridePass}
                      onChange={(e) => setOverridePass(e.target.value)}
                      placeholder={overrideProvider === 'smtp' ? "XXXX XXXX XXXX XXXX" : (overrideProvider === 'resend' ? "re_abc123..." : "xskeyib-...")}
                      className="w-full text-xs font-mono border border-slate-200 rounded-xl px-3.5 py-2.5 focus:outline-none focus:ring-1 focus:ring-indigo-500 text-slate-850 disabled:bg-slate-50 disabled:text-slate-400"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="text-[10px] font-bold text-slate-650 block mb-2 uppercase tracking-wide font-sans">Endpoint Host</label>
                      <input
                        type="text"
                        disabled={true}
                        value={overrideHost}
                        placeholder="smtp.gmail.com"
                        className="w-full text-xs border border-slate-100 bg-slate-50 rounded-xl px-3 py-2 text-slate-450 focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] font-bold text-slate-650 block mb-2 uppercase tracking-wide font-sans">Port</label>
                      <input
                        type="text"
                        disabled={true}
                        value={overridePort}
                        placeholder="587"
                        className="w-full text-xs border border-slate-100 bg-slate-50 rounded-xl px-3 py-2 text-slate-450 focus:outline-none"
                      />
                    </div>
                  </div>

                  <button
                    type="submit"
                    disabled={savingOverrides}
                    className="w-full mt-2 bg-indigo-600 text-white text-xs font-bold py-2.5 rounded-xl hover:bg-indigo-700 active:scale-98 disabled:opacity-50 transition-all flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    {savingOverrides ? (
                      <>
                        <Loader2 className="animate-spin w-3.5 h-3.5" />
                        <span>Updating Delivery System...</span>
                      </>
                    ) : (
                      <>
                        <Check size={14} />
                        <span>Save Delivery Config</span>
                      </>
                    )}
                  </button>
                </form>

                {overrideError && (
                  <div className="bg-rose-50 border border-rose-100 rounded-xl p-3 text-[10px] font-mono text-rose-700">
                    Failed to save: {overrideError}
                  </div>
                )}
                {overrideSuccess && (
                  <div className="bg-emerald-50 border border-emerald-100 rounded-xl p-3 text-[11px] text-emerald-800 flex items-center gap-2">
                    <CheckCircle2 size={14} className="text-emerald-600" />
                    <span>Dynamic SMTP settings updated!</span>
                  </div>
                )}
              </div>
            </div>

            {/* SMTP Test Console Card */}
            <div className="bg-white border border-slate-150 rounded-2xl p-6 shadow-sm flex flex-col justify-between">
              <div className="space-y-4">
                <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2">
                  <Send size={16} className="text-slate-400" />
                  <span>Instant Delivery Test Tunnel</span>
                </h3>
                <p className="text-xs text-slate-500 leading-relaxed">
                  Fire a clean diagnostic test email directly through the server's NodeMailer engine and capture full error traces immediately.
                </p>

                <form onSubmit={handleTestSmtp} className="space-y-3 pt-1">
                  <div>
                    <label className="text-[11px] font-bold text-slate-650 block mb-1">Recipient Address</label>
                    <div className="flex gap-2">
                      <input
                        type="email"
                        required
                        value={testEmailAddress}
                        onChange={(e) => setTestEmailAddress(e.target.value)}
                        placeholder="e.g. administrator@abyssiniatutors.com"
                        className="flex-1 text-xs border border-slate-200 rounded-xl px-3.5 py-2.5 focus:outline-none focus:ring-1 focus:ring-indigo-500 text-slate-850"
                      />
                      <button
                        type="submit"
                        disabled={testSending || !testEmailAddress}
                        className="bg-indigo-600 text-white text-xs font-bold px-4 py-2.5 rounded-xl hover:bg-indigo-700 active:scale-95 disabled:opacity-50 transition-all flex items-center gap-1.5 shrink-0 cursor-pointer"
                      >
                        {testSending ? (
                          <>
                            <Loader2 className="animate-spin w-3 h-3" />
                            <span>Sending...</span>
                          </>
                        ) : (
                          <>
                            <Send size={12} />
                            <span>Direct Test</span>
                          </>
                        )}
                      </button>
                    </div>
                  </div>
                </form>

                {/* Test Diagnostic Result */}
                {testResult && (
                  <div className={`rounded-xl p-4 border text-xs leading-relaxed ${
                    testResult.success 
                      ? 'bg-emerald-50 border-emerald-100 text-emerald-800' 
                      : 'bg-rose-50 border-rose-100 text-rose-800 font-mono text-[10px] max-h-[140px] overflow-y-auto whitespace-pre-wrap'
                  }`}>
                    <div className="flex items-start gap-2">
                      {testResult.success ? (
                        <Check size={14} className="shrink-0 mt-0.5 text-emerald-600" />
                      ) : (
                        <X size={14} className="shrink-0 mt-0.5 text-rose-600" />
                      )}
                      <div>
                        <p className="font-bold">{testResult.success ? "Success!" : "SMTP Connection Failed!"}</p>
                        <p className="mt-0.5 leading-normal">{testResult.message}</p>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              <div className="text-[10px] text-slate-400 font-semibold pt-4 text-center">
                System records test transactions as custom audit paths inside Firestore logs.
              </div>
            </div>
          </div>

          {/* E-mail Transmission Logs Table */}
          <div className="bg-white border border-slate-150 rounded-2xl shadow-sm overflow-hidden">
            <div className="p-5 border-b border-slate-100 flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2">
                  <Activity size={16} className="text-indigo-600" />
                  <span>Real-Time E-mail Transmission Index</span>
                </h3>
                <p className="text-[11px] text-slate-450 mt-0.5">Captures system notification loops, trial bookings, and automated auto-responder outputs</p>
              </div>
              <span className="text-[10px] font-mono bg-slate-50 border border-slate-100 text-slate-450 px-2.5 py-1 rounded-full font-bold uppercase tracking-wider animate-pulse">
                Live Snaps
              </span>
            </div>

            <div className="divide-y divide-slate-100 max-h-[400px] overflow-y-auto">
              {logsLoading ? (
                <div className="p-8 text-center text-slate-400 text-xs flex flex-col items-center justify-center gap-2">
                  <Loader2 className="animate-spin text-indigo-650" size={20} />
                  <span>Subscribing to notification snapshots...</span>
                </div>
              ) : emailLogs.length === 0 ? (
                <div className="p-12 text-center text-slate-400 text-xs">
                  <Mail className="mx-auto text-slate-300 mb-2" size={28} />
                  <p>No recent email transactions recorded in development bounds.</p>
                </div>
              ) : (
                emailLogs.map((log) => {
                  const dateStr = log.timestamp instanceof Date 
                    ? log.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }) + ' ' + log.timestamp.toLocaleDateString()
                    : 'Just now';

                  return (
                    <div key={log.id} className="p-4 hover:bg-slate-50/50 transition-colors text-xs flex flex-col md:flex-row md:items-center justify-between gap-3 text-left">
                      <div className="space-y-1.5 md:max-w-[70%]">
                        <div className="flex flex-wrap items-center gap-2">
                          <span className="font-bold text-slate-800 truncate select-all">{log.to}</span>
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded-full capitalize bg-indigo-50 text-indigo-700">
                            {log.role}
                          </span>
                        </div>
                        <div className="text-slate-650 font-semibold">{log.subject}</div>
                        {log.errorMessage && (
                          <div className="text-[10px] font-mono text-rose-600 bg-rose-50/60 border border-rose-100/50 rounded p-1.5 mt-1 select-all break-all overflow-x-auto">
                            {log.errorMessage}
                          </div>
                        )}
                        <details className="mt-1.5 group">
                          <summary className="text-[10.5px] font-bold text-indigo-600 hover:text-indigo-800 cursor-pointer list-none flex items-center gap-1 shrink-0">
                            <span>▶ View Message Markup</span>
                          </summary>
                          <div className="mt-2 text-[10px] font-mono text-slate-600 bg-slate-50 p-2.5 rounded border border-slate-100 overflow-x-auto whitespace-pre-wrap max-h-[150px] select-all leading-normal">
                            {log.body}
                          </div>
                        </details>
                      </div>

                      <div className="flex md:flex-col items-center md:items-end justify-between gap-2 shrink-0">
                        {log.status === 'SMTP_SENT' ? (
                          <span className="inline-flex items-center gap-1 text-[10px] font-bold text-emerald-700 bg-emerald-50 border border-emerald-100 px-2 py-1 rounded-full">
                            <Check size={10} strokeWidth={3} />
                            <span>Delivered via SMTP</span>
                          </span>
                        ) : log.status === 'SIMULATED' ? (
                          <span className="inline-flex items-center gap-1 text-[10px] font-bold text-blue-700 bg-blue-50 border border-blue-100 px-2 py-1 rounded-full" title="No real SMTP credentials set. Email was printed to log.">
                            <RefreshCw size={10} className="animate-pulse" />
                            <span>Simulated (Fallback)</span>
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 text-[10px] font-bold text-rose-700 bg-rose-50 border border-rose-100 px-2 py-1 rounded-full">
                            <X size={10} strokeWidth={3} />
                            <span>Dispatch Failed</span>
                          </span>
                        )}
                        <span className="text-[10px] font-mono text-slate-400 font-semibold md:text-right">{dateStr}</span>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

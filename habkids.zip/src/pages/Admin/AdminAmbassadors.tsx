import React, { useState, useEffect } from 'react';
import { 
  Gift, 
  DollarSign, 
  Users, 
  ArrowUpRight, 
  Briefcase, 
  Activity, 
  CheckCircle, 
  XCircle, 
  Clock, 
  Search, 
  ChevronRight, 
  Save, 
  Loader2, 
  AlertCircle,
  TrendingUp,
  Award
} from 'lucide-react';
import { 
  collection, 
  query, 
  onSnapshot, 
  doc, 
  updateDoc, 
  getDocs,
  where,
  serverTimestamp
} from 'firebase/firestore';
import { db } from '../../lib/firebase';
import { useAuth } from '../../context/AuthContext';
import { subscribeToSettings, saveSettings } from '../../services/dataService';

export default function AdminAmbassadors() {
  const { user } = useAuth();
  const isAdmin = user?.role === 'admin';

  // State arrays representation
  const [payouts, setPayouts] = useState<any[]>([]);
  const [referrals, setReferrals] = useState<any[]>([]);
  const [ambassadors, setAmbassadors] = useState<any[]>([]);
  const [globalSettings, setGlobalSettings] = useState<any>({
    referralCommissionRate: 9,
    referralDiscountPercent: 10,
    referralBonusCredits: 1,
    whatsappUrl: 'https://wa.me/251940651491'
  });

  const [loading, setLoading] = useState(true);
  const [isSavingSettings, setIsSavingSettings] = useState(false);
  const [settingsSaveStatus, setSettingsSaveStatus] = useState<'idle' | 'success' | 'error'>('idle');
  const [selectedPayout, setSelectedPayout] = useState<any | null>(null);
  const [payoutSearch, setPayoutSearch] = useState('');
  const [ambassadorSearch, setAmbassadorSearch] = useState('');
  const [activeSubTab, setActiveSubTab] = useState<'payout_requests' | 'ambassadors_list' | 'program_settings'>('payout_requests');

  // Input bindings for setting parameters
  const [commissionRate, setCommissionRate] = useState(9);
  const [discountPercent, setDiscountPercent] = useState(10);
  const [bonusCredits, setBonusCredits] = useState(1);

  useEffect(() => {
    // 1. Subscribe to Global Settings
    const unsubSettings = subscribeToSettings((data) => {
      if (data) {
        setGlobalSettings(data);
        setCommissionRate(typeof data.referralCommissionRate === 'number' ? data.referralCommissionRate : 9);
        setDiscountPercent(typeof data.referralDiscountPercent === 'number' ? data.referralDiscountPercent : 10);
        setBonusCredits(typeof data.referralBonusCredits === 'number' ? data.referralBonusCredits : 1);
      }
    });

    // 2. Subscribe to Payout Requests
    const qPayouts = query(collection(db, 'payout_requests'));
    const unsubPayouts = onSnapshot(qPayouts, (snap) => {
      const payoutList = snap.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      // Sort: pending first, then newest
      const sorted = payoutList.sort((a: any, b: any) => {
        if (a.status === 'pending' && b.status !== 'pending') return -1;
        if (a.status !== 'pending' && b.status === 'pending') return 1;
        const dA = a.createdAt?.toDate ? a.createdAt.toDate() : new Date(a.createdAt || 0);
        const dB = b.createdAt?.toDate ? b.createdAt.toDate() : new Date(b.createdAt || 0);
        return dB.getTime() - dA.getTime();
      });
      setPayouts(sorted);
    }, (error) => {
      console.error("Payout Requests listener error in AdminAmbassadors:", error);
    });

    // 3. Subscribe to Referrals logs ledger
    const qRefs = query(collection(db, 'referrals'));
    const unsubRefs = onSnapshot(qRefs, (snap) => {
      const refList = snap.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setReferrals(refList);
    }, (error) => {
      console.error("Referrals collection listener error:", error);
    });

    // 4. Fetch registered Ambassadors / Users with referralCode
    const qUsers = query(collection(db, 'users'));
    const unsubUsers = onSnapshot(qUsers, (snap) => {
      const userList = snap.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      // Filter out users who have a referral code
      const ambassadorList = userList.filter((u: any) => !!u.referralCode);
      setAmbassadors(ambassadorList);
      setLoading(false);
    }, (error) => {
      console.error("Users list load error:", error);
      setLoading(false);
    });

    return () => {
      unsubSettings();
      unsubPayouts();
      unsubRefs();
      unsubUsers();
    };
  }, []);

  const handleUpdatePayoutStatus = async (payoutId: string, newStatus: 'approved' | 'rejected') => {
    try {
      const pRef = doc(db, 'payout_requests', payoutId);
      await updateDoc(pRef, {
        status: newStatus,
        processedAt: serverTimestamp(),
        processedBy: user?.email || 'System Admin'
      });
      alert(`🎉 Payout request successfully marked as ${newStatus}!`);
      setSelectedPayout(null);
    } catch (e) {
      console.error("Error updating payout status:", e);
      alert("Failed to committed status changes. Please check permissions.");
    }
  };

  const handleSaveReferralSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!isAdmin) return;
    setIsSavingSettings(true);
    setSettingsSaveStatus('idle');

    const updated = {
      ...globalSettings,
      referralCommissionRate: Number(commissionRate),
      referralDiscountPercent: Number(discountPercent),
      referralBonusCredits: Number(bonusCredits),
    };

    const res = await saveSettings(updated);
    setIsSavingSettings(false);
    if (res.success) {
      setSettingsSaveStatus('success');
      setTimeout(() => setSettingsSaveStatus('idle'), 2500);
    } else {
      setSettingsSaveStatus('error');
    }
  };

  // Aggregated calculated statistics
  const totalApprovedAmount = payouts
    .filter(p => p.status === 'approved')
    .reduce((sum, p) => sum + (Number(p.claimedAmountUsd) || 0), 0);

  const totalPendingAmount = payouts
    .filter(p => p.status === 'pending')
    .reduce((sum, p) => sum + (Number(p.claimedAmountUsd) || 0), 0);

  const pendingPayoutsCount = payouts.filter(p => p.status === 'pending').length;

  // Filter lists based on searches
  const filteredPayouts = payouts.filter(p => {
    const parentEmail = (p.parentEmail || '').toLowerCase();
    const payId = (p.id || '').toLowerCase();
    const type = (p.payoutType || '').toLowerCase();
    const searchVal = payoutSearch.toLowerCase();
    return parentEmail.includes(searchVal) || payId.includes(searchVal) || type.includes(searchVal);
  });

  const filteredAmbassadors = ambassadors.filter(a => {
    const name = (a.fullName || '').toLowerCase();
    const email = (a.email || '').toLowerCase();
    const code = (a.referralCode || '').toLowerCase();
    const searchVal = ambassadorSearch.toLowerCase();
    return name.includes(searchVal) || email.includes(searchVal) || code.includes(searchVal);
  });

  if (loading) {
    return (
      <div className="h-[60vh] flex flex-col items-center justify-center text-slate-400 gap-3">
        <Loader2 className="animate-spin text-amber-500" size={32} />
        <p className="text-sm font-medium">Loading Ambassador System metrics...</p>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto space-y-8 animate-in fade-in duration-300 text-left">
      
      {/* Page Header */}
      <header className="border-b border-slate-150 pb-6 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-amber-50 text-amber-600 rounded-2xl shadow-sm">
            <Gift size={28} />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-slate-950 tracking-tight font-sans">
              Partnership & Ambassador Program
            </h1>
            <p className="text-slate-400 text-sm mt-1">
              Verify global referrals, review active claim streams, and wire student enrollment commissions.
            </p>
          </div>
        </div>

        {/* Dynamic Badge for Pending Requests */}
        {pendingPayoutsCount > 0 && (
          <span className="bg-rose-50 border border-rose-150 text-rose-700 text-xs font-black px-4 py-2 rounded-full flex items-center gap-2 animate-pulse font-sans shadow-sm">
            <Clock size={14} className="animate-spin text-rose-600" />
            <span>{pendingPayoutsCount} Action Required Claim{pendingPayoutsCount > 1 ? 's' : ''}</span>
          </span>
        )}
      </header>

      {/* Metrics Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        
        {/* Metric 1 */}
        <div className="bg-white p-6 rounded-2xl border border-slate-150 shadow-xs">
          <div className="flex items-center justify-between mb-3">
            <span className="text-[10px] font-bold text-slate-405 uppercase tracking-wider">Requested Claims</span>
            <div className="p-2 bg-amber-50 text-amber-500 rounded-xl">
              <DollarSign size={18} />
            </div>
          </div>
          <div className="space-y-1">
            <p className="text-2xl font-bold text-slate-900 font-mono">${(totalApprovedAmount + totalPendingAmount).toLocaleString()}.00</p>
            <p className="text-[10px] text-slate-400 font-medium">Accumulated rewards ledger value</p>
          </div>
        </div>

        {/* Metric 2 */}
        <div className="bg-white p-6 rounded-2xl border border-slate-150 shadow-xs">
          <div className="flex items-center justify-between mb-3">
            <span className="text-[10px] font-bold text-slate-405 uppercase tracking-wider">Approved & Paid out</span>
            <div className="p-2 bg-emerald-50 text-emerald-500 rounded-xl">
              <CheckCircle size={18} />
            </div>
          </div>
          <div className="space-y-1">
            <p className="text-2xl font-bold text-emerald-600 font-mono">${totalApprovedAmount.toLocaleString()}.00</p>
            <p className="text-[10px] text-slate-400 font-medium tracking-tight">Commissions fully dispatched to accounts</p>
          </div>
        </div>

        {/* Metric 3 */}
        <div className="bg-white p-6 rounded-2xl border border-slate-150 shadow-xs">
          <div className="flex items-center justify-between mb-3">
            <span className="text-[10px] font-bold text-slate-405 uppercase tracking-wider">Unresolved/Pending</span>
            <div className="p-2 bg-rose-50 text-rose-500 rounded-xl">
              <Clock size={18} />
            </div>
          </div>
          <div className="space-y-1">
            <p className="text-2xl font-bold text-rose-600 font-mono">${totalPendingAmount.toLocaleString()}.00</p>
            <p className="text-[10px] text-slate-400 font-medium">Payouts awaiting admin bank wire</p>
          </div>
        </div>

        {/* Metric 4 */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs">
          <div className="flex items-center justify-between mb-3">
            <span className="text-[10px] font-bold text-slate-405 uppercase tracking-wider">Active Ambassadors</span>
            <div className="p-2 bg-indigo-50 text-indigo-550 rounded-xl">
              <Users size={18} />
            </div>
          </div>
          <div className="space-y-1">
            <p className="text-2xl font-bold text-indigo-650">{ambassadors.length}</p>
            <p className="text-[10px] text-slate-400 font-medium">Inviting referrers worldwide</p>
          </div>
        </div>
      </div>

      {/* Main Container Tabs */}
      <div className="bg-white rounded-3xl border border-slate-150 overflow-hidden shadow-xs flex flex-col">
        
        {/* Sub Navigation Tabs */}
        <div className="flex border-b border-slate-100 bg-slate-50/50 p-2 gap-1">
          <button
            type="button"
            onClick={() => setActiveSubTab('payout_requests')}
            className={`px-5 py-3 rounded-xl text-xs font-bold font-sans tracking-wide transition-all uppercase flex items-center gap-2 cursor-pointer ${
              activeSubTab === 'payout_requests'
                ? 'bg-slate-900 text-white shadow-md'
                : 'text-slate-500 hover:text-slate-800 hover:bg-slate-150/40'
            }`}
          >
            <DollarSign size={14} />
            <span>Payout Reward Requests</span>
            {pendingPayoutsCount > 0 && (
              <span className="bg-rose-600 text-white font-mono text-[9px] font-bold w-4.5 h-4.5 rounded-full flex items-center justify-center animate-pulse">
                {pendingPayoutsCount}
              </span>
            )}
          </button>

          <button
            type="button"
            onClick={() => setActiveSubTab('ambassadors_list')}
            className={`px-5 py-3 rounded-xl text-xs font-bold font-sans tracking-wide transition-all uppercase flex items-center gap-2 cursor-pointer ${
              activeSubTab === 'ambassadors_list'
                ? 'bg-slate-900 text-white shadow-md'
                : 'text-slate-500 hover:text-slate-800 hover:bg-slate-150/40'
            }`}
          >
            <Users size={14} />
            <span>Ambassadors Directory ({ambassadors.length})</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveSubTab('program_settings')}
            className={`px-5 py-3 rounded-xl text-xs font-bold font-sans tracking-wide transition-all uppercase flex items-center gap-2 cursor-pointer ${
              activeSubTab === 'program_settings'
                ? 'bg-slate-900 text-white shadow-md'
                : 'text-slate-500 hover:text-slate-800 hover:bg-slate-150/40'
            }`}
          >
            <Save size={14} />
            <span>Program Variables Settings</span>
          </button>
        </div>

        {/* Tab content area */}
        <div className="p-6">
          
          {/* TAB 1: Payout Requests Panel */}
          {activeSubTab === 'payout_requests' && (
            <div className="space-y-6">
              
              {/* Filter Row */}
              <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pb-2 border-b border-slate-100">
                <div>
                  <h3 className="text-base font-bold text-slate-900 font-sans">Accrued Commission Claims</h3>
                  <p className="text-[11px] text-slate-400 mt-0.5">Approve requests sent by parents, or track past wire transfers.</p>
                </div>
                <div className="relative w-full sm:w-64">
                  <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-350">
                    <Search size={14} />
                  </span>
                  <input
                    type="text"
                    placeholder="Search by email, bank, option..."
                    value={payoutSearch}
                    onChange={(e) => setPayoutSearch(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-9 pr-4 py-2 text-xs text-slate-700 outline-none focus:ring-1 focus:ring-amber-500"
                  />
                </div>
              </div>

              {/* Claims database table */}
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="border-b border-slate-100/90 text-[10px] text-slate-400 font-bold uppercase tracking-wider">
                      <th className="py-3 px-4">Affiliate Parent / Ambassador</th>
                      <th className="py-3 px-4">Payment Channel Target</th>
                      <th className="py-3 px-4">Claimed Reward</th>
                      <th className="py-3 px-4">Request Date</th>
                      <th className="py-3 px-4">Verification State</th>
                      <th className="py-3 px-4 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {filteredPayouts.map((p) => {
                      const reqDate = p.createdAt?.toDate ? p.createdAt.toDate().toLocaleDateString('en-US', {
                        month: 'short',
                        day: 'numeric',
                        year: 'numeric'
                      }) : 'Pending';

                      return (
                        <tr key={p.id} className="hover:bg-slate-50/50 transition-colors">
                          <td className="py-4 px-4">
                            <div className="flex items-center gap-3">
                              <div className="w-8 h-8 rounded-full bg-indigo-50 flex items-center justify-center text-[10px] font-bold text-indigo-600 uppercase shrink-0">
                                {p.parentEmail?.[0] || 'A'}
                              </div>
                              <div>
                                <p className="font-bold text-slate-850 truncate max-w-[180px]" title={p.parentEmail}>
                                  {p.parentEmail}
                                </p>
                                <p className="text-[10px] text-slate-400 block font-mono">ID: {p.id?.substring(0, 8)}...</p>
                              </div>
                            </div>
                          </td>
                          <td className="py-4 px-4">
                            <div className="space-y-0.5">
                              <span className="font-extrabold uppercase text-[9px] bg-slate-100 text-slate-700 px-1.5 py-0.5 rounded">
                                {p.payoutType || 'Telebirr'}
                              </span>
                              <p className="font-medium font-mono text-slate-600 tracking-tight mt-1">{p.accountDetails}</p>
                            </div>
                          </td>
                          <td className="py-4 px-4">
                            <p className="text-sm font-extrabold text-slate-900 font-mono">${Number(p.claimedAmountUsd || 0).toLocaleString()}.00</p>
                            <p className="text-[10px] text-slate-400 font-sans">Enrollment payout</p>
                          </td>
                          <td className="py-4 px-4 text-slate-500 font-medium">
                            {reqDate}
                          </td>
                          <td className="py-4 px-4">
                            <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[9px] font-black uppercase tracking-wider border ${
                              p.status === 'approved' 
                                ? 'bg-emerald-50 text-emerald-700 border-emerald-150'
                                : p.status === 'rejected'
                                  ? 'bg-rose-50 text-rose-700 border-rose-150'
                                  : 'bg-amber-50 text-amber-700 border-amber-150 animate-pulse'
                            }`}>
                              <span className={`w-1.5 h-1.5 rounded-full ${
                                p.status === 'approved' 
                                  ? 'bg-emerald-500' 
                                  : p.status === 'rejected' 
                                    ? 'bg-rose-500' 
                                    : 'bg-amber-500 animate-ping'
                              }`} />
                              <span>{p.status || 'pending'}</span>
                            </span>
                          </td>
                          <td className="py-4 px-4 text-right">
                            {p.status === 'pending' ? (
                              <div className="flex items-center justify-end gap-2">
                                <button
                                  type="button"
                                  onClick={() => handleUpdatePayoutStatus(p.id, 'approved')}
                                  className="bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold px-3 py-1.5 rounded-lg text-[10px] uppercase tracking-wider transition-all cursor-pointer"
                                >
                                  Wire & Pay
                                </button>
                                <button
                                  type="button"
                                  onClick={() => handleUpdatePayoutStatus(p.id, 'rejected')}
                                  className="bg-slate-105 hover:bg-slate-200 text-slate-700 font-bold px-2.5 py-1.5 rounded-lg text-[10px] uppercase transition-all cursor-pointer"
                                  title="Deny request"
                                >
                                  Deny
                                </button>
                              </div>
                            ) : (
                              <span className="text-[10px] text-slate-400 font-medium font-sans">
                                Processed • {p.processedBy ? 'Admin' : 'Auto'}
                              </span>
                            )}
                          </td>
                        </tr>
                      );
                    })}

                    {filteredPayouts.length === 0 && (
                      <tr>
                        <td colSpan={6} className="py-12 text-center text-slate-400 font-medium italic text-xs">
                          No commission payout requests logged.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>

            </div>
          )}

          {/* TAB 2: Ambassadors List / Referrers Directory */}
          {activeSubTab === 'ambassadors_list' && (
            <div className="space-y-6 animate-in fade-in duration-200">
              
              {/* Filter header */}
              <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pb-2 border-b border-slate-100">
                <div>
                  <h3 className="text-base font-bold text-slate-900 font-sans">Active Partners Directory</h3>
                  <p className="text-[11px] text-slate-400 mt-0.5">Users who registered custom codes or shared links to promote HabKids.</p>
                </div>
                <div className="relative w-full sm:w-64">
                  <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-350">
                    <Search size={14} />
                  </span>
                  <input
                    type="text"
                    placeholder="Search by name, email, code..."
                    value={ambassadorSearch}
                    onChange={(e) => setAmbassadorSearch(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-9 pr-4 py-2 text-xs text-slate-700 outline-none focus:ring-1 focus:ring-amber-500"
                  />
                </div>
              </div>

              {/* Table of active codes */}
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="border-b border-slate-100/90 text-[10px] text-slate-400 font-bold uppercase tracking-wider">
                      <th className="py-3 px-4">Ambassador Profile</th>
                      <th className="py-3 px-4">Designated Referral Code</th>
                      <th className="py-3 px-4">Performance: Invites Created</th>
                      <th className="py-3 px-4">Total Accrued Income</th>
                      <th className="py-3 px-4">Support State / Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {filteredAmbassadors.map((amb) => {
                      // Calculate refers matching this specific code
                      const codeRefs = referrals.filter(r => r.referralCode === amb.referralCode);
                      const joinedCount = codeRefs.length;
                      const enrolledCount = codeRefs.filter(r => r.status === 'enrolled' || r.status === 'converted').length;
                      const totalAccrued = codeRefs.reduce((acc, r) => acc + (r.commissionAmount || 25), 0);

                      return (
                        <tr key={amb.id || amb.uid} className="hover:bg-slate-50/50 transition-colors">
                          <td className="py-4 px-4 col-span-2">
                            <div className="flex items-center gap-3">
                              <div className="w-9 h-9 rounded-xl bg-amber-50 text-amber-600 font-bold flex items-center justify-center shrink-0 shadow-sm border border-amber-100/40">
                                <Award size={16} />
                              </div>
                              <div>
                                <p className="font-bold text-slate-900">{amb.fullName || 'HabKids Ambassador'}</p>
                                <p className="text-[10px] text-slate-400 block">{amb.email}</p>
                              </div>
                            </div>
                          </td>
                          <td className="py-4 px-4 font-mono font-bold text-slate-850">
                            <span className="bg-slate-900 text-amber-400 text-[10px] px-2 py-1 rounded-md font-bold tracking-tight shadow-sm border border-slate-800">
                              {amb.referralCode}
                            </span>
                          </td>
                          <td className="py-4 px-4 text-slate-600">
                            <div className="flex items-center gap-3">
                              <span className="font-bold text-slate-900">{joinedCount} clicks</span>
                              <span className="text-slate-300">•</span>
                              <span className="text-[10px] font-black uppercase text-emerald-600 bg-emerald-50 px-1.5 py-0.5 rounded">
                                {enrolledCount} enrolled
                              </span>
                            </div>
                          </td>
                          <td className="py-4 px-4 font-mono font-bold text-sm text-slate-900">
                            ${totalAccrued || 0}.00
                          </td>
                          <td className="py-4 px-4">
                            <a
                              href={`https://wa.me/251940651491?text=${encodeURIComponent(`Hello HabKids Ambassador Team! I am coordinating referral setup with ambassador user: ${amb.fullName} (${amb.email}) code: ${amb.referralCode}`)}`}
                              target="_blank"
                              referrerPolicy="no-referrer"
                              className="text-[10px] font-bold text-indigo-650 bg-indigo-50 hover:bg-indigo-100 px-3 py-1.5 rounded-lg transition-all uppercase flex w-fit items-center gap-1.5"
                            >
                              💬 Contact WhatsApp
                            </a>
                          </td>
                        </tr>
                      );
                    })}

                    {filteredAmbassadors.length === 0 && (
                      <tr>
                        <td colSpan={5} className="py-12 text-center text-slate-400 font-medium italic text-xs">
                          No ambassadors registered customized referral codes yet.
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>

            </div>
          )}

          {/* TAB 3: Program Settings Panel */}
          {activeSubTab === 'program_settings' && (
            <div className="max-w-xl mx-auto py-4 animate-in fade-in duration-200 text-left">
              <form onSubmit={handleSaveReferralSettings} className="space-y-6">
                
                <div className="border-b border-slate-100 pb-3">
                  <h3 className="text-base font-bold text-slate-905 font-sans">Affiliate Partnership Rules</h3>
                  <p className="text-[11px] text-slate-400 mt-1">
                    Configure standard rewards automatically offered to newly registering referrers and friends using referral codes.
                  </p>
                </div>

                {settingsSaveStatus === 'success' && (
                  <div className="bg-emerald-50 border border-emerald-150 p-4 rounded-xl flex items-center gap-3 text-emerald-800 animate-in slide-in-from-top-4 duration-300">
                    <CheckCircle size={18} className="text-emerald-500 shrink-0" />
                    <div className="text-xs font-semibold">
                      Committed updated program variables dynamically. Let ambassadors double check accounts!
                    </div>
                  </div>
                )}

                {settingsSaveStatus === 'error' && (
                  <div className="bg-rose-50 border border-rose-150 p-4 rounded-xl flex items-center gap-3 text-rose-800 animate-in slide-in-from-top-4 duration-300">
                    <AlertCircle size={18} className="text-rose-500 shrink-0" />
                    <div className="text-xs font-semibold">
                      Permission verification failed. Ensure you have Admin credentials.
                    </div>
                  </div>
                )}

                <div className="space-y-4">
                  {/* Rule 1: Flat Commission Rate */}
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-bold text-slate-450 uppercase tracking-widest block">Flat Commission Rate Per Student Enrollment</label>
                    <div className="relative rounded-xl shadow-xs">
                      <div className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 text-xs font-bold">$</div>
                      <input
                        required
                        disabled={!isAdmin}
                        type="number"
                        min="0"
                        value={commissionRate}
                        onChange={(e) => setCommissionRate(Number(e.target.value) || 0)}
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-9 pr-4 py-3 text-sm focus:ring-1 focus:ring-amber-505 transition-all text-slate-800 font-bold outline-none"
                      />
                      <div className="absolute right-4 top-1/2 -translate-y-1/2 text-[10px] text-slate-400 font-bold uppercase">USD Flat</div>
                    </div>
                    <p className="text-[10px] text-slate-400 font-medium">Accumulated inside referrals ledger whenever friend subscribes to plan.</p>
                  </div>

                  {/* Rule 2: Friend Discount Percentage */}
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-bold text-slate-450 uppercase tracking-widest block">Friend Welcome Discount</label>
                    <div className="relative rounded-xl shadow-xs">
                      <input
                        required
                        disabled={!isAdmin}
                        type="number"
                        min="0"
                        max="100"
                        value={discountPercent}
                        onChange={(e) => setDiscountPercent(Number(e.target.value) || 0)}
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-4 pr-10 py-3 text-sm focus:ring-1 focus:ring-amber-550 transition-all text-slate-800 font-bold outline-none"
                      />
                      <div className="absolute right-4 top-1/2 -translate-y-1/2 text-sm font-bold text-slate-400">%</div>
                    </div>
                    <p className="text-[10px] text-slate-400 font-medium">Welcome discount applied instantly at trial bookings or checkout.</p>
                  </div>

                  {/* Rule 3: Friend Bonus Credits */}
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-bold text-slate-450 uppercase tracking-widest block">Friend Welcome Gift (Bonus Class/Credit)</label>
                    <div className="relative rounded-xl shadow-xs">
                      <input
                        required
                        disabled={!isAdmin}
                        type="number"
                        min="0"
                        value={bonusCredits}
                        onChange={(e) => setBonusCredits(Number(e.target.value) || 0)}
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-4 pr-14 py-3 text-sm focus:ring-1 focus:ring-amber-550 transition-all text-slate-800 font-bold outline-none"
                      />
                      <div className="absolute right-4 top-1/2 -translate-y-1/2 text-[10px] text-slate-400 font-bold uppercase">Credits</div>
                    </div>
                  </div>
                </div>

                {isAdmin && (
                  <div className="pt-4 border-t border-slate-100 flex justify-end">
                    <button
                      type="submit"
                      disabled={isSavingSettings}
                      className="bg-slate-900 hover:bg-slate-800 text-white font-bold px-6 py-3 rounded-xl text-xs uppercase tracking-wider flex items-center gap-2 shadow-md transition-all cursor-pointer"
                    >
                      {isSavingSettings ? (
                        <>
                          <Loader2 className="animate-spin" size={14} />
                          <span>Saving parameters...</span>
                        </>
                      ) : (
                        <>
                          <Save size={14} />
                          <span>Commit Config</span>
                        </>
                      )}
                    </button>
                  </div>
                )}
              </form>
            </div>
          )}

        </div>
      </div>
      
    </div>
  );
}

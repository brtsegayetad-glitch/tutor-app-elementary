import React, { useState, useEffect } from 'react';
import { 
  Search, 
  MoreHorizontal, 
  UserPlus,
  Loader2,
  MessageSquare,
  Calendar,
  X,
  CheckCircle2,
  AlertCircle,
  Plus,
  Trash2
} from 'lucide-react';
import { cn } from '../../lib/utils';
import { subscribeToLeads, subscribeToTutors, updateLeadStatus, deleteLead, createLeadManually } from '../../services/dataService';
import SchedulingModal from '../../components/Admin/SchedulingModal';

export default function AdminLeads() {
  const [leads, setLeads] = useState<any[]>([]);
  const [tutors, setTutors] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');
  
  // Create Lead State
  const [isCreatingLead, setIsCreatingLead] = useState(false);
  const [newLeadLoading, setNewLeadLoading] = useState(false);
  const [newLeadData, setNewLeadData] = useState({
    parentName: '',
    email: '',
    password: '',
    childName: '',
    childAge: '',
    whatsapp: '',
    learningGoal: '',
    status: 'new',
    timezone: 'UTC',
    children: [] as any[]
  });

  // Scheduling Modal State
  const [selectedLead, setSelectedLead] = useState<any>(null);
  const [viewingReport, setViewingReport] = useState<any>(null);
  const [openLeadMenuId, setOpenLeadMenuId] = useState<string | null>(null);

  const [newLeadError, setNewLeadError] = useState<string | null>(null);
  const [newLeadSuccess, setNewLeadSuccess] = useState(false);

  const handleCreateLead = async (e: React.FormEvent) => {
    e.preventDefault();
    setNewLeadLoading(true);
    setNewLeadError(null);
    setNewLeadSuccess(false);
    try {
      const res = await createLeadManually(newLeadData, newLeadData.password);
      if (res.success) {
        setNewLeadSuccess(true);
        setTimeout(() => {
          setIsCreatingLead(false);
          setNewLeadSuccess(false);
          setNewLeadData({
            parentName: '',
            email: '',
            password: '',
            childName: '',
            childAge: '',
            whatsapp: '',
            learningGoal: '',
            status: 'new',
            timezone: 'UTC',
            children: []
          });
        }, 2000);
      } else {
        setNewLeadError("Failed to create lead. Please try again.");
      }
    } catch (err: any) {
      console.error("Error creating lead:", err);
      setNewLeadError(err.message || "An unexpected error occurred.");
    } finally {
      setNewLeadLoading(false);
    }
  };

  const handleAddChild = () => {
    setNewLeadData(prev => ({
      ...prev,
      children: [...prev.children, { name: '', age: '', subjects: ['Amharic'] }]
    }));
  };

  const handleRemoveChild = (index: number) => {
    setNewLeadData(prev => ({
      ...prev,
      children: prev.children.filter((_, i) => i !== index)
    }));
  };

  const handleChildChange = (index: number, field: string, value: any) => {
    setNewLeadData(prev => ({
      ...prev,
      children: prev.children.map((c, i) => i === index ? { ...c, [field]: value } : c)
    }));
  };

  const handleUpdateStatus = async (leadId: string, status: string) => {
    try {
      await updateLeadStatus(leadId, status);
    } catch (err) {
      console.error("Error updating lead status:", err);
    }
  };

  const handleDelete = async (leadId: string, parentName: string) => {
    if (!window.confirm(`Are you sure you want to permanently delete the lead from ${parentName}?`)) {
      return;
    }
    try {
      await deleteLead(leadId);
    } catch (err) {
      console.error("Error deleting lead:", err);
    }
  };

  useEffect(() => {
    let leadsLoaded = false;
    let tutorsLoaded = false;

    const checkLoading = () => {
      if (leadsLoaded && tutorsLoaded) {
        setLoading(false);
      }
    };

    const unsubscribeLeads = subscribeToLeads(
      (data) => {
        setLeads(data);
        leadsLoaded = true;
        checkLoading();
      },
      () => {
        leadsLoaded = true;
        checkLoading();
      }
    );

    const unsubscribeTutors = subscribeToTutors(
      (data) => {
        setTutors(data);
        tutorsLoaded = true;
        checkLoading();
      },
      () => {
        tutorsLoaded = true;
        checkLoading();
      }
    );

    return () => {
      unsubscribeLeads();
      unsubscribeTutors();
    };
  }, []);

  const filteredLeads = leads.filter(lead => {
    const matchesFilter = filter === 'all' || lead.status === filter;
    const matchesSearch = lead.parentName?.toLowerCase().includes(searchTerm.toLowerCase()) || 
                         lead.childName?.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesFilter && matchesSearch;
  });

  if (loading) {
    return (
      <div className="h-[60vh] flex flex-col items-center justify-center text-slate-400 gap-3">
        <Loader2 className="animate-spin text-secondary" size={32} />
        <p className="text-sm font-medium">Loading lead infrastructure...</p>
      </div>
    );
  }

  return (
    <div className="space-y-8 relative">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <h1 className="text-3xl font-bold text-primary mb-1 tracking-tight">Lead Pipeline</h1>
          <p className="text-slate-500 text-sm">Managing enrollment process from interest to conversion.</p>
        </div>
        <button 
          onClick={() => setIsCreatingLead(true)}
          className="btn-primary text-xs py-2 px-4 shadow-none cursor-pointer"
        >
          <UserPlus size={16} />
          Create New Lead
        </button>
      </header>

      {/* Stats Bar */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: 'Total Leads', count: leads.length, color: 'text-primary' },
          { label: 'Recent Trials', count: leads.filter(l => l.status === 'scheduled').length, color: 'text-secondary' },
          { label: 'New Today', count: leads.filter(l => l.status === 'new').length, color: 'text-accent' },
          { label: 'Conv. Rate', count: '42%', color: 'text-emerald-600' },
        ].map((s, i) => (
          <div key={i} className="bg-white p-4 rounded-xl border border-slate-100 shadow-sm flex flex-col gap-1">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{s.label}</span>
            <span className={cn("text-2xl font-bold tracking-tight", s.color)}>{s.count}</span>
          </div>
        ))}
      </div>

      {/* Filter & Search */}
      <div className="flex flex-col md:flex-row gap-4 items-center justify-between bg-white p-3 rounded-xl border border-slate-100 shadow-sm">
        <div className="flex gap-1 p-1 bg-slate-50 rounded-lg w-full md:w-fit overflow-x-auto">
          {['all', 'new', 'trial_pending', 'scheduled', 'trial_completed', 'converted'].map((f) => (
            <button 
              key={f}
              onClick={() => setFilter(f)}
              className={cn(
                "px-4 py-1.5 rounded-md text-[10px] font-bold capitalize transition-all uppercase tracking-widest whitespace-nowrap",
                filter === f ? "bg-white text-primary shadow-sm" : "text-slate-400 hover:text-slate-600"
              )}
            >
              {f.replace('_', ' ')}
            </button>
          ))}
        </div>
        
        <div className="flex items-center bg-slate-50 border border-slate-200 rounded-lg px-3 py-1.5 w-full md:w-72 focus-within:ring-2 focus-within:ring-primary/5 focus-within:border-primary">
          <Search size={14} className="text-slate-400 mr-2" />
          <input 
            type="text" 
            placeholder="Search leads..." 
            className="bg-transparent border-none focus:outline-none text-xs w-full text-slate-600"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
      </div>

      {/* Leads Table */}
      <div className="bg-white rounded-xl border border-slate-100 shadow-sm overflow-hidden flex flex-col">
        <div className="overflow-x-auto flex-1">
          <table className="data-table">
            <thead>
              <tr>
                <th>Parent & Child</th>
                <th>Channel</th>
                <th>Goal</th>
                <th>Status</th>
                <th className="text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredLeads.map((lead) => (
                <tr key={lead.id}>
                  <td>
                    <div className="flex items-center gap-3">
                       <div className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center text-[10px] font-bold text-slate-400">
                          {lead.parentName?.[0] || 'U'}{lead.parentName?.split(' ')[1]?.[0] || ''}
                       </div>
                       <div>
                        <p className="font-semibold text-slate-900 leading-tight">{lead.parentName}</p>
                        <p className="text-[10px] text-slate-400 mt-0.5">{lead.childName} ({lead.childAge}) • {lead.country || lead.timezone}</p>
                        {lead.tutorId && lead.tutorId.trim() !== "" ? (
                          <div className="mt-1.5 inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-indigo-50 text-[9px] font-bold text-indigo-755 border border-indigo-150 shadow-sm">
                            <span className="w-1.5 h-1.5 rounded-full bg-indigo-500 animate-pulse"></span>
                            <span>👤 Chosen: {lead.tutorName || "Hand-selected Tutor"}</span>
                          </div>
                        ) : (
                          <div className="mt-1.5 inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-slate-50 text-[9px] font-bold text-slate-650 border border-slate-200">
                            <span>🤖 Auto Match Approved</span>
                          </div>
                        )}
                        {lead.children && Array.isArray(lead.children) && (
                          <div className="flex flex-wrap gap-1 mt-1.5 max-w-sm">
                            {lead.children.map((c: any, ci: number) => (
                              <span key={ci} className="bg-slate-50 text-[9px] font-semibold text-slate-600 px-2 py-0.5 rounded border border-slate-100 flex items-center gap-1">
                                👦 {c.name} ({c.age} yrs): <span className="text-primary font-bold">{(c.subjects || []).join(' & ')}</span>
                              </span>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>
                  </td>
                  <td>
                    <div className="flex items-center gap-2">
                       <div className="w-6 h-6 bg-emerald-50 text-emerald-600 rounded-md flex items-center justify-center">
                        <MessageSquare size={12} />
                      </div>
                      <span className="text-[10px] font-medium text-slate-600 tracking-tight">{lead.whatsapp || lead.phone || 'N/A'}</span>
                    </div>
                  </td>
                  <td>
                    <p className="text-[11px] text-slate-500 max-w-xs truncate font-medium" title={lead.learningGoal || lead.targetCourse}>{lead.learningGoal || lead.targetCourse}</p>
                  </td>
                  <td>
                    <span className={cn(
                      "px-2.5 py-1 rounded-full text-[9px] font-bold uppercase tracking-wider",
                      (lead.status === 'new' || !lead.status) && "bg-amber-100 text-amber-700",
                      (lead.status === 'trial_pending' || lead.status === 'TRIAL PENDING') && "bg-amber-100 text-amber-700 border border-amber-300/40 font-extrabold",
                      lead.status === 'contacted' && "bg-blue-100 text-blue-700",
                      lead.status === 'scheduled' && "bg-purple-100 text-purple-700",
                      lead.status === 'trial_completed' && "bg-slate-100 text-slate-600",
                      lead.status === 'converted' && "bg-emerald-100 text-emerald-700"
                    )}>
                      {(lead.status || 'new').replace('_', ' ')}
                    </span>
                  </td>
                  <td className="text-right">
                     <div className="flex justify-end gap-2">
                       {(lead.status === 'new' || !lead.status || lead.status === 'trial_pending' || lead.status === 'TRIAL PENDING') && (
                         <button 
                           onClick={() => setSelectedLead(lead)}
                           className="bg-primary/5 text-primary hover:bg-primary hover:text-white px-2 py-1 rounded text-[9px] font-bold uppercase transition-all cursor-pointer"
                         >
                            Assign Tutor
                         </button>
                       )}
                       {lead.status === 'trial_completed' && (
                         <button 
                           onClick={() => setViewingReport(lead)}
                           className="bg-secondary/10 text-secondary hover:bg-secondary hover:text-white px-2 py-1 rounded text-[9px] font-bold uppercase transition-all"
                         >
                            View Report
                         </button>
                       )}
                       <div className="relative inline-block text-left">
                         <button 
                           type="button"
                           onClick={() => setOpenLeadMenuId(openLeadMenuId === lead.id ? null : lead.id)}
                           className="text-slate-300 hover:text-primary p-1 cursor-pointer transition-colors"
                         >
                            <MoreHorizontal size={16} />
                         </button>
                         {openLeadMenuId === lead.id && (
                           <div 
                             className="absolute right-0 top-full mt-1 bg-white border border-slate-200 rounded-xl shadow-xl py-1.5 w-40 z-30 text-left animate-in fade-in slide-in-from-top-1 duration-100"
                             onMouseLeave={() => setOpenLeadMenuId(null)}
                           >
                             <button
                               type="button"
                               onClick={() => {
                                 setOpenLeadMenuId(null);
                                 handleUpdateStatus(lead.id, 'new');
                               }}
                               className="w-full text-left px-3.5 py-1.5 text-[10px] font-bold text-slate-700 hover:bg-slate-50 flex items-center gap-2 cursor-pointer transition-colors"
                             >
                               <span className="w-2 h-2 rounded-full bg-amber-400 shrink-0" />
                               <span>Mark New</span>
                             </button>
                             <button
                               type="button"
                               onClick={() => {
                                 setOpenLeadMenuId(null);
                                 handleUpdateStatus(lead.id, 'contacted');
                               }}
                               className="w-full text-left px-3.5 py-1.5 text-[10px] font-bold text-slate-700 hover:bg-slate-50 flex items-center gap-2 cursor-pointer transition-colors"
                             >
                               <span className="w-2 h-2 rounded-full bg-blue-500 shrink-0" />
                               <span>Mark Contacted</span>
                             </button>
                             <button
                               type="button"
                               onClick={() => {
                                 setOpenLeadMenuId(null);
                                 setSelectedLead(lead);
                               }}
                               className="w-full text-left px-3.5 py-1.5 text-[10px] font-bold text-slate-700 hover:bg-slate-50 flex items-center gap-2 cursor-pointer transition-colors"
                             >
                               <span className="w-2 h-2 rounded-full bg-indigo-500 shrink-0" />
                               <span>Schedule Trial</span>
                             </button>
                             <button
                               type="button"
                               onClick={() => {
                                 setOpenLeadMenuId(null);
                                 handleUpdateStatus(lead.id, 'converted');
                               }}
                               className="w-full text-left px-3.5 py-1.5 text-[10px] font-bold text-slate-700 hover:bg-slate-50 flex items-center gap-2 cursor-pointer transition-colors"
                             >
                               <span className="w-2 h-2 rounded-full bg-emerald-500 shrink-0" />
                               <span>Mark Converted</span>
                             </button>
                             <div className="h-[1px] bg-slate-100 my-1 font-normal" />
                             <button
                               type="button"
                               onClick={() => {
                                 setOpenLeadMenuId(null);
                                 handleDelete(lead.id, lead.parentName);
                               }}
                               className="w-full text-left px-3.5 py-1.5 text-[10px] font-bold text-rose-600 hover:bg-rose-50 flex items-center gap-2 cursor-pointer transition-colors"
                             >
                               <span>🗑️ Delete Lead</span>
                             </button>
                           </div>
                         )}
                       </div>
                     </div>
                  </td>
                </tr>
              ))}
              {filteredLeads.length === 0 && (
                <tr>
                  <td colSpan={5} className="py-20 text-center text-slate-400 text-xs italic font-medium">No results found for your search/filter.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Scheduling Modal */}
      {selectedLead && (
        <SchedulingModal 
          lead={selectedLead} 
          tutors={tutors} 
          onClose={() => setSelectedLead(null)} 
        />
      )}

      {/* Trial Report Modal */}
      {viewingReport && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
           <div className="bg-white w-full max-w-xl rounded-[32px] shadow-2xl overflow-hidden">
              <div className="p-8 bg-slate-900 text-white flex justify-between items-start">
                 <div>
                    <div className="flex items-center gap-2 mb-2">
                       <CheckCircle2 size={16} className="text-secondary" />
                       <span className="text-[10px] font-bold uppercase tracking-widest text-slate-400">Post-Trial Report</span>
                    </div>
                    <h3 className="text-2xl font-bold tracking-tight">Lead: {viewingReport.childName}</h3>
                    <p className="text-slate-400 text-xs mt-1">Parent: {viewingReport.parentName} • Level {viewingReport.recommendedLevel || 'TBD'}</p>
                 </div>
                 <button onClick={() => setViewingReport(null)} className="p-2 hover:bg-white/10 rounded-full transition-colors">
                    <X size={20} />
                 </button>
              </div>

              <div className="p-10 space-y-8">
                 <div className="space-y-4">
                    <h4 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Tutor Evaluation</h4>
                    <div className="bg-slate-50 p-6 rounded-2xl border border-slate-100 text-sm text-slate-600 italic leading-relaxed">
                       "{viewingReport.evaluation || 'No evaluation logic found. Please check manual tutor logs.'}"
                    </div>
                 </div>

                 <div className="grid grid-cols-2 gap-6">
                    <div className="p-5 bg-white border border-slate-100 rounded-2xl">
                       <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest mb-1">Recommended Level</p>
                       <p className="text-lg font-bold text-slate-900">Level {viewingReport.recommendedLevel || 'Assessment Done'}</p>
                    </div>
                    <div className="p-5 bg-white border border-slate-100 rounded-2xl">
                       <p className="text-[9px] font-bold text-slate-400 uppercase tracking-widest mb-1">Status</p>
                       <p className="text-lg font-bold text-emerald-600 uppercase">Ready to Enroll</p>
                    </div>
                 </div>

                 <div className="pt-6 border-t border-slate-100 flex gap-4">
                    <button 
                      onClick={() => {
                        setViewingReport(null);
                        // Maybe trigger enrollment follow-up
                      }}
                      className="flex-1 bg-slate-900 text-white font-bold py-4 rounded-xl text-xs uppercase tracking-widest hover:bg-slate-800 transition-all shadow-lg shadow-slate-900/10"
                    >
                       Contact Parent
                    </button>
                    <button 
                      onClick={() => setViewingReport(null)}
                      className="px-8 py-4 bg-slate-50 text-slate-400 font-bold rounded-xl text-xs uppercase tracking-widest hover:bg-slate-100 transition-all"
                    >
                       Close
                    </button>
                 </div>
              </div>
           </div>
        </div>
      )}

      {/* Create Lead Modal */}
      {isCreatingLead && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-white w-full max-w-2xl rounded-[32px] shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
            <div className="p-8 bg-primary text-white flex justify-between items-start shrink-0">
               <div>
                  <div className="flex items-center gap-2 mb-2">
                     <UserPlus size={16} className="text-secondary" />
                     <span className="text-[10px] font-bold uppercase tracking-widest text-white/60">Manual Enrollment</span>
                  </div>
                  <h3 className="text-2xl font-bold tracking-tight">Create New Lead</h3>
                  <p className="text-white/60 text-xs mt-1">Add a new family to the pipeline and optionally create a portal account.</p>
               </div>
               <button onClick={() => setIsCreatingLead(false)} className="p-2 hover:bg-white/10 rounded-full transition-colors">
                  <X size={20} />
               </button>
            </div>

            <form onSubmit={handleCreateLead} className="p-8 overflow-y-auto space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Parent Full Name</label>
                  <input 
                    type="text" 
                    required
                    value={newLeadData.parentName}
                    onChange={(e) => setNewLeadData({...newLeadData, parentName: e.target.value})}
                    placeholder="e.g. Martha Jones"
                    className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-primary/5 focus:border-primary transition-all text-sm"
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Parent Email</label>
                  <input 
                    type="email" 
                    required
                    value={newLeadData.email}
                    onChange={(e) => setNewLeadData({...newLeadData, email: e.target.value})}
                    placeholder="martha@example.com"
                    className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-primary/5 focus:border-primary transition-all text-sm"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Portal Password (for parent login)</label>
                  <input 
                    type="text" 
                    value={newLeadData.password}
                    onChange={(e) => setNewLeadData({...newLeadData, password: e.target.value})}
                    placeholder="Temporary login password"
                    className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-primary/5 focus:border-primary transition-all text-sm"
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">WhatsApp / Phone</label>
                  <input 
                    type="text" 
                    value={newLeadData.whatsapp}
                    onChange={(e) => setNewLeadData({...newLeadData, whatsapp: e.target.value})}
                    placeholder="+1 234 567 890"
                    className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-primary/5 focus:border-primary transition-all text-sm"
                  />
                </div>
              </div>

              {newLeadError && (
                <div className="p-4 bg-rose-50 border border-rose-100 rounded-xl flex items-center gap-3 text-rose-600 text-xs animate-in slide-in-from-top-2">
                  <AlertCircle size={16} />
                  <p>{newLeadError}</p>
                </div>
              )}

              {newLeadSuccess && (
                <div className="p-4 bg-emerald-50 border border-emerald-100 rounded-xl flex items-center gap-3 text-emerald-600 text-xs animate-in slide-in-from-top-2">
                  <CheckCircle2 size={16} />
                  <p>Lead and parent portal access created successfully!</p>
                </div>
              )}

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Primary Child Name</label>
                  <input 
                    type="text" 
                    value={newLeadData.childName}
                    onChange={(e) => setNewLeadData({...newLeadData, childName: e.target.value})}
                    placeholder="e.g. Sam"
                    className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-primary/5 focus:border-primary transition-all text-sm"
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Primary Child Age</label>
                  <input 
                    type="text" 
                    value={newLeadData.childAge}
                    onChange={(e) => setNewLeadData({...newLeadData, childAge: e.target.value})}
                    placeholder="e.g. 8"
                    className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-primary/5 focus:border-primary transition-all text-sm"
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Learning Goals</label>
                <textarea 
                  value={newLeadData.learningGoal}
                  onChange={(e) => setNewLeadData({...newLeadData, learningGoal: e.target.value})}
                  placeholder="e.g. Speak Amharic with grandparents"
                  className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-primary/5 focus:border-primary transition-all text-sm h-20 resize-none"
                />
              </div>

              {/* Dynamic Children List */}
              <div className="space-y-4 pt-4 border-t border-slate-100">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold text-slate-900">Additional Children</h4>
                  <button 
                    type="button"
                    onClick={handleAddChild}
                    className="text-[10px] font-bold text-primary flex items-center gap-1 hover:underline"
                  >
                    <Plus size={12} /> Add Another
                  </button>
                </div>
                
                {newLeadData.children.map((child, index) => (
                  <div key={index} className="p-4 bg-slate-50 rounded-2xl border border-slate-100 flex items-start gap-4">
                    <div className="grid grid-cols-2 gap-4 flex-1">
                      <input 
                        type="text" 
                        value={child.name}
                        onChange={(e) => handleChildChange(index, 'name', e.target.value)}
                        placeholder="Child Name"
                        className="px-3 py-1.5 bg-white border border-slate-200 rounded-lg text-xs"
                      />
                      <input 
                        type="text" 
                        value={child.age}
                        onChange={(e) => handleChildChange(index, 'age', e.target.value)}
                        placeholder="Age"
                        className="px-3 py-1.5 bg-white border border-slate-200 rounded-lg text-xs"
                      />
                    </div>
                    <button 
                      type="button"
                      onClick={() => handleRemoveChild(index)}
                      className="p-1.5 text-slate-400 hover:text-rose-500 transition-colors"
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>
                ))}
              </div>

              <div className="pt-4 flex gap-4">
                <button 
                  type="submit"
                  disabled={newLeadLoading}
                  className="flex-1 bg-primary text-white font-bold py-4 rounded-xl text-xs uppercase tracking-widest hover:bg-opacity-90 transition-all flex items-center justify-center gap-2"
                >
                  {newLeadLoading ? <Loader2 size={16} className="animate-spin" /> : 'Create Enrollment Lead'}
                </button>
                <button 
                  type="button"
                  onClick={() => setIsCreatingLead(false)}
                  className="px-8 py-4 bg-slate-50 text-slate-400 font-bold rounded-xl text-xs uppercase tracking-widest hover:bg-slate-100 transition-all"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

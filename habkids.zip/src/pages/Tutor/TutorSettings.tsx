import React, { useState, useEffect } from 'react';
import { 
  Settings, 
  User as UserIcon, 
  Mail, 
  Phone, 
  BookOpen, 
  Plus, 
  X, 
  CheckCircle2, 
  Loader2, 
  Send,
  Video
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { updateTutorAvailability, updateTutorProfile } from '../../services/dataService';
import { cn } from '../../lib/utils';
import { db, auth } from '../../lib/firebase';
import { updateEmail } from 'firebase/auth';
import { doc, updateDoc, collection, query, where, getDocs } from 'firebase/firestore';

const DAYS = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'];
const HOURS = [
  '00:00', '01:00', '02:00', '03:00', '04:00', '05:00',
  '06:00', '07:00', '08:00', '09:00', '10:00', '11:00',
  '12:00', '13:00', '14:00', '15:00', '16:00', '17:00',
  '18:00', '19:00', '20:00', '21:00', '22:00', '23:00'
];

const DAYS_ORDER = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];

function getSlotTimeString(slot: any): string {
  if (typeof slot === 'string') return slot;
  if (slot && typeof slot === 'object') {
    if (typeof slot.start === 'string') return slot.start;
    if (typeof slot.startTime === 'string') return slot.startTime;
    if (typeof slot.slot === 'string') return slot.slot;
  }
  return String(slot || '');
}

function getTimezoneOffsetMinutes(timezoneStr: string): number {
  const clean = String(timezoneStr || '').toLowerCase();
  if (clean.includes('eat') || clean.includes('addis') || clean.includes('africa')) {
    return -180; // UTC+3
  }
  if (clean.includes('gmt') || clean.includes('london')) {
    return 0; // UTC+0
  }
  if (clean.includes('europe') || clean.includes('paris') || clean.includes('berlin')) {
    return -60; // UTC+1
  }
  if (clean.includes('pst') || clean.includes('los angeles') || clean.includes('seattle')) {
    return 480; // UTC-8
  }
  if (clean.includes('cst') || clean.includes('chicago')) {
    return 360; // UTC-6
  }
  if (clean.includes('est') || clean.includes('new york') || clean.includes('washington') || clean.includes('dc')) {
    return 300; // UTC-5
  }
  return new Date().getTimezoneOffset();
}

function localSlotToUTC(dayName: string, slotTime: any, timezoneStr: string = 'EAT (Addis Ababa)'): { day: string; slot: string } {
  const dayIndex = DAYS_ORDER.indexOf(dayName.toLowerCase());
  const str = getSlotTimeString(slotTime);
  if (dayIndex === -1 || !str.includes(':')) return { day: dayName, slot: str || '09:00' };

  const [h, m] = str.split(':').map(Number);
  const totalMinutesLocal = dayIndex * 24 * 60 + h * 60 + m;
  
  const offset = getTimezoneOffsetMinutes(timezoneStr); // in minutes (UTC - local)
  
  let totalMinutesUTC = totalMinutesLocal + offset;
  totalMinutesUTC = (totalMinutesUTC + 10080) % 10080;
  
  const utcDayIndex = Math.floor(totalMinutesUTC / (24 * 60));
  const remainingMinutes = totalMinutesUTC % (24 * 60);
  
  const utcH = String(Math.floor(remainingMinutes / 60)).padStart(2, '0');
  const utcM = String(remainingMinutes % 60).padStart(2, '0');
  
  return { day: DAYS_ORDER[utcDayIndex], slot: `${utcH}:${utcM}` };
}

function utcSlotToLocal(dayName: string, slotTime: any, timezoneStr: string = 'EAT (Addis Ababa)'): { day: string; slot: string } {
  const dayIndex = DAYS_ORDER.indexOf(dayName.toLowerCase());
  const str = getSlotTimeString(slotTime);
  if (dayIndex === -1 || !str.includes(':')) return { day: dayName, slot: str || '09:00' };

  const [h, m] = str.split(':').map(Number);
  const totalMinutesUTC = dayIndex * 24 * 60 + h * 60 + m;
  
  const offset = getTimezoneOffsetMinutes(timezoneStr); // in minutes (UTC - local)
  
  let totalMinutesLocal = totalMinutesUTC - offset;
  totalMinutesLocal = (totalMinutesLocal + 10080) % 10080;
  
  const localDayIndex = Math.floor(totalMinutesLocal / (24 * 60));
  const remainingMinutes = totalMinutesLocal % (24 * 60);
  
  const localH = String(Math.floor(remainingMinutes / 60)).padStart(2, '0');
  const localM = String(remainingMinutes % 60).padStart(2, '0');
  
  return { day: DAYS_ORDER[localDayIndex], slot: `${localH}:${localM}` };
}

function convertLocalAvailabilityToUTC(localAvail: any, timezoneStr: string = 'EAT (Addis Ababa)'): any {
  if (!localAvail) return null;
  const cloned: any = {};
  Object.entries(localAvail).forEach(([day, dayData]: [string, any]) => {
    const slots = Array.isArray(dayData?.slots) ? [...dayData.slots].sort() : [];
    cloned[day] = {
      active: slots.length > 0,
      slots
    };
  });
  return cloned;
}

function convertUTCAvailabilityToLocal(utcAvail: any, timezoneStr: string = 'EAT (Addis Ababa)'): any {
  if (!utcAvail) return null;
  const cloned: any = {};
  Object.entries(utcAvail).forEach(([day, dayData]: [string, any]) => {
    const slots = Array.isArray(dayData?.slots) ? [...dayData.slots].sort() : [];
    cloned[day] = {
      active: slots.length > 0,
      slots
    };
  });
  return cloned;
}

export default function TutorSettings() {
  const { user, reloadUser } = useAuth() as any;
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);

  // Profile Form State
  const [profileForm, setProfileForm] = useState({
    displayName: '',
    phone: '',
    expertise: '',
    classroomLink: ''
  });

  // Email update and sync state for misspelled emails
  const [profileEmail, setProfileEmail] = useState("");
  const [isEditingEmail, setIsEditingEmail] = useState(false);
  const [updatingEmailState, setUpdatingEmailState] = useState(false);
  const [emailUpdateStatus, setEmailUpdateStatus] = useState<"idle" | "success" | "error" | "requires-login">("idle");
  const [emailErrorMessage, setEmailErrorMessage] = useState("");

  // Availability State
  const [availability, setAvailability] = useState<any>({
    monday: { active: true, slots: ['09:00', '10:00', '11:00'] },
    tuesday: { active: true, slots: ['09:00', '10:00', '11:00'] },
    wednesday: { active: true, slots: ['09:00', '10:00', '11:00'] },
    thursday: { active: true, slots: ['09:00', '10:00', '11:00'] },
    friday: { active: true, slots: ['09:00', '10:00', '11:00'] },
    saturday: { active: false, slots: [] },
    sunday: { active: false, slots: [] },
  });

  useEffect(() => {
    if (user) {
      setProfileForm({
        displayName: user.displayName || user.fullName || '',
        phone: user.phone || '',
        expertise: user.expertise || user.specializedSyllabus || 'Amharic Instruction',
        classroomLink: user.classroomLink || ''
      });
      setProfileEmail(user.email || '');
      if (user.availability) {
        setAvailability(convertUTCAvailabilityToLocal(user.availability, user.timezone || 'EAT (Addis Ababa)'));
      } else {
        // Fallback: fetch directly from tutors collection based on user's email or tutorId
        const loadTutorAvailabilityFallback = async () => {
          try {
            const { getDoc, doc, collection, query, where, getDocs } = await import('firebase/firestore');
            const { db } = await import('../../lib/firebase');
            
            let tutorData: any = null;
            if (user.tutorId) {
              const tSnap = await getDoc(doc(db, 'tutors', user.tutorId));
              if (tSnap.exists()) {
                tutorData = tSnap.data();
              }
            }
            if (!tutorData && user.email) {
              const q = query(collection(db, 'tutors'), where('email', '==', user.email.trim().toLowerCase()));
              const qSnap = await getDocs(q);
              if (!qSnap.empty) {
                tutorData = qSnap.docs[0].data();
              }
            }
            
            if (tutorData) {
              if (tutorData.availability) {
                setAvailability(convertUTCAvailabilityToLocal(tutorData.availability, user.timezone || tutorData.timezone || 'EAT (Addis Ababa)'));
              }
              setProfileForm(prev => ({
                ...prev,
                phone: prev.phone || tutorData.phone || '',
                expertise: prev.expertise || tutorData.specializedSyllabus || tutorData.expertise || 'Amharic Instruction',
                classroomLink: prev.classroomLink || tutorData.classroomLink || ''
              }));
            }
          } catch (err) {
            console.warn("Fallback tutor availability load failed:", err);
          }
        };
        loadTutorAvailabilityFallback();
      }
    }
  }, [user]);

  const handleSyncEmail = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!auth.currentUser) {
      setEmailErrorMessage("No authenticated user found.");
      setEmailUpdateStatus("error");
      return;
    }
    const cleanEmail = profileEmail.trim().toLowerCase();
    if (!cleanEmail || !cleanEmail.includes("@")) {
      setEmailErrorMessage("Please enter a valid email address.");
      setEmailUpdateStatus("error");
      return;
    }

    setUpdatingEmailState(true);
    setEmailUpdateStatus("idle");
    setEmailErrorMessage("");

    try {
      // 1. Update Email in Firebase Auth
      await updateEmail(auth.currentUser, cleanEmail);

      // 2. Update Email in Firestore users collection
      const userRef = doc(db, "users", auth.currentUser.uid);
      await updateDoc(userRef, {
        email: cleanEmail
      });

      // 3. Update Email in Firestore tutors collection (tutorId or match by current user email)
      let targetTutorId = user.tutorId;
      if (targetTutorId) {
        const tutorRef = doc(db, 'tutors', targetTutorId);
        await updateDoc(tutorRef, {
          email: cleanEmail
        });
      } else if (user.email) {
        const q = query(collection(db, 'tutors'), where('email', '==', user.email.trim().toLowerCase()));
        const qSnap = await getDocs(q);
        if (!qSnap.empty) {
          for (const docSnap of qSnap.docs) {
            await updateDoc(doc(db, 'tutors', docSnap.id), {
              email: cleanEmail
            });
          }
        }
      }

      // Reload auth context so headers and states sync
      if (reloadUser) {
        await reloadUser();
      }

      setEmailUpdateStatus("success");
      setIsEditingEmail(false); // Make it read-only again after successful update
      setTimeout(() => setEmailUpdateStatus("idle"), 5000);
    } catch (err: any) {
      console.error("Error updating email:", err);
      if (err?.code === "auth/requires-recent-login" || String(err).includes("requires-recent-login")) {
        setEmailUpdateStatus("requires-login");
        setEmailErrorMessage("Security requires recent login. Please log out and log back in, then try again.");
      } else {
        setEmailUpdateStatus("error");
        setEmailErrorMessage(err?.message || "Could not update email. Please try again.");
      }
    } finally {
      setUpdatingEmailState(false);
    }
  };

  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    setIsSubmitting(true);

    try {
      // 1. Update Profile Fields
      await updateTutorProfile(user.uid, {
        displayName: profileForm.displayName,
        fullName: profileForm.displayName,
        phone: profileForm.phone,
        expertise: profileForm.expertise,
        specializedSyllabus: profileForm.expertise,
        classroomLink: profileForm.classroomLink
      }, user.tutorId);

      // 2. Update Availability
      const utcAvail = convertLocalAvailabilityToUTC(availability, user.timezone || 'EAT (Addis Ababa)');
      await updateTutorAvailability(user.uid, utcAvail, user.tutorId);

      // Reload auth context so header syncs
      if (reloadUser) {
        await reloadUser();
      }

      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 3000);
    } catch (err) {
      console.error(err);
      alert('Error saving setup parameters.');
    }
    setIsSubmitting(false);
  };

  return (
    <div className="space-y-8 max-w-4xl mx-auto">
      <header className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 bg-primary/5 text-primary rounded-2xl flex items-center justify-center">
            <Settings size={28} />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-slate-950 tracking-tight font-sans">Tutor Profile & Setup</h1>
            <p className="text-slate-400 text-sm mt-1">Manage physical contact metrics, specialized syllabus tags, and weekly availabilities.</p>
          </div>
        </div>
      </header>

      <form onSubmit={handleSaveSettings} className="space-y-8">
        {saveSuccess && (
          <div className="bg-emerald-50 border border-emerald-250 p-4 rounded-xl flex items-center gap-3 text-emerald-800 animate-in slide-in-from-top-4 duration-300">
            <CheckCircle2 size={20} className="text-emerald-600 shrink-0" />
            <div className="text-xs font-semibold">
              <strong>Success:</strong> Your profile metrics and weekly availability lists have been synchronized.
            </div>
          </div>
        )}

        {/* 1. Profile Information */}
        <div className="bg-white rounded-3xl p-6 md:p-8 border border-slate-150 shadow-sm space-y-6">
          <h2 className="text-lg font-bold text-slate-900 border-b border-slate-100 pb-3 flex items-center gap-2">
            <UserIcon size={18} className="text-slate-400" />
            <span>Personal Information</span>
          </h2>
          
          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Display Full Name</label>
              <div className="relative">
                <UserIcon className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
                <input
                  required
                  type="text"
                  value={profileForm.displayName}
                  onChange={(e) => setProfileForm({ ...profileForm, displayName: e.target.value })}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-12 pr-4 py-3 text-sm focus:ring-2 focus:ring-primary/10 transition-all outline-none font-medium text-slate-850"
                  placeholder="e.g. Mizan Amanuel"
                />
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Login Email (Read-only)</label>
              <div className="relative">
                <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
                <input
                  disabled
                  type="email"
                  value={user?.email || ''}
                  className="w-full bg-slate-100 border border-slate-200 rounded-xl pl-12 pr-4 py-3 text-sm outline-none text-slate-400 cursor-not-allowed font-medium"
                />
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Specialized Syllabus / Expertise</label>
              <div className="relative">
                <BookOpen className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
                <input
                  required
                  type="text"
                  value={profileForm.expertise}
                  onChange={(e) => setProfileForm({ ...profileForm, expertise: e.target.value })}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-12 pr-4 py-3 text-sm focus:ring-2 focus:ring-primary/10 transition-all outline-none text-slate-800"
                  placeholder="e.g. Ge'ez Literacy & Beginner Conversational Amharic"
                />
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Personal Phone Number</label>
              <div className="relative">
                <Phone className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
                <input
                  type="text"
                  value={profileForm.phone}
                  onChange={(e) => setProfileForm({ ...profileForm, phone: e.target.value })}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-12 pr-4 py-3 text-sm focus:ring-2 focus:ring-primary/10 transition-all outline-none text-slate-800 font-medium"
                  placeholder="e.g. +251 912 345 678"
                />
              </div>
            </div>

            <div className="space-y-2 md:col-span-2">
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">
                Google Meet / Zoom Classroom Link
              </label>
              <div className="relative">
                <Video className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
                <input
                  type="url"
                  value={profileForm.classroomLink}
                  onChange={(e) => setProfileForm({ ...profileForm, classroomLink: e.target.value })}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-12 pr-4 py-3 text-sm focus:ring-2 focus:ring-primary/10 transition-all outline-none text-slate-850 font-medium font-sans"
                  placeholder="e.g. https://meet.google.com/abc-defg-hij"
                />
              </div>
              <p className="text-[10px] text-slate-400 font-medium leading-relaxed">
                Provide your permanent Google Meet or Zoom space link here. This link will dynamically bind to the "Enter Class" buttons on the student and parent dashboards whenever they have an upcoming lesson with you.
              </p>
            </div>
          </div>
        </div>

        {/* 2. Availability Setup Checkbox Matrix Grid */}
        <div id="weekly-availability-grid-container" className="bg-white rounded-3xl p-6 md:p-8 border border-slate-150 shadow-sm space-y-6">
          <div className="border-b border-slate-100 pb-4">
            <h2 className="text-lg font-bold text-slate-900">Weekly Availability Checkbox Grid</h2>
            <p className="text-slate-500 text-xs mt-1">Check individual grid boxes corresponding to hours you are open for class bookings. This matrix is lightweight, highly visual, and optimized for Chromebook systems.</p>
          </div>

          {/* Special Matchmaking Optimization Helper for families abroad */}
          <div className="p-4 bg-amber-50/50 border border-amber-200/70 rounded-2xl space-y-2">
            <h4 className="text-xs font-black text-amber-900 uppercase tracking-wide flex items-center gap-1.5">
              <span>✨</span>
              <span>Onboarding Optimizer: Peak Demand Hours Abroad</span>
            </h4>
            <p className="text-[11px] text-amber-800 leading-relaxed font-sans">
              Students abroad (located in the US, Europe, and Canada) book lessons primarily when they are out-of-school and during their weekends. In your local East African Time (EAT), this translates to these high demand peak slots, highlighted in <strong>gold</strong> below:
            </p>
            <div className="flex flex-wrap gap-4 text-[10px] text-amber-700 font-sans font-semibold pt-1">
              <span className="flex items-center gap-1.5">
                <span className="w-3 h-3 rounded-md bg-amber-100 border border-amber-300 block"></span>
                <span>Weekdays (Mon-Fri): 10:00 PM – 5:00 AM (EAT)</span>
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-3 h-3 rounded-md bg-amber-105 border border-amber-300 block"></span>
                <span>Weekends (Sat-Sun): 4:00 PM – 3:00 AM (EAT)</span>
              </span>
            </div>
          </div>

          {/* Time Zone Indicator */}
          <div className="bg-slate-50 border border-slate-150 p-3.5 rounded-2xl flex items-center justify-between text-[11px] text-slate-500 font-medium">
            <div className="flex items-center gap-2">
              <span className="text-sm">🌐</span>
              <span>Your schedule is running in: <strong className="text-slate-800 font-bold">{Intl.DateTimeFormat().resolvedOptions().timeZone}</strong></span>
            </div>
            <span className="text-[10px] text-indigo-600 bg-indigo-50 font-bold px-2 py-0.5 rounded-md uppercase tracking-wide">Local Detector</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse min-w-[600px]">
              <thead>
                <tr className="border-b border-slate-100 bg-slate-50/50">
                  <th className="py-3 px-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest w-[160px]">Time Block</th>
                  {DAYS.map(day => (
                    <th key={day} className="py-3 px-2 text-center text-[10px] font-bold text-slate-400 uppercase tracking-widest capitalize">
                      {day.substring(0, 3)}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100/50">
                {HOURS.map(hour => {
                  const hourNumber = parseInt(hour.split(':')[0], 10);
                  const formattedTime = hourNumber >= 12 
                    ? `${hourNumber === 12 ? 12 : hourNumber - 12}:00 PM` 
                    : `${hourNumber}:00 AM`;
                  return (
                    <tr key={hour} className="hover:bg-slate-50/40 transition-colors">
                      <td className="py-3 px-4 text-xs font-extrabold text-slate-700 font-mono">
                        {formattedTime}
                      </td>
                      {DAYS.map(day => {
                        const dayObj = availability[day] || { active: false, slots: [] };
                        const slots = dayObj.slots || [];
                        const isChecked = slots.includes(hour) && (dayObj.active !== false);

                        // Determine if this specific block is a peak time for families abroad
                        const isWeekend = day === 'saturday' || day === 'sunday';
                        const isPeak = isWeekend ? (hourNumber >= 16 || hourNumber <= 2) : (hourNumber >= 22 || hourNumber <= 5);

                        return (
                          <td 
                            key={day} 
                            className={cn(
                              "py-2.5 px-2 text-center transition-colors",
                              isPeak ? "bg-amber-50/15" : ""
                            )}
                          >
                            <input 
                              type="checkbox"
                              checked={isChecked}
                              onChange={(e) => {
                                let newSlots = [...slots];
                                if (e.target.checked) {
                                  if (!newSlots.includes(hour)) {
                                    newSlots.push(hour);
                                  }
                                  newSlots.sort();
                                } else {
                                  newSlots = newSlots.filter(s => s !== hour);
                                }
                                setAvailability({
                                  ...availability,
                                  [day]: {
                                    active: newSlots.length > 0,
                                    slots: newSlots
                                  }
                                });
                              }}
                              className={cn(
                                "w-5 h-5 rounded border-slate-300 focus:ring-indigo-500 cursor-pointer shadow-sm transition-all hover:scale-105",
                                isPeak && !isChecked ? "accent-amber-500 border-amber-300 ring-amber-200" : "text-indigo-600"
                              )}
                            />
                          </td>
                        );
                      })}
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
          <div className="p-4 bg-slate-50 border border-slate-100 rounded-xl text-[10px] text-slate-400 leading-normal font-medium flex items-center gap-2">
            <span>💡</span>
            <span>Checking boxes saves 50-minute teaching intervals. Unchecked time blocks are hidden from families during permanent slot scheduling.</span>
          </div>
        </div>

        {/* Save Submission */}
        <div className="flex items-center justify-end gap-4 border-t border-slate-100 pt-6">
          <button
            type="submit"
            disabled={isSubmitting}
            className="btn-primary flex items-center justify-center gap-2 px-10 py-4 rounded-xl shadow-lg shadow-indigo-600/10 hover:scale-[1.01] transition-all cursor-pointer font-bold text-sm"
          >
            {isSubmitting ? (
              <>
                <Loader2 className="animate-spin" size={18} />
                <span>Synchronizing Profile...</span>
              </>
            ) : (
              <>
                <Send size={16} />
                <span>Save Setup Parameters</span>
              </>
            )}
          </button>
        </div>
      </form>
    </div>
  );
}

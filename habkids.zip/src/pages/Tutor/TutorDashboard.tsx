import React, { useEffect, useState, useRef } from 'react';
import { 
  Calendar, 
  Users, 
  BookOpen, 
  Clock, 
  CheckCircle2, 
  MoreHorizontal,
  Plus,
  Loader2,
  X,
  Star,
  Send,
  Sparkles,
  ExternalLink,
  ChevronRight,
  MessageSquare,
  AlertCircle,
  Copy,
  Mail,
  Check,
  Share2
} from 'lucide-react';
import { useLocation } from 'react-router-dom';
import { cn } from '../../lib/utils';
import LessonViewer from '../../components/LessonViewer';
import { useAuth } from '../../context/AuthContext';
import { 
  subscribeToSessions, 
  subscribeToStudentProgress, 
  completeTrialSession, 
  updateTutorAvailability,
  markSessionMissed,
  sendMessage,
  subscribeToTutorChats,
  subscribeToTutorChatMessages,
  sendTutorChatMessage,
  subscribeToPendingLeadsForTutor,
  updateLeadData,
  getDeterministicGoogleMeetUrl,
  getTutorSlug
} from '../../services/dataService';
import { doc, getDoc } from 'firebase/firestore';
import { db } from '../../lib/firebase';

const DAYS_ORDER = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];

function getSlotTimeString(slot: any): string {
  if (typeof slot === 'string') return slot;
  if (slot && typeof slot === 'object') {
    if (typeof slot.start === 'string') return slot.start;
    if (typeof slot.startTime === 'string') return slot.startTime;
    if (typeof slot.slot === 'string') return slot.slot;
  }
  return String(slot || '');
}

function getTimezoneOffsetMinutes(timezoneStr: string): number {
  const clean = String(timezoneStr || '').toLowerCase();
  if (clean.includes('eat') || clean.includes('addis') || clean.includes('africa')) {
    return -180; // UTC+3
  }
  if (clean.includes('gmt') || clean.includes('london')) {
    return 0; // UTC+0
  }
  if (clean.includes('europe') || clean.includes('paris') || clean.includes('berlin')) {
    return -60; // UTC+1
  }
  if (clean.includes('pst') || clean.includes('los angeles') || clean.includes('seattle')) {
    return 480; // UTC-8
  }
  if (clean.includes('cst') || clean.includes('chicago')) {
    return 360; // UTC-6
  }
  if (clean.includes('est') || clean.includes('new york') || clean.includes('washington') || clean.includes('dc')) {
    return 300; // UTC-5
  }
  return new Date().getTimezoneOffset();
}

function localSlotToUTC(dayName: string, slotTime: any, timezoneStr: string = 'EAT (Addis Ababa)'): { day: string; slot: string } {
  const dayIndex = DAYS_ORDER.indexOf(dayName.toLowerCase());
  const str = getSlotTimeString(slotTime);
  if (dayIndex === -1 || !str.includes(':')) return { day: dayName, slot: str || '09:00' };

  const [h, m] = str.split(':').map(Number);
  const totalMinutesLocal = dayIndex * 24 * 60 + h * 60 + m;
  
  const offset = getTimezoneOffsetMinutes(timezoneStr); // in minutes (UTC - local)
  
  let totalMinutesUTC = totalMinutesLocal + offset;
  totalMinutesUTC = (totalMinutesUTC + 10080) % 10080;
  
  const utcDayIndex = Math.floor(totalMinutesUTC / (24 * 60));
  const remainingMinutes = totalMinutesUTC % (24 * 60);
  
  const utcH = String(Math.floor(remainingMinutes / 60)).padStart(2, '0');
  const utcM = String(remainingMinutes % 60).padStart(2, '0');
  
  return { day: DAYS_ORDER[utcDayIndex], slot: `${utcH}:${utcM}` };
}

function utcSlotToLocal(dayName: string, slotTime: any, timezoneStr: string = 'EAT (Addis Ababa)'): { day: string; slot: string } {
  const dayIndex = DAYS_ORDER.indexOf(dayName.toLowerCase());
  const str = getSlotTimeString(slotTime);
  if (dayIndex === -1 || !str.includes(':')) return { day: dayName, slot: str || '09:00' };

  const [h, m] = str.split(':').map(Number);
  const totalMinutesUTC = dayIndex * 24 * 60 + h * 60 + m;
  
  const offset = getTimezoneOffsetMinutes(timezoneStr); // in minutes (UTC - local)
  
  let totalMinutesLocal = totalMinutesUTC - offset;
  totalMinutesLocal = (totalMinutesLocal + 10080) % 10080;
  
  const localDayIndex = Math.floor(totalMinutesLocal / (24 * 60));
  const remainingMinutes = totalMinutesLocal % (24 * 60);
  
  const localH = String(Math.floor(remainingMinutes / 60)).padStart(2, '0');
  const localM = String(remainingMinutes % 60).padStart(2, '0');
  
  return { day: DAYS_ORDER[localDayIndex], slot: `${localH}:${localM}` };
}

function convertLocalAvailabilityToUTC(localAvail: any, timezoneStr: string = 'EAT (Addis Ababa)'): any {
  if (!localAvail) return null;
  const cloned: any = {};
  Object.entries(localAvail).forEach(([day, dayData]: [string, any]) => {
    const slots = Array.isArray(dayData?.slots) ? [...dayData.slots].sort() : [];
    cloned[day] = {
      active: slots.length > 0,
      slots
    };
  });
  return cloned;
}

function convertUTCAvailabilityToLocal(utcAvail: any, timezoneStr: string = 'EAT (Addis Ababa)'): any {
  if (!utcAvail) return null;
  const cloned: any = {};
  Object.entries(utcAvail).forEach(([day, dayData]: [string, any]) => {
    const slots = Array.isArray(dayData?.slots) ? [...dayData.slots].sort() : [];
    cloned[day] = {
      active: slots.length > 0,
      slots
    };
  });
  return cloned;
}

/**
 * Robust helper to format Firestore timestamps, JS Dates, or schedule objects {start, end}
 */
const formatDateTime = (val: any, options: Intl.DateTimeFormatOptions = { hour: '2-digit', minute: '2-digit' }): string => {
  if (!val) return '00:00';
  
  let date: Date;
  
  // 1. Handle Firestore Timestamp
  if (val && typeof val.toDate === 'function') {
    date = val.toDate();
  } 
  // 2. Handle { start, end } object
  else if (val && typeof val === 'object' && ('start' in val || 'startTime' in val)) {
    const startVal = val.start || val.startTime;
    if (startVal && typeof startVal.toDate === 'function') {
      date = startVal.toDate();
    } else if (typeof startVal === 'string' || typeof startVal === 'number') {
      const parsed = new Date(startVal);
      date = isNaN(parsed.getTime()) ? new Date() : parsed;
    } else if (startVal instanceof Date) {
      date = startVal;
    } else {
      return typeof startVal === 'string' ? startVal : JSON.stringify(startVal);
    }
  }
  // 3. Handle Date object
  else if (val instanceof Date) {
    date = val;
  }
  // 4. Handle string/number
  else if (typeof val === 'string' || typeof val === 'number') {
    const parsed = new Date(val);
    if (!isNaN(parsed.getTime())) {
      date = parsed;
    } else {
      return String(val);
    }
  }
  // 5. Fallback
  else if (typeof val === 'object') {
    return val.start || val.time || JSON.stringify(val);
  }
  else {
    return String(val);
  }

  return date.toLocaleTimeString([], options);
};

/**
 * Specifically for rendering slot times which might be objects or strings
 */
const renderSlotTime = (time: any) => {
  if (typeof time === 'string') return time;
  if (time && typeof time === 'object') {
    if (time.start && typeof time.start === 'string') return time.start;
    if (time.startTime && typeof time.startTime === 'string') return time.startTime;
    return formatDateTime(time.start || time.startTime || time, { hour: '2-digit', minute: '2-digit' });
  }
  return String(time || '');
};

export default function TutorDashboard() {
  const { user } = useAuth();
  const location = useLocation();
  const [sessions, setSessions] = useState<any[]>([]);
  const [students, setStudents] = useState<any[]>([]);
  const [pendingLeads, setPendingLeads] = useState<any[]>([]);
  const [isUpdatingOptionId, setIsUpdatingOptionId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  // 3-Dots Dropdown menu
  const [openMenuSessionId, setOpenMenuSessionId] = useState<string | null>(null);

  // Student Bio Modal state
  const [activeBioStudent, setActiveBioStudent] = useState<any>(null);
  const [isFetchingBio, setIsFetchingBio] = useState(false);
  const [bioModalOpen, setBioModalOpen] = useState(false);

  // Reschedule Form State
  const [reschedulingSession, setReschedulingSession] = useState<any>(null);
  const [rescheduleReason, setRescheduleReason] = useState('');
  const [rescheduleModalOpen, setRescheduleModalOpen] = useState(false);
  const [rescheduleSuccess, setRescheduleSuccess] = useState(false);

  // Global Library State
  const [libraryModalOpen, setLibraryModalOpen] = useState(false);

  // Invitation Form State
  const [inviteParentName, setInviteParentName] = useState('');
  const [inviteParentEmail, setInviteParentEmail] = useState('');
  const [inviteMessage, setInviteMessage] = useState('');
  const [inviteSending, setInviteSending] = useState(false);
  const [inviteSuccess, setInviteSuccess] = useState(false);
  const [inviteError, setInviteError] = useState('');
  const [copiedLinkType, setCopiedLinkType] = useState<'profile' | 'booking' | null>(null);

  // Missed Session State
  const [missingSession, setMissingSession] = useState<any>(null);
  const [missedReason, setMissedReason] = useState('Student no-show');
  const [deductMissedCredit, setDeductMissedCredit] = useState(true);

  const handleCopyLink = (type: 'profile' | 'booking') => {
    const tutorId = user?.tutorId || user?.uid || '';
    const slug = getTutorSlug(user);
    const identifier = slug || tutorId;
    const url = type === 'profile' 
      ? `${window.location.origin}/tutors/${identifier}`
      : `${window.location.origin}/book-trial?tutor=${identifier}`;

    navigator.clipboard.writeText(url).then(() => {
      setCopiedLinkType(type);
      setTimeout(() => setCopiedLinkType(null), 3000);
    }).catch(err => {
      console.error("Failed to copy link:", err);
    });
  };

  const handleSendInvite = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inviteParentEmail.trim() || !inviteParentName.trim()) {
      setInviteError("Please fill in both parent's name and email.");
      return;
    }
    setInviteSending(true);
    setInviteError('');
    setInviteSuccess(false);

    const tutorName = user?.displayName || user?.fullName || (user as any)?.name || 'Your Tutor';
    const tutorId = user?.tutorId || user?.uid || '';
    const slug = getTutorSlug(user);
    const identifier = slug || tutorId;
    const bookingUrl = `${window.location.origin}/book-trial?tutor=${identifier}`;
    const profileUrl = `${window.location.origin}/tutors/${identifier}`;

    const defaultMsg = inviteMessage.trim() || `I would love to invite your child to learn Amharic/Ge'ez with me at HabKids! During our 25-minute evaluation trial session, we will assess your child's starting level and introduce them to basic Ge'ez fidel shapes through fun games!`;

    const emailSubject = `Invitation from tutor ${tutorName} to book a trial Amharic lesson!`;
    const emailBody = `Dear ${inviteParentName},\n\n` +
      `${defaultMsg}\n\n` +
      `You can book a 25-minute evaluation trial lesson with me directly using my personal booking link:\n` +
      `${bookingUrl}\n\n` +
      `Or you can learn more about my background, specializations, and availability on my profile page:\n` +
      `${profileUrl}\n\n` +
      `Looking forward to meeting you and your child in our virtual classroom!\n\n` +
      `Best regards,\n` +
      `${tutorName}\n` +
      `HabKids tutor Team`;

    try {
      const response = await fetch('/api/notify/email', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          to: inviteParentEmail.trim().toLowerCase(),
          subject: emailSubject,
          body: emailBody,
          role: 'tutor'
        })
      });

      if (!response.ok) {
        throw new Error('Failed to send invitation email.');
      }

      setInviteSuccess(true);
      setInviteParentName('');
      setInviteParentEmail('');
      setInviteMessage('');
    } catch (err: any) {
      console.error("Error sending invite:", err);
      setInviteError(err.message || 'Error occurred while sending invitation email. Please check your SMTP settings.');
    } finally {
      setInviteSending(false);
    }
  };

  // Synchronize URL query parameter 'library' and 'messages' with state
  useEffect(() => {
    if (location.search.includes("library=true")) {
      setLibraryModalOpen(true);
    } else {
      setLibraryModalOpen(false);
    }

    if (location.search.includes("messages=true")) {
      setActiveTab('messages');
    }
  }, [location.search]);

  const handleViewStudentBio = async (session: any) => {
    setBioModalOpen(true);
    setIsFetchingBio(true);
    setActiveBioStudent(null);
    try {
      if (session.studentId) {
        const docRef = doc(db, 'students', session.studentId);
        const docSnap = await getDoc(docRef);
        if (docSnap.exists()) {
          const sData = docSnap.data();
          setActiveBioStudent({
            id: docSnap.id,
            ...sData,
            studentAge: sData.studentAge || session.studentAge || 'N/A',
            learningGoal: sData.learningGoal || session.learningGoal || 'No goals specified'
          });
          setIsFetchingBio(false);
          return;
        }
      }
      
      // Fallback or trial mode info if student document not indexed yet
      setActiveBioStudent({
        id: session.studentId || 'trial-id',
        name: session.studentName || 'Student',
        studentAge: session.studentAge || 'N/A',
        progress: 0,
        isTrial: true,
        plan: 'Trial Class',
        learningGoal: session.learningGoal || 'No goals specified',
        schedulePattern: 'Trial Period'
      });
    } catch (err) {
      console.error("Error fetching student bio:", err);
      setActiveBioStudent({
        id: session.studentId || 'fallback-id',
        name: session.studentName || 'Student',
        studentAge: session.studentAge || 'N/A',
        progress: 0,
        isTrial: true,
        learningGoal: session.learningGoal || 'No goals specified',
        schedulePattern: 'Pre-schedule'
      });
    }
    setIsFetchingBio(false);
  };

  const handleRescheduleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!reschedulingSession || !user) return;
    setIsSubmitting(true);
    
    try {
      const timeFormatted = formatDateTime(reschedulingSession.startTime, {
        weekday: 'long', 
        month: 'short', 
        day: 'numeric', 
        hour: '2-digit', 
        minute: '2-digit'
      });

      const messageText = `[Reschedule Request] Request to reschedule class for student "${reschedulingSession.studentName}" originally scheduled at ${timeFormatted}. Reason: ${rescheduleReason}`;

      const result = await sendMessage({
        senderId: user.uid,
        senderName: user.displayName || user.email || 'Tutor',
        senderRole: 'tutor',
        recipientId: 'admin',
        text: messageText
      });

      if (result.success) {
        setRescheduleSuccess(true);
        setTimeout(() => {
          setRescheduleSuccess(false);
          setRescheduleModalOpen(false);
          setReschedulingSession(null);
          setRescheduleReason('');
        }, 2200);
      } else {
        alert("Failed to deliver your request to scheduling operators.");
      }
    } catch (err) {
      console.error(err);
      alert("An error occurred while submitting reschedule request.");
    }
    setIsSubmitting(false);
  };
  const [activeTab, setActiveTab] = useState<'agenda' | 'availability' | 'messages'>('agenda');
  const [agendaTab, setAgendaTab] = useState<'today' | 'upcoming' | 'past'>('today');
  const [searchQuery, setSearchQuery] = useState('');

  // --- Tutor Messages & Chats ---
  const [tutorChatsList, setTutorChatsList] = useState<any[]>([]);
  const [activeChatId, setActiveChatId] = useState<string | null>(null);
  const [chatMessages, setChatMessages] = useState<any[]>([]);
  const [chatInput, setChatInput] = useState('');
  const [sendingMessage, setSendingMessage] = useState(false);
  const [chatViolationWarning, setChatViolationWarning] = useState<string | null>(null);
  const tutorMsgEndRef = useRef<HTMLDivElement>(null);

  // Completion Modal State
  const [completingSession, setCompletingSession] = useState<any>(null);
  const [evaluation, setEvaluation] = useState('');
  const [level, setLevel] = useState('1');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Availability State
  const [availability, setAvailability] = useState<any>({
    monday: { active: true, slots: ['09:00', '10:00', '11:00'] },
    tuesday: { active: true, slots: ['09:00', '10:00', '11:00'] },
    wednesday: { active: true, slots: ['09:00', '10:00', '11:00'] },
    thursday: { active: true, slots: ['09:00', '10:00', '11:00'] },
    friday: { active: true, slots: ['09:00', '10:00', '11:00'] },
    saturday: { active: false, slots: [] },
    sunday: { active: false, slots: [] },
  });

  const [saveSuccess, setSaveSuccess] = useState(false);

  const saveAvailability = async () => {
    if (!user) return;
    setIsSubmitting(true);
    const utcAvail = convertLocalAvailabilityToUTC(availability, (user as any).timezone || 'EAT (Addis Ababa)');
    const result = await updateTutorAvailability(user.uid, utcAvail, user.tutorId);
    setIsSubmitting(false);
    if (result.success) {
      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 3000);
    } else {
      alert('Failed to save availability. Please try again.');
    }
  };

  useEffect(() => {
    if (!user) return;
    
    // Load initial availability if exists
    if (user.availability) {
      setAvailability(convertUTCAvailabilityToLocal(user.availability, (user as any).timezone || 'EAT (Addis Ababa)'));
    } else {
      // Fallback: fetch directly from tutors collection based on user's email or tutorId
      const loadTutorAvailabilityFallback = async () => {
        try {
          const { getDoc, doc, collection, query, where, getDocs } = await import('firebase/firestore');
          const { db } = await import('../../lib/firebase');
          
          let tutorData: any = null;
          if (user.tutorId) {
            const tSnap = await getDoc(doc(db, 'tutors', user.tutorId));
            if (tSnap.exists()) {
              tutorData = tSnap.data();
            }
          }
          if (!tutorData && user.email) {
            const q = query(collection(db, 'tutors'), where('email', '==', user.email.trim().toLowerCase()));
            const qSnap = await getDocs(q);
            if (!qSnap.empty) {
              tutorData = qSnap.docs[0].data();
              if (tutorData.availability) {
                setAvailability(convertUTCAvailabilityToLocal(tutorData.availability, (user as any).timezone || tutorData.timezone || 'EAT (Addis Ababa)'));
              }
            }
          } else if (tutorData && tutorData.availability) {
            setAvailability(convertUTCAvailabilityToLocal(tutorData.availability, (user as any).timezone || tutorData.timezone || 'EAT (Addis Ababa)'));
          }
        } catch (err) {
          console.warn("Fallback tutor dashboard availability load failed:", err);
        }
      };
      loadTutorAvailabilityFallback();
    }

    let sessionsLoaded = false;
    let progressLoaded = false;

    const checkLoading = () => {
      if (sessionsLoaded && progressLoaded) {
        setLoading(false);
      }
    };

    const targetTutorId = user.tutorId || user.uid;

    const unsubscribeSessions = subscribeToSessions('tutor', targetTutorId, 
      (data) => {
        setSessions(data);
        sessionsLoaded = true;
        checkLoading();
      },
      () => {
        sessionsLoaded = true;
        checkLoading();
      }
    );

    const unsubscribeProgress = subscribeToStudentProgress(targetTutorId, 
      (data) => {
        setStudents(data);
        progressLoaded = true;
        checkLoading();
      },
      () => {
        progressLoaded = true;
        checkLoading();
      }
    );

    const unsubscribePendingLeads = subscribeToPendingLeadsForTutor(targetTutorId,
      (data) => {
        setPendingLeads(data);
      },
      () => {
        console.error("Error subscribing to pending leads in TutorDashboard");
      },
      user.email
    );

    return () => {
      unsubscribeSessions();
      unsubscribeProgress();
      unsubscribePendingLeads();
    };
  }, [user]);

  // --- Real-time Tutor Chat Subscriptions ---
  useEffect(() => {
    if (!user) return;
    const targetTutorId = user.tutorId || user.uid;
    const unsubscribe = subscribeToTutorChats('tutor', targetTutorId, (chats) => {
      setTutorChatsList(chats);
    });
    return () => unsubscribe();
  }, [user]);

  useEffect(() => {
    if (!activeChatId) {
      setChatMessages([]);
      return;
    }
    const unsubscribe = subscribeToTutorChatMessages(activeChatId, (messages) => {
      setChatMessages(messages);
    });
    return () => unsubscribe();
  }, [activeChatId]);

  useEffect(() => {
    setTimeout(() => {
      tutorMsgEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, 100);
  }, [chatMessages]);

  const handleCompleteSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!completingSession) return;

    setIsSubmitting(true);
    const result = await completeTrialSession(
      completingSession.id,
      completingSession.leadId,
      { 
        evaluation, 
        recommendedLevel: level, 
        completedAt: new Date() 
      },
      { 
        email: completingSession.parentEmail, 
        name: completingSession.parentName 
      }
    );

    if (result.success) {
      setCompletingSession(null);
      setEvaluation('');
      setLevel('1');
    }
    setIsSubmitting(false);
  };

  const handleMarkMissed = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!missingSession) return;

    setIsSubmitting(true);
    const result = await markSessionMissed(missingSession.id, missedReason, deductMissedCredit);

    if (result.success) {
      setMissingSession(null);
      setMissedReason('Student no-show');
      setDeductMissedCredit(true);
    }
    setIsSubmitting(false);
  };

  const handleTutorSelectOption = async (leadId: string, optionIndex: number, optionValue: string) => {
    setIsUpdatingOptionId(leadId + '_' + optionIndex);
    try {
      await updateLeadData(leadId, {
        tutorPreferredOptionIndex: optionIndex,
        tutorPreferredOptionValue: optionValue,
        tutorPreferredOptionLabel: optionIndex === 1 ? 'Option 1 (Gold)' : optionIndex === 2 ? 'Option 2 (Silver)' : 'Option 3 (Bronze)'
      });
    } catch (err) {
      console.error("Error setting tutor preferred option:", err);
    } finally {
      setIsUpdatingOptionId(null);
    }
  };

  const handleSendChatMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !activeChatId || !chatInput.trim()) return;

    const activeChatDoc = tutorChatsList.find(c => c.id === activeChatId);
    if (!activeChatDoc) return;

    setSendingMessage(true);
    setChatViolationWarning(null);

    const textToSend = chatInput.trim();
    setChatInput('');

    const targetTutorId = user.tutorId || user.uid;

    const res = await sendTutorChatMessage({
      chatId: activeChatId,
      parentId: activeChatDoc.parentId,
      tutorId: targetTutorId,
      senderId: user.uid,
      senderName: user.fullName || user.displayName || 'Tutor',
      senderRole: 'tutor',
      text: textToSend
    });

    setSendingMessage(false);

    if (res.success) {
      if (res.hasViolation) {
        setChatViolationWarning("Notice: Your message contained contact-sharing info, such as a phone number or email, which was redacted for safety.");
        setTimeout(() => setChatViolationWarning(null), 6000);
      }
    } else {
      alert("Failed to send message. Please try again.");
    }
  };

  if (loading) {
    return (
      <div className="h-[60vh] flex flex-col items-center justify-center text-slate-400 gap-3">
        <Loader2 className="animate-spin text-secondary" size={32} />
        <p className="text-sm font-medium">Preparing your classroom...</p>
      </div>
    );
  }

  return (
    <div className="space-y-8 relative">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <h1 className="text-3xl font-bold text-primary mb-1 tracking-tight">Tutor Dashboard</h1>
          <p className="text-slate-500 text-sm">Hello, Teacher. Manage your classes and availability here.</p>
        </div>
        <div className="flex bg-slate-100 p-1 rounded-xl w-fit">
          <button 
            onClick={() => setActiveTab('agenda')}
            className={cn(
              "px-4 py-2 rounded-lg text-xs font-bold transition-all",
              activeTab === 'agenda' ? "bg-white text-primary shadow-sm" : "text-slate-500 hover:text-primary"
            )}
          >
            Daily Agenda
          </button>
          <button 
            onClick={() => setActiveTab('availability')}
            className={cn(
              "px-4 py-2 rounded-lg text-xs font-bold transition-all",
              activeTab === 'availability' ? "bg-white text-primary shadow-sm" : "text-slate-500 hover:text-primary"
            )}
          >
            My Availability
          </button>
          <button 
            onClick={() => setActiveTab('messages')}
            className={cn(
              "px-4 py-2 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5",
              activeTab === 'messages' ? "bg-white text-primary shadow-sm" : "text-slate-500 hover:text-primary"
            )}
          >
            <MessageSquare size={13} />
            <span>Classroom Messages</span>
            {tutorChatsList.length > 0 && (
              <span className="w-2 h-2 bg-rose-500 rounded-full inline-block animate-pulse" />
            )}
          </button>
        </div>
      </header>

      {activeTab === 'agenda' && (
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Daily Agenda with Sub-Tabs */}
          <div className="lg:col-span-2 space-y-6">
            {/* Time Zone Indicator */}
            <div className="bg-slate-50 border border-slate-150 p-3.5 rounded-2xl flex items-center justify-between text-[11px] text-slate-500 font-medium">
              <div className="flex items-center gap-2">
                <span className="text-sm">🌐</span>
                <span>Your schedule is running in: <strong className="text-slate-800 font-bold">{Intl.DateTimeFormat().resolvedOptions().timeZone}</strong></span>
              </div>
              <span className="text-[10px] text-indigo-600 bg-indigo-50 font-bold px-2 py-0.5 rounded-md uppercase tracking-wide">Local Detector</span>
            </div>

            {/* Pending Trial Requests (Specially Chosen) */}
            {pendingLeads && pendingLeads.length > 0 && (
              <div className="bg-amber-50/50 border border-amber-200 p-6 rounded-2xl space-y-4 shadow-sm animate-in fade-in slide-in-from-top-4 duration-300">
                <div className="flex items-center justify-between border-b border-amber-150 pb-3">
                  <div className="flex items-center gap-2">
                    <span className="text-lg">⭐</span>
                    <div>
                      <h4 className="text-sm font-bold text-slate-900 tracking-tight flex items-center gap-2">
                        <span>New Trial Bookings Selected You!</span>
                        <span className="bg-amber-100 text-amber-800 text-[9px] font-extrabold px-1.5 py-0.5 rounded uppercase tracking-wide">
                          {pendingLeads.length} Pending
                        </span>
                      </h4>
                      <p className="text-[10px] text-slate-500 font-medium">Parents have hand-selected you. The administrative coordinator will finalize and lock the session time shortly.</p>
                    </div>
                  </div>
                  <span className="text-[10px] text-amber-700 bg-amber-100/50 font-bold px-2 py-0.5 rounded">Action Pending</span>
                </div>

                <div className="space-y-3">
                  {pendingLeads.map((lead) => (
                    <div key={lead.id} className="bg-white border border-slate-150 p-4 rounded-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
                      <div className="space-y-1">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="text-xs font-bold text-slate-900">{lead.parentName}'s child: {lead.childName || 'Student'}</span>
                          <span className="text-[9px] font-mono text-slate-400 bg-slate-100 px-1.5 py-0.5 rounded">Age {lead.childAge || 'N/A'}</span>
                          <span className="text-[9px] font-mono text-indigo-600 bg-indigo-50 px-1.5 py-0.5 rounded">{lead.timezone || 'EST'}</span>
                        </div>
                        {lead.learningGoal && (
                          <p className="text-[11px] text-slate-500 italic line-clamp-1 max-w-md">" {lead.learningGoal} "</p>
                        )}
                      </div>

                      <div className="flex flex-col gap-1 min-w-[280px] text-right md:text-right">
                        <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-0.5">Confirm Your Availability:</span>
                        <div className="text-[10px] text-slate-700 space-y-1.5 font-sans font-semibold">
                          <div className="flex items-center justify-between md:justify-end gap-2.5">
                            <span className="text-amber-600">Option 1:</span>
                            <span className="font-mono text-[11px] font-bold text-slate-800">{lead.preferredTime || 'N/A'}</span>
                            {lead.tutorPreferredOptionIndex === 1 ? (
                              <span className="bg-emerald-100 text-emerald-800 font-extrabold text-[8px] px-2 py-0.5 rounded uppercase tracking-wider">
                                My Preferred Slot ✅
                              </span>
                            ) : (
                              <button
                                type="button"
                                disabled={isUpdatingOptionId !== null}
                                onClick={() => handleTutorSelectOption(lead.id, 1, lead.preferredTime)}
                                className="bg-slate-100 text-slate-600 hover:bg-slate-900 hover:text-white font-bold text-[8px] px-2 py-0.5 rounded uppercase tracking-wider transition-all cursor-pointer"
                              >
                                {isUpdatingOptionId === lead.id + '_1' ? '...' : 'Select'}
                              </button>
                            )}
                          </div>
                          {lead.preferredTime2 && (
                            <div className="flex items-center justify-between md:justify-end gap-2.5">
                              <span className="text-slate-400">Option 2:</span>
                              <span className="font-mono text-[11px] font-bold text-slate-800">{lead.preferredTime2}</span>
                              {lead.tutorPreferredOptionIndex === 2 ? (
                                <span className="bg-emerald-100 text-emerald-800 font-extrabold text-[8px] px-2 py-0.5 rounded uppercase tracking-wider">
                                  My Preferred Slot ✅
                                </span>
                              ) : (
                                <button
                                  type="button"
                                  disabled={isUpdatingOptionId !== null}
                                  onClick={() => handleTutorSelectOption(lead.id, 2, lead.preferredTime2)}
                                  className="bg-slate-100 text-slate-600 hover:bg-slate-900 hover:text-white font-bold text-[8px] px-2 py-0.5 rounded uppercase tracking-wider transition-all cursor-pointer"
                                >
                                  {isUpdatingOptionId === lead.id + '_2' ? '...' : 'Select'}
                                </button>
                              )}
                            </div>
                          )}
                          {lead.preferredTime3 && (
                            <div className="flex items-center justify-between md:justify-end gap-2.5">
                              <span className="text-slate-400">Option 3:</span>
                              <span className="font-mono text-[11px] font-bold text-slate-800">{lead.preferredTime3}</span>
                              {lead.tutorPreferredOptionIndex === 3 ? (
                                <span className="bg-emerald-100 text-emerald-800 font-extrabold text-[8px] px-2 py-0.5 rounded uppercase tracking-wider">
                                  My Preferred Slot ✅
                                </span>
                              ) : (
                                <button
                                  type="button"
                                  disabled={isUpdatingOptionId !== null}
                                  onClick={() => handleTutorSelectOption(lead.id, 3, lead.preferredTime3)}
                                  className="bg-slate-100 text-slate-600 hover:bg-slate-900 hover:text-white font-bold text-[8px] px-2 py-0.5 rounded uppercase tracking-wider transition-all cursor-pointer"
                                >
                                  {isUpdatingOptionId === lead.id + '_3' ? '...' : 'Select'}
                                </button>
                              )}
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            <div className="flex flex-col gap-4">
              <div className="flex items-center justify-between">
                <h3 className="font-bold text-slate-900 tracking-tight text-xl">Daily Agenda</h3>
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest bg-slate-50 px-2 py-1 rounded">
                  {new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}
                </span>
              </div>

              {/* Sub-Tabs & Search */}
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div className="flex bg-slate-100 p-1 rounded-xl w-fit">
                  <button 
                    onClick={() => setAgendaTab('today')}
                    className={cn(
                      "px-4 py-2 rounded-lg text-[10px] font-bold uppercase tracking-wider transition-all",
                      agendaTab === 'today' ? "bg-white text-primary shadow-sm" : "text-slate-500 hover:text-primary"
                    )}
                  >
                    Today
                  </button>
                  <button 
                    onClick={() => setAgendaTab('upcoming')}
                    className={cn(
                      "px-4 py-2 rounded-lg text-[10px] font-bold uppercase tracking-wider transition-all",
                      agendaTab === 'upcoming' ? "bg-white text-primary shadow-sm" : "text-slate-500 hover:text-primary"
                    )}
                  >
                    Upcoming
                  </button>
                  <button 
                    onClick={() => setAgendaTab('past')}
                    className={cn(
                      "px-4 py-2 rounded-lg text-[10px] font-bold uppercase tracking-wider transition-all",
                      agendaTab === 'past' ? "bg-white text-primary shadow-sm" : "text-slate-500 hover:text-primary"
                    )}
                  >
                    Past History
                  </button>
                </div>

                <div className="relative">
                  <input 
                    type="text"
                    placeholder="Search students..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="bg-white border border-slate-200 rounded-xl px-4 py-2 pl-9 text-xs focus:ring-2 focus:ring-primary/10 focus:border-primary outline-none w-full md:w-64 transition-all"
                  />
                  <Users size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                </div>
              </div>
            </div>

            <div className="space-y-4">
              {(() => {
                const now = new Date();
                const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
                const tomorrow = new Date(today);
                tomorrow.setDate(today.getDate() + 1);

                const filtered = sessions
                  .filter(s => {
                    if (!s.startTime) return false;
                    const date = s.startTime.toDate ? s.startTime.toDate() : new Date(s.startTime);
                    
                    // Date Filter
                    let passDate = false;
                    if (agendaTab === 'today') {
                      passDate = date >= today && date < tomorrow;
                    } else if (agendaTab === 'upcoming') {
                      passDate = date >= tomorrow;
                    } else {
                      passDate = date < today;
                    }

                    // Search Filter
                    const matchesSearch = (s.studentName || '').toLowerCase().includes(searchQuery.toLowerCase());

                    return passDate && matchesSearch;
                  })
                  .sort((a, b) => {
                    // Sorting logic:
                    // 1. Status (active/scheduled first)
                    // 2. Time
                    if (a.status !== b.status) {
                       if (a.status === 'scheduled') return -1;
                       if (b.status === 'scheduled') return 1;
                    }

                    const dA = a.startTime.toDate ? a.startTime.toDate() : new Date(a.startTime);
                    const dB = b.startTime.toDate ? b.startTime.toDate() : new Date(b.startTime);
                    
                    if (agendaTab === 'past') return dB.getTime() - dA.getTime();
                    return dA.getTime() - dB.getTime();
                  });

                if (filtered.length === 0) {
                  return (
                    <div className="py-12 bg-white rounded-xl border border-dashed border-slate-200 text-center text-slate-400 text-xs italic font-medium">
                      No {agendaTab} sessions found {searchQuery && `matching "${searchQuery}"`}.
                    </div>
                  );
                }

                return filtered.map((session) => (
                  <div key={session.id} className="bg-white p-5 rounded-xl border border-slate-100 flex items-center justify-between group hover:shadow-md transition-all">
                    <div className="flex items-center gap-5">
                      <div className="w-14 h-14 bg-slate-50 border border-slate-100 rounded-lg flex flex-col items-center justify-center text-slate-900 font-bold shadow-sm">
                        <span className="text-[9px] text-slate-400 uppercase tracking-widest font-bold mb-0.5">
                          {agendaTab === 'today' ? 'Start' : (session.startTime.toDate ? session.startTime.toDate().toLocaleDateString([], { month: 'short', day: 'numeric' }) : 'Time')}
                        </span>
                        <span className="text-sm">
                          {formatDateTime(session.startTime)}
                        </span>
                      </div>
                      <div>
                        <div className="flex items-center gap-2 mb-1">
                          <h4 className="font-bold text-slate-900 leading-tight">{session.studentName || 'Student'}</h4>
                          <span className={cn(
                            "text-[9px] font-bold px-1.5 py-0.5 rounded uppercase tracking-wider",
                            session.type === 'trial' ? "bg-orange-100 text-orange-700" : "bg-slate-100 text-slate-500"
                          )}>
                            {session.type || 'Session'}
                          </span>
                        </div>
                        <div className="flex flex-col gap-1 text-[11px] text-slate-400 font-medium">
                          <div className="flex items-center gap-3">
                            <div className="flex items-center gap-1">
                              <Users size={12} className="text-slate-300" />
                              Age {session.studentAge || 'N/A'}
                            </div>
                            <div className="flex items-center gap-1">
                              <Clock size={12} className="text-slate-300" />
                              50 mins
                            </div>
                          </div>
                          {session.learningGoal && (
                            <div className="flex items-start gap-1 mt-1 text-slate-500 italic line-clamp-1 max-w-xs">
                               <BookOpen size={12} className="text-secondary shrink-0 mt-0.5" />
                               {session.learningGoal}
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-4">
                      {session.status === 'scheduled' ? (
                        (() => {
                          const student = students.find((s: any) => s.id === session.studentId);
                          const isExpired = student?.status === 'expired' || (student && student.remainingClassCredits !== undefined && student.remainingClassCredits <= 0);
                          
                          if (isExpired) {
                            return (
                              <div className="flex flex-col items-end gap-1">
                                <span className="text-[9px] font-bold text-red-600 bg-red-50 border border-red-100 px-2 py-1 rounded-md uppercase tracking-wider flex items-center gap-1">
                                  🔐 Suspended / Credits 0
                                </span>
                                <span className="text-[8px] text-slate-400 font-medium">Classroom Locked</span>
                              </div>
                            );
                          }
                          
                          return (
                            <div className="flex flex-col items-end gap-1.5">
                              <div className="flex items-center gap-2">
                                <a 
                                  href={(user as any)?.classroomLink || getDeterministicGoogleMeetUrl(undefined, (user as any)?.tutorId || (user as any)?.uid || (user as any)?.id)} 
                                  target="_blank" 
                                  rel="noopener noreferrer" 
                                  className="btn-primary text-[10px] py-1.5 px-3 shadow-none uppercase tracking-widest cursor-pointer inline-flex items-center hover:scale-[1.01] transition-all"
                                >
                                  Enter Class
                                </a>
                                <button 
                                  onClick={() => setCompletingSession(session)}
                                  className="bg-emerald-50 text-emerald-600 hover:bg-emerald-600 hover:text-white px-3 py-1.5 rounded-lg text-[10px] font-bold uppercase border border-emerald-100 transition-all cursor-pointer"
                                >
                                  Complete
                                </button>
                              </div>
                              <button 
                                onClick={() => {
                                  const url = (user as any)?.classroomLink || getDeterministicGoogleMeetUrl(undefined, (user as any)?.tutorId || (user as any)?.uid || (user as any)?.id);
                                  navigator.clipboard.writeText(url);
                                  alert("Link copied! You can share it with the parent.");
                                }}
                                className="text-[8px] text-slate-400 hover:text-indigo-600 flex items-center gap-1 font-bold uppercase tracking-tighter"
                              >
                                <Copy size={8} />
                                <span>Copy Link</span>
                              </button>
                            </div>
                          );
                        })()
                      ) : session.status === 'missed' ? (
                        <div className="flex items-center gap-1.5 text-amber-600 font-bold bg-amber-50 px-3 py-1.5 rounded-lg text-[11px] border border-amber-100">
                          <AlertCircle size={14} />
                          Missed: {session.missedReason || 'No Show'}
                        </div>
                      ) : (
                        <div className="flex items-center gap-1.5 text-emerald-600 font-bold bg-emerald-50 px-3 py-1.5 rounded-lg text-[11px] border border-emerald-100">
                          <CheckCircle2 size={14} />
                          Report Sent
                        </div>
                      )}
                      <div className="relative">
                        <button 
                          onClick={() => setOpenMenuSessionId(openMenuSessionId === session.id ? null : session.id)}
                          className="p-1 text-slate-300 hover:text-primary transition-colors cursor-pointer"
                        >
                          <MoreHorizontal size={18} />
                        </button>
                        {openMenuSessionId === session.id && (
                          <div 
                            className="absolute right-0 top-full mt-1 bg-white border border-slate-200 rounded-2xl shadow-xl py-2 w-48 z-20 text-left animate-in fade-in slide-in-from-top-2 duration-100"
                            onMouseLeave={() => setOpenMenuSessionId(null)}
                          >
                            <button
                              type="button"
                              onClick={() => {
                                setOpenMenuSessionId(null);
                                handleViewStudentBio(session);
                              }}
                              className="w-full text-left px-4 py-2 text-xs font-bold text-slate-700 hover:bg-slate-50 flex items-center gap-2 cursor-pointer transition-colors"
                            >
                              <BookOpen size={14} className="text-slate-400" />
                              <span>View Student Bio</span>
                            </button>
                            <button
                              type="button"
                              onClick={() => {
                                setOpenMenuSessionId(null);
                                setMissingSession(session);
                              }}
                              className="w-full text-left px-4 py-2 text-xs font-bold text-amber-600 hover:bg-amber-50 flex items-center gap-2 cursor-pointer transition-colors"
                            >
                              <AlertCircle size={14} className="text-amber-500" />
                              <span>Mark as Missed</span>
                            </button>
                            <button
                              type="button"
                              onClick={() => {
                                setOpenMenuSessionId(null);
                                setReschedulingSession(session);
                                setRescheduleReason('');
                                setRescheduleModalOpen(true);
                              }}
                              className="w-full text-left px-4 py-2 text-xs font-bold text-slate-700 hover:bg-slate-50 flex items-center gap-2 cursor-pointer transition-colors"
                            >
                              <Calendar size={14} className="text-slate-400" />
                              <span>Request Reschedule</span>
                            </button>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                ));
              })()}
            </div>
          </div>

        {/* Resources & Sidebar */}
        <div className="space-y-6">
          <div className="bg-slate-900 text-white p-8 rounded-xl shadow-xl relative overflow-hidden">
            <h3 className="text-lg font-bold mb-3 tracking-tight">Ge'ez Hub & Library</h3>
            <p className="text-slate-400 text-xs mb-8 leading-relaxed">Quick access to 32 original Meraf lessons, adaptive quizzes, flashcards, and the Ge'ez Root dictionary.</p>
            <button 
              onClick={() => {
                setLibraryModalOpen(true);
              }}
              className="btn-secondary w-full text-[10px] uppercase font-bold tracking-widest border-none py-2 bg-slate-850 text-white hover:bg-slate-750 cursor-pointer"
            >
              <BookOpen size={14} />
              Open Ge'ez Hub
            </button>
            <div className="absolute -bottom-10 -right-10 w-40 h-40 bg-secondary/5 rounded-full blur-3xl"></div>
          </div>

          {/* Direct Share & Invitation Console */}
          <div className="bg-white p-6 rounded-xl border border-slate-100 shadow-sm space-y-5">
            <div>
              <h3 className="font-bold text-slate-900 tracking-tight text-sm flex items-center gap-2">
                <Share2 size={16} className="text-indigo-600" />
                <span>Invite & Share Booking Link</span>
              </h3>
              <p className="text-slate-500 text-[11px] mt-1 leading-relaxed">
                Give parents your direct link to view your verified native profile and book 25-minute evaluation trials with you instantly.
              </p>
            </div>

            <div className="space-y-2.5">
              {/* Copy booking url button */}
              <div>
                <label className="block text-[10px] font-black uppercase tracking-wider text-slate-400 mb-1">Direct Booking Link</label>
                <div className="flex items-center gap-1.5">
                  <input
                    type="text"
                    readOnly
                    value={`${window.location.origin}/book-trial?tutor=${getTutorSlug(user) || user?.tutorId || user?.uid || ''}`}
                    className="bg-slate-50 text-[10px] font-mono text-slate-600 p-2 rounded-lg border border-slate-200 flex-grow select-all focus:outline-none"
                  />
                  <button
                    onClick={() => handleCopyLink('booking')}
                    className="p-2 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 rounded-lg border border-indigo-100 transition-all"
                    title="Copy Link"
                  >
                    {copiedLinkType === 'booking' ? <Check size={14} className="text-emerald-600" /> : <Copy size={14} />}
                  </button>
                </div>
              </div>

              {/* Copy profile url button */}
              <div>
                <label className="block text-[10px] font-black uppercase tracking-wider text-slate-400 mb-1">Showcase Profile Link</label>
                <div className="flex items-center gap-1.5">
                  <input
                    type="text"
                    readOnly
                    value={`${window.location.origin}/tutors/${getTutorSlug(user) || user?.tutorId || user?.uid || ''}`}
                    className="bg-slate-50 text-[10px] font-mono text-slate-600 p-2 rounded-lg border border-slate-200 flex-grow select-all focus:outline-none"
                  />
                  <button
                    onClick={() => handleCopyLink('profile')}
                    className="p-2 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 rounded-lg border border-indigo-100 transition-all"
                    title="Copy Link"
                  >
                    {copiedLinkType === 'profile' ? <Check size={14} className="text-emerald-600" /> : <Copy size={14} />}
                  </button>
                </div>
              </div>
            </div>

            {/* Email Invitation Form */}
            <div className="border-t border-slate-100 pt-4">
              <h4 className="text-[11px] font-bold text-slate-800 flex items-center gap-1.5 mb-3">
                <Mail size={13} className="text-indigo-500" />
                <span>Send Direct Email Invite</span>
              </h4>

              <form onSubmit={handleSendInvite} className="space-y-3">
                <div>
                  <input
                    type="text"
                    placeholder="Parent's Name"
                    value={inviteParentName}
                    onChange={(e) => setInviteParentName(e.target.value)}
                    className="w-full text-xs p-2.5 rounded-lg border border-slate-200 focus:ring-1 focus:ring-indigo-500 focus:outline-none"
                    required
                  />
                </div>
                <div>
                  <input
                    type="email"
                    placeholder="Parent's Email Address"
                    value={inviteParentEmail}
                    onChange={(e) => setInviteParentEmail(e.target.value)}
                    className="w-full text-xs p-2.5 rounded-lg border border-slate-200 focus:ring-1 focus:ring-indigo-500 focus:outline-none"
                    required
                  />
                </div>
                <div>
                  <textarea
                    placeholder="Custom invitation message (optional)..."
                    value={inviteMessage}
                    onChange={(e) => setInviteMessage(e.target.value)}
                    rows={2}
                    className="w-full text-xs p-2.5 rounded-lg border border-slate-200 focus:ring-1 focus:ring-indigo-500 focus:outline-none resize-none leading-normal"
                  />
                </div>

                {inviteError && (
                  <p className="text-[10px] font-bold text-rose-600 bg-rose-50 border border-rose-100 p-2 rounded-lg leading-normal">
                    ⚠️ {inviteError}
                  </p>
                )}

                {inviteSuccess && (
                  <p className="text-[10px] font-bold text-emerald-700 bg-emerald-50 border border-emerald-100 p-2.5 rounded-lg leading-normal flex items-start gap-1">
                    <span>✓</span>
                    <span>Invitation successfully sent! A personalized trial booking link has been emailed to the parent.</span>
                  </p>
                )}

                <button
                  type="submit"
                  disabled={inviteSending}
                  className="w-full py-2 bg-indigo-600 hover:bg-indigo-700 disabled:bg-indigo-400 text-white font-extrabold text-xs rounded-lg transition-all flex items-center justify-center gap-1.5 cursor-pointer shadow-sm hover:shadow"
                >
                  {inviteSending ? (
                    <>
                      <Loader2 size={12} className="animate-spin" />
                      <span>Sending Invite...</span>
                    </>
                  ) : (
                    <>
                      <Send size={12} />
                      <span>Send Invite Email</span>
                    </>
                  )}
                </button>
              </form>
            </div>
          </div>

          <div className="bg-white p-6 rounded-xl border border-slate-100 shadow-sm">
             <div className="flex items-center justify-between mb-8">
                <h3 className="font-bold text-slate-900">Student Progress</h3>
                <Plus size={16} className="text-slate-400 cursor-pointer hover:text-secondary" />
             </div>
             <div className="space-y-5">
                {students.map((s, i) => (
                  <div key={i}>
                    <div className="flex justify-between text-[11px] font-bold mb-2">
                       <span className="text-slate-700">{s.name}</span>
                       <span className="text-slate-400 uppercase tracking-widest">{s.progress || 0}%</span>
                    </div>
                    <div className="h-1.5 w-full bg-slate-50 rounded-full overflow-hidden">
                       <div 
                        className="h-full transition-all duration-1000" 
                        style={{ width: `${s.progress || 0}%`, backgroundColor: '#0f172a' }}
                       />
                    </div>
                  </div>
                ))}
                {students.length === 0 && (
                  <p className="text-[10px] text-slate-400 italic text-center font-medium">No assigned students yet.</p>
                )}
             </div>
          </div>
        </div>
      </div>
      )}

      {activeTab === 'availability' && (
        <div className="bg-white rounded-[32px] p-8 md:p-12 border border-slate-100 shadow-sm">
          <div className="max-w-2xl mx-auto">
            <h2 className="text-2xl font-bold text-primary mb-2">Weekly Availability</h2>
            <p className="text-slate-500 mb-8 text-sm">Set your recurring weekly teaching hours. These will be visible to parents booking trials.</p>
            
            {/* Time Zone Indicator */}
            <div className="bg-slate-50 border border-slate-150 p-3.5 rounded-2xl flex items-center justify-between text-[11px] text-slate-500 font-medium mb-6">
              <div className="flex items-center gap-2">
                <span className="text-sm">🌐</span>
                <span>Your schedule is running in: <strong className="text-slate-800 font-bold">{Intl.DateTimeFormat().resolvedOptions().timeZone}</strong></span>
              </div>
              <span className="text-[10px] text-indigo-600 bg-indigo-50 font-bold px-2 py-0.5 rounded-md uppercase tracking-wide">Local Detector</span>
            </div>

            <div className="space-y-6">
              {Object.entries(availability).map(([day, data]: [string, any]) => (
                <div key={day} className={cn(
                   "p-6 rounded-2xl border transition-all",
                   data.active ? "bg-white border-slate-200 shadow-sm" : "bg-slate-50 border-transparent opacity-60"
                )}>
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <input 
                        type="checkbox" 
                        checked={data.active}
                        onChange={(e) => setAvailability({
                          ...availability,
                          [day]: { ...data, active: e.target.checked }
                        })}
                        className="w-5 h-5 rounded border-slate-300 text-secondary focus:ring-secondary cursor-pointer"
                      />
                      <span className="font-bold text-slate-900 capitalize tracking-tight">{day}</span>
                    </div>
                    {data.active && (
                      <span className="text-[10px] font-bold text-secondary bg-secondary/5 px-2 py-0.5 rounded uppercase">Accepting Regular Students</span>
                    )}
                  </div>
                  
                  {data.active && (
                    <div className="space-y-4">
                      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
                        {data.slots.map((slot: string, idx: number) => (
                          <div key={idx} className="relative group">
                            <input 
                              type="time" 
                              value={slot}
                              onChange={(e) => {
                                const newSlots = [...data.slots];
                                newSlots[idx] = e.target.value;
                                setAvailability({ ...availability, [day]: { ...data, slots: newSlots }});
                              }}
                              className="w-full bg-slate-50 border border-slate-100 rounded-xl px-3 py-3 text-sm focus:border-secondary focus:ring-2 focus:ring-secondary/10 outline-none font-bold text-slate-700"
                            />
                            <button 
                              onClick={() => {
                                const newSlots = data.slots.filter((_: any, i: number) => i !== idx);
                                setAvailability({ ...availability, [day]: { ...data, slots: newSlots }});
                              }}
                              className="absolute -top-2 -right-2 bg-white text-slate-400 hover:text-red-500 rounded-full p-1 border border-slate-100 opacity-0 group-hover:opacity-100 transition-opacity shadow-sm"
                            >
                              <X size={12} />
                            </button>
                          </div>
                        ))}
                        <button 
                          onClick={() => {
                            const defaultSlot = (day === 'saturday' || day === 'sunday') ? '16:00' : '22:00';
                            setAvailability({ ...availability, [day]: { ...data, slots: [...data.slots, defaultSlot] }});
                          }}
                          className="flex items-center justify-center gap-2 border-2 border-dashed border-slate-100 rounded-xl p-3 text-slate-400 hover:border-secondary hover:text-secondary transition-all group"
                        >
                          <Plus size={16} className="group-hover:scale-110 transition-transform" />
                          <span className="text-[10px] font-bold uppercase tracking-widest">Add Slot</span>
                        </button>
                      </div>
                      <p className="text-[9px] text-slate-400 font-medium italic">* Each session is 50 minutes. Please allow 10 minutes buffer between slots.</p>
                    </div>
                  )}
                </div>
              ))}
            </div>

            <div className="mt-12 flex items-center justify-end gap-6 pt-8 border-t border-slate-100">
               {saveSuccess && (
                 <div className="flex items-center gap-2 text-emerald-600 font-bold text-xs animate-in fade-in slide-in-from-right-4">
                    <CheckCircle2 size={16} />
                    Changes saved successfully!
                 </div>
               )}
               <button 
                 disabled={isSubmitting}
                 onClick={saveAvailability}
                 className="btn-primary px-12 py-4 shadow-xl shadow-primary/20 flex items-center gap-2"
               >
                 {isSubmitting ? <Loader2 className="animate-spin" size={18} /> : (
                   <>
                     <Send size={16} />
                     Save Availability Changes
                   </>
                 )}
               </button>
            </div>
          </div>
        </div>
      )}

      {/* Classroom Messages Tab */}
      {activeTab === 'messages' && (
        <div className="h-[calc(100vh-12rem)] min-h-[500px] bg-white rounded-3xl border border-slate-150 shadow-xs flex overflow-hidden animate-in fade-in duration-300">
          {/* Threads Sidebar (Left panel) */}
          <div className="w-80 border-r border-slate-150 flex flex-col bg-slate-50/25 shrink-0">
            {/* Sidebar Header */}
            <div className="p-5 border-b border-slate-100 space-y-3 bg-white">
              <div className="flex items-center justify-between">
                <h2 className="text-sm font-bold text-slate-900 tracking-tight flex items-center gap-1.5">
                  <MessageSquare size={16} className="text-primary" />
                  <span>Classroom Inboxes</span>
                </h2>
                <span className="text-[10px] font-bold bg-slate-100 text-slate-500 px-2 py-0.5 rounded-full">
                  {tutorChatsList.length} families
                </span>
              </div>
            </div>

            {/* Threads List */}
            <div className="flex-1 overflow-y-auto divide-y divide-slate-100/60 p-2 space-y-1">
              {tutorChatsList.map((chat) => {
                const isActive = activeChatId === chat.id;
                const formattedTime = chat.lastMessageAt ? (chat.lastMessageAt.toDate ? chat.lastMessageAt.toDate().toLocaleDateString('en-US', {month: 'short', day: 'numeric'}) : new Date(chat.lastMessageAt).toLocaleDateString('en-US', {month: 'short', day: 'numeric'})) : '';
                
                return (
                  <button
                    key={chat.id}
                    onClick={() => {
                      setActiveChatId(chat.id);
                      setChatViolationWarning(null);
                    }}
                    className={cn(
                      "w-full text-left p-3.5 rounded-xl transition-all flex items-start gap-3 cursor-pointer",
                      isActive 
                        ? "bg-slate-900 text-white shadow-md shadow-slate-900/10" 
                        : "hover:bg-slate-50"
                    )}
                  >
                    <div className={cn(
                      "w-10 h-10 rounded-full flex items-center justify-center font-bold text-xs uppercase shrink-0 shadow-xs",
                      isActive ? "bg-white/10 text-white" : "bg-primary/10 text-primary"
                    )}>
                      {(chat.parentName || chat.parentEmail || 'P').charAt(0)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-1 mb-0.5">
                        <span className={cn(
                          "font-bold text-xs truncate block",
                          isActive ? "text-white" : "text-slate-900"
                        )}>
                          {chat.parentName || "Parent Account"}
                        </span>
                        <span className={cn(
                          "text-[9px] font-bold tracking-wider shrink-0",
                          isActive ? "text-white/60" : "text-slate-400"
                        )}>
                          {formattedTime}
                        </span>
                      </div>
                      <span className={cn(
                        "text-[10px] block truncate font-medium mb-1",
                        isActive ? "text-white/75" : "text-slate-400"
                      )}>
                        {chat.parentEmail}
                      </span>
                      <p className={cn(
                        "text-[11px] truncate leading-normal",
                        isActive ? "text-white/70" : "text-slate-500 font-medium"
                      )}>
                        {chat.lastMessage || 'No messages yet'}
                      </p>
                    </div>
                  </button>
                );
              })}

              {tutorChatsList.length === 0 && (
                <div className="text-center py-12 px-4">
                  <div className="w-12 h-12 bg-slate-50 border border-slate-100 rounded-full flex items-center justify-center mx-auto mb-3">
                    <MessageSquare className="text-slate-300" size={20} />
                  </div>
                  <h4 className="text-xs font-bold text-slate-800 mb-1">No Active Parent Convos</h4>
                  <p className="text-[10px] text-slate-450 leading-relaxed font-semibold">
                    Once parents coordinate classroom slots or book virtual trial lessons, private communication portals will initialize synchronously here.
                  </p>
                </div>
              )}
            </div>
          </div>

          {/* Chat Window (Right panel) */}
          <div className="flex-1 flex flex-col bg-slate-50/15">
            {activeChatId ? (() => {
              const activeChatDoc = tutorChatsList.find(c => c.id === activeChatId);
              if (!activeChatDoc) return null;
              
              return (
                <div className="flex-1 flex flex-col h-full overflow-hidden">
                  {/* Active Header */}
                  <div className="p-5 border-b border-slate-100 bg-white flex items-center justify-between text-left shadow-2xs">
                    <div>
                      <span className="text-[9px] font-extrabold text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded-md uppercase tracking-wider block w-fit mb-1 font-extrabold">
                        HabKids Parent Coordinator
                      </span>
                      <h3 className="font-extrabold text-sm text-slate-900 tracking-tight">
                        {activeChatDoc.parentName || "Parent Family"}
                      </h3>
                      <p className="text-[10px] text-slate-400 font-semibold mt-0.5">
                        Inquiry Channel: {activeChatDoc.parentEmail}
                      </p>
                    </div>
                  </div>

                  {/* Messages Feed */}
                  <div className="flex-1 overflow-y-auto p-6 space-y-4 bg-slate-50/20 text-left">
                    {chatMessages.map((msg, index) => {
                      const isTutorRole = msg.senderRole === 'tutor';
                      const isAdminRole = msg.senderRole === 'admin';
                      return (
                        <div
                          key={msg.id || index}
                          className={cn(
                            "flex flex-col max-w-[80%] leading-relaxed",
                            isTutorRole 
                              ? "ml-auto items-end" 
                              : isAdminRole 
                              ? "mx-auto items-center text-center bg-amber-50/70 border border-amber-100 p-3 rounded-2xl max-w-lg mb-1"
                              : "mr-auto items-start"
                          )}
                        >
                          {!isAdminRole && (
                            <span className="text-[9px] text-slate-400 font-extrabold uppercase mb-1 tracking-wider block">
                              {msg.senderName} ({isTutorRole ? 'You' : 'Parent'})
                            </span>
                          )}
                          <div
                            className={cn(
                              "p-3 rounded-2xl text-xs font-semibold leading-relaxed shadow-3xs",
                              isTutorRole
                                ? "bg-slate-900 text-white rounded-tr-none font-bold"
                                : isAdminRole
                                ? "bg-transparent shadow-none border-none text-amber-900 max-w-full text-center pb-0"
                                : "bg-white border border-slate-150 text-slate-800 rounded-tl-none font-semibold"
                            )}
                          >
                            {isAdminRole && (
                              <span className="text-[9px] font-extrabold text-amber-800 uppercase tracking-widest block mb-1">
                                📣 Administration Broadcast ({msg.senderName})
                              </span>
                            )}
                            {msg.text}
                          </div>
                        </div>
                      );
                    })}

                    {chatMessages.length === 0 && (
                      <div className="p-8 text-center bg-white border border-slate-100 rounded-2xl italic text-slate-405 text-xs leading-relaxed max-w-md mx-auto my-12 font-medium">
                        💬 Conversational portal initialized. Initiate a message to coordinate lesson sequences, homework links, and milestones with the student's parent directly.
                      </div>
                    )}
                    
                    <div ref={tutorMsgEndRef} />
                  </div>

                  {/* Message Input Footer */}
                  <div className="p-4 border-t border-slate-100 bg-white">
                    {chatViolationWarning && (
                      <div className="mb-3 p-3 bg-rose-50 border border-rose-100 text-rose-800 text-[10px] rounded-xl font-bold flex items-center gap-1.5 animate-in slide-in-from-top-2 duration-200">
                        <AlertCircle size={14} className="text-rose-600 shrink-0" />
                        <span>{chatViolationWarning}</span>
                      </div>
                    )}
                    
                    <form onSubmit={handleSendChatMessage} className="flex gap-2">
                      <input
                        type="text"
                        value={chatInput}
                        onChange={(e) => setChatInput(e.target.value)}
                        placeholder="Type standard security-compliant instruction updates..."
                        className="flex-1 bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-xs focus:ring-2 focus:ring-slate-950/10 focus:border-slate-900 outline-none transition-all font-semibold text-slate-800"
                      />
                      <button
                        type="submit"
                        disabled={sendingMessage || !chatInput.trim()}
                        className="bg-slate-900 text-white rounded-xl px-4 py-2 flex items-center justify-center gap-1.5 transition-all text-xs font-bold hover:bg-slate-800 disabled:opacity-50 cursor-pointer"
                      >
                        {sendingMessage ? (
                          <Loader2 size={14} className="animate-spin" />
                        ) : (
                          <>
                            <Send size={13} />
                            <span>Send</span>
                          </>
                        )}
                      </button>
                    </form>
                  </div>
                </div>
              );
            })() : (
              <div className="flex-1 flex flex-col items-center justify-center text-slate-400 p-8">
                <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mb-4">
                  <MessageSquare className="text-slate-350" size={32} />
                </div>
                <h4 className="font-bold text-slate-800 tracking-tight text-sm mb-1">
                  Active Correspondence Hub
                </h4>
                <p className="text-xs text-slate-400 text-center max-w-sm leading-relaxed font-semibold">
                  Select a family conversation from the left margin panel to review real-time messages, coordinates, and homework feedback.
                </p>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Completion Modal */}
      {completingSession && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-white w-full max-w-lg rounded-2xl shadow-2xl overflow-hidden">
            <div className="p-6 bg-emerald-600 text-white flex justify-between items-center">
              <div>
                <h3 className="font-bold text-lg leading-tight">Post-Trial Evaluation</h3>
                <p className="text-emerald-100 text-xs mt-1">Student: {completingSession.studentName}</p>
              </div>
              <button 
                onClick={() => setCompletingSession(null)} 
                className="p-2 hover:bg-white/10 rounded-full transition-colors"
              >
                <X size={20} />
              </button>
            </div>
            
            <form onSubmit={handleCompleteSubmit} className="p-8 space-y-6">
              <div className="space-y-3">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Initial Assessment Score</label>
                <div className="flex gap-2">
                  {['1', '2', '3', '4', '5'].map((l) => (
                    <button 
                      key={l}
                      type="button"
                      onClick={() => setLevel(l)}
                      className={cn(
                        "flex-1 py-3 rounded-xl border-2 transition-all font-bold text-sm",
                        level === l 
                          ? "bg-slate-900 text-white border-slate-900 scale-105 shadow-lg shadow-slate-900/20" 
                          : "bg-slate-50 text-slate-400 border-slate-100 hover:border-slate-200"
                      )}
                    >
                      Lvl {l}
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-3">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Tutor Evaluation & Feedback</label>
                <textarea 
                  required
                  rows={4}
                  value={evaluation}
                  onChange={(e) => setEvaluation(e.target.value)}
                  placeholder="Describe student's current proficiency, strengths, and recommended focus areas for the curriculum..."
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-emerald-500/10 focus:border-emerald-500 transition-all outline-none resize-none"
                />
              </div>

              <div className="bg-emerald-50 border border-emerald-100 p-4 rounded-xl flex gap-3">
                <Star className="text-emerald-600 shrink-0" size={18} />
                <p className="text-[11px] text-emerald-700 leading-relaxed font-medium">
                  <strong>Parent Notification:</strong> Submitting this report will automatically send a professional email to <strong>{completingSession.parentName}</strong> with your high-level evaluation and invitation to subscribe.
                </p>
              </div>

              <button 
                disabled={isSubmitting}
                type="submit" 
                className="w-full bg-emerald-600 text-white font-bold py-4 rounded-xl shadow-lg shadow-emerald-600/20 flex items-center justify-center gap-2 hover:bg-emerald-700 transition-all uppercase tracking-widest text-xs"
              >
                {isSubmitting ? <Loader2 className="animate-spin" size={18} /> : (
                  <>
                    <Send size={16} />
                    Finalize & Send Report
                  </>
                )}
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Interactive Amharic Lesson Viewer */}
      <LessonViewer isOpen={libraryModalOpen} onClose={() => setLibraryModalOpen(false)} />

      {/* Student Bio Modal */}
      {bioModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-white w-full max-w-md rounded-3xl shadow-2xl overflow-hidden border border-slate-150">
            <div className="p-6 bg-slate-900 text-white flex justify-between items-center">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-white/10 rounded-xl text-secondary">
                  <Users size={20} />
                </div>
                <div>
                  <h3 className="font-bold text-base leading-none text-white">Student Profile Bio</h3>
                  <p className="text-slate-400 text-[10px] mt-1 font-medium">Active Classroom Index Row</p>
                </div>
              </div>
              <button 
                onClick={() => setBioModalOpen(false)} 
                className="p-2 hover:bg-white/10 rounded-full transition-colors cursor-pointer"
              >
                <X size={20} className="text-white" />
              </button>
            </div>

            {isFetchingBio ? (
              <div className="py-16 flex flex-col items-center justify-center gap-3 text-slate-400">
                <Loader2 size={24} className="animate-spin text-secondary" />
                <span className="text-xs font-bold uppercase tracking-wider">Loading record...</span>
              </div>
            ) : activeBioStudent ? (
              <div className="p-6 space-y-6">
                <div className="flex items-center gap-4">
                  <div className="w-14 h-14 bg-slate-100 rounded-2xl flex items-center justify-center text-slate-600 text-xl font-black shadow-sm">
                    {activeBioStudent.name ? activeBioStudent.name[0] : 'S'}
                  </div>
                  <div>
                    <h4 className="font-extrabold text-slate-900 text-lg leading-tight">{activeBioStudent.name}</h4>
                    <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-1">
                      {activeBioStudent.isTrial ? 'Trial Assessment' : `${activeBioStudent.plan || 'Standard'} Subscriber`}
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-slate-50 p-3 rounded-xl border border-slate-100">
                    <span className="text-[9px] font-bold text-slate-400 uppercase tracking-wider block">Student Age</span>
                    <span className="text-xs text-slate-950 font-bold">{activeBioStudent.studentAge || 'N/A'}</span>
                  </div>
                  <div className="bg-slate-50 p-3 rounded-xl border border-slate-100">
                    <span className="text-[9px] font-bold text-slate-400 uppercase tracking-wider block">Class Pattern</span>
                    <span className="text-xs text-slate-950 font-bold truncate block">{activeBioStudent.schedulePattern || 'Ongoing'}</span>
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between items-center text-[10px] font-bold text-slate-500 uppercase tracking-wider">
                    <span>Curriculum Progress</span>
                    <span>{activeBioStudent.progress || 0}%</span>
                  </div>
                  <div className="h-2 w-full bg-slate-100 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-slate-900 rounded-full transition-all duration-500"
                      style={{ width: `${activeBioStudent.progress || 0}%` }}
                    />
                  </div>
                </div>

                <div className="space-y-2 pt-2">
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Syllabus Focus & Goals</span>
                  <div className="bg-slate-50 p-4 rounded-2xl border border-slate-100 text-xs text-slate-700 leading-relaxed font-semibold italic">
                    "{activeBioStudent.learningGoal}"
                  </div>
                </div>

                {activeBioStudent.isTrial && (
                  <div className="p-3 bg-amber-50 border border-amber-100 rounded-xl text-[10px] text-amber-800 leading-normal font-semibold">
                    * This is a pre-enrollment classroom slot. Completion evaluation will automatically index this member in the system archive.
                  </div>
                )}
              </div>
            ) : (
              <div className="py-12 text-center text-xs text-slate-400 italic">
                Could not retrieve student bio record.
              </div>
            )}

            <div className="bg-slate-50 p-4 border-t border-slate-100 flex justify-end">
              <button 
                onClick={() => setBioModalOpen(false)}
                className="btn-primary text-[10px] uppercase font-bold tracking-widest px-6 py-2 bg-slate-900 text-white cursor-pointer"
              >
                Close Profile
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Reschedule Request Modal */}
      {rescheduleModalOpen && reschedulingSession && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-white w-full max-w-md rounded-3xl shadow-2xl overflow-hidden border border-slate-150">
            <div className="p-6 bg-slate-900 text-white flex justify-between items-center">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-white/10 rounded-xl text-secondary">
                  <Calendar size={20} />
                </div>
                <div>
                  <h3 className="font-bold text-base leading-none text-white">Request Reschedule</h3>
                  <p className="text-slate-400 text-[10px] mt-1 font-medium">Notifies Master Administration Operators</p>
                </div>
              </div>
              <button 
                onClick={() => setRescheduleModalOpen(false)} 
                className="p-2 hover:bg-white/10 rounded-full transition-colors cursor-pointer"
              >
                <X size={20} className="text-white" />
              </button>
            </div>

            <form onSubmit={handleRescheduleSubmit} className="p-6 space-y-5">
              <div className="bg-slate-50 p-4 rounded-xl space-y-1.5 border border-slate-100 text-[11px] text-slate-600 font-semibold">
                <div className="flex justify-between">
                  <span className="text-slate-400 uppercase text-[9px]">Student:</span>
                  <span className="text-slate-900 font-bold">{reschedulingSession.studentName}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400 uppercase text-[9px]">Original Class Time:</span>
                  <span className="text-slate-900 font-bold">
                    {formatDateTime(reschedulingSession.startTime, {
                      weekday: 'long', 
                      month: 'short', 
                      day: 'numeric', 
                      hour: '2-digit', 
                      minute: '2-digit'
                    })}
                  </span>
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block font-sans">Reason for Rescheduling</label>
                <textarea 
                  required
                  rows={3}
                  value={rescheduleReason}
                  onChange={(e) => setRescheduleReason(e.target.value)}
                  placeholder="Please specify your request and suggested timeslots (e.g. reschedule to Friday afternoon at 4pm due to school exams)..."
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-xs focus:ring-2 focus:ring-slate-950/10 focus:border-slate-900 transition-all outline-none resize-none font-semibold text-slate-800"
                />
              </div>

              {rescheduleSuccess ? (
                <div className="p-4 bg-emerald-50 border border-emerald-100 rounded-xl flex items-center gap-2 text-emerald-800 text-[11px] font-bold animate-in zoom-in-95">
                  <CheckCircle2 className="text-emerald-600 shrink-0" size={16} />
                  <span>Request delivered successfully to Admin console inbox.</span>
                </div>
              ) : (
                <div className="p-3 bg-amber-50 border border-amber-100 rounded-xl text-[10px] text-amber-800 leading-normal font-semibold">
                  * Live reschedule request maintains slot ledger integrity. An administrative coordinator will contact the parent to adjust their active recurring session.
                </div>
              )}

              <div className="flex justify-end gap-3 pt-4 border-t border-slate-100">
                <button 
                  type="button"
                  onClick={() => setRescheduleModalOpen(false)}
                  className="text-slate-500 hover:text-slate-800 font-bold text-[10px] uppercase tracking-widest px-4 cursor-pointer"
                >
                  Cancel
                </button>
                <button 
                  disabled={isSubmitting || rescheduleSuccess}
                  type="submit"
                  className="btn-primary text-[10px] uppercase font-bold tracking-widest px-8 py-3 bg-slate-900 text-white flex items-center gap-2 cursor-pointer"
                >
                  {isSubmitting ? <Loader2 size={12} className="animate-spin" /> : <Send size={12} />}
                  <span>Submit Request</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
      {/* Mark as Missed Modal */}
      {missingSession && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-[32px] w-full max-w-lg overflow-hidden shadow-2xl animate-in zoom-in-95 duration-200">
            <div className="p-8">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h3 className="text-xl font-bold text-slate-900 tracking-tight">Mark Session as Missed</h3>
                  <p className="text-sm text-slate-500 mt-1">Class with {missingSession.studentName}</p>
                </div>
                <button 
                  onClick={() => setMissingSession(null)}
                  className="p-2 hover:bg-slate-50 rounded-full transition-colors"
                >
                  <X size={20} className="text-slate-400" />
                </button>
              </div>

              <form onSubmit={handleMarkMissed} className="space-y-6 text-left">
                <div className="bg-amber-50 border border-amber-100 p-4 rounded-2xl flex gap-3">
                  <AlertCircle className="text-amber-500 shrink-0" size={20} />
                  <p className="text-xs text-amber-800 leading-relaxed font-medium">
                    Please specify why this class was not undertaken. Marking a session as missed will update the status and can optionally deduct a credit from the student.
                  </p>
                </div>

                <div>
                  <label className="block text-[11px] font-black uppercase tracking-wider text-slate-400 mb-2 ml-1">Reason for Absence</label>
                  <select 
                    value={missedReason}
                    onChange={(e) => setMissedReason(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-100 rounded-2xl px-4 py-3.5 text-sm font-bold text-slate-700 focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 outline-none transition-all cursor-pointer"
                  >
                    <option value="Student no-show">Student no-show</option>
                    <option value="Technical issues (Student)">Technical issues (Student)</option>
                    <option value="Technical issues (Tutor)">Technical issues (Tutor)</option>
                    <option value="Last minute cancellation">Last minute cancellation</option>
                    <option value="Other">Other</option>
                  </select>
                </div>

                <div className="flex items-center gap-3 p-4 bg-slate-50 rounded-2xl border border-slate-100">
                  <input 
                    type="checkbox"
                    id="deductCredit"
                    checked={deductMissedCredit}
                    onChange={(e) => setDeductMissedCredit(e.target.checked)}
                    className="w-5 h-5 rounded border-slate-300 text-indigo-600 focus:ring-indigo-500 cursor-pointer"
                  />
                  <label htmlFor="deductCredit" className="text-sm font-bold text-slate-700 cursor-pointer select-none">
                    Deduct 1 Credit from student
                  </label>
                </div>

                <div className="flex gap-3 pt-2">
                  <button
                    type="button"
                    onClick={() => setMissingSession(null)}
                    className="flex-1 py-4 bg-slate-100 hover:bg-slate-200 text-slate-600 font-bold text-sm rounded-2xl transition-all cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="flex-1 py-4 bg-amber-600 hover:bg-amber-700 text-white font-bold text-sm rounded-2xl transition-all shadow-lg shadow-amber-600/20 flex items-center justify-center gap-2 cursor-pointer"
                  >
                    {isSubmitting ? <Loader2 size={18} className="animate-spin" /> : <CheckCircle2 size={18} />}
                    <span>Mark as Missed</span>
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

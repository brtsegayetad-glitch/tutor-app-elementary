import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Link, useNavigate } from 'react-router-dom';
import { 
  ChevronLeft, 
  CheckCircle2, 
  Loader2, 
  Globe, 
  Send, 
  Award, 
  Heart, 
  GraduationCap, 
  Video, 
  DollarSign, 
  Clock, 
  BookOpen, 
  Image, 
  Sparkles, 
  Check, 
  Flame,
  Camera,
  Upload
} from 'lucide-react';
import { cn, compressImageToBase64 } from '../lib/utils';
import { submitTutorApplication, subscribeToSettings } from '../services/dataService';
import BrandLogo from '../components/BrandLogo';
import { auth, db } from '../lib/firebase';
import { createUserWithEmailAndPassword, updateProfile, signOut } from 'firebase/auth';
import { doc, setDoc, serverTimestamp } from 'firebase/firestore';
import { useAuth } from '../context/AuthContext';

const AVATAR_TEMPLATES = [
  {
    name: "Martha",
    url: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=260"
  },
  {
    name: "Eden",
    url: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=260"
  },
  {
    name: "Solomon",
    url: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=260"
  },
  {
    name: "Daniel",
    url: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=260"
  }
];

function normalizeYoutubeUrl(url: string) {
  if (!url) return '';
  const cleanUrl = url.trim();

  // Support YouTube shorts
  if (cleanUrl.includes('/shorts/')) {
    const parts = cleanUrl.split('/shorts/');
    if (parts.length > 1) {
      const idPart = parts[1].split(/[?&]/)[0];
      if (idPart.length >= 11) {
        return `https://www.youtube.com/embed/${idPart.substring(0, 11)}`;
      }
    }
  }

  if (cleanUrl.includes('/embed/')) {
    return cleanUrl.split('?')[0];
  }

  const regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|\&v=)([^#\&\?]*).*/;
  const match = cleanUrl.match(regExp);
  if (match && match[2] && match[2].length === 11) {
    return `https://www.youtube.com/embed/${match[2]}`;
  }
  return cleanUrl;
}

const DAYS_ORDER = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];

function getSlotTimeString(slot: any): string {
  if (typeof slot === 'string') return slot;
  if (slot && typeof slot === 'object') {
    if (typeof slot.start === 'string') return slot.start;
    if (typeof slot.startTime === 'string') return slot.startTime;
    if (typeof slot.slot === 'string') return slot.slot;
  }
  return String(slot || '');
}

function getTimezoneOffsetMinutes(timezoneStr: string): number {
  const clean = String(timezoneStr || '').toLowerCase();
  if (clean.includes('eat') || clean.includes('addis') || clean.includes('africa')) {
    return -180; // UTC+3
  }
  if (clean.includes('gmt') || clean.includes('london')) {
    return 0; // UTC+0
  }
  if (clean.includes('europe') || clean.includes('paris') || clean.includes('berlin')) {
    return -60; // UTC+1
  }
  if (clean.includes('pst') || clean.includes('los angeles') || clean.includes('seattle')) {
    return 480; // UTC-8
  }
  if (clean.includes('cst') || clean.includes('chicago')) {
    return 360; // UTC-6
  }
  if (clean.includes('est') || clean.includes('new york') || clean.includes('washington') || clean.includes('dc')) {
    return 300; // UTC-5
  }
  return new Date().getTimezoneOffset();
}

function localSlotToUTC(dayName: string, slotTime: any, timezoneStr: string = 'EAT (Addis Ababa)'): { day: string; slot: string } {
  const dayIndex = DAYS_ORDER.indexOf(dayName.toLowerCase());
  const str = getSlotTimeString(slotTime);
  if (dayIndex === -1 || !str.includes(':')) return { day: dayName, slot: str || '09:00' };

  const [h, m] = str.split(':').map(Number);
  const totalMinutesLocal = dayIndex * 24 * 60 + h * 60 + m;
  
  const offset = getTimezoneOffsetMinutes(timezoneStr); // in minutes (UTC - local)
  
  let totalMinutesUTC = totalMinutesLocal + offset;
  totalMinutesUTC = (totalMinutesUTC + 10080) % 10080;
  
  const utcDayIndex = Math.floor(totalMinutesUTC / (24 * 60));
  const remainingMinutes = totalMinutesUTC % (24 * 60);
  
  const utcH = String(Math.floor(remainingMinutes / 60)).padStart(2, '0');
  const utcM = String(remainingMinutes % 60).padStart(2, '0');
  
  return { day: DAYS_ORDER[utcDayIndex], slot: `${utcH}:${utcM}` };
}

function convertLocalAvailabilityToUTC(localAvail: any, timezoneStr: string = 'EAT (Addis Ababa)'): any {
  if (!localAvail) return null;
  const cloned: any = {};
  Object.entries(localAvail).forEach(([day, dayData]: [string, any]) => {
    const slots = Array.isArray(dayData?.slots) ? [...dayData.slots].sort() : [];
    cloned[day] = {
      active: slots.length > 0,
      slots
    };
  });
  return cloned;
}

export default function BecomeTutorPage() {
  const navigate = useNavigate();
  const { user, signUpWithEmail, signOut: signOutContext } = useAuth();
  
  const [logoUrl, setLogoUrl] = useState(() => {
    try {
      const cached = localStorage.getItem('habkids_cached_settings');
      if (cached) {
        const data = JSON.parse(cached);
        if (data && data.activeLogoUrl) {
          return data.activeLogoUrl;
        }
      }
    } catch (e) {
      console.warn(e);
    }
    return '/logo_option_one.png';
  });
  const [academyName, setAcademyName] = useState(() => {
    try {
      const cached = localStorage.getItem('habkids_cached_settings');
      if (cached) {
        const data = JSON.parse(cached);
        if (data && data.academyName) {
          return data.academyName;
        }
      }
    } catch (e) {
      console.warn(e);
    }
    return 'HabKids';
  });

  useEffect(() => {
    const originalTitle = document.title;
    document.title = "Join HabKids tutor as a Native Language Tutor";

    const unsubscribe = subscribeToSettings((data) => {
      if (data) {
        if (data.activeLogoUrl) {
          setLogoUrl(data.activeLogoUrl);
        }
        if (data.academyName) {
          setAcademyName(data.academyName);
        }
        if (data.tutorHourlyRate !== undefined) {
          setHourlyRate(String(data.tutorHourlyRate));
        }
      }
    });
    return () => {
      unsubscribe();
      document.title = originalTitle;
    };
  }, []);
  
  // Standard fields
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [whatsapp, setWhatsapp] = useState('');
  const [timezone, setTimezone] = useState('EAT (Addis Ababa)');
  const [experience, setExperience] = useState('');
  const [expertise, setExpertise] = useState('Amharic');

  useEffect(() => {
    if (user) {
      setFullName(user.fullName || user.displayName || '');
      setEmail(user.email || '');
    }
  }, [user]);
  
  // Professional premium fields
  const [hourlyRate, setHourlyRate] = useState('25');
  const [yearsOfExperience, setYearsOfExperience] = useState('3-5 years');
  const [quote, setQuote] = useState('');
  const [detailedBio, setDetailedBio] = useState('');
  const [videoUrl, setVideoUrl] = useState('');
  const [targetAge, setTargetAge] = useState('All Children (Ages 6-12)');
  const [selectedAvatar, setSelectedAvatar] = useState(AVATAR_TEMPLATES[0].url);
  const [uploadedPhotoBase64, setUploadedPhotoBase64] = useState('');
  const [uploadMethod, setUploadMethod] = useState<'upload' | 'placeholder' | 'url'>('upload');
  const [isCertified, setIsCertified] = useState(false);
  const [isCustomAvatar, setIsCustomAvatar] = useState(false);
  const [customAvatarUrl, setCustomAvatarUrl] = useState('');

  const [availability, setAvailability] = useState<any>({
    monday: { active: true, slots: ['22:00', '23:00', '00:00', '01:00', '02:00', '03:00', '04:00', '05:00'] },
    tuesday: { active: true, slots: ['22:00', '23:00', '00:00', '01:00', '02:00', '03:00', '04:00', '05:00'] },
    wednesday: { active: true, slots: ['22:00', '23:00', '00:00', '01:00', '02:00', '03:00', '04:00', '05:00'] },
    thursday: { active: true, slots: ['22:00', '23:00', '00:00', '01:00', '02:00', '03:00', '04:00', '05:00'] },
    friday: { active: true, slots: ['22:00', '23:00', '00:00', '01:00', '02:00', '03:00', '04:00', '05:00'] },
    saturday: { active: true, slots: ['16:00', '18:00', '20:00', '22:00', '00:00', '02:00'] },
    sunday: { active: true, slots: ['16:00', '18:00', '20:00', '22:00', '00:00', '02:00'] }
  });

  const toggleSlot = (day: string, slot: string) => {
    const current = { ...availability };
    const dayObj = { ...current[day] };
    let newSlots = [...(dayObj.slots || [])];
    if (newSlots.includes(slot)) {
      newSlots = newSlots.filter(s => s !== slot);
    } else {
      newSlots.push(slot);
      newSlots.sort();
    }
    dayObj.slots = newSlots;
    dayObj.active = newSlots.length > 0;
    current[day] = dayObj;
    setAvailability(current);
  };

  const toggleDayActive = (day: string) => {
    const current = { ...availability };
    const dayObj = { ...current[day] };
    dayObj.active = !dayObj.active;
    if (!dayObj.active) {
      dayObj.slots = [];
    } else if (!dayObj.slots || dayObj.slots.length === 0) {
      if (day === 'saturday' || day === 'sunday') {
        dayObj.slots = ['16:00', '18:00', '20:00', '22:00', '00:00', '02:00'];
      } else {
        dayObj.slots = ['22:00', '23:00', '00:00', '01:00', '02:00', '03:00', '04:00', '05:00'];
      }
    }
    current[day] = dayObj;
    setAvailability(current);
  };

  const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      try {
        const compressedBase64 = await compressImageToBase64(file, 800 * 1024);
        setUploadedPhotoBase64(compressedBase64);
      } catch (err: any) {
        alert(err.message || "Failed to process photo.");
      }
    }
  };
  
  // Connection mapping - OFF by default now that applications are directly reviewed by admin!
  
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [errorStatus, setErrorStatus] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorStatus('');

    // Field Validations
    if (!fullName.trim()) {
      setErrorStatus('Full name is required.');
      return;
    }
    if (!email.trim() || !email.includes('@')) {
      setErrorStatus('Please enter a valid email address.');
      return;
    }
    if (!password) {
      setErrorStatus('Password is required.');
      return;
    }
    if (password.length < 6) {
      setErrorStatus('Password must be at least 6 characters long.');
      return;
    }
    if (password !== confirmPassword) {
      setErrorStatus('Passwords do not match.');
      return;
    }
    if (!whatsapp.trim()) {
      setErrorStatus('WhatsApp phone number is required.');
      return;
    }
    if (!experience.trim()) {
      setErrorStatus('Please provide a short summary of your teaching experience.');
      return;
    }
    if (!detailedBio.trim()) {
      setErrorStatus('Please write teaching methodology or details for parents to review.');
      return;
    }
    if (!quote.trim()) {
      setErrorStatus('Please write a warm welcoming quote or greeting phrase (e.g. ሰላም ልጆች!).');
      return;
    }

    setIsSubmitting(true);
    try {
      const avatarToUse = uploadedPhotoBase64 || "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&q=80&w=200";

      const normalizedVideo = videoUrl.trim() 
        ? normalizeYoutubeUrl(videoUrl.trim()) 
        : "";

      const utcAvail = convertLocalAvailabilityToUTC(availability, timezone);

      // Create actual Firebase Authentication credentials first!
      let registeredUid = "";
      let firebaseUser = auth.currentUser;
      const virtualUserId = localStorage.getItem('virtual_user_id');

      if (firebaseUser) {
        registeredUid = firebaseUser.uid;
      } else if (virtualUserId) {
        registeredUid = virtualUserId;
      } else {
        try {
          // Use our robust context signUpWithEmail helper which handles real-vs-virtual fallbacks!
          const res = await signUpWithEmail(email.trim().toLowerCase(), password, fullName, false);
          if (res && res.uid) {
            registeredUid = res.uid;
          } else {
            throw new Error("Registration failed.");
          }
        } catch (authErr: any) {
          if (authErr.message?.includes('already registered') || authErr.code === 'auth/email-already-in-use') {
            setErrorStatus('An account already exists with this email address. Please sign in instead.');
          } else if (authErr.code === 'auth/operation-not-allowed') {
            setErrorStatus("Email/Password Sign-In is not yet enabled in your Firebase Console. Please open your Firebase Console, navigate to 'Authentication' > 'Sign-in method', and enable 'Email/Password' to allow registering new users!");
          } else {
            setErrorStatus(authErr.message || 'Firebase Authentication registration failed.');
          }
          setIsSubmitting(false);
          return;
        }
      }

      // 1. Save standard structured application in tutor_applications collection for admin tracking
      const result = await submitTutorApplication({
        fullName,
        email: email.trim().toLowerCase(),
        whatsapp: whatsapp.trim(),
        experience: experience.trim(),
        expertise,
        timezone,
        hourlyRate,
        yearsOfExperience,
        quote: quote.trim(),
        detailedBio: detailedBio.trim(),
        videoUrl: normalizedVideo,
        avatarUrl: avatarToUse,
        targetAge,
        availability: utcAvail,
        uid: registeredUid
      } as any);

      if (!result.success) {
        setErrorStatus(result.error || 'Failed to submit application. Please try again.');
        setIsSubmitting(false);
        return;
      }

      // Create user document with role tutor_pending and sign out so they aren't logged in
      await setDoc(doc(db, 'users', registeredUid), {
        uid: registeredUid,
        email: email.trim().toLowerCase(),
        fullName: fullName.trim(),
        role: 'tutor_pending',
        whatsapp: whatsapp.trim(),
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      }, { merge: true });

      await signOutContext();

      setIsSuccess(true);
    } catch (err: any) {
      setErrorStatus(err.message || 'An error occurred during submission.');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Real-time completeness checks
  const hasContact = fullName.trim().length > 0 && email.trim().length > 0 && whatsapp.trim().length > 0;
  const hasSecurity = !!user || (password.length >= 6 && password === confirmPassword);
  const hasFocus = expertise.length > 0 && yearsOfExperience.length > 0;
  const hasBio = experience.trim().length > 0 && detailedBio.trim().length > 0;
  const hasQuote = quote.trim().length > 0;
  const hasPhoto = uploadedPhotoBase64.length > 0;
  const hasSlots = Object.values(availability).some((dayData: any) => dayData.active && dayData.slots && dayData.slots.length > 0);

  const checks = [hasContact, hasSecurity, hasFocus, hasPhoto, hasQuote, hasBio, hasSlots];
  const completedChecksCount = checks.filter(Boolean).length;
  const progressPercent = Math.round((completedChecksCount / checks.length) * 100);

  return (
    <div className="min-h-screen bg-slate-50 font-sans flex flex-col justify-between">
      {/* Navbar/Header */}
      <header className="bg-white border-b border-slate-100 py-5 px-6 sticky top-0 z-40 shadow-sm">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <Link to="/" className="flex items-center gap-3">
            <div className="w-14 h-14 rounded-xl flex items-center justify-center shrink-0">
              <BrandLogo 
                logoUrl={logoUrl} 
                className="w-full h-full"
              />
            </div>
            <span className="text-xl font-bold tracking-tight text-primary font-serif">{academyName}</span>
          </Link>
          
          <Link 
            to="/" 
            className="flex items-center gap-2 text-slate-650 hover:text-primary transition-colors text-sm font-bold"
          >
            <ChevronLeft size={16} />
            <span>Back to Home</span>
          </Link>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 max-w-6xl w-full mx-auto px-6 py-12 grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
        
        {/* Left Column: Requirements & Standard Information */}
        <div className="lg:col-span-4 space-y-6 lg:sticky lg:top-28">
          <div>
            <span className="px-3 py-1 bg-indigo-55 text-white text-[10px] font-black uppercase tracking-widest rounded-full inline-block mb-3 shadow-sm">
              አስተማሪ ይሁኑ • Join Staff
            </span>
            <h1 className="text-3xl md:text-4xl font-serif font-black text-[#2D3329] leading-tight">
              Bring language roots to <span className="text-indigo-65 font-bold">young minds</span>.
            </h1>
            <p className="text-slate-500 text-xs mt-3 leading-relaxed font-sans">
              Help children in North America and Europe speak, understand, and read Amharic or Ge'ez. Share our rich cultural legacy with highly interactive, gamified lesson material.
            </p>
          </div>

          {/* Real-Time Completeness Meter */}
          <div className="bg-slate-900 text-white rounded-[24px] p-6 shadow-xl border border-slate-800 space-y-4">
            <div className="flex justify-between items-center border-b border-slate-800 pb-3">
              <h3 className="font-serif font-black text-xs tracking-wide text-indigo-300 uppercase">Profile Checklist</h3>
              <span className="text-xs font-mono font-bold px-2.5 py-0.5 bg-indigo-600 rounded-full text-white">
                {progressPercent}% Done
              </span>
            </div>
            
            {/* Progress Bar */}
            <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
              <div 
                className="bg-indigo-500 h-full transition-all duration-300 rounded-full"
                style={{ width: `${progressPercent}%` }}
              ></div>
            </div>

            <ul className="space-y-2.5 pt-1 text-[11px] font-bold text-slate-300">
              <li className="flex items-center gap-2.5">
                <span className={cn(
                  "w-4 h-4 rounded-full flex items-center justify-center shrink-0 text-[9px] font-black transition-colors",
                  hasContact ? "bg-green-500 text-white" : "bg-slate-850 text-slate-500 border border-slate-750"
                )}>
                  {hasContact ? "✓" : "1"}
                </span>
                <span className={hasContact ? "text-slate-500 line-through font-medium" : ""}>Contact Details</span>
              </li>
              <li className="flex items-center gap-2.5">
                <span className={cn(
                  "w-4 h-4 rounded-full flex items-center justify-center shrink-0 text-[9px] font-black transition-colors",
                  hasSecurity ? "bg-green-500 text-white" : "bg-slate-850 text-slate-500 border border-slate-750"
                )}>
                  {hasSecurity ? "✓" : "2"}
                </span>
                <span className={hasSecurity ? "text-slate-500 line-through font-medium" : ""}>Portal Password</span>
              </li>
              <li className="flex items-center gap-2.5">
                <span className={cn(
                  "w-4 h-4 rounded-full flex items-center justify-center shrink-0 text-[9px] font-black transition-colors",
                  hasFocus ? "bg-green-500 text-white" : "bg-slate-850 text-slate-500 border border-slate-750"
                )}>
                  {hasFocus ? "✓" : "3"}
                </span>
                <span className={hasFocus ? "text-slate-500 line-through font-medium" : ""}>Language Focus</span>
              </li>
              <li className="flex items-center gap-2.5">
                <span className={cn(
                  "w-4 h-4 rounded-full flex items-center justify-center shrink-0 text-[9px] font-black transition-colors",
                  hasPhoto ? "bg-green-500 text-white" : "bg-slate-850 text-slate-500 border border-slate-750"
                )}>
                  {hasPhoto ? "✓" : "4"}
                </span>
                <span className={hasPhoto ? "text-slate-500 line-through font-medium" : ""}>Portrait Photo</span>
              </li>
              <li className="flex items-center gap-2.5">
                <span className={cn(
                  "w-4 h-4 rounded-full flex items-center justify-center shrink-0 text-[9px] font-black transition-colors",
                  hasQuote ? "bg-green-500 text-white" : "bg-slate-850 text-slate-500 border border-slate-750"
                )}>
                  {hasQuote ? "✓" : "5"}
                </span>
                <span className={hasQuote ? "text-slate-500 line-through font-medium" : ""}>Greeting Tagline</span>
              </li>
              <li className="flex items-center gap-2.5">
                <span className={cn(
                  "w-4 h-4 rounded-full flex items-center justify-center shrink-0 text-[9px] font-black transition-colors",
                  hasBio ? "bg-green-500 text-white" : "bg-slate-850 text-slate-500 border border-slate-750"
                )}>
                  {hasBio ? "✓" : "6"}
                </span>
                <span className={hasBio ? "text-slate-500 line-through font-medium" : ""}>Bio & Philosophy</span>
              </li>
              <li className="flex items-center gap-2.5">
                <span className={cn(
                  "w-4 h-4 rounded-full flex items-center justify-center shrink-0 text-[9px] font-black transition-colors",
                  hasSlots ? "bg-green-500 text-white" : "bg-slate-850 text-slate-500 border border-slate-750"
                )}>
                  {hasSlots ? "✓" : "7"}
                </span>
                <span className={hasSlots ? "text-slate-500 line-through font-medium" : ""}>Weekly Active Slots</span>
              </li>
            </ul>

            <div className="pt-2 text-[10px] text-slate-400 leading-normal font-sans font-medium">
              💡 <strong>Guidance tip:</strong> Complete all items to construct a stunning, trustworthy professional profile that parents abroad can book in confidence!
            </div>
          </div>

          <div className="space-y-4">
            <div className="flex gap-4 p-5 bg-white border border-slate-100 rounded-2xl shadow-sm">
              <div className="w-10 h-10 bg-indigo-50 text-indigo-700 rounded-xl flex items-center justify-center shrink-0 border border-indigo-100/30">
                <Heart size={18} />
              </div>
              <div>
                <h3 className="font-bold text-slate-900 text-xs">Patience is Prime</h3>
                <p className="text-slate-500 text-[11px] mt-1 leading-relaxed">
                  Youth abroad are starting from scratch. We emphasize supportive speech loops, high encouragement, and games.
                </p>
              </div>
            </div>

            <div className="flex gap-4 p-5 bg-white border border-slate-100 rounded-2xl shadow-sm">
              <div className="w-10 h-10 bg-amber-50 text-amber-600 rounded-xl flex items-center justify-center shrink-0 border border-amber-100/30">
                <Award size={18} />
              </div>
              <div>
                <h3 className="font-bold text-slate-900 text-xs">Aesthetic Profiles</h3>
                <p className="text-slate-500 text-[11px] mt-1 leading-relaxed">
                  Provide a clean professional portrait tagline and lesson introductory video. This makes booking selections warm and premium.
                </p>
              </div>
            </div>

            <div className="flex gap-4 p-5 bg-white border border-slate-100 rounded-2xl shadow-sm">
              <div className="w-10 h-10 bg-emerald-50 text-emerald-600 rounded-xl flex items-center justify-center shrink-0 border border-emerald-100/30">
                <GraduationCap size={18} />
              </div>
              <div>
                <h3 className="font-bold text-slate-900 text-xs">Tutor Registry Sync</h3>
                <p className="text-slate-500 text-[11px] mt-1 leading-relaxed">
                  Your submitted profile will automatically join our tutor directory, ready for parents to book trial runs in real-time.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Interactive Professional Form */}
        <div className="lg:col-span-8 bg-white rounded-[32px] border border-slate-100 shadow-xl p-6 md:p-10">
          <AnimatePresence mode="wait">
            {!isSuccess ? (
              <motion.div
                key="tutor-apply-form"
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -15 }}
                className="space-y-8"
              >
                <div>
                  <h2 className="text-2xl font-bold font-serif text-slate-900">Professional Application</h2>
                  <p className="text-slate-400 text-xs mt-1">
                    Fill in your portfolio details. Completed entries appear directly inside our selective parent bookings list!
                  </p>
                </div>

                {errorStatus && (
                  <div className="p-4 bg-rose-50 text-rose-700 text-xs rounded-2xl border border-rose-100 font-bold space-y-1">
                    <p className="font-sans">🚨 Submission Error:</p>
                    <p className="font-mono text-[11px] font-normal">{errorStatus}</p>
                  </div>
                )}

                <form onSubmit={handleSubmit} className="space-y-8">
                  {/* Section 1: Core Contact */}
                  <div className="bg-slate-55/40 p-6 rounded-3xl border border-slate-100/60 space-y-5">
                    <h3 className="text-xs font-black uppercase text-slate-400 tracking-wider flex items-center gap-2">
                      <Globe size={14} className="text-slate-400" />
                      1. Contact & Location
                    </h3>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                      <div className="space-y-2">
                        <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider">
                          Full Name
                        </label>
                        <input 
                          type="text" 
                          required
                          value={fullName}
                          onChange={(e) => setFullName(e.target.value)}
                          placeholder="e.g. Martha Hailu"
                          className="w-full bg-white border border-slate-200 rounded-xl px-4 py-3 text-xs focus:outline-none focus:ring-2 focus:ring-primary/10 tracking-tight"
                        />
                      </div>

                      <div className="space-y-2">
                        <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider">
                          Email Address
                        </label>
                        <input 
                          type="email" 
                          required
                          disabled={!!user}
                          value={email}
                          onChange={(e) => setEmail(e.target.value)}
                          placeholder="e.g. martha@heritage.academy"
                          className="w-full bg-white border border-slate-200 rounded-xl px-4 py-3 text-xs focus:outline-none focus:ring-2 focus:ring-primary/10 tracking-tight disabled:bg-slate-100 disabled:text-slate-400 font-mono"
                        />
                        {user && (
                          <div className="mt-1.5 p-2 bg-indigo-50/70 border border-indigo-100 rounded-lg text-[10px] text-indigo-700 leading-normal font-semibold">
                            Logged in as Parent ({user.email}). Submitting will convert/link this account. Want to use a different email?{' '}
                            <button
                              type="button"
                              onClick={async () => {
                                await signOut(auth);
                                window.location.reload();
                              }}
                              className="text-indigo-600 hover:text-indigo-800 underline font-black cursor-pointer"
                            >
                              Sign Out First
                            </button>
                          </div>
                        )}
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                      <div className="space-y-2">
                        <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider">
                          WhatsApp Number
                        </label>
                        <input 
                          type="text" 
                          required
                          value={whatsapp}
                          onChange={(e) => setWhatsapp(e.target.value)}
                          placeholder="e.g. +251 911 234 567"
                          className="w-full bg-white border border-slate-200 rounded-xl px-4 py-3 text-xs focus:outline-none focus:ring-2 focus:ring-primary/10 font-mono"
                        />
                      </div>

                      <div className="space-y-2">
                        <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider">
                          Primary Timezone
                        </label>
                        <select 
                          value={timezone}
                          onChange={(e) => setTimezone(e.target.value)}
                          className="w-full bg-white border border-slate-200 rounded-xl px-4 py-3 text-xs focus:outline-none focus:ring-2 focus:ring-primary/10 cursor-pointer"
                        >
                          <option value="EST (New York / Washington DC)">EST (New York / DC)</option>
                          <option value="CST (Chicago)">CST (Chicago)</option>
                          <option value="PST (Los Angeles / Seattle)">PST (Los Angeles)</option>
                          <option value="GMT (London / UK)">GMT (London / UK)</option>
                          <option value="EAT (Addis Ababa)">EAT (Addis Ababa)</option>
                          <option value="Europe (Paris / Berlin)">Europe (Paris / Berlin)</option>
                        </select>
                      </div>
                    </div>

                    {!user && (
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-5 pt-2">
                        <div className="space-y-2">
                          <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider">
                            Choose Portal Password
                          </label>
                          <input 
                            type="password" 
                            required
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            placeholder="At least 6 characters"
                            className="w-full bg-white border border-slate-200 rounded-xl px-4 py-3 text-xs focus:outline-none focus:ring-2 focus:ring-primary/10 tracking-tight font-mono"
                          />
                        </div>

                        <div className="space-y-2">
                          <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider">
                            Confirm Password
                          </label>
                          <input 
                            type="password" 
                            required
                            value={confirmPassword}
                            onChange={(e) => setConfirmPassword(e.target.value)}
                            placeholder="Re-enter password"
                            className="w-full bg-white border border-slate-200 rounded-xl px-4 py-3 text-xs focus:outline-none focus:ring-2 focus:ring-primary/10 tracking-tight font-mono"
                          />
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Section 2: Professional Qualifications */}
                  <div className="bg-slate-55/40 p-6 rounded-3xl border border-slate-100/60 space-y-5">
                    <h3 className="text-xs font-black uppercase text-slate-400 tracking-wider flex items-center gap-2">
                      <Award size={14} className="text-slate-400" />
                      2. Tutor Credentials & Rate
                    </h3>

                    <div className="grid grid-cols-1 gap-5">
                      <div className="space-y-2">
                        <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider">
                          Primary Syllabus Specialization
                        </label>
                        <select 
                          value={expertise}
                          onChange={(e) => setExpertise(e.target.value)}
                          className="w-full bg-white border border-slate-200 rounded-xl px-4 py-3 text-xs focus:outline-none focus:ring-2 focus:ring-primary/10 cursor-pointer"
                        >
                          <option value="Amharic">Amharic</option>
                          <option value="Ge'ez">Ge'ez</option>
                        </select>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                      <div className="space-y-2">
                        <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider">
                          Years of Language Teaching
                        </label>
                        <select 
                          value={yearsOfExperience}
                          onChange={(e) => setYearsOfExperience(e.target.value)}
                          className="w-full bg-white border border-slate-200 rounded-xl px-4 py-3 text-xs focus:outline-none focus:ring-2 focus:ring-primary/10 cursor-pointer"
                        >
                          <option value="1-2 years">1-2 years</option>
                          <option value="3-5 years">3-5 years</option>
                          <option value="5-10 years">5-10 years</option>
                          <option value="10+ years">10+ years</option>
                        </select>
                      </div>

                      <div className="space-y-2">
                        <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider flex items-center justify-between">
                          <span>Constant Hourly Rate (USD/hr)</span>
                          <span className="text-[9px] text-indigo-650 font-black font-mono">Standard Compensation</span>
                        </label>
                        <div className="bg-slate-50 border border-slate-205 rounded-xl px-4 py-3 text-xs font-bold text-slate-800 flex items-center justify-between">
                          <span className="font-mono text-indigo-600 font-extrabold">${hourlyRate} / hour</span>
                          <span className="text-[9px] text-slate-400 font-medium">Constant (Set by Admin)</span>
                        </div>
                      </div>
                    </div>

                    <div className="pt-2">
                      <label className="flex items-center gap-3 bg-white p-3.5 rounded-2xl border border-slate-100 cursor-pointer hover:border-indigo-100 transition shadow-sm select-none">
                        <input 
                          type="checkbox" 
                          checked={isCertified}
                          onChange={(e) => setIsCertified(e.target.checked)}
                          className="w-4.5 h-4.5 rounded border-slate-300 text-indigo-600 focus:ring-indigo-55"
                        />
                        <div>
                          <p className="text-xs font-bold text-slate-800">I hold a certified teaching degree or language credentials</p>
                          <p className="text-[10px] text-slate-400 mt-0.5">Displays a distinctive "Certified Educator" ribbon badge on your public booking card.</p>
                        </div>
                      </label>
                    </div>
                  </div>

                  {/* Section 3: Visual Marketing Card Profile */}
                  <div className="bg-slate-55/40 p-6 rounded-3xl border border-slate-100/60 space-y-5">
                    <h3 className="text-xs font-black uppercase text-slate-400 tracking-wider flex items-center gap-2">
                      <Sparkles size={14} className="text-slate-400" />
                      3. Public Profile Portfolio Design
                    </h3>

                    <div className="space-y-4">
                      <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider">
                        Portrait Profile Portrait Photo (Base64 Compressed)
                      </label>
                      
                      <div className="space-y-4 animate-in fade-in duration-200">
                        {uploadedPhotoBase64 ? (
                          <div className="flex flex-col items-center gap-3 p-5 bg-white border border-slate-150 rounded-2xl">
                            <div className="w-24 h-24 rounded-full overflow-hidden border-4 border-indigo-50 shadow-md">
                              <img 
                                src={uploadedPhotoBase64} 
                                alt="Real-time upload preview" 
                                className="w-full h-full object-cover"
                              />
                            </div>
                            <div className="text-center">
                              <span className="text-[9px] font-bold text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded-full uppercase tracking-widest">
                                Live Image Ready!
                              </span>
                              <p className="text-[10px] text-slate-500 mt-1">This high-resolution file will render perfectly in our staff index.</p>
                            </div>
                            <button
                              type="button"
                              onClick={() => setUploadedPhotoBase64('')}
                              className="text-[10px] font-bold text-rose-500 hover:underline flex items-center gap-1 mt-1 cursor-pointer"
                            >
                              Try another picture
                            </button>
                          </div>
                        ) : (
                          <label className="border-2 border-dashed border-slate-200 hover:border-indigo-400 bg-white p-6 rounded-2xl flex flex-col items-center justify-center gap-2 cursor-pointer transition-colors text-center group">
                            <input 
                              type="file" 
                              accept="image/*"
                              onChange={handlePhotoUpload}
                              className="hidden" 
                            />
                            <div className="w-10 h-10 bg-indigo-50 group-hover:bg-indigo-100 rounded-full flex items-center justify-center text-indigo-600 transition-colors">
                              <Upload size={18} />
                            </div>
                            <div>
                              <span className="text-xs font-bold text-slate-800 block">Select Profile Portrait Photo</span>
                              <span className="text-[10px] text-slate-450 block mt-0.5">Supports PNG, JPG, or WEBP up to 2MB</span>
                            </div>
                          </label>
                        )}
                      </div>
                    </div>

                    <div className="space-y-2">
                      <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider flex items-center justify-between">
                        <span>Ato/Wro Welcome Quote Tagline</span>
                        <span className="text-[9px] text-slate-450 font-bold">Amharic Characters Preferred!</span>
                      </label>
                      <input 
                        type="text" 
                        required
                        value={quote}
                        onChange={(e) => setQuote(e.target.value)}
                        placeholder="e.g. ሰላም ልጆች! I cannot wait to explore early Ge'ez puzzles with you! Let's play together."
                        className="w-full bg-white border border-slate-200 rounded-xl px-4 py-3 text-xs focus:outline-none focus:ring-2 focus:ring-primary/10 tracking-tight italic"
                      />
                      <p className="text-[9px] text-slate-400 mt-0.5">This greeting displays right inside the welcome speech box on your booking profile.</p>
                    </div>

                    <div className="space-y-2">
                      <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider">
                        Short Summary of Experiences
                      </label>
                      <input 
                        type="text" 
                        required
                        value={experience}
                        onChange={(e) => setExperience(e.target.value)}
                        placeholder="e.g. Certified public school tutor with 4 years hosting speech camps for children abroad"
                        className="w-full bg-white border border-slate-200 rounded-xl px-4 py-3 text-xs focus:outline-none focus:ring-2 focus:ring-primary/10"
                      />
                    </div>

                    <div className="space-y-2">
                      <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider">
                        Detailed Bio & Teaching Philosophy (Profile Paragraph)
                      </label>
                      <textarea 
                        required
                        value={detailedBio}
                        onChange={(e) => setDetailedBio(e.target.value)}
                        placeholder="Explain your approach to helping kids abroad. For example, how you combine sound bubbles, gamified shape matches, and Amharic letter songs to build confidence..."
                        rows={4}
                        className="w-full bg-white border border-slate-200 rounded-xl px-4 py-3 text-xs focus:outline-none focus:ring-2 focus:ring-primary/10 leading-relaxed resize-none"
                      />
                    </div>

                    <div className="space-y-2">
                      <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider flex items-center justify-between">
                        <span>YouTube Introductory Presentation Video link</span>
                        <span className="text-[9px] text-slate-400 font-medium">Standard or Shortened Links OK</span>
                      </label>
                      <div className="relative">
                        <Video size={14} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
                        <input 
                          type="url" 
                          value={videoUrl}
                          onChange={(e) => setVideoUrl(e.target.value)}
                          placeholder="e.g. https://www.youtube.com/watch?v=dQw4w9WgXcQ"
                          className="w-full bg-white border border-slate-200 rounded-xl pl-9 pr-4 py-3 text-xs focus:outline-none focus:ring-2 focus:ring-primary/10 font-mono"
                        />
                      </div>
                      <p className="text-[9px] text-slate-400 mt-0.5">Please provide an intro clip presenting your background. Displays an interactive modal window for parents.</p>
                    </div>
                  </div>

                  {/* Section 4: Initial Weekly Availability */}
                  <div className="bg-slate-55/40 p-6 rounded-3xl border border-slate-100/60 space-y-5">
                    <h3 className="text-xs font-black uppercase text-slate-400 tracking-wider flex items-center gap-2">
                      <Clock size={14} className="text-slate-400" />
                      4. Initial Weekly Availability Settings
                    </h3>
                    
                    <p className="text-[11px] text-slate-550 leading-relaxed font-sans">
                      Parents can book trial sessions and live lessons directly using our interactive booking grid. Set up your regular weekly available days and hours below (shown in your timezone configured as <strong>{timezone}</strong>). You can easily update these anytime from your Tutor Dashboard after onboarding. <strong className="text-indigo-600 block mt-1.5 font-bold">⚠️ Note: Setting up highly accurate and consistent availability slots is EXTREMELY important to maximize parent booking visual matches and recurring bookings!</strong>
                    </p>

                    <div className="space-y-3">
                      {['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'].map((day) => {
                        const dayData = availability[day] || { active: false, slots: [] };
                        return (
                          <div key={day} className="p-4 bg-white rounded-2xl border border-slate-200/60 space-y-3 shadow-sm transition-all hover:border-slate-300">
                            <div className="flex items-center justify-between">
                              <label className="flex items-center gap-2.5 cursor-pointer select-none">
                                <input 
                                  type="checkbox"
                                  checked={dayData.active}
                                  onChange={() => toggleDayActive(day)}
                                  className="w-4 h-4 rounded border-slate-300 text-indigo-600 focus:ring-indigo-505"
                                />
                                <span className="text-xs font-extrabold capitalize text-slate-800 tracking-wide font-sans">{day}s</span>
                              </label>
                              
                              <span className={cn(
                                "text-[9px] font-bold px-2 py-0.5 rounded-full",
                                dayData.active ? "bg-indigo-50 text-indigo-700 border border-indigo-100" : "bg-slate-100 text-slate-400"
                              )}>
                                {dayData.active ? `${dayData.slots?.length || 0} Slots Active` : "Inactive"}
                              </span>
                            </div>

                            {dayData.active && (
                              <div className="space-y-4 pt-3.5 border-t border-slate-100/70 animate-in fade-in duration-200">
                                <div className="flex flex-col sm:flex-row justify-between gap-1.5">
                                  <p className="text-[10px] text-slate-550">
                                    Toggle slot times to add or remove them from your weekly calendar:
                                  </p>
                                  <div className="flex items-center gap-1 text-[9px] font-black text-amber-700 bg-amber-55 px-2 py-0.5 rounded-full border border-amber-100/80 w-fit">
                                    <span>✨</span>
                                    <span>Peak Demand Hours Abroad</span>
                                  </div>
                                </div>
                                <div className="grid grid-cols-4 sm:grid-cols-6 md:grid-cols-8 gap-1.5">
                                  {['00:00', '01:00', '02:00', '03:00', '04:00', '05:00', '06:00', '07:00', '08:00', '09:00', '10:00', '11:00', '12:00', '13:00', '14:00', '15:00', '16:00', '17:00', '18:00', '19:00', '20:00', '21:00', '22:00', '23:00'].map((slotTime) => {
                                    const isChosen = dayData.slots?.includes(slotTime);
                                    
                                    // Determine if this is peak hours for families abroad (EAT E. Africa Time):
                                    const isWeekend = day === 'saturday' || day === 'sunday';
                                    const hr = parseInt(slotTime.split(':')[0], 10);
                                    const isPeak = isWeekend ? (hr >= 16 || hr <= 2) : (hr >= 22 || hr <= 5);

                                    return (
                                      <button
                                        key={slotTime}
                                        type="button"
                                        onClick={() => toggleSlot(day, slotTime)}
                                        className={cn(
                                          "py-2 text-[10px] font-extrabold rounded-xl border transition-all cursor-pointer font-sans flex flex-col items-center justify-center gap-0.5 min-w-[50px]",
                                          isChosen 
                                            ? "bg-indigo-600 text-white border-indigo-650 shadow-sm font-black"
                                            : isPeak
                                              ? "bg-amber-50/45 text-amber-800 border-amber-200 hover:border-amber-400"
                                              : "bg-slate-50/70 text-slate-600 border-slate-200 hover:border-indigo-300"
                                        )}
                                      >
                                        <span>{slotTime}</span>
                                        {isPeak && !isChosen && (
                                          <span className="text-[7px] text-amber-500 font-extrabold uppercase tracking-wide leading-none">✨ Peak</span>
                                        )}
                                      </button>
                                    );
                                  })}
                                </div>
                              </div>
                            )}
                          </div>
                        );
                      })}
                    </div>


                  </div>

                  {/* Submit Button */}
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full btn-primary py-4 rounded-2xl flex items-center justify-center gap-2 hover:scale-[1.01] transition-transform shadow-lg shadow-indigo-600/10 cursor-pointer"
                  >
                    {isSubmitting ? (
                      <>
                        <Loader2 className="w-4 h-4 animate-spin text-white" />
                        <span>Submitting Your Application...</span>
                      </>
                    ) : (
                      <>
                        <Send size={15} />
                        <span>Submit Professional Staff Application</span>
                      </>
                    )}
                  </button>
                </form>
              </motion.div>
            ) : (
              <motion.div
                key="tutor-apply-success"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="py-12 text-center flex flex-col items-center justify-center space-y-6"
              >
                <div className="w-20 h-20 bg-emerald-50 text-emerald-600 rounded-full flex items-center justify-center border border-emerald-100 shadow-inner">
                  <CheckCircle2 size={40} />
                </div>
                
                <div className="space-y-1">
                  <h2 className="text-3xl font-black font-serif text-slate-900 leading-tight">
                    Application Logged!
                  </h2>
                  <h3 className="text-lg font-bold font-serif text-emerald-700">
                    እናመሰግናለን (Thank You)
                  </h3>
                </div>
                
                <p className="text-slate-500 text-xs max-w-sm leading-relaxed">
                  We've received your professional tutoring profile, <strong>{fullName}</strong>. We have registered your real Firebase Authentication credentials. Once our coordinators approve your credentials, you will be able to log in to your Tutor Dashboard using your email and chosen password!
                </p>

                <div className="pt-4 flex flex-col sm:flex-row gap-4 w-full justify-center max-w-md">
                  <button 
                    onClick={() => navigate('/')}
                    className="bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold py-3.5 px-6 rounded-2xl text-xs uppercase tracking-wider transition-all cursor-pointer flex-1"
                  >
                    Return Home
                  </button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

      </main>

      {/* Footer */}
      <footer className="bg-slate-900 text-slate-500 py-10 px-6 border-t border-slate-800 shrink-0 mt-12">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-6 text-xs font-medium tracking-wide">
          <p>© 2026 HabKids. All pedagogical content is property of HabKids.</p>
        </div>
      </footer>
    </div>
  );
}

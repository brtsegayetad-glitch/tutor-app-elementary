import { BookOpen, Star, Clock, Globe, MessageSquare, ChevronRight, Menu, X, LayoutDashboard, Linkedin, Facebook, Youtube, ChevronDown, Plus, Minus, Gift } from 'lucide-react';
import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { subscribeToSettings } from '../services/dataService';
import BrandLogo from '../components/BrandLogo';
import SupportWidget from '../components/SupportWidget';
import BubblePopSandbox from '../components/BubblePopSandbox';

const faqs = [
  {
    question: "What teaching methods do HabKids use for children abroad?",
    answer: "We employ a play-based, highly interactive curriculum tailored specifically for children aged 6–12. Our lessons connect kids to their heritage using localized storytelling, gamified Ge'ez alphabet exercises, sound-bubble matches, and digital flashcards that make learning feel natural and engaging."
  },
  {
    question: "How does the Ge'ez script curriculum adapt to different age groups?",
    answer: "We support two tailored learning pathways. For younger children and absolute beginners (Level 1), we focus on foundational shapes, sound recognition, and word-to-image association. For older or more advanced children (Level 2+), the curriculum ramps up to advanced word architectural puzzles, phonetic blending, sentence structure, and conversational confidence."
  },
  {
    question: "What is the scheduling system like? Can we customize hours?",
    answer: "Yes, absolute scheduling flexibility is at the core of our platform. Parents can access the scheduling panel to select trial sessions, set reoccurring weekly spots, view tutors' real-time calendars matching your system's timezone detector (e.g. Africa/Nairobi, EST, PST), and cancel or reschedule sessions with ease."
  },
  {
    question: "Who are the tutors at HabKids?",
    answer: "Our educators are highly trained, native-speaking veteran Amharic teachers experienced in instructing children in international and abroad environments. They are patient, child-centric, and vetted to supply welcoming, secure, and encouraging spaces for interactive bilingual learning."
  },
  {
    question: "How long is each live tutoring session?",
    answer: "Regular sessions are 50 minutes long—the optimized window of attention for children in this age group. This duration is perfectly balanced with our interactive game suites, quizzes, and live vocal drills to maximize retention without causing screen fatigue."
  },
  {
    question: "Can parents track their child's language-learning progress?",
    answer: "Absolutely! Parents get detailed, comprehensive performance insights inside the Parent Portal. Following trial sessions and milestone assessments, you will receive exhaustive Evaluation Reports outlining their accuracy in specific letter families, spelling progress, and speech confidence."
  }
];

export default function LandingPage() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [openFaqIndex, setOpenFaqIndex] = useState<number | null>(null);
  const [showAmbassadorModal, setShowAmbassadorModal] = useState(false);
  const { user, signOut } = useAuth();
  
  const getCurriculumUrl = () => {
    if (user) {
      if (user.role === 'tutor') return '/tutor?library=true';
      if (user.role === 'admin') return '/admin?library=true';
      return '/parent?library=true';
    }
    return '/login?library=true';
  };
  
  const [settings, setSettings] = useState(() => {
    try {
      const cached = localStorage.getItem('habkids_cached_settings');
      if (cached) {
        const data = JSON.parse(cached);
        if (data) {
          const rawName = data.founderName || '';
          const rawLink = data.founderLinkedIn || '';
          return {
            academyName: data.academyName || 'HabKids',
            founderName: (!rawName || rawName === 'Brtsegaye Tad') ? 'Biruk Tadesse' : rawName,
            founderLinkedIn: (!rawLink || rawLink.includes('brtsegayetad')) ? 'https://www.linkedin.com/in/biruk-tadesse-1750a3223/' : rawLink,
            welcomeMotto: data.welcomeMotto || 'Expanding heritage language tutoring and curriculum worldwide',
            instagramUrl: data.instagramUrl || 'https://www.instagram.com/abyssiniatutors',
            whatsappUrl: data.whatsappUrl || 'https://wa.me/251940651491',
            facebookUrl: data.facebookUrl || 'https://www.facebook.com/abyssiniatutors',
            youtubeUrl: data.youtubeUrl || 'https://www.youtube.com/@abyssiniatutors',
            activeLogoUrl: data.activeLogoUrl || '',
            referralCommissionRate: typeof data.referralCommissionRate === 'number' ? data.referralCommissionRate : 9,
            referralDiscountPercent: typeof data.referralDiscountPercent === 'number' ? data.referralDiscountPercent : 10,
            referralBonusCredits: typeof data.referralBonusCredits === 'number' ? data.referralBonusCredits : 1
          };
        }
      }
    } catch (e) {
      console.warn("Could not parse cached settings in LandingPage initial state:", e);
    }
    return {
      academyName: 'HabKids',
      founderName: 'Biruk Tadesse',
      founderLinkedIn: 'https://www.linkedin.com/in/biruk-tadesse-1750a3223/',
      welcomeMotto: 'Expanding heritage language tutoring and curriculum worldwide',
      instagramUrl: 'https://www.instagram.com/abyssiniatutors',
      whatsappUrl: 'https://wa.me/251940651491',
      facebookUrl: 'https://www.facebook.com/abyssiniatutors',
      youtubeUrl: 'https://www.youtube.com/@abyssiniatutors',
      activeLogoUrl: '',
      referralCommissionRate: 9,
      referralDiscountPercent: 10,
      referralBonusCredits: 1
    };
  });

  const [referralCode, setReferralCode] = useState<string | null>(null);
  const [showReferralBanner, setShowReferralBanner] = useState(false);

  useEffect(() => {
    const code = localStorage.getItem('habkids_referral_code');
    if (code) {
      setReferralCode(code);
      setShowReferralBanner(true);
    }
  }, []);

  useEffect(() => {
    const unsubscribe = subscribeToSettings((data) => {
      if (data) {
        const rawName = data.founderName || '';
        const rawLink = data.founderLinkedIn || '';
        setSettings({
          academyName: data.academyName || 'HabKids',
          founderName: (!rawName || rawName === 'Brtsegaye Tad') ? 'Biruk Tadesse' : rawName,
          founderLinkedIn: (!rawLink || rawLink.includes('brtsegayetad')) ? 'https://www.linkedin.com/in/biruk-tadesse-1750a3223/' : rawLink,
          welcomeMotto: data.welcomeMotto || 'Expanding heritage language tutoring and curriculum worldwide',
          instagramUrl: data.instagramUrl || 'https://www.instagram.com/abyssiniatutors',
          whatsappUrl: data.whatsappUrl || 'https://wa.me/251940651491',
          facebookUrl: data.facebookUrl || 'https://www.facebook.com/abyssiniatutors',
          youtubeUrl: data.youtubeUrl || 'https://www.youtube.com/@abyssiniatutors',
          activeLogoUrl: data.activeLogoUrl || '',
          referralCommissionRate: typeof data.referralCommissionRate === 'number' ? data.referralCommissionRate : 9,
          referralDiscountPercent: typeof data.referralDiscountPercent === 'number' ? data.referralDiscountPercent : 10,
          referralBonusCredits: typeof data.referralBonusCredits === 'number' ? data.referralBonusCredits : 1
        });
      }
    });
    return () => unsubscribe();
  }, []);

  return (
    <div className="min-h-screen bg-white">
      {/* Referral Welcome Banner */}
      {showReferralBanner && referralCode && (
        <div className="bg-slate-900 text-white py-2 px-4 text-center relative z-[70] animate-in slide-in-from-top duration-500">
          <div className="max-w-7xl mx-auto flex items-center justify-center gap-3">
            <Gift size={14} className="text-secondary animate-pulse" />
            <p className="text-[11px] md:text-xs font-bold tracking-wide">
              Invitation Active! Your <span className="text-secondary">{settings.referralDiscountPercent}% Heritage Discount</span> will be applied at checkout.
            </p>
            <button 
              onClick={() => setShowReferralBanner(false)}
              className="ml-4 text-white/50 hover:text-white transition-colors"
            >
              <X size={14} />
            </button>
          </div>
        </div>
      )}

      {/* Navigation - Changed from fixed to sticky to work with the banner */}
      <nav className="sticky top-0 w-full z-50 bg-white/90 backdrop-blur-md border-b border-slate-100">
        <div className="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-3">
            <div className="w-14 h-14 rounded-xl flex items-center justify-center shrink-0">
              <BrandLogo 
                logoUrl={settings.activeLogoUrl || '/logo_option_one.png'} 
                className="w-full h-full"
              />
            </div>
            <span className="text-2xl font-bold tracking-tight text-primary">{settings.academyName}</span>
          </Link>
          
          <div className="hidden md:flex items-center gap-8">
            <a href="#why-us" className="text-slate-600 font-medium hover:text-primary transition-colors text-sm">Why us</a>
            <a href="#how-it-works" className="text-slate-600 font-medium hover:text-primary transition-colors text-sm">How it works</a>
            <Link to="/become-tutor" className="text-slate-600 font-medium hover:text-primary transition-colors text-sm">Apply as a Tutor</Link>
            {user ? (
              <div className="flex items-center gap-4">
                <Link to={`/${user.role}`} className="flex items-center gap-2 btn-primary py-2 px-5 text-sm">
                  <LayoutDashboard size={14} />
                  Dashboard
                </Link>
                <button
                  type="button"
                  onClick={async () => {
                    await signOut();
                    window.location.reload();
                  }}
                  className="text-slate-600 hover:text-rose-600 font-semibold transition-colors text-sm cursor-pointer"
                >
                  Sign Out
                </button>
              </div>
            ) : (
              <div className="flex items-center gap-4">
                <Link to="/login" className="text-slate-600 font-semibold hover:text-primary transition-colors text-sm">Log In</Link>
                <Link to="/signup" className="text-slate-600 font-semibold hover:text-primary transition-colors text-sm">Sign Up</Link>
                <Link to="/book-trial" className="bg-blue-600 hover:bg-blue-700 text-white font-semibold transition-all px-6 py-2.5 rounded-lg shadow-sm flex items-center justify-center gap-2 cursor-pointer text-sm ml-2">Book Trial Session</Link>
              </div>
            )}
          </div>

          <button className="md:hidden text-primary" onClick={() => setIsMenuOpen(!isMenuOpen)}>
            {isMenuOpen ? <X size={28} /> : <Menu size={28} />}
          </button>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden absolute top-20 left-0 w-full bg-white border-b border-gray-100 p-6 flex flex-col gap-4 shadow-xl">
            <a href="#why-us" className="text-slate-600 font-bold" onClick={() => setIsMenuOpen(false)}>Why us</a>
            <a href="#how-it-works" className="text-slate-600 font-bold" onClick={() => setIsMenuOpen(false)}>How it works</a>
            <Link to="/become-tutor" className="text-slate-600 font-bold" onClick={() => setIsMenuOpen(false)}>Apply as a Tutor</Link>
            {user ? (
              <>
                <Link to={`/${user.role}`} className="btn-primary w-full text-center py-2.5" onClick={() => setIsMenuOpen(false)}>
                  Go to {user.role.charAt(0).toUpperCase() + user.role.slice(1)} Dashboard
                </Link>
                <button
                  type="button"
                  onClick={async () => {
                    await signOut();
                    setIsMenuOpen(false);
                    window.location.reload();
                  }}
                  className="w-full text-center font-bold text-rose-600 bg-rose-50 rounded-xl py-2 cursor-pointer transition-colors"
                >
                  Sign Out
                </button>
              </>
            ) : (
              <div className="flex flex-col gap-3">
                <Link to="/book-trial" className="bg-blue-600 hover:bg-blue-700 text-white font-semibold transition-all w-full text-center py-2.5 rounded-lg shadow-sm block cursor-pointer text-sm" onClick={() => setIsMenuOpen(false)}>Book Trial Session</Link>
                <div className="grid grid-cols-2 gap-3">
                  <Link to="/login" className="bg-slate-50 text-slate-600 font-bold text-center py-2.5 rounded-xl text-sm" onClick={() => setIsMenuOpen(false)}>Log In</Link>
                  <Link to="/signup" className="bg-slate-900 text-white font-bold text-center py-2.5 rounded-xl text-sm" onClick={() => setIsMenuOpen(false)}>Sign Up</Link>
                </div>
              </div>
            )}
          </div>
        )}
      </nav>

      {/* Hero Section */}
      <section className="pt-40 pb-20 px-6 bg-slate-50">
        <div className="max-w-7xl mx-auto grid lg:grid-cols-2 gap-16 items-center">
          <div className="max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-secondary/10 text-secondary border border-secondary/20 rounded-full text-xs font-bold uppercase tracking-widest mb-6">
              🇪🇹 Ethiopian Heritage Education
            </div>
            <h1 className="text-6xl md:text-8xl font-bold text-primary leading-[0.9] mb-8 tracking-tighter">
              Online Amharic and <span className="text-secondary italic">Ge'ez</span> Tutoring
            </h1>
            <p className="text-xl text-slate-500 mb-10 leading-relaxed max-w-lg">
              Helping children abroad preserve their Ethiopian heritage through interactive games and live lessons.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              {user ? (
                <Link to={`/${user.role}`} className="btn-primary text-lg px-10">
                  Enter Your Portal
                  <ChevronRight size={20} />
                </Link>
              ) : (
                <Link to="/book-trial" className="bg-blue-600 hover:bg-blue-700 text-white font-bold text-lg px-10 py-3.5 rounded-xl flex items-center justify-center gap-2 shadow-lg hover:scale-[1.01] transition-all cursor-pointer">
                  Book Trial Session
                  <ChevronRight size={20} />
                </Link>
              )}
              <a href="#how-it-works" className="btn-secondary text-sm">
                How it works
              </a>
            </div>
            
            <div className="mt-12 flex items-center gap-6">
              <div className="flex -space-x-2">
                {[1, 2, 3, 4].map(i => (
                  <div key={i} className="w-8 h-8 rounded-full border-2 border-white bg-slate-200"></div>
                ))}
              </div>
              <div className="text-xs">
                <div className="flex text-secondary mb-0.5">
                  {[1, 2, 3, 4, 5].map(i => <Star key={i} size={12} fill="currentColor" />)}
                </div>
                <p className="text-slate-400 font-bold uppercase tracking-widest">500+ Families Joined</p>
              </div>
            </div>
          </div>
          
          <div className="relative w-full max-w-lg lg:max-w-none mx-auto group">
            <BubblePopSandbox />
            <div className="absolute -bottom-6 -right-6 w-32 h-32 bg-white p-2 rounded-2xl shadow-2xl rotate-6 group-hover:rotate-0 transition-transform hidden sm:block border border-slate-100">
              <img 
                src="/homepage-preview.png" 
                alt="Children playing interactive Amharic Fidel bubble pop game" 
                className="w-full h-full object-cover rounded-xl"
                referrerPolicy="no-referrer"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Why Us */}
      <section id="why-us" className="section-padding bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="text-center max-w-3xl mx-auto mb-20">
            <p className="text-secondary font-bold text-xs uppercase tracking-widest mb-4">The Student Experience</p>
            <h2 className="text-4xl md:text-5xl font-bold text-primary mb-6">Why Modern Families Choose HabKids</h2>
            <p className="text-slate-500 text-lg">Connecting heritage through patient, specialized pedagogy and native expertise.</p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { 
                icon: <BookOpen />, 
                title: "Curriculum", 
                desc: "Proprietary course design specifically for non-native children in English-speaking societies."
              },
              { 
                icon: <Star />, 
                title: "Native Experts", 
                desc: "Every tutor is specialized in teaching children abroad with patience and cultural nuance."
              },
              { 
                icon: <Clock />, 
                title: "Flexible Hours", 
                desc: "Times optimized for USA (EST/PST), UK, and EU. We work around your child's local school life."
              },
              { 
                icon: <MessageSquare />, 
                title: "WhatsApp Flow", 
                desc: "Direct access to tutors and admins for easy updates, progress reports, and reminders."
              }
            ].map((item, idx) => (
              <div key={idx} className="p-8 rounded-3xl bg-slate-50 border border-transparent hover:border-secondary/20 transition-all group">
                <div className="w-12 h-12 bg-white rounded-xl flex items-center justify-center text-primary mb-6 shadow-sm group-hover:bg-secondary group-hover:text-white transition-colors">
                  {item.icon}
                </div>
                <h3 className="text-xl font-bold text-primary mb-3">{item.title}</h3>
                <p className="text-sm text-slate-500 leading-relaxed">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How it Works */}
      <section id="how-it-works" className="section-padding bg-surface/50">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row gap-20 items-center">
            <div className="flex-1">
              <h2 className="text-4xl md:text-6xl font-serif font-bold text-primary mb-12">Three Steps to Fluency</h2>
              <div className="space-y-12">
                {[
                  { step: "01", title: "Book a Trial ($5)", desc: "Start with a 25-minute evaluation session to meet your tutor and assess your child's level." },
                  { step: "02", title: "Personal Assessment", desc: "Receive a detailed report on child's current level and a recommended learning path." },
                  { step: "03", title: "Start Weekly Learning", desc: "Join our recurring weekly sessions (1, 2, or 3 times a week) and watch the progress happen." }
                ].map((item, idx) => (
                  <div key={idx} className="flex gap-6">
                    <span className="text-5xl font-serif font-bold text-secondary-dark/30">{item.step}</span>
                    <div>
                      <h4 className="text-2xl font-serif font-bold text-primary mb-2">{item.title}</h4>
                      <p className="text-gray-600 mb-4">{item.desc}</p>
                      <div className="h-px bg-gray-200 w-24"></div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            
            <div className="flex-1 bg-primary p-12 rounded-[60px] text-white">
              <div className="aspect-square bg-white/10 rounded-[40px] p-8 flex flex-col justify-center gap-6 backdrop-blur-sm border border-white/10">
                <div className="bg-secondary text-primary w-fit px-4 py-1 rounded-full text-xs font-bold uppercase tracking-widest mb-2">Live Session</div>
                <h3 className="text-4xl font-serif font-bold italic leading-tight">Interactive, screen-shared digital classrooms.</h3>
                <p className="opacity-80 leading-relaxed">We use interactive games, digital flashcards, and live drawing to keep children engaged for the full duration of the lesson.</p>
                <Link to="/book-trial" className="bg-blue-600 hover:bg-blue-700 text-white w-full text-center py-2.5 rounded-lg shadow-md font-bold block cursor-pointer transition-all">Start trial now</Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Meet the Founder Section */}
      <section className="section-padding bg-slate-50 border-t border-b border-slate-100">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid lg:grid-cols-12 gap-12 lg:gap-16 items-center">
            {/* Founder Photo / Avatar badge */}
            <div className="lg:col-span-5 relative">
              <div className="aspect-square w-full max-w-sm mx-auto bg-gradient-to-tr from-secondary/10 to-indigo-50 rounded-[32px] border border-slate-200/60 p-8 flex flex-col justify-between shadow-sm relative overflow-hidden">
                <div className="absolute top-0 right-0 -mr-16 -mt-16 w-48 h-48 bg-secondary/10 rounded-full blur-2xl"></div>
                
                {/* Visual Amharic Stamp */}
                <div className="text-[100px] sm:text-[120px] font-black text-secondary/15 select-none absolute inset-0 flex items-center justify-center pointer-events-none">
                  ሰላም
                </div>

                <div className="flex justify-between items-start relative z-10">
                  <div className="w-16 h-16 bg-white rounded-2xl flex items-center justify-center shadow-md font-serif text-3xl text-primary font-bold">
                    🇪🇹
                  </div>
                  <a 
                    href={settings.founderLinkedIn} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="bg-[#0a66c2] hover:bg-[#004182] text-white p-3 rounded-full shadow-md transition-all hover:scale-105 duration-300"
                    title="Connect on LinkedIn"
                  >
                    <Linkedin size={22} fill="currentColor" />
                  </a>
                </div>

                <div className="relative z-10 space-y-2 mt-auto">
                  <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-primary/10 text-primary rounded-full text-xs font-bold uppercase tracking-wider">
                     Platform Founder
                  </div>
                  <h3 className="text-3xl font-bold text-primary tracking-tight font-sans">
                    {settings.founderName}
                  </h3>
                  <p className="text-slate-500 font-mono text-xs font-bold uppercase tracking-wider">
                    HabKids Network
                  </p>
                </div>
              </div>
            </div>

            {/* Founder Message / Pitch / LinkedIn details */}
            <div className="lg:col-span-7 space-y-6 text-left">
              <span className="text-secondary font-black text-xs uppercase tracking-widest block">FOUNDER'S VISION</span>
              <h2 className="text-4xl md:text-5xl font-sans lg:leading-[1.1] font-bold text-primary tracking-tight">
                Connecting Ethiopian Children Abroad with their Heritage
              </h2>
              <p className="text-slate-500 text-lg leading-relaxed">
                As the Founder of <strong>{settings.academyName}</strong>, our mission is to deliver an authentic, patient, and modern online curriculum designed with the cultural nuances needed for families abroad. By integrating interactive language apps and veteran instructional talent, we are preserving our beautiful Amharic and Ge'ez languages for future generations around the globe.
              </p>
              
              <div className="pt-2 flex flex-col sm:flex-row gap-4 items-start sm:items-center">
                <a 
                  href={settings.founderLinkedIn} 
                  target="_blank" 
                  rel="noopener noreferrer" 
                  className="inline-flex items-center gap-3 bg-[#0a66c2]/95 hover:bg-[#0a66c2] text-white px-7 py-4 rounded-xl font-bold tracking-tight shadow-md hover:shadow-lg hover:scale-[1.01] transition-all duration-300"
                >
                  <Linkedin size={20} fill="currentColor" />
                  <span>Connect with the Founder on LinkedIn</span>
                </a>
                
                <span className="text-slate-400 text-xs sm:pt-0 font-medium">
                  Updated profile & project milestones live on LinkedIn
                </span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Frequently Asked Questions (FAQ) Section */}
      <section className="py-24 px-6 bg-slate-50/50 border-t border-b border-slate-100">
        <div className="max-w-4xl mx-auto">
          <div className="text-center space-y-4 mb-16">
            <span className="text-secondary font-black text-xs uppercase tracking-widest block">HELP & KNOWLEDGE BASE</span>
            <h2 className="text-4xl font-sans font-bold text-primary tracking-tight">
              Frequently Asked Questions
            </h2>
            <p className="text-slate-500 max-w-xl mx-auto text-base">
              Everything you need to know about our modern Amharic tutoring, Ge'ez script curriculum, and responsive scheduling system.
            </p>
          </div>

          <div className="space-y-4">
            {faqs.map((faq, index) => {
              const isOpen = openFaqIndex === index;
              return (
                <div 
                  key={index}
                  className={`bg-white rounded-[24px] border transition-all duration-300 ${
                    isOpen 
                      ? "border-primary/20 shadow-xl shadow-slate-100/40" 
                      : "border-slate-100 hover:border-slate-200 shadow-sm"
                  }`}
                >
                  <button
                    onClick={() => setOpenFaqIndex(isOpen ? null : index)}
                    className="w-full text-left px-8 py-6 flex items-center justify-between gap-6 cursor-pointer focus:outline-none group"
                  >
                    <span className="font-sans font-bold text-[17px] text-primary leading-snug group-hover:text-secondary transition-colors">
                      {faq.question}
                    </span>
                    <div className={`p-2 rounded-xl shrink-0 transition-all duration-300 ${
                      isOpen ? "bg-primary text-white animate-pulse" : "bg-slate-50 text-slate-400 group-hover:bg-slate-100"
                    }`}>
                      {isOpen ? <Minus size={16} /> : <Plus size={16} />}
                    </div>
                  </button>

                  <div 
                    className={`overflow-hidden transition-all duration-300 ${
                      isOpen ? "max-h-96 opacity-100" : "max-h-0 opacity-0"
                    }`}
                  >
                    <div className="px-8 pb-6 text-slate-500 leading-relaxed text-sm md:text-base border-t border-slate-50 pt-4">
                      {faq.answer}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Quick Trial Conversion Card */}
          <div className="mt-16 bg-gradient-to-br from-primary to-[#0f1d2e] text-white rounded-[32px] p-8 md:p-12 text-center relative overflow-hidden shadow-2xl shadow-primary/20">
            <div className="absolute right-0 bottom-0 top-0 w-1/3 bg-[radial-gradient(circle_at_bottom_right,var(--color-secondary)_0%,transparent_60%)] opacity-30 select-none pointer-events-none" />
            <div className="relative z-10 space-y-6 max-w-2xl mx-auto">
              <h3 className="text-2xl md:text-3xl font-bold font-sans tracking-tight">Ready to see HabKids in action?</h3>
              <p className="text-slate-300 text-sm md:text-base leading-relaxed">
                Book a risk-free, complimentary 1-on-1 trial session. Our expert tutors will perform a quick milestone assessment and custom-tailor a learning pathway for your child.
              </p>
              <div className="pt-2">
                <Link 
                  to="/book-trial" 
                  className="inline-flex items-center gap-2 bg-blue-600 text-white hover:bg-blue-700 px-8 py-4 rounded-xl font-bold text-xs uppercase tracking-wider shadow-lg hover:shadow-xl hover:scale-[1.01] transition-all duration-300"
                >
                  <span>Book Complementary Trial</span>
                  <ChevronRight size={14} />
                </Link>
              </div>
            </div>
          </div>

        </div>
      </section>

      {/* Footer */}
      <footer className="bg-primary text-white py-24 px-6">
        <div className="max-w-7xl mx-auto grid lg:grid-cols-2 gap-16 pb-12 border-b border-white/10">
          <div>
            <div className="flex items-center gap-3 mb-8">
              <div className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0">
                <BrandLogo 
                  logoUrl={settings.activeLogoUrl || '/logo_option_one.png'} 
                  className="w-full h-full"
                />
              </div>
              <span className="text-2xl font-bold text-white tracking-tight">{settings.academyName}</span>
            </div>
            <p className="text-slate-400 max-w-sm mb-8 leading-relaxed">
              Empowering the next generation of the Ethiopian community abroad to speak, read, and write Amharic through personalized online pedagogy.
            </p>
          </div>
          
          <div className="grid grid-cols-2 gap-12">
            <div>
              <h5 className="font-bold text-lg mb-6 text-white">Platform</h5>
              <ul className="space-y-4 text-slate-400">
                <li><Link to={getCurriculumUrl()} className="hover:text-secondary transition-colors text-sm">Curriculum</Link></li>
                <li><a href="#" className="hover:text-secondary transition-colors text-sm">Placement Assessment</a></li>
              </ul>
            </div>
            <div>
              <h5 className="font-bold text-lg mb-6 text-white">Support</h5>
              <ul className="space-y-4 text-slate-400">
                <li><Link to="/login" className="hover:text-secondary transition-colors text-sm">Help Center</Link></li>
                <li><Link to="/become-tutor" className="hover:text-secondary transition-colors text-sm">Teacher Careers</Link></li>
              </ul>
            </div>
          </div>
        </div>
        <div className="max-w-7xl mx-auto pt-12 flex flex-col md:flex-row justify-between items-center gap-6 text-slate-500 text-xs font-bold uppercase tracking-widest">
          <p>© 2026 HabKids. All rights reserved.</p>
          <div className="flex flex-wrap gap-5 items-center justify-center">
            <a href={settings.founderLinkedIn} target="_blank" rel="noopener noreferrer" className="hover:text-white transition-colors flex items-center gap-1.5 bg-[#0a66c2]/10 px-2.5 py-1 rounded-md text-slate-300">
              <Linkedin size={13} fill="currentColor" />
              <span>LinkedIn</span>
            </a>
            <a href={settings.facebookUrl} target="_blank" rel="noopener noreferrer" className="hover:text-white transition-colors flex items-center gap-1.5 text-slate-300">
              <Facebook size={13} />
              <span>Facebook</span>
            </a>
            <a href={settings.instagramUrl} target="_blank" rel="noopener noreferrer" className="hover:text-white transition-colors text-slate-300">Instagram</a>
            <a href={settings.youtubeUrl} target="_blank" rel="noopener noreferrer" className="hover:text-white transition-colors flex items-center gap-1.5 text-slate-300">
              <Youtube size={13} />
              <span>YouTube</span>
            </a>
            <a href={settings.whatsappUrl} target="_blank" rel="noopener noreferrer" className="hover:text-white transition-colors text-slate-300">WhatsApp</a>
          </div>
        </div>
      </footer>

      {/* FLOATING AMBASSADOR / PARTNER GIFT COIN */}
      <button
        type="button"
        onClick={() => setShowAmbassadorModal(true)}
        className="fixed bottom-6 left-6 z-50 bg-gradient-to-r from-amber-400 via-amber-500 to-amber-600 text-slate-900 font-extrabold px-4 py-3 rounded-full shadow-2xl hover:scale-105 active:scale-95 transition-all text-xs flex items-center gap-2 border border-amber-300 animate-bounce cursor-pointer group hover:shadow-amber-500/20"
      >
        <span className="relative flex h-2.5 w-2.5">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-slate-950 opacity-75"></span>
          <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-slate-950"></span>
        </span>
        <Gift size={15} className="text-slate-950 animate-pulse" />
        <span>Ambassador Program: <strong className="font-mono bg-slate-950 text-amber-400 px-1.5 py-0.5 rounded-md text-[10px] ml-0.5 font-bold">Earn ${settings.referralCommissionRate ?? 9}</strong></span>
      </button>

      {/* AMBASSADOR PLATFORM EXPLANATIVE OVERLAY */}
      {showAmbassadorModal && (
        <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-md z-[100] flex items-center justify-center p-4 animate-in fade-in duration-200">
          <div 
            className="absolute inset-0" 
            onClick={() => setShowAmbassadorModal(false)}
          />
          <div className="bg-white rounded-[32px] border border-slate-100 max-w-lg w-full p-8 relative shadow-2xl animate-in zoom-in-95 duration-200 text-left font-sans">
            <button
              type="button"
              onClick={() => setShowAmbassadorModal(false)}
              className="absolute right-4 top-4 p-2 text-slate-400 hover:text-slate-600 rounded-full transition-colors"
            >
              <X size={18} />
            </button>

            <div className="space-y-6">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-amber-50 rounded-2xl flex items-center justify-center text-amber-500 shrink-0 shadow-sm">
                  <Gift size={24} />
                </div>
                <div>
                  <span className="text-[10px] font-extrabold text-amber-600 uppercase tracking-widest block font-sans">
                    🏆 Join HabKids Partnership Club
                  </span>
                  <h3 className="text-xl font-bold font-sans text-slate-950 tracking-tight">
                    Partner with HabKids
                  </h3>
                </div>
              </div>

              <div className="p-4 bg-amber-50/50 rounded-2xl border border-amber-100/35 space-y-1">
                <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">The General Reward</p>
                <p className="text-xl font-black text-amber-700 font-sans tracking-tight">
                  {settings.referralDiscountPercent ?? 10}% OFF For Friends • ${settings.referralCommissionRate ?? 9} Cash Or {settings.referralBonusCredits ?? 1} Free Class For You
                </p>
              </div>

              <div className="space-y-4 text-xs text-slate-650 leading-relaxed font-sans">
                <p>
                  Help us connect more kids abroad with beautiful heritage languages (Amharic & Ge'ez script). The Ambassador platform is open to parents, educators, global affiliates, and social media influencers.
                </p>

                <div className="space-y-2.5">
                  <div className="flex gap-2.5 items-start">
                    <span className="text-base">🎟️</span>
                    <div>
                      <strong className="text-slate-900 font-bold block">Invite with {settings.referralDiscountPercent ?? 10}% discount:</strong>
                      Whenever a friend joins using your referral coupon code, they instantly secure a {settings.referralDiscountPercent ?? 10}% discount off any of our subscriptions.
                    </div>
                  </div>
                  <div className="flex gap-2.5 items-start">
                    <span className="text-base">💰</span>
                    <div>
                      <strong className="text-slate-900 font-bold block">Collect cash payout commissions:</strong>
                      We pay out <strong className="text-slate-900">${settings.referralCommissionRate ?? 9} USD flat rate</strong> cash for every student enrollment. Claim your cash in the portal via Telebirr, CBE local bank account, or PayPal!
                    </div>
                  </div>
                  <div className="flex gap-2.5 items-start">
                    <span className="text-base">🎓</span>
                    <div>
                      <strong className="text-slate-900 font-bold block">Or unlock free classes:</strong>
                      Prefer to invest in your children's training? Directly exchange commissions for free, {settings.referralBonusCredits ?? 1} 1-on-1 private tutoring classes.
                    </div>
                  </div>
                </div>
              </div>

              <div className="pt-2 flex flex-col sm:flex-row gap-3">
                <Link
                  to="/signup?intent=ambassador"
                  onClick={() => setShowAmbassadorModal(false)}
                  className="flex-1 bg-slate-900 hover:bg-slate-800 text-white font-bold py-3 px-4 rounded-xl text-xs tracking-wider uppercase text-center shadow-lg transition-all"
                >
                  Create Ambassador Portal
                </Link>
                <Link
                  to="/login?intent=ambassador"
                  onClick={() => setShowAmbassadorModal(false)}
                  className="bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold py-3 px-5 rounded-xl text-xs uppercase text-center transition-all"
                >
                  Log In
                </Link>
              </div>

              <div className="border-t border-slate-100 pt-4 flex justify-between items-center text-[10px] text-slate-400 font-medium">
                <span>💬 WhatsApp Setup Helper: +251940651491</span>
                <span>Active 24/7 Global</span>
              </div>
            </div>
          </div>
        </div>
      )}

      <SupportWidget />
    </div>
  );
}

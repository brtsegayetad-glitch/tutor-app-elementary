import React, { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { 
  ChevronLeft, Star, Play, CheckCircle2, Globe, Video, Award, 
  Sparkles, BookOpen, Heart, Shield, Clock, ArrowRight, MapPin, 
  X, Calendar, GraduationCap, Languages, CalendarDays, ExternalLink,
  Share2, Check
} from 'lucide-react';
import { cn } from '../lib/utils';
import { getTutorsWithAvailability, subscribeToSettings, getTutorSlug, getTutorBySlugOrId } from '../services/dataService';
import BrandLogo from '../components/BrandLogo';

function detectUserTimezone(): string {
  try {
    const tz = Intl.DateTimeFormat().resolvedOptions().timeZone;
    if (!tz) return 'EST (New York)';
    
    // Convert popular IANA zones to simple user-friendly tags
    if (tz.includes('New_York') || tz.includes('Eastern') || tz.includes('Detroit') || tz.includes('Indiana')) {
      return 'EST (New York)';
    }
    if (tz.includes('Chicago') || tz.includes('Central') || tz.includes('Houston') || tz.includes('Winnipeg')) {
      return 'CST (Chicago)';
    }
    if (tz.includes('Denver') || tz.includes('Mountain') || tz.includes('Phoenix') || tz.includes('Salt_Lake_City')) {
      return 'MST (Denver)';
    }
    if (tz.includes('Los_Angeles') || tz.includes('Pacific') || tz.includes('Seattle') || tz.includes('Vancouver')) {
      return 'PST (Los Angeles)';
    }
    if (tz.includes('London') || tz.includes('Dublin') || tz.includes('GMT') || tz.includes('UTC')) {
      return 'GMT (London)';
    }
    if (tz.includes('Paris') || tz.includes('Berlin') || tz.includes('Rome') || tz.includes('Madrid') || tz.includes('Amsterdam') || tz.includes('Brussels')) {
      return 'CET (Paris)';
    }
    if (tz.includes('Addis_Ababa') || tz.includes('Nairobi') || tz.includes('Kampala') || tz.includes('Dar_es_Salaam') || tz.includes('EAT')) {
      return 'EAT (Addis Ababa)';
    }
    
    return tz;
  } catch {
    return 'EST (New York)';
  }
}

function getTimezoneOffsetMinutes(timezoneStr: string): number {
  const clean = String(timezoneStr || '').toLowerCase();
  if (clean.includes('eat') || clean.includes('addis') || clean.includes('africa') || clean.includes('nairobi')) {
    return -180; // UTC+3
  }
  if (clean.includes('gmt') || clean.includes('london') || clean.includes('utc')) {
    return 0; // UTC+0
  }
  if (clean.includes('europe') || clean.includes('paris') || clean.includes('berlin') || clean.includes('cet')) {
    return -60; // UTC+1
  }
  if (clean.includes('pst') || clean.includes('los angeles') || clean.includes('seattle') || clean.includes('pacific')) {
    return 480; // UTC-8
  }
  if (clean.includes('mst') || clean.includes('denver') || clean.includes('phoenix') || clean.includes('mountain')) {
    return 420; // UTC-7
  }
  if (clean.includes('cst') || clean.includes('chicago') || clean.includes('central') || clean.includes('houston')) {
    return 360; // UTC-6
  }
  if (clean.includes('est') || clean.includes('new york') || clean.includes('washington') || clean.includes('dc') || clean.includes('eastern')) {
    return 300; // UTC-5
  }
  return new Date().getTimezoneOffset();
}

function convertTutorSlots(
  tutorAvail: any,
  tutorTimezone: string = 'EAT (Addis Ababa)',
  parentTimezone: string = 'EST (New York)'
): any {
  if (!tutorAvail) return null;
  
  const DAYS_ORDER = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
  const tutorOffset = getTimezoneOffsetMinutes(tutorTimezone);
  const parentOffset = getTimezoneOffsetMinutes(parentTimezone);
  
  const localAvail: any = {};
  DAYS_ORDER.forEach(day => {
    localAvail[day] = { active: false, slots: [] };
  });

  Object.entries(tutorAvail).forEach(([day, dayData]: [string, any]) => {
    let slots: string[] = [];
    if (dayData && typeof dayData === 'object' && Array.isArray(dayData.slots)) {
      slots = dayData.slots;
    } else if (Array.isArray(dayData)) {
      slots = dayData;
    } else if (typeof dayData === 'string') {
      slots = dayData.split(',').map((s: string) => s.trim()).filter(Boolean);
    }

    slots.forEach((slotStr: string) => {
      if (!slotStr || !slotStr.includes(':')) return;
      
      const timePart = slotStr.split(' ')[0];
      const isAMPM = slotStr.toUpperCase().includes('AM') || slotStr.toUpperCase().includes('PM');
      let [h, m] = timePart.split(':').map(Number);
      
      if (isNaN(h) || isNaN(m)) return;

      if (isAMPM) {
        if (slotStr.toUpperCase().includes('PM') && h < 12) h += 12;
        if (slotStr.toUpperCase().includes('AM') && h === 12) h = 0;
      }

      const dayIndex = DAYS_ORDER.indexOf(day.toLowerCase());
      if (dayIndex === -1) return;

      const totalMinutesTutor = dayIndex * 24 * 60 + h * 60 + m;
      
      let totalMinutesLocal = totalMinutesTutor + tutorOffset - parentOffset;
      totalMinutesLocal = (totalMinutesLocal + 10080) % 10080;

      const localDayIndex = Math.floor(totalMinutesLocal / (24 * 60));
      const remainingMinutes = totalMinutesLocal % (24 * 60);
      
      const localH = Math.floor(remainingMinutes / 60);
      const localM = remainingMinutes % 60;
      
      const formattedM = String(localM).padStart(2, '0');
      let formattedH = localH;
      let ampm = 'AM';
      
      if (formattedH >= 12) {
        ampm = 'PM';
        if (formattedH > 12) formattedH -= 12;
      }
      if (formattedH === 0) {
        formattedH = 12;
      }
      
      const formattedSlot = `${String(formattedH).padStart(2, '0')}:${formattedM} ${ampm}`;
      const targetDay = DAYS_ORDER[localDayIndex];
      
      if (localAvail[targetDay]) {
        if (!localAvail[targetDay].slots.includes(formattedSlot)) {
          localAvail[targetDay].slots.push(formattedSlot);
        }
      }
    });
  });

  DAYS_ORDER.forEach(day => {
    localAvail[day].slots.sort((a: string, b: string) => {
      const getMins = (s: string) => {
        const parts = s.split(' ');
        let [hh, mm] = parts[0].split(':').map(Number);
        if (parts[1] === 'PM' && hh < 12) hh += 12;
        if (parts[1] === 'AM' && hh === 12) hh = 0;
        return hh * 60 + mm;
      };
      return getMins(a) - getMins(b);
    });
    localAvail[day].active = localAvail[day].slots.length > 0;
  });

  return localAvail;
}

export default function TutorProfilePage() {
  const { tutorId } = useParams<{ tutorId: string }>();
  const [tutor, setTutor] = useState<any | null>(null);
  const [tutors, setTutors] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeLogoUrl, setActiveLogoUrl] = useState('/logo_option_one.png');
  const [showVideo, setShowVideo] = useState(false);
  const [hoveredTimeSlot, setHoveredTimeSlot] = useState<string | null>(null);
  const navigate = useNavigate();
  const [copied, setCopied] = useState(false);

  const handleCopyProfileLink = () => {
    navigator.clipboard.writeText(window.location.href).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 3000);
    }).catch(err => console.error("Clipboard copy failed:", err));
  };

  // Load Settings for Logo
  useEffect(() => {
    const unsub = subscribeToSettings((settings) => {
      if (settings && settings.activeLogoUrl) {
        setActiveLogoUrl(settings.activeLogoUrl);
      }
    });
    return () => unsub();
  }, []);

  // Fetch Tutors and match by ID or slug name
  useEffect(() => {
    if (!tutorId) return;

    setLoading(true);
    getTutorBySlugOrId(tutorId)
      .then((matched) => {
        setTutor(matched || null);
        setLoading(false);
      })
      .catch((err) => {
        console.error("Error loading tutor profile details:", err);
        setLoading(false);
      });
  }, [tutorId]);

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center font-sans">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-indigo-600 mb-4"></div>
        <p className="text-slate-500 text-sm font-semibold animate-pulse">Loading tutor profile...</p>
      </div>
    );
  }

  if (!tutor) {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-6 text-center font-sans">
        <div className="bg-white p-8 rounded-[32px] border border-slate-200/60 max-w-md w-full shadow-lg space-y-6">
          <div className="w-16 h-16 bg-red-50 text-red-500 rounded-full flex items-center justify-center mx-auto shadow-sm">
            <X size={32} />
          </div>
          <div className="space-y-2">
            <h2 className="text-2xl font-serif font-black text-slate-900">Tutor Not Found</h2>
            <p className="text-slate-500 text-sm">
              We couldn't find a tutor matching "{tutorId}". They may have updated their profile or URL.
            </p>
          </div>
          <div className="pt-2">
            <Link 
              to="/book-trial" 
              className="w-full py-3 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl transition-all shadow-md hover:shadow-lg text-sm block"
            >
              Browse All Tutors
            </Link>
          </div>
        </div>
      </div>
    );
  }

  // Get YouTube video ID supporting standard, short, embed, and shorts links
  const getYoutubeVideoId = (url: string) => {
    if (!url) return '';
    const cleanUrl = url.trim();
    
    // 1. YouTube Shorts support
    if (cleanUrl.includes('/shorts/')) {
      const parts = cleanUrl.split('/shorts/');
      if (parts.length > 1) {
        const idPart = parts[1].split(/[?&]/)[0];
        if (idPart.length >= 11) {
          return idPart.substring(0, 11);
        }
      }
    }

    // 2. Already formatted embed url
    if (cleanUrl.includes('/embed/')) {
      const parts = cleanUrl.split('/embed/');
      if (parts.length > 1) {
        return parts[1].split(/[?&]/)[0].substring(0, 11);
      }
    }

    // 3. Standard and short YouTube links
    const regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|\&v=)([^#\&\?]*).*/;
    const match = cleanUrl.match(regExp);
    if (match && match[2] && match[2].length === 11) {
      return match[2];
    }
    return '';
  };

  // Generate clean Embed URL for YouTube
  const getYoutubeEmbedUrl = (url: string) => {
    if (!url) return '';
    const cleanUrl = url.trim();
    const videoId = getYoutubeVideoId(cleanUrl);
    if (videoId) {
      return `https://www.youtube.com/embed/${videoId}?autoplay=1&rel=0`;
    }
    return cleanUrl;
  };

  const getYoutubeThumbnailUrl = (url: string) => {
    const videoId = getYoutubeVideoId(url);
    if (videoId) {
      // Use hqdefault.jpg for YouTube video photo thumbnail
      return `https://img.youtube.com/vi/${videoId}/hqdefault.jpg`;
    }
    return tutor.avatar || "https://images.unsplash.com/photo-1577896851231-70ef18881754?auto=format&fit=crop&q=80&w=1000";
  };

  // Check if videoUrl is a valid http/https URL, otherwise fallback to standard Youtube intro video
  const isValidVideoUrl = (url: string) => {
    if (!url) return false;
    const clean = url.trim();
    return clean.startsWith('http://') || clean.startsWith('https://');
  };

  const rawVideoUrl = tutor.videoUrl || tutor.youtubeUrl || "";
  const videoUrlForTutor = isValidVideoUrl(rawVideoUrl) ? rawVideoUrl.trim() : "https://www.youtube.com/watch?v=BObEMk9vY_M";
  const embedUrl = getYoutubeEmbedUrl(videoUrlForTutor);
  const videoThumbnailUrl = getYoutubeThumbnailUrl(rawVideoUrl);
  const isAvatarThumbnail = videoThumbnailUrl ? (!videoThumbnailUrl.includes('youtube.com/vi/') && !videoThumbnailUrl.includes('ytimg.com')) : true;

  // Organize tutor days for rendering schedules
  const daysOfWeek = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'];

  // Global fallback availability for tutoring sessions if none exists
  const fallbackAvailability = {
    monday: { active: true, slots: ['22:00', '23:00', '00:00', '01:00', '02:00', '03:00', '04:00', '05:00'] },
    tuesday: { active: true, slots: ['22:00', '23:00', '00:00', '01:00', '02:00', '03:00', '04:00', '05:00'] },
    wednesday: { active: true, slots: ['22:00', '23:00', '00:00', '01:00', '02:00', '03:00', '04:00', '05:00'] },
    thursday: { active: true, slots: ['22:00', '23:00', '00:00', '01:00', '02:00', '03:00', '04:00', '05:00'] },
    friday: { active: true, slots: ['22:00', '23:00', '00:00', '01:00', '02:00', '03:00', '04:00', '05:00'] },
    saturday: { active: true, slots: ['14:00', '15:00', '16:00', '17:00', '18:00', '19:00', '20:00', '21:00', '22:00', '23:00', '00:00', '01:00'] },
    sunday: { active: true, slots: ['14:00', '15:00', '16:00', '17:00', '18:00', '19:00', '20:00', '21:00', '22:00', '23:00', '00:00', '01:00'] }
  };

  const parentTimezone = detectUserTimezone();

  const getTutorAvailability = () => {
    if (tutor && tutor.availability && Object.keys(tutor.availability).length > 0) {
      // Check if there are actually any slots in any day
      const hasAnySlots = daysOfWeek.some(day => {
        const val = tutor.availability[day];
        if (!val) return false;
        if (typeof val === 'object' && Array.isArray(val.slots) && val.slots.length > 0) return true;
        if (Array.isArray(val) && val.length > 0) return true;
        if (typeof val === 'string' && val.trim().length > 0) return true;
        return false;
      });
      if (hasAnySlots) {
        return tutor.availability;
      }
    }
    return fallbackAvailability;
  };
  
  const convertedAvailability = convertTutorSlots(
    getTutorAvailability(),
    tutor?.timezone || 'EAT (Addis Ababa)',
    parentTimezone
  );

  // Safe helper to extract slots from tutor's availability for a given day (string, array, or object)
  const getDaySlots = (day: string): string[] => {
    if (!convertedAvailability) return [];
    const val = convertedAvailability[day];
    if (!val) return [];
    if (val && typeof val === 'object' && Array.isArray(val.slots)) {
      return val.slots;
    }
    return [];
  };

  const hasAvailability = daysOfWeek.some(day => getDaySlots(day).length > 0);

  const formatDayName = (day: string) => {
    return day.charAt(0).toUpperCase() + day.slice(1);
  };

  const handleBookingRedirect = (slotInfo?: string) => {
    const shortSlug = getTutorSlug(tutor);
    const dest = `/book-trial?tutor=${shortSlug || tutor.id}${slotInfo ? `&slot=${encodeURIComponent(slotInfo)}` : ''}`;
    navigate(dest);
  };

  return (
    <div className="min-h-screen bg-slate-50/60 font-sans text-slate-800">
      {/* Dynamic Header */}
      <header className="sticky top-0 bg-white/85 backdrop-blur-md border-b border-slate-100 z-50 py-4 px-6 shadow-sm">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <Link to="/" className="flex items-center gap-3">
            <div className="w-10 h-10 flex items-center justify-center bg-indigo-50 border border-indigo-100 rounded-xl p-1 overflow-hidden shadow-sm">
              <BrandLogo logoUrl={activeLogoUrl} className="max-h-full max-w-full object-contain" />
            </div>
            <div>
              <span className="font-serif text-xl font-extrabold text-primary tracking-tight">HabKids</span>
              <span className="hidden sm:inline-block text-[9px] bg-indigo-50 text-indigo-700 border border-indigo-100 font-black px-2 py-0.5 rounded-full ml-2 uppercase">Official Partner</span>
            </div>
          </Link>
          <div className="flex items-center gap-4">
            <Link 
              to="/book-trial" 
              className="text-xs font-bold text-slate-600 hover:text-indigo-600 transition-colors"
            >
              Browse Directory
            </Link>
            <Link 
              to="/book-trial"
              className="bg-indigo-600 hover:bg-indigo-700 text-white font-extrabold text-xs px-5 py-2.5 rounded-xl shadow-md hover:shadow-lg transition-all"
            >
              Book Direct Trial
            </Link>
          </div>
        </div>
      </header>

      {/* Main Content Body */}
      <main className="max-w-7xl mx-auto py-8 px-4 md:px-6">
        <Link 
          to="/book-trial" 
          className="inline-flex items-center gap-1.5 text-xs font-bold text-slate-500 hover:text-indigo-600 transition-all mb-6 group bg-white px-4 py-2.5 rounded-full border border-slate-200/50 shadow-sm"
        >
          <ChevronLeft size={14} className="transition-transform group-hover:-translate-x-0.5" />
          <span>Back to Tutors Directory</span>
        </Link>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left Column: Tutor Details (8 spans) */}
          <div className="lg:col-span-8 space-y-6">
            
            {/* Profile Overview Card - AT THE TOP */}
            <div className="bg-white rounded-[32px] p-6 md:p-8 border border-slate-200/60 shadow-sm space-y-6 relative overflow-hidden">
              <div className="absolute top-0 right-0 w-48 h-48 bg-gradient-to-br from-indigo-100/20 to-emerald-100/20 rounded-full blur-3xl -z-10"></div>
              
              <div className="flex flex-col sm:flex-row gap-6 items-start">
                {/* Avatar area */}
                <div className="relative flex-shrink-0 mx-auto sm:mx-0">
                  <img 
                    src={tutor.avatar || "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=260"} 
                    alt={tutor.displayName} 
                    className="w-28 h-28 sm:w-32 sm:h-32 rounded-[24px] object-cover border-2 border-white shadow-md ring-4 ring-slate-100"
                    referrerPolicy="no-referrer"
                  />
                  <span className="absolute bottom-1 right-1 w-5 h-5 bg-emerald-500 border-4 border-white rounded-full animate-pulse"></span>
                </div>

                {/* Name and Quick stats */}
                <div className="flex-grow space-y-3 text-center sm:text-left">
                  <div className="space-y-1.5">
                    <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2">
                      <h1 className="text-2xl sm:text-3xl font-serif font-black text-slate-900 tracking-tight">
                        {tutor.displayName || tutor.name || tutor.fullName}
                      </h1>
                      <div className="flex items-center gap-1 px-2.5 py-0.5 bg-emerald-50 text-emerald-700 border border-emerald-150 rounded-full text-[10px] font-bold">
                        <Shield size={10} className="fill-emerald-700" />
                        <span>Verified Native</span>
                      </div>
                    </div>
                    <p className="text-xs sm:text-sm font-semibold text-slate-500 italic">
                      "{tutor.quote || 'Committed to empowering the next generation of Amharic learners abroad through play and conversation.'}"
                    </p>
                  </div>

                  <div className="flex flex-wrap items-center justify-center sm:justify-start gap-4 text-xs font-bold pt-1">
                    <div className="flex items-center gap-1 text-amber-500 bg-amber-50/80 border border-amber-100 px-3 py-1.5 rounded-full">
                      <Star size={14} className="fill-amber-500" />
                      <span>{tutor.rating || "5.0"}</span>
                      <span className="text-[10px] text-slate-400 font-normal">
                        ({tutor.reviewsCount || "1"} Review{Number(tutor.reviewsCount) === 1 ? '' : 's'})
                      </span>
                    </div>

                    <div className="flex items-center gap-1.5 text-indigo-600 bg-indigo-50 border border-indigo-100 px-3 py-1.5 rounded-full">
                      <Award size={14} />
                      <span>{tutor.totalBookings || 12} Lessons Done</span>
                    </div>

                    <div className="flex items-center gap-1.5 text-slate-600 bg-slate-50 border border-slate-200 px-3 py-1.5 rounded-full">
                      <Globe size={14} />
                      <span>{tutor.location || "Addis Ababa, Ethiopia"}</span>
                    </div>

                    <button 
                      onClick={handleCopyProfileLink}
                      className={cn(
                        "flex items-center gap-1.5 px-3 py-1.5 rounded-full transition-all border font-bold cursor-pointer",
                        copied 
                          ? "bg-emerald-50 text-emerald-700 border-emerald-200" 
                          : "bg-indigo-50 text-indigo-700 border-indigo-150 hover:bg-indigo-100"
                      )}
                    >
                      {copied ? (
                        <>
                          <Check size={14} />
                          <span>Link Copied!</span>
                        </>
                      ) : (
                        <>
                          <Share2 size={14} />
                          <span>Share Direct Profile</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>
              </div>

              {/* Badges / Subject Tags */}
              <div className="border-t border-slate-100 pt-5 space-y-3">
                <p className="text-[10px] uppercase font-bold text-slate-400 tracking-wider font-sans">Core Academic Tracks & Expertise</p>
                <div className="flex flex-wrap gap-2">
                  <span className="text-xs font-bold text-indigo-700 bg-indigo-50 border border-indigo-150 px-3.5 py-1.5 rounded-xl flex items-center gap-1.5">
                    <Languages size={12} />
                    CourseFocus: {tutor.expertise}
                  </span>
                  <span className="text-xs font-bold text-emerald-700 bg-emerald-50 border border-emerald-150 px-3.5 py-1.5 rounded-xl flex items-center gap-1.5">
                    <GraduationCap size={12} />
                    Specialization: {tutor.primarySyllabusSpecialization || 'Amharic'}
                  </span>
                  <span className="text-xs font-bold text-amber-700 bg-amber-50 border border-amber-150 px-3.5 py-1.5 rounded-xl flex items-center gap-1.5">
                    <Sparkles size={12} />
                    Kids Specialist Abroad (6-12)
                  </span>
                </div>
              </div>
            </div>

            {/* Video Introduction Player / Banner - BELOW BASIC INFO */}
            <div className="bg-white rounded-[32px] p-6 md:p-8 border border-slate-200/60 shadow-sm space-y-4">
              <h3 className="font-serif text-lg font-bold text-slate-900 flex items-center gap-2">
                <Video size={18} className="text-indigo-600" />
                <span>Meet {tutor.displayName || 'Tutor'} (Video Introduction)</span>
              </h3>
              
              <div className="relative aspect-video w-full rounded-2xl overflow-hidden bg-slate-900 shadow-inner group border border-slate-200">
                {showVideo && embedUrl ? (
                  <iframe 
                    src={embedUrl} 
                    title="Tutor Introduction Video"
                    className="w-full h-full"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowFullScreen
                  />
                ) : (
                  <div className="absolute inset-0 overflow-hidden flex items-center justify-center">
                    <img 
                      src={videoThumbnailUrl} 
                      alt="Intro Banner Background" 
                      className="absolute inset-0 w-full h-full object-cover opacity-25 blur-lg scale-110"
                    />
                    {isAvatarThumbnail ? (
                      <div className="absolute inset-0 bg-slate-950/40 flex flex-col justify-center items-center p-6 text-center space-y-4">
                        <div className="relative group/avatar">
                          <div className="w-24 h-24 sm:w-28 sm:h-28 rounded-full overflow-hidden border-4 border-white shadow-lg relative">
                            <img 
                              src={videoThumbnailUrl} 
                              alt={tutor.displayName} 
                              className="w-full h-full object-cover"
                            />
                            <div className="absolute inset-0 bg-slate-900/10" />
                          </div>
                          <button 
                            onClick={() => setShowVideo(true)}
                            className="absolute -bottom-1 -right-1 w-11 h-11 bg-indigo-600 hover:bg-indigo-500 hover:scale-105 active:scale-95 text-white rounded-full flex items-center justify-center shadow-lg transition-all cursor-pointer ring-4 ring-white"
                          >
                            <Play size={18} className="fill-white translate-x-0.5" />
                          </button>
                        </div>
                        <div>
                          <p className="text-white font-black text-sm sm:text-base tracking-tight">Watch {tutor.displayName}'s video introduction</p>
                          <p className="text-slate-200 text-xs mt-1 max-w-md">Listen to their pronunciation, conversational flow, and teaching philosophy.</p>
                        </div>
                      </div>
                    ) : (
                      <>
                        <img 
                          src={videoThumbnailUrl} 
                          alt="Video Thumbnail" 
                          className="absolute inset-0 w-full h-full object-cover opacity-70 group-hover:scale-101 transition-all duration-500"
                        />
                        <div className="absolute inset-0 bg-slate-950/30 flex flex-col justify-center items-center p-6 text-center space-y-4">
                          <button 
                            onClick={() => setShowVideo(true)}
                            className="w-16 h-16 bg-indigo-600 hover:bg-indigo-500 hover:scale-105 active:scale-95 text-white rounded-full flex items-center justify-center shadow-lg transition-all cursor-pointer ring-4 ring-white/20"
                          >
                            <Play size={28} className="fill-white translate-x-0.5" />
                          </button>
                          <div>
                            <p className="text-white font-extrabold text-sm sm:text-base">Watch dynamic 1-minute intro video</p>
                            <p className="text-slate-200 text-xs mt-1">Listen to {tutor.displayName}'s teaching methodology and standard pronunciation.</p>
                          </div>
                        </div>
                      </>
                    )}
                  </div>
                )}
              </div>
              
              {!showVideo && embedUrl && (
                <div className="flex justify-end pt-1">
                  <a 
                    href={videoUrlForTutor} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="text-xs text-indigo-600 hover:text-indigo-800 hover:underline font-bold flex items-center gap-1.5 transition-all"
                  >
                    <span>Problems playing? Watch directly on YouTube</span>
                    <ExternalLink size={12} />
                  </a>
                </div>
              )}
            </div>

            {/* Biography & Approach Section - DIRECTLY BELOW VIDEO */}
            <div className="bg-white rounded-[32px] p-6 md:p-8 border border-slate-200/60 shadow-sm space-y-6">
              <div className="space-y-3">
                <h3 className="font-serif text-lg font-bold text-slate-900 flex items-center gap-2">
                  <Award size={18} className="text-indigo-600" />
                  <span>About {tutor.displayName}</span>
                </h3>
                <p className="text-sm text-slate-600 leading-relaxed font-sans whitespace-pre-line">
                  {tutor.bio || `${tutor.displayName} is a certified heritage language instructor based in Addis Ababa, specializing in immersive oral and phonetic instruction for children. Utilizing modern flashcards, gamified digital challenges, and high-praise visual reinforcements, she simplifies complex Amharic alphabets and Geez grammar rules so kids abroad stay actively engaged.`}
                </p>
              </div>

              <div className="border-t border-slate-100 pt-5 space-y-4">
                <h4 className="font-serif text-base font-bold text-slate-900 flex items-center gap-2">
                  <BookOpen size={16} className="text-indigo-600" />
                  <span>Interactive Teaching Style</span>
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="p-4 bg-slate-50 rounded-2xl border border-slate-100 space-y-1.5">
                    <p className="font-bold text-xs text-indigo-800">🎮 Gamified Curriculum</p>
                    <p className="text-slate-550 text-xs leading-relaxed">Incorporates digital games, visual sound-bubbles, and customized matching exercises designed specifically for children abroad ages 6 to 12.</p>
                  </div>
                  <div className="p-4 bg-slate-50 rounded-2xl border border-slate-100 space-y-1.5">
                    <p className="font-bold text-xs text-indigo-800">💬 Immersive Conversational Play</p>
                    <p className="text-slate-550 text-xs leading-relaxed">Focuses on everyday practical conversation first (family terms, greetings, food items, transportation) to build instant household confidence.</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Testimonials section */}
            <div className="bg-white rounded-[32px] p-6 md:p-8 border border-slate-200/60 shadow-sm space-y-4">
              <h3 className="font-serif text-lg font-bold text-slate-900 flex items-center gap-2">
                <Heart size={18} className="text-indigo-600" />
                <span>Parent Testimonials ({tutor.reviewsCount || 1})</span>
              </h3>
              
              <div className="bg-indigo-50/20 border border-indigo-100/50 p-5 rounded-2xl space-y-3">
                <div className="flex justify-between items-center">
                  <span className="font-bold text-xs text-slate-900">Aster M. (USA)</span>
                  <div className="flex items-center gap-0.5 text-amber-500">
                    <Star size={10} className="fill-amber-500" />
                    <Star size={10} className="fill-amber-500" />
                    <Star size={10} className="fill-amber-500" />
                    <Star size={10} className="fill-amber-500" />
                    <Star size={10} className="fill-amber-500" />
                  </div>
                </div>
                <p className="text-xs text-slate-600 italic">
                  "{tutor.displayName} is absolutely spectacular. My 8-year-old was reluctant to start Amharic classes, but the games and gentle feedback made him look forward to every single session! His vocabulary has expanded immensely."
                </p>
              </div>
            </div>

          </div>

          {/* Right Column: Dynamic Sidebar Booking Card (4 spans) */}
          <div className="lg:col-span-4 sticky top-24 space-y-6">
            
            <div className="bg-white rounded-[32px] border border-slate-200/80 p-6 shadow-md space-y-6">
              <div className="space-y-2 text-center">
                <span className="text-[10px] uppercase font-extrabold tracking-widest text-indigo-700 bg-indigo-50 border border-indigo-100 px-3 py-1 rounded-full font-sans">
                  Active On-Boarding Roster
                </span>
                <h3 className="font-serif text-xl font-black text-slate-900">
                  Book a Trial Session
                </h3>
                <div className="flex items-center justify-center gap-1 text-slate-500 text-xs">
                  <Clock size={12} />
                  <span>30-minute placement trial session</span>
                </div>
              </div>

              {/* Features summary list */}
              <div className="bg-slate-50/80 rounded-2xl p-4 border border-slate-100 space-y-3">
                <div className="flex gap-2.5 items-start">
                  <CheckCircle2 size={14} className="text-emerald-500 mt-0.5 flex-shrink-0" />
                  <p className="text-[11px] text-slate-650 font-medium">Complete conversational proficiency test</p>
                </div>
                <div className="flex gap-2.5 items-start">
                  <CheckCircle2 size={14} className="text-emerald-500 mt-0.5 flex-shrink-0" />
                  <p className="text-[11px] text-slate-650 font-medium">Custom digital curriculum matching</p>
                </div>
                <div className="flex gap-2.5 items-start">
                  <CheckCircle2 size={14} className="text-emerald-500 mt-0.5 flex-shrink-0" />
                  <p className="text-[11px] text-slate-650 font-medium">Detailed placement diagnostic report</p>
                </div>
              </div>

              {/* Direct Booking CTA */}
              <button 
                onClick={() => handleBookingRedirect()}
                className="w-full py-4 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-black uppercase tracking-widest rounded-2xl transition-all shadow-md hover:shadow-lg flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>Reserve My Trial Session</span>
                <ArrowRight size={14} />
              </button>

              {/* Quick weekly schedule slots preview */}
              <div className="space-y-4 pt-4 border-t border-slate-150/50">
                <div>
                  <p className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                    <CalendarDays size={14} className="text-indigo-600" />
                    <span>Direct Availability Slots</span>
                  </p>
                  <p className="text-[9px] text-indigo-700/85 mt-1 font-sans flex items-center gap-1">
                    <Globe size={11} className="text-indigo-500 animate-pulse" />
                    <span>Times automatically shown in your timezone: <strong>{parentTimezone}</strong></span>
                  </p>
                </div>

                {hasAvailability ? (
                  <div className="space-y-3.5 max-h-72 overflow-y-auto pr-1">
                    {daysOfWeek.map((day) => {
                      const slots = getDaySlots(day);
                      if (slots.length === 0) return null;
                      return (
                        <div key={day} className="space-y-1">
                          <p className="text-[10px] font-extrabold text-slate-400 uppercase tracking-wider">{formatDayName(day)}</p>
                          <div className="flex flex-wrap gap-1.5">
                            {slots.map((slot: string, idx: number) => {
                              const uniqueKey = `${day}-${slot}`;
                              const isHovered = hoveredTimeSlot === uniqueKey;
                              return (
                                <button
                                  key={idx}
                                  onClick={() => handleBookingRedirect(`${formatDayName(day)} ${slot}`)}
                                  onMouseEnter={() => setHoveredTimeSlot(uniqueKey)}
                                  onMouseLeave={() => setHoveredTimeSlot(null)}
                                  className="text-[10px] font-extrabold bg-slate-50 hover:bg-indigo-50 border border-slate-200/70 hover:border-indigo-200 hover:text-indigo-700 px-2.5 py-1.5 rounded-lg transition-all cursor-pointer flex-grow text-center"
                                >
                                  {slot}
                                </button>
                              );
                            })}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                ) : (
                  <div className="p-4 rounded-xl bg-amber-50/50 border border-amber-100 text-center">
                    <p className="text-[10px] text-amber-800 font-medium font-sans">
                      No static availability entered. Ask our core platform to automatically allocate or reserve manually.
                    </p>
                  </div>
                )}
              </div>

              {/* Satisfaction Guarantee */}
              <p className="text-[9px] text-slate-450 text-center leading-normal">
                🔒 Protected & secure payments. If your selected tutor isn't the perfect fit, we will automatically match you with another tutor or issue a complete refund.
              </p>
            </div>

          </div>
        </div>
      </main>
    </div>
  );
}

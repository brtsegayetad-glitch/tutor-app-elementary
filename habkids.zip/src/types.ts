/**
 * Purpose: Shared TypeScript interfaces and types for the HabKids application.
 */

import { Timestamp } from 'firebase/firestore';

export type UserRole = 'admin' | 'tutor' | 'parent';

export interface UserProfile {
  uid: string;
  email: string;
  displayName: string;
  fullName?: string;
  role: UserRole;
  tutorId?: string;
  parentId?: string;
  expertise?: string;
  updatedAt?: any;
}

export type NotificationType = 'message' | 'booking' | 'schedule_change' | 'system';

export interface Notification {
  id: string;
  userId: string; // Recipient UID
  title: string;
  message: string;
  type: NotificationType;
  link?: string;
  isRead: boolean;
  createdAt: any;
  relatedId?: string; // ID of the related message, session, etc.
}

export interface TutorChat {
  id: string;
  parentId: string;
  parentName: string;
  parentEmail: string;
  tutorId: string;
  tutorName: string;
  tutorEmail: string;
  lastMessage: string;
  lastMessageAt: any;
  lastMessageSenderId: string;
  updatedAt: any;
}

export interface ChatMessage {
  id: string;
  chatId: string;
  senderId: string;
  senderName: string;
  senderRole: 'parent' | 'tutor';
  text: string;
  createdAt: any;
  hasSharingViolation?: boolean;
  originalText?: string;
}

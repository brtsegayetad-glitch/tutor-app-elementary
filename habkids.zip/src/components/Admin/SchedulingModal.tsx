import React, { useState, useEffect } from 'react';
import { 
  X, 
  Calendar, 
  CheckCircle2, 
  AlertCircle, 
  Loader2,
  Plus
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { cn } from '../../lib/utils';
import { scheduleTrial, subscribeToAllSessions } from '../../services/dataService';

const DAYS_ORDER = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];

function getSlotTimeString(slot: any): string {
  if (typeof slot === 'string') return slot;
  if (slot && typeof slot === 'object') {
    if (typeof slot.start === 'string') return slot.start;
    if (typeof slot.startTime === 'string') return slot.startTime;
    if (typeof slot.slot === 'string') return slot.slot;
  }
  return String(slot || '');
}

function utcSlotToLocal(dayName: string, slotTime: any): { day: string; slot: string } {
  const dayIndex = DAYS_ORDER.indexOf(dayName.toLowerCase());
  const str = getSlotTimeString(slotTime);
  if (dayIndex === -1 || !str.includes(':')) return { day: dayName, slot: str || '09:00' };

  const [h, m] = str.split(':').map(Number);
  const totalMinutesUTC = dayIndex * 24 * 60 + h * 60 + m;
  
  const now = new Date();
  const offset = now.getTimezoneOffset(); // in minutes (UTC - local)
  
  let totalMinutesLocal = totalMinutesUTC - offset;
  totalMinutesLocal = (totalMinutesLocal + 10080) % 10080;
  
  const localDayIndex = Math.floor(totalMinutesLocal / (24 * 60));
  const remainingMinutes = totalMinutesLocal % (24 * 60);
  
  const localH = String(Math.floor(remainingMinutes / 60)).padStart(2, '0');
  const localM = String(remainingMinutes % 60).padStart(2, '0');
  
  return { day: DAYS_ORDER[localDayIndex], slot: `${localH}:${localM}` };
}

function getLocalAvailability(utcAvail: any): any {
  if (!utcAvail) return null;
  const cloned: any = {};
  Object.entries(utcAvail).forEach(([day, dayData]: [string, any]) => {
    const slots = Array.isArray(dayData?.slots) ? [...dayData.slots].sort() : [];
    cloned[day] = {
      active: slots.length > 0,
      slots
    };
  });
  return cloned;
}

function getFilteredAvailability(utcAvail: any, tutorId: string, sessions: any[]): any {
  const fallbackAvailability = {
    monday: { active: true, slots: ['22:00', '23:00', '00:00', '01:00', '02:00', '03:00', '04:00', '05:00'] },
    tuesday: { active: true, slots: ['22:00', '23:00', '00:00', '01:00', '02:00', '03:00', '04:00', '05:00'] },
    wednesday: { active: true, slots: ['22:00', '23:00', '00:00', '01:00', '02:00', '03:00', '04:00', '05:00'] },
    thursday: { active: true, slots: ['22:00', '23:00', '00:00', '01:00', '02:00', '03:00', '04:00', '05:00'] },
    friday: { active: true, slots: ['22:00', '23:00', '00:00', '01:00', '02:00', '03:00', '04:00', '05:00'] },
    saturday: { active: true, slots: ['14:00', '15:00', '16:00', '17:00', '18:00', '19:00', '20:00', '21:00', '22:00', '23:00', '00:00', '01:00'] },
    sunday: { active: true, slots: ['14:00', '15:00', '16:00', '17:00', '18:00', '19:00', '20:00', '21:00', '22:00', '23:00', '00:00', '01:00'] }
  };
  const resolvedAvail = utcAvail && Object.keys(utcAvail).length > 0 ? utcAvail : fallbackAvailability;
  const localAvail = getLocalAvailability(resolvedAvail);
  if (!localAvail) return null;
  if (!tutorId || !sessions || sessions.length === 0) return localAvail;

  const nowMs = Date.now() - (55 * 60 * 1000); // 55 mins margin

  // Find all active/scheduled sessions for this tutor that are in the future
  const tutorSessions = sessions.filter(s => {
    if (s.tutorId !== tutorId) return false;
    if (s.status === 'completed' || s.status === 'cancelled') return false;
    
    const d = s.startTime?.toDate ? s.startTime.toDate() : new Date(s.startTime);
    return !isNaN(d.getTime()) && d.getTime() > nowMs;
  });

  // For each session, determine its day of week and slot (HH:mm)
  const DAYS_ORDER = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
  
  tutorSessions.forEach(s => {
    const d = s.startTime?.toDate ? s.startTime.toDate() : new Date(s.startTime);
    const dayName = DAYS_ORDER[d.getDay()];
    const hh = String(d.getHours()).padStart(2, '0');
    const mm = String(d.getMinutes()).padStart(2, '0');
    const h_m = `${hh}:${mm}`;

    // Remove this exact slot from localAvail
    if (localAvail[dayName]) {
      localAvail[dayName].slots = localAvail[dayName].slots.filter((slotStr: string) => {
        try {
          const [sh, sm] = slotStr.split(':').map(Number);
          const [th, tm] = h_m.split(':').map(Number);
          const diffMins = Math.abs((sh * 60 + sm) - (th * 60 + tm));
          return diffMins >= 55; // if less than 55 mins apart, consider it blocked/taken!
        } catch {
          return slotStr !== h_m;
        }
      });
      // Re-evaluate if day is active
      localAvail[dayName].active = localAvail[dayName].slots.length > 0;
    }
  });

  return localAvail;
}

interface SchedulingModalProps {
  lead: any;
  tutors: any[];
  onClose: () => void;
}

export default function SchedulingModal({ lead, tutors, onClose }: SchedulingModalProps) {
  const [selectedTutorId, setSelectedTutorId] = useState(lead?.tutorId || '');
  const [trialTime, setTrialTime] = useState('');
  const [allSessions, setAllSessions] = useState<any[]>([]);
  const [isScheduling, setIsScheduling] = useState(false);
  const [schedulingStatus, setSchedulingStatus] = useState<'idle' | 'success' | 'error'>('idle');

  useEffect(() => {
    const unsubscribe = subscribeToAllSessions((data) => {
      setAllSessions(data);
    }, () => {
      console.error("Error subscribing to all sessions in SchedulingModal");
    });
    return () => unsubscribe();
  }, []);

  const getConflictSession = (tutorId: string, timeString: string) => {
    if (!tutorId || !timeString) return null;
    try {
      const selectedTime = new Date(timeString);
      if (isNaN(selectedTime.getTime())) return null;

      return allSessions.find(s => {
        if (s.tutorId !== tutorId) return false;
        if (s.status === 'completed' || s.status === 'cancelled') return false;
        
        const sTime = s.startTime?.toDate ? s.startTime.toDate() : new Date(s.startTime);
        // Check if session times overlap (assuming 50 mins sessions + 10 min buffer)
        const diffMs = Math.abs(selectedTime.getTime() - sTime.getTime());
        return diffMs < 60 * 60 * 1000; // Less than 60 mins apart is considered a block conflict
      });
    } catch {
      return null;
    }
  };

  const conflictSession = getConflictSession(selectedTutorId, trialTime);

  const getSelectedDayAndHour = (timeVal: string) => {
    if (!timeVal) return null;
    try {
      const dt = new Date(timeVal);
      if (isNaN(dt.getTime())) return null;
      const days = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
      const dayName = days[dt.getDay()];
      const hourVal = `${String(dt.getHours()).padStart(2, '0')}:00`;
      return { dayName, hourVal };
    } catch {
      return null;
    }
  };

  const selectedInfo = getSelectedDayAndHour(trialTime);

  // Get all requested slots/preferences of parent
  const getParentsRequestedSlots = () => {
    const list: string[] = [];
    if (lead?.chosenSchedule) {
      lead.chosenSchedule.split(',').forEach((s: string) => {
        if (s.trim()) list.push(s.trim());
      });
    }
    if (lead?.preferredTime) list.push(lead.preferredTime);
    if (lead?.preferredTime2) list.push(lead.preferredTime2);
    if (lead?.preferredTime3) list.push(lead.preferredTime3);
    return list;
  };

  const getTutorCompatibility = (tutor: any) => {
    const requested = getParentsRequestedSlots();
    if (requested.length === 0) return { score: 0, matchCount: 0, totalCount: 0, matches: [] };
    
    const avail = getFilteredAvailability(tutor.availability, tutor.id, allSessions);
    if (!avail) return { score: 0, matchCount: 0, totalCount: requested.length, matches: [] };
    
    let matchCount = 0;
    const matches: string[] = [];
    
    requested.forEach(slotStr => {
      let dayName = '';
      let hourVal = '';
      
      const weekdays = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
      const foundDay = weekdays.find(w => slotStr.toLowerCase().includes(w));
      if (foundDay) {
        dayName = foundDay;
      }
      
      const matchHour = slotStr.match(/(\d{1,2}):(\d{2})/);
      if (matchHour) {
        let h = parseInt(matchHour[1]);
        const m = matchHour[2];
        if (slotStr.toUpperCase().includes('PM') && h < 12) h += 12;
        if (slotStr.toUpperCase().includes('AM') && h === 12) h = 0;
        hourVal = `${String(h).padStart(2, '0')}:${m}`;
      }
      
      if (dayName && hourVal) {
        const hasSlot = avail[dayName]?.active && avail[dayName].slots?.includes(hourVal);
        if (hasSlot) {
          matchCount++;
          matches.push(`${dayName.toUpperCase().substring(0, 3)} @ ${hourVal}`);
        }
      }
    });
    
    const percentage = requested.length > 0 ? Math.round((matchCount / requested.length) * 100) : 0;
    return {
      score: percentage,
      matchCount,
      totalCount: requested.length,
      matches
    };
  };

  const sortedTutorsByCompatibility = [...tutors].sort((a, b) => {
    const aComp = getTutorCompatibility(a);
    const bComp = getTutorCompatibility(b);
    if (bComp.score !== aComp.score) {
      return bComp.score - aComp.score; // Descending order of compatibility score
    }
    
    // Fall back to target slot hour match
    if (!selectedInfo) return 0;
    const aAvailData = getFilteredAvailability(a.availability, a.id, allSessions);
    const bAvailData = getFilteredAvailability(b.availability, b.id, allSessions);
    const aAvail = !!aAvailData?.[selectedInfo.dayName]?.slots?.includes(selectedInfo.hourVal);
    const bAvail = !!bAvailData?.[selectedInfo.dayName]?.slots?.includes(selectedInfo.hourVal);
    if (aAvail && !bAvail) return -1;
    if (!aAvail && bAvail) return 1;
    return 0;
  });

  const sortedTutors = sortedTutorsByCompatibility;

  const handleScheduleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!lead || !selectedTutorId || !trialTime) return;

    setIsScheduling(true);
    setSchedulingStatus('idle');

    const tutor = tutors.find(t => t.id === selectedTutorId);
    if (!tutor) return;

    const result = await scheduleTrial(
      lead.id,
      { 
        id: tutor.id, 
        name: tutor.displayName || tutor.email, 
        email: tutor.email,
        classroomLink: tutor.classroomLink || ''
      },
      new Date(trialTime),
      lead
    );

    if (result.success) {
      setSchedulingStatus('success');
      setTimeout(() => {
        onClose();
      }, 2000);
    } else {
      setSchedulingStatus('error');
    }
    setIsScheduling(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm overflow-y-auto animate-in fade-in duration-200">
      <div className="bg-white w-full max-w-md rounded-2xl shadow-2xl overflow-hidden max-h-[90vh] flex flex-col animate-in zoom-in-95 duration-200">
        <div className="p-6 bg-slate-900 text-white flex justify-between items-center shrink-0">
          <div>
            <h3 className="font-bold text-lg leading-tight">Schedule Trial Session</h3>
            <p className="text-slate-400 text-xs mt-1">Assigning {lead.childName}'s first session</p>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-white/10 rounded-full transition-colors">
            <X size={20} />
          </button>
        </div>
        
        <form onSubmit={handleScheduleSubmit} className="p-6 space-y-5 overflow-y-auto flex-1">
          {schedulingStatus === 'success' ? (
            <div className="py-10 flex flex-col items-center justify-center text-center gap-4">
              <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center animate-bounce">
                <CheckCircle2 size={32} />
              </div>
              <div>
                <h4 className="font-bold text-slate-900">Trial Scheduled!</h4>
                <p className="text-sm text-slate-500">Emails dispatched to parent and tutor.</p>
              </div>
            </div>
          ) : schedulingStatus === 'error' ? (
            <div className="p-4 bg-red-50 border border-red-100 rounded-xl text-red-600 flex gap-3 text-sm">
              <AlertCircle size={18} className="shrink-0" />
              <p>Failed to schedule trial. Please try again or check logs.</p>
            </div>
          ) : (
            <>
              {lead?.tutorId && lead?.tutorId.trim() !== "" && (
                <div className="p-3.5 bg-indigo-50 border border-indigo-150 rounded-xl space-y-1">
                  <div className="flex items-center gap-1.5 text-indigo-855 font-black text-[11px] uppercase tracking-wider">
                    <span className="text-sm">👤</span>
                    <span>Parent Hand-Selected Tutor</span>
                  </div>
                  <p className="text-[10px] text-indigo-700 leading-normal font-medium">
                    This parent hand-picked <strong>{lead.tutorName || "a specific tutor"}</strong> during their trial booking checkout. The dropdown below has been auto-configured to match their selection.
                  </p>
                </div>
              )}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Select Heritage Tutor</label>
                  {tutors.length === 0 && (
                     <Link to="/admin/tutors" className="text-[10px] text-primary hover:underline font-bold flex items-center gap-1">
                        <Plus size={10} /> Add Tutor First
                     </Link>
                  )}
                </div>
                <select 
                  required
                  value={selectedTutorId}
                  onChange={(e) => setSelectedTutorId(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg px-4 py-2.5 text-sm focus:ring-2 focus:ring-primary/10 transition-all outline-none"
                >
                  <option value="">{tutors.length === 0 ? "No tutors onboarded yet..." : "Choose a tutor..."}</option>
                  {sortedTutors.map(t => {
                    const localAvail = getFilteredAvailability(t.availability, t.id, allSessions);
                    const isAvailable = selectedInfo && localAvail?.[selectedInfo.dayName]?.active && localAvail?.[selectedInfo.dayName]?.slots?.includes(selectedInfo.hourVal);
                    const comp = getTutorCompatibility(t);
                    return (
                      <option key={t.id} value={t.id}>
                        {t.displayName || t.email} ({comp.score}% Match) {selectedInfo ? (isAvailable ? " (✅ Available Match)" : " (❌ Conflict)") : ""}
                      </option>
                    );
                  })}
                </select>
                {tutors.length === 0 && (
                   <p className="text-[10px] text-orange-500 font-medium">You need to add at least one tutor in the "Tutors" section before assigning sessions.</p>
                )}
                
                {tutors.length > 0 && (
                  <div className="mt-3.5 bg-slate-50 border border-slate-200 rounded-xl p-3.5 space-y-2.5">
                    <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-1.5">
                      <span>🤖 Smart AI Auto-Assign Tutor Suggestions</span>
                    </p>
                    <div className="grid grid-cols-1 gap-2 max-h-[160px] overflow-y-auto">
                      {sortedTutorsByCompatibility.slice(0, 3).map((tutor) => {
                        const comp = getTutorCompatibility(tutor);
                        const isSelected = selectedTutorId === tutor.id;
                        return (
                          <div 
                            key={tutor.id} 
                            onClick={() => setSelectedTutorId(tutor.id)}
                            className={cn(
                              "p-2.5 rounded-lg border text-left cursor-pointer transition-all flex items-center justify-between",
                              isSelected 
                                ? "bg-indigo-50 border-indigo-250 shadow-sm font-semibold" 
                                : "bg-white border-slate-150 hover:bg-slate-50 hover:border-slate-300"
                            )}
                          >
                            <div className="space-y-0.5">
                              <p className="text-xs font-bold text-slate-805 flex items-center gap-1.5">
                                <span>{tutor.displayName || tutor.email}</span>
                                {comp.score === 100 && (
                                  <span className="bg-emerald-50 text-emerald-800 text-[8px] font-black px-1.5 py-0.5 rounded uppercase tracking-wider scale-90">
                                    🏆 Best Match
                                  </span>
                                )}
                              </p>
                              <p className="text-[9px] text-slate-450 leading-normal">
                                Matches {comp.matchCount} / {comp.totalCount} parent requested slots
                              </p>
                              {comp.matches.length > 0 && (
                                <p className="text-[8px] font-mono text-indigo-500 font-extrabold mt-1">
                                  Free: {comp.matches.join(', ')}
                                </p>
                              )}
                            </div>
                            <div className="text-right">
                              <span className={cn(
                                "text-[10px] font-black font-mono",
                                comp.score >= 80 ? "text-emerald-600" : comp.score >= 50 ? "text-amber-500" : "text-slate-400"
                              )}>
                                {comp.score}% Match
                              </span>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}
                {/* Tutor Availability Showroom */}
                {selectedTutorId && (() => {
                  const tutor = tutors.find(t => t.id === selectedTutorId);
                  if (!tutor) return null;
                  const avail = getFilteredAvailability(tutor.availability, tutor.id, allSessions);
                  if (!avail) {
                    return (
                      <p className="text-[9px] text-slate-400 italic mt-1.5">* No structured weekly availability map has been saved by this tutor yet.</p>
                    );
                  }
                  const activeEntries = Object.entries(avail).filter(([_, data]: [string, any]) => data && data.active && data.slots?.length > 0);
                  if (activeEntries.length === 0) {
                    return (
                      <p className="text-[9px] text-amber-600 font-semibold italic mt-1.5">⚠️ Selected tutor is currently marked as fully unavailable in their Checkbox Grid.</p>
                    );
                  }
                  return (
                    <div className="bg-slate-50 border border-slate-150 rounded-xl p-3 space-y-1.5 animate-in fade-in duration-150 mt-2">
                      <span className="text-[9px] font-bold text-slate-400 uppercase tracking-wider block">Checked Weekly Hours:</span>
                      <div className="space-y-1 max-h-[105px] overflow-y-auto">
                        {activeEntries.map(([day, data]: [string, any]) => (
                          <div key={day} className="flex justify-between text-[10px]">
                            <span className="capitalize font-bold text-slate-705">{day.substring(0, 3)}:</span>
                            <span className="font-semibold text-slate-600 max-w-[180px] truncate text-right">
                              {data.slots.map((s: any) => {
                                const str = getSlotTimeString(s);
                                const h = parseInt(str.split(':')[0] || '9');
                                return h >= 12 ? `${h === 12 ? 12 : h - 12}:00 PM` : `${h}:00 AM`;
                              }).join(', ')}
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>
                  );
                })()}
              </div>

                <div className="bg-amber-50 border border-amber-100 p-4 rounded-xl space-y-4">
                  <div className="flex items-center justify-between text-amber-800">
                    <div className="flex items-center gap-2">
                      <Calendar size={14} className="shrink-0" />
                      <span className="text-[10px] font-bold uppercase tracking-widest">Parent's Preferences</span>
                    </div>
                    {lead.tutorPreferredOptionIndex && (
                      <span className="bg-emerald-100 text-emerald-800 text-[9px] font-extrabold px-2 py-0.5 rounded-md uppercase tracking-wider animate-pulse">
                        Tutor Replied Choice ✅
                      </span>
                    )}
                  </div>
                  <div className="grid grid-cols-1 gap-2">
                    {[
                      { label: 'Option 1 (Gold)', time: lead.preferredTime, index: 1 },
                      { label: 'Option 2 (Silver)', time: lead.preferredTime2, index: 2 },
                      { label: 'Option 3 (Bronze)', time: lead.preferredTime3, index: 3 }
                    ].map((opt, i) => opt.time && (
                      <div 
                        key={i} 
                        className={cn(
                          "flex items-center justify-between p-2 rounded-lg border transition-all",
                          lead.tutorPreferredOptionIndex === opt.index 
                            ? "bg-emerald-50 border-emerald-300 shadow-sm" 
                            : "bg-white/60 border-amber-200/50 hover:bg-white"
                        )}
                      >
                        <div className="flex flex-col">
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <span className={cn(
                              "text-[8px] font-bold uppercase",
                              lead.tutorPreferredOptionIndex === opt.index ? "text-emerald-700 font-extrabold" : "text-amber-600"
                            )}>
                              {opt.label}
                            </span>
                            {lead.tutorPreferredOptionIndex === opt.index && (
                              <span className="bg-emerald-250 text-emerald-800 text-[8px] font-black px-1.5 py-0.2 rounded uppercase tracking-wider scale-95 origin-left">
                                Tutor Choice ⭐
                              </span>
                            )}
                          </div>
                          <span className="text-xs font-bold text-slate-800">{opt.time}</span>
                        </div>
                        <div className="text-[9px] font-mono text-slate-400 font-bold px-2">
                          Preference Reference
                        </div>
                      </div>
                    ))}
                    {!lead.preferredTime && <p className="text-[10px] italic text-amber-600">No specific preferences provided.</p>}
                  </div>
                  <p className="text-[10px] text-amber-700 leading-tight">
                    <strong>Note:</strong> Select a definitive date/time below. The tutor's responded choice is flagged matching their calendar checklist.
                  </p>
                </div>

                <div className={cn("space-y-2", tutors.length === 0 && "opacity-50 pointer-events-none")}>
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Confirm Final Session Time (GMT)</label>
                  <div className="relative">
                    <Calendar className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
                    <input 
                      required
                      disabled={tutors.length === 0}
                      type="datetime-local" 
                      value={trialTime}
                      onChange={(e) => setTrialTime(e.target.value)}
                      className={cn(
                        "w-full bg-slate-50 border rounded-lg pl-12 pr-4 py-2.5 text-sm focus:ring-2 focus:ring-primary/10 transition-all outline-none",
                        conflictSession ? "border-rose-300 bg-rose-50 text-rose-950 focus:ring-rose-200" : "border-slate-200"
                      )} 
                    />
                  </div>
                  {conflictSession && (
                    <div className="p-3 bg-rose-50 border border-rose-100 rounded-xl text-rose-700 flex gap-2 text-xs font-medium animate-in slide-in-from-top-1 duration-150">
                      <AlertCircle size={14} className="shrink-0 mt-0.5" />
                      <div>
                        <strong className="block font-bold">⚠️ Scheduling Conflict Warning!</strong>
                        The selected tutor already has an active session scheduled with student <strong>{conflictSession.studentName}</strong> around this time block. Double-booking is discouraged.
                      </div>
                    </div>
                  )}
                </div>

              <button 
                disabled={isScheduling || tutors.length === 0}
                type="submit" 
                className="w-full bg-slate-900 text-white font-bold py-3 rounded-xl shadow-lg shadow-slate-900/20 flex items-center justify-center gap-2 hover:bg-slate-800 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isScheduling ? <Loader2 className="animate-spin" size={18} /> : "Dispatch Invites"}
              </button>
            </>
          )}
        </form>
      </div>
    </div>
  );
}

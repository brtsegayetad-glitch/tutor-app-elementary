/**
 * Purpose: Real-time Notification Bell component for the Dashboard Header.
 * Displays unread count and a dropdown list of recent notifications.
 */

import React, { useState, useEffect } from 'react';
import { Bell, MessageSquare, Calendar, UserPlus, Info, Check } from 'lucide-react';
import { subscribeToNotifications, markNotificationAsRead, markAllNotificationsAsRead } from '../services/dataService';
import { Notification, NotificationType } from '../types';
import { useAuth } from '../context/AuthContext';
import { cn } from '../lib/utils';
import { formatDistanceToNow } from 'date-fns';
import { motion, AnimatePresence } from 'motion/react';
import { Link } from 'react-router-dom';

const typeIcons: Record<NotificationType, any> = {
  message: MessageSquare,
  booking: UserPlus,
  schedule_change: Calendar,
  system: Info
};

const typeColors: Record<NotificationType, string> = {
  message: 'text-blue-500 bg-blue-50',
  booking: 'text-emerald-500 bg-emerald-50',
  schedule_change: 'text-orange-500 bg-orange-50',
  system: 'text-slate-500 bg-slate-50'
};

export default function NotificationBell() {
  const { user } = useAuth();
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [isOpen, setIsOpen] = useState(false);
  const unreadCount = notifications.filter(n => !n.isRead).length;

  useEffect(() => {
    if (!user?.uid) return;

    const unsubscribe = subscribeToNotifications(user.uid, (data) => {
      setNotifications(data);
    });

    return () => unsubscribe();
  }, [user?.uid]);

  const handleMarkAsRead = async (id: string) => {
    await markNotificationAsRead(id);
  };

  const handleMarkAllAsRead = async () => {
    if (user?.uid) {
      await markAllNotificationsAsRead(user.uid);
    }
  };

  return (
    <div className="relative">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="relative p-2 text-slate-400 hover:text-slate-600 transition-colors cursor-pointer group"
        id="notification-bell-btn"
      >
        <Bell size={20} className="group-hover:scale-110 transition-transform" />
        {unreadCount > 0 && (
          <span className="absolute top-1.5 right-1.5 w-4 h-4 bg-secondary text-white text-[10px] font-bold rounded-full border-2 border-white flex items-center justify-center animate-in zoom-in duration-300">
            {unreadCount > 9 ? '9+' : unreadCount}
          </span>
        )}
      </button>

      <AnimatePresence>
        {isOpen && (
          <>
            <div 
              className="fixed inset-0 z-40" 
              onClick={() => setIsOpen(false)} 
            />
            <motion.div
              initial={{ opacity: 0, y: 10, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 10, scale: 0.95 }}
              transition={{ duration: 0.15 }}
              className="absolute right-0 top-12 mt-2 bg-white border border-slate-200 rounded-2xl shadow-2xl w-80 z-50 overflow-hidden"
            >
              <div className="px-4 py-3 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
                <span className="text-sm font-bold text-slate-800">Notifications</span>
                {unreadCount > 0 && (
                  <button 
                    onClick={handleMarkAllAsRead}
                    className="text-[10px] font-bold text-secondary hover:text-secondary/80 flex items-center gap-1"
                  >
                    <Check size={12} />
                    Mark all as read
                  </button>
                )}
              </div>

              <div className="max-h-[400px] overflow-y-auto">
                {notifications.length > 0 ? (
                  <div className="divide-y divide-slate-50">
                    {notifications.map((notification) => {
                      const Icon = typeIcons[notification.type] || Info;
                      const timeStr = notification.createdAt?.toDate 
                        ? formatDistanceToNow(notification.createdAt.toDate(), { addSuffix: true })
                        : 'recently';

                      return (
                        <div 
                          key={notification.id}
                          className={cn(
                            "p-4 transition-colors relative group",
                            !notification.isRead ? "bg-secondary/5" : "hover:bg-slate-50"
                          )}
                        >
                          <div className="flex gap-3">
                            <div className={cn("w-8 h-8 rounded-full flex items-center justify-center shrink-0", typeColors[notification.type])}>
                              <Icon size={14} />
                            </div>
                            <div className="flex-1 min-w-0">
                              <div className="flex items-start justify-between gap-2">
                                <p className={cn("text-xs font-bold leading-tight", !notification.isRead ? "text-slate-900" : "text-slate-600")}>
                                  {notification.title}
                                </p>
                                {!notification.isRead && (
                                  <span className="w-1.5 h-1.5 bg-secondary rounded-full shrink-0 mt-1"></span>
                                )}
                              </div>
                              <p className="text-[11px] text-slate-500 mt-1 leading-relaxed">
                                {notification.message}
                              </p>
                              <div className="flex items-center justify-between mt-2">
                                <span className="text-[9px] text-slate-400 font-bold uppercase tracking-wider">
                                  {timeStr}
                                </span>
                                {notification.link && (
                                  <Link
                                    to={notification.link}
                                    onClick={() => {
                                      handleMarkAsRead(notification.id);
                                      setIsOpen(false);
                                    }}
                                    className="text-[10px] font-bold text-secondary hover:underline"
                                  >
                                    View details
                                  </Link>
                                )}
                              </div>
                            </div>
                          </div>
                          {!notification.isRead && (
                            <button
                              onClick={() => handleMarkAsRead(notification.id)}
                              className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 p-1 text-slate-400 hover:text-secondary transition-all"
                              title="Mark as read"
                            >
                              <Check size={12} />
                            </button>
                          )}
                        </div>
                      );
                    })}
                  </div>
                ) : (
                  <div className="py-12 text-center">
                    <div className="w-12 h-12 bg-slate-50 rounded-full flex items-center justify-center mx-auto mb-3">
                      <Bell size={20} className="text-slate-300" />
                    </div>
                    <p className="text-xs text-slate-500 font-medium">No notifications yet</p>
                  </div>
                )}
              </div>
              
              {notifications.length > 0 && (
                <div className="p-2 border-t border-slate-100 bg-slate-50/50 text-center">
                  <button className="text-[10px] font-bold text-slate-400 hover:text-slate-600 transition-colors">
                    View all history
                  </button>
                </div>
              )}
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}

import { CheckCircle2 } from 'lucide-react';

interface PathwaySelectorProps {
  onSelect: (lang: 'Amharic' | "Ge'ez" | 'Both') => void;
}

export default function PathwaySelector({ onSelect }: PathwaySelectorProps) {
  return (
    <div id="pathway-selector-container" className="bg-white p-8 rounded-[36px] border border-slate-100 space-y-6 shadow-sm animate-in fade-in zoom-in-95 duration-300">
      <div className="text-center space-y-2">
        <span className="text-[10px] uppercase font-bold tracking-widest text-indigo-700 bg-indigo-50 border border-indigo-100 px-3 py-1 rounded-full font-sans">
          Target Language Setup
        </span>
        <h2 className="text-2xl font-serif font-extrabold text-slate-900 mt-2">Choose Your Child's Study Pathway</h2>
        <p className="text-xs text-slate-500 leading-relaxed font-sans max-w-sm mx-auto">
          Select the linguistic focus for your free assessment session. You can change this setting at any time.
        </p>
      </div>

      <div className="grid grid-cols-1 gap-4">
        <button
          id="select-amharic-btn"
          type="button"
          onClick={() => onSelect('Amharic')}
          className="p-5 rounded-[24px] border border-slate-100 bg-slate-50/40 hover:border-indigo-600 hover:bg-indigo-50/5 text-left transition-all cursor-pointer flex items-center gap-4 group"
        >
          <div className="w-12 h-12 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center font-bold text-lg border border-emerald-100 group-hover:scale-105 transition-transform font-sans">አ</div>
          <div className="flex-1">
            <div className="flex items-center gap-2">
              <h3 className="font-bold text-sm text-slate-900 font-sans">Amharic (አማርኛ)</h3>
              <span className="text-[9px] bg-emerald-50 text-emerald-700 font-extrabold px-1.5 py-0.2 rounded font-sans">Syllabus 1</span>
            </div>
            <p className="text-[11px] text-slate-500 font-medium leading-relaxed mt-0.5 font-sans">Heritage speaking, daily conversations, vocabulary and sentence composition.</p>
          </div>
        </button>

        <button
          id="select-geez-btn"
          type="button"
          onClick={() => onSelect("Ge'ez")}
          className="p-5 rounded-[24px] border border-slate-100 bg-slate-50/40 hover:border-indigo-600 hover:bg-indigo-50/5 text-left transition-all cursor-pointer flex items-center gap-4 group"
        >
          <div className="w-12 h-12 rounded-xl bg-indigo-50 text-indigo-700 flex items-center justify-center font-bold text-lg border border-indigo-100 group-hover:scale-105 transition-transform font-sans">ግ</div>
          <div className="flex-1">
            <div className="flex items-center gap-2">
              <h3 className="font-bold text-sm text-slate-900 font-sans font-sans">Ge'ez Language (ግዕዝ)</h3>
              <span className="text-[9px] bg-indigo-50 text-indigo-700 font-extrabold px-1.5 py-0.2 rounded font-sans">Syllabus 2</span>
            </div>
            <p className="text-[11px] text-slate-500 font-medium leading-relaxed mt-0.5 font-sans">Classical Ethiopic script studies, basic liturgy grammar, and cultural heritage.</p>
          </div>
        </button>

        <button
          id="select-both-btn"
          type="button"
          onClick={() => onSelect('Both')}
          className="p-5 rounded-[24px] border-2 border-indigo-600 bg-indigo-50/10 hover:bg-indigo-50/15 text-left transition-all cursor-pointer flex items-center gap-4 relative overflow-hidden group"
        >
          <div className="absolute top-0 right-0 bg-indigo-600 text-white text-[8px] font-black uppercase tracking-wider px-3 py-1 rounded-bl-lg font-sans">Double Pathway</div>
          <div className="w-12 h-12 rounded-xl bg-indigo-100 text-indigo-800 flex items-center justify-center font-bold text-lg border border-indigo-200 group-hover:scale-105 transition-transform">✨</div>
          <div className="flex-1">
            <h3 className="font-bold text-sm text-slate-900 font-sans">Both Pathways (Amharic & Ge'ez)</h3>
            <p className="text-[11px] text-slate-500 font-medium leading-relaxed mt-0.5 font-sans">Seamlessly book trial sessions for both languages back-to-back with custom expert tutors.</p>
          </div>
        </button>
      </div>
    </div>
  );
}

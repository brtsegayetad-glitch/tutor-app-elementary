import React, { useState, useEffect } from 'react';
import { Download, X, Smartphone, Monitor, Plus } from 'lucide-react';
import { cn } from '../lib/utils';

export default function PWAInstallPrompt() {
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [showPrompt, setShowPrompt] = useState(false);
  const [isIOS, setIsIOS] = useState(false);
  const [isStandalone, setIsStandalone] = useState(false);

  useEffect(() => {
    // Check if already installed
    if (window.matchMedia('(display-mode: standalone)').matches || (window.navigator as any).standalone) {
      setIsStandalone(true);
      return;
    }

    // Check if iOS
    const isIOSDevice = /iPad|iPhone|iPod/.test(navigator.userAgent) && !(window as any).MSStream;
    setIsIOS(isIOSDevice);

    const handleBeforeInstallPrompt = (e: any) => {
      // Prevent Chrome 67 and earlier from automatically showing the prompt
      e.preventDefault();
      // Stash the event so it can be triggered later.
      setDeferredPrompt(e);
      // Update UI notify the user they can install the PWA
      setShowPrompt(true);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);

    // If it's iOS and not standalone, show prompt after a short delay
    if (isIOSDevice && !window.matchMedia('(display-mode: standalone)').matches) {
      const timer = setTimeout(() => {
        setShowPrompt(true);
      }, 5000);
      return () => clearTimeout(timer);
    }

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    };
  }, []);

  const handleInstallClick = async () => {
    if (!deferredPrompt) return;
    
    // Show the install prompt
    deferredPrompt.prompt();
    
    // Wait for the user to respond to the prompt
    const { outcome } = await deferredPrompt.userChoice;
    console.log(`User response to the install prompt: ${outcome}`);
    
    // We've used the prompt, and can't use it again, throw it away
    setDeferredPrompt(null);
    setShowPrompt(false);
  };

  if (isStandalone || !showPrompt) return null;

  return (
    <div className="fixed bottom-6 left-6 right-6 md:left-auto md:right-8 md:bottom-8 md:w-80 z-[100] animate-in slide-in-from-bottom-8 duration-500">
      <div className="bg-white rounded-2xl shadow-2xl border border-slate-100 overflow-hidden">
        <div className="p-5">
          <div className="flex items-start justify-between mb-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-primary rounded-xl flex items-center justify-center shadow-lg shadow-primary/20 overflow-hidden">
                <img src="/icon-512.jpg" alt="HabKids Logo" className="w-full h-full object-cover" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-slate-900">Install HabKids tutor</h3>
                <p className="text-[10px] text-slate-500 font-medium">Get the best experience on your device</p>
              </div>
            </div>
            <button 
              onClick={() => setShowPrompt(false)}
              className="text-slate-400 hover:text-slate-600 transition-colors"
            >
              <X size={18} />
            </button>
          </div>

          {isIOS ? (
            <div className="space-y-3 bg-slate-50 rounded-xl p-3 border border-slate-100">
              <p className="text-[10px] text-slate-600 leading-relaxed font-medium">
                To install on your iPhone/iPad:
              </p>
              <div className="flex items-center gap-2 text-[10px] text-slate-800 font-bold">
                <div className="w-6 h-6 bg-white rounded border border-slate-200 flex items-center justify-center text-blue-500">
                  <Download size={14} className="rotate-180" />
                </div>
                <span>1. Tap the Share button</span>
              </div>
              <div className="flex items-center gap-2 text-[10px] text-slate-800 font-bold">
                <div className="w-6 h-6 bg-white rounded border border-slate-200 flex items-center justify-center text-slate-600">
                  <Plus size={14} />
                </div>
                <span>2. Select "Add to Home Screen"</span>
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="flex items-center gap-4 text-slate-400">
                <div className="flex items-center gap-1">
                  <Smartphone size={14} />
                  <span className="text-[9px] font-bold uppercase tracking-wider">Mobile</span>
                </div>
                <div className="flex items-center gap-1">
                  <Monitor size={14} />
                  <span className="text-[9px] font-bold uppercase tracking-wider">Desktop</span>
                </div>
              </div>
              
              <button
                onClick={handleInstallClick}
                className="w-full bg-slate-900 text-white font-bold text-xs py-3 rounded-xl hover:bg-slate-800 transition-all flex items-center justify-center gap-2 shadow-lg shadow-slate-900/10"
              >
                <Download size={14} />
                <span>Install Application</span>
              </button>
            </div>
          )}
        </div>
        <div className="bg-slate-50 px-5 py-2 border-t border-slate-100">
          <p className="text-[9px] text-slate-400 font-medium text-center italic">Works offline & fast loading</p>
        </div>
      </div>
    </div>
  );
}

import React, { useState, useEffect } from 'react';
import { Volume2, Sparkles, Check, ArrowRight, RefreshCw, Trophy } from 'lucide-react';
import { playAudioOrSpeak } from '../utils/audioPlayer';

const SANDBOX_QUESTS = [
  {
    target: "ሉ",
    phonetic: "Lu",
    word: "ሉል (Pearl)",
    voiceText: "ሉ",
    choices: ["ለ", "ሉ", "ሊ", "ላ"],
    colors: ["from-pink-500 to-rose-600", "from-indigo-500 to-blue-600", "from-orange-400 to-amber-500", "from-emerald-400 to-teal-500"],
    title: "ምዕራፍ ፩ — Meraf 1: Foundations of ለ (Le)",
    subtitle: "Unit 1 • Module 1.1 — Game 6: Bubble Pop: ሉ"
  },
  {
    target: "ሙ",
    phonetic: "Mu",
    word: "ሙዝ (Banana)",
    voiceText: "ሙ",
    choices: ["መ", "ማ", "ሙ", "ሜ"],
    colors: ["from-pink-500 to-rose-600", "from-orange-400 to-amber-500", "from-indigo-500 to-blue-600", "from-emerald-400 to-teal-500"],
    title: "ምዕራፍ ፪ — Meraf 2: Foundations of መ (Me)",
    subtitle: "Unit 2 • Module 2.1 — Game 6: Bubble Pop: ሙ"
  },
  {
    target: "ሊ",
    phonetic: "Li",
    word: "ሊስትሮ (Shoe Shiner)",
    voiceText: "ሊ",
    choices: ["ለ", "ሊ", "ላ", "ሎ"],
    colors: ["from-teal-400 to-emerald-500", "from-purple-500 to-indigo-600", "from-cyan-400 to-blue-500", "from-pink-400 to-rose-500"],
    title: "ምዕራፍ ፩ — Meraf 1: Foundations of ለ (Le)",
    subtitle: "Unit 1 • Module 1.1 — Game 3: Bubble Pop: ሊ"
  },
  {
    target: "ሳ",
    phonetic: "Sa",
    word: "ሳጥን (Box)",
    voiceText: "ሳ",
    choices: ["ሰ", "ሲ", "ሳ", "ሴ"],
    colors: ["from-purple-400 to-indigo-500", "from-amber-400 to-orange-500", "from-blue-500 to-indigo-600", "from-rose-400 to-pink-500"],
    title: "ምዕራፍ ፫ — Meraf 3: Foundations of ሰ (Se)",
    subtitle: "Unit 3 • Module 3.1 — Game 6: Bubble Pop: ሳ"
  },
  {
    target: "ሮ",
    phonetic: "Ro",
    word: "ሮማን (Pomegranate)",
    voiceText: "ሮ",
    choices: ["ረ", "ሩ", "ሪ", "ሮ"],
    colors: ["from-cyan-400 to-sky-500", "from-emerald-400 to-teal-500", "from-rose-500 to-red-600", "from-indigo-500 to-blue-600"],
    title: "ምዕራፍ ፬ — Meraf 4: Foundations of ረ (Re)",
    subtitle: "Unit 4 • Module 4.1 — Game 6: Bubble Pop: ሮ"
  },
  {
    target: "ቁ",
    phonetic: "Qu",
    word: "ቁልፍ (Key)",
    voiceText: "ቁ",
    choices: ["ቀ", "ቁ", "ቂ", "ቃ"],
    colors: ["from-pink-400 to-rose-500", "from-purple-500 to-indigo-600", "from-orange-400 to-amber-500", "from-emerald-500 to-teal-600"],
    title: "ምዕራፍ ጱ — Meraf 5: Foundations of ቀ (Qe)",
    subtitle: "Unit 5 • Module 5.1 — Game 6: Bubble Pop: ቁ"
  }
];

export default function BubblePopSandbox() {
  const [currentIdx, setCurrentIdx] = useState(0);
  const [score, setScore] = useState(0);
  const [streak, setStreak] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const [poppedBubbles, setPoppedBubbles] = useState<string[]>([]);
  const [message, setMessage] = useState<{ text: string; isCorrect: boolean } | null>(null);
  const [isPopping, setIsPopping] = useState<string | null>(null);

  const quest = SANDBOX_QUESTS[currentIdx];

  // Map choices to positions on the canvas so they look scattered and realistic
  const bubblePositions = [
    { left: "15%", animClass: "bubble-rise-1" },
    { left: "38%", animClass: "bubble-rise-2" },
    { left: "62%", animClass: "bubble-rise-3" },
    { left: "85%", animClass: "bubble-rise-4" },
  ];

  const speakText = (text: string, lang?: string) => {
    playAudioOrSpeak(text);
  };

  const playTargetSound = () => {
    speakText(quest.target);
    setMessage({ text: `Listen carefully to "${quest.target}" (${quest.phonetic})`, isCorrect: true });
  };

  useEffect(() => {
    setMessage({ text: `Listen carefully to "${quest.target}" (${quest.phonetic})`, isCorrect: true });
  }, [currentIdx]);

  const handleBubbleClick = (choice: string) => {
    if (selectedAnswer !== null) return; // Prevent multiple clicks during evaluation

    setIsPopping(choice);
    setTimeout(() => {
      setIsPopping(null);
    }, 300);

    const isCorrect = choice === quest.target;
    setSelectedAnswer(choice);

    if (isCorrect) {
      setScore((prev) => prev + 15);
      setStreak((prev) => prev + 1);
      setMessage({ text: `✨ Brilliant! "${choice}" is correct!`, isCorrect: true });
      speakText("Very good! correct", "en-US");
    } else {
      setStreak(0);
      setPoppedBubbles((prev) => [...prev, choice]);
      setMessage({ text: `Oops! That's not correct. Try again!`, isCorrect: false });
      speakText("Oops! Try again", "en-US");
      setSelectedAnswer(null); // allow retrying
    }
  };

  const handleNext = () => {
    setSelectedAnswer(null);
    setPoppedBubbles([]);
    setMessage(null);
    if (currentIdx < SANDBOX_QUESTS.length - 1) {
      setCurrentIdx((prev) => prev + 1);
    } else {
      // Loop back to level 1 with a congratulations
      setCurrentIdx(0);
      setScore((prev) => prev + 50); // bonus for completing the set
      setMessage({ text: "🎉 Mastery Unlocked! Restarting practice game with bonus XP!", isCorrect: true });
    }
  };

  const handleReset = () => {
    setCurrentIdx(0);
    setScore(0);
    setStreak(0);
    setSelectedAnswer(null);
    setPoppedBubbles([]);
    setMessage(null);
  };

  return (
    <div id="bubble-pop-sandbox-root" className="w-full bg-white rounded-3xl border border-slate-100 shadow-xl overflow-hidden font-sans p-6 space-y-6">
      {/* Styles for float animation */}
      <style>{`
        @keyframes rise-up {
          0% {
            top: 115%;
            transform: translateX(-50%) scale(0.9);
            opacity: 0;
          }
          10% {
            opacity: 1;
            transform: translateX(-50%) scale(1);
          }
          90% {
            opacity: 1;
            transform: translateX(calc(-50% + var(--wobble-x, 0px))) scale(1);
          }
          100% {
            top: -20%;
            transform: translateX(calc(-50% + var(--wobble-x, 0px))) scale(0.9);
            opacity: 0;
          }
        }
        
        .bubble-rise-1 {
          animation: rise-up 6.5s linear infinite;
          --wobble-x: 25px;
        }
        .bubble-rise-2 {
          animation: rise-up 8s linear infinite;
          animation-delay: 1.5s;
          --wobble-x: -30px;
        }
        .bubble-rise-3 {
          animation: rise-up 7s linear infinite;
          animation-delay: 3s;
          --wobble-x: 20px;
        }
        .bubble-rise-4 {
          animation: rise-up 9s linear infinite;
          animation-delay: 4.5s;
          --wobble-x: -25px;
        }
        
        @keyframes pop-effect {
          0% { transform: scale(1); opacity: 1; }
          50% { transform: scale(1.3); opacity: 0.5; filter: brightness(1.5); }
          100% { transform: scale(0); opacity: 0; }
        }
        .bubble-popping {
          animation: pop-effect 0.3s ease-out forwards !important;
        }
      `}</style>

      {/* Header Info */}
      <div className="flex items-center justify-between pb-4 border-b border-slate-100">
        <div>
          <span className="text-[10px] font-black uppercase text-indigo-600 tracking-wider block">{quest.title}</span>
          <h3 className="text-sm md:text-base font-bold text-slate-800 tracking-tight">{quest.subtitle}</h3>
        </div>
        <div className="flex items-center gap-3">
          <div className="text-right">
            <span className="text-[9px] uppercase font-bold text-slate-400 block">Practice Score</span>
            <span className="text-xs font-extrabold text-indigo-600 flex items-center gap-1 justify-end">
              <Trophy size={12} className="text-amber-500 fill-amber-400" />
              {score} PTS
            </span>
          </div>
          <div className="h-8 w-px bg-slate-100"></div>
          <div className="text-right">
            <span className="text-[9px] uppercase font-bold text-slate-400 block">Streak</span>
            <span className="text-xs font-extrabold text-orange-500">🔥 {streak}</span>
          </div>
        </div>
      </div>

      {/* Game controls and instructions */}
      <div className="bg-amber-50/50 border border-amber-100 rounded-2xl p-4 text-center space-y-3">
        <p className="text-xs font-medium text-amber-900 leading-relaxed">
          Listen carefully, then pop the bubble that matches <span className="font-extrabold text-amber-700 font-serif">"{quest.target}"</span>!
        </p>

        <div className="flex justify-center items-center gap-4">
          <button
            type="button"
            id="play-sandbox-sound-btn"
            onClick={playTargetSound}
            className="inline-flex items-center gap-2 bg-amber-500 hover:bg-amber-600 text-white font-extrabold text-xs uppercase tracking-wider px-5 py-2.5 rounded-xl transition-all shadow-md active:scale-95 cursor-pointer hover:rotate-1"
          >
            <Volume2 size={16} />
            Listen to Sound
          </button>

          <div className="bg-white border border-amber-200 px-4 py-2 rounded-xl shadow-xs text-center min-w-[100px]">
            <span className="text-[8px] uppercase font-bold text-slate-400 block mb-0.5">Target Symbol</span>
            <span className="text-sm font-black text-amber-600 font-serif">"{quest.target}" ({quest.phonetic})</span>
          </div>
        </div>
      </div>

      {/* Interactive Gameplay Canvas */}
      <div className="aspect-[4/3] w-full bg-gradient-to-b from-slate-900 via-indigo-950 to-slate-950 rounded-2xl relative overflow-hidden shadow-inner border border-slate-800">
        {/* Background stars / constellation subtle effect */}
        <div className="absolute inset-0 opacity-10 pointer-events-none flex items-center justify-center">
          <div className="text-[140px] font-black text-white select-none tracking-widest opacity-20">ሀለሐ</div>
        </div>

        {/* Floating Bubble Characters */}
        {quest.choices.map((choice, idx) => {
          const isPopped = poppedBubbles.includes(choice);
          if (isPopped) return null;

          const position = bubblePositions[idx % bubblePositions.length];
          const isPoppingThis = isPopping === choice;

          // Determine glowing colors for our bubble
          const colorClass = quest.colors[idx % quest.colors.length];

          return (
            <div
              key={choice}
              style={{
                left: position.left,
              }}
              className={`absolute w-16 h-16 ${position.animClass}`}
            >
              <button
                type="button"
                id={`sandbox-bubble-${choice}`}
                onClick={() => handleBubbleClick(choice)}
                className={`w-full h-full rounded-full bg-gradient-to-br ${colorClass} text-white font-serif font-black text-2xl flex items-center justify-center shadow-lg cursor-pointer transition-all hover:scale-110 active:scale-90 select-none border border-white/20 hover:border-white/40 ${isPoppingThis ? 'bubble-popping' : ''}`}
              >
                <span className="drop-shadow-md">{choice}</span>
              </button>
            </div>
          );
        })}

        {/* Level Complete / Next overlay */}
        {selectedAnswer === quest.target && (
          <div className="absolute inset-0 bg-slate-950/80 backdrop-blur-xs flex flex-col items-center justify-center p-6 text-center animate-in fade-in zoom-in-95 duration-200">
            <div className="w-14 h-14 bg-emerald-500 rounded-full flex items-center justify-center mb-4 text-white animate-bounce shadow-lg shadow-emerald-500/20">
              <Sparkles size={28} />
            </div>
            <h4 className="text-white font-black text-lg tracking-tight">Excellent! You Found It!</h4>
            <p className="text-indigo-200 text-xs mt-1 mb-6 font-medium">
              "{quest.target}" corresponds to the vocal sound "{quest.phonetic}" as in {quest.word}.
            </p>
            <div className="flex gap-3">
              <button
                type="button"
                id="sandbox-next-btn"
                onClick={handleNext}
                className="bg-white hover:bg-slate-50 text-indigo-950 font-black text-xs uppercase tracking-widest px-6 py-2.5 rounded-xl shadow-md transition-all active:scale-95 flex items-center gap-1.5 cursor-pointer"
              >
                <span>Continue</span>
                <ArrowRight size={14} />
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Message Prompt */}
      {message && (
        <div className={`p-3 rounded-xl text-center text-xs font-bold border transition-all animate-in slide-in-from-bottom-2 ${
          message.isCorrect 
            ? 'bg-emerald-50 border-emerald-100 text-emerald-800' 
            : 'bg-rose-50 border-rose-100 text-rose-800'
        }`}>
          {message.text}
        </div>
      )}

      {/* Footer Info / Portal Note */}
      <div className="flex items-center justify-between pt-2">
        <button
          type="button"
          onClick={handleReset}
          className="text-xs font-semibold text-slate-400 hover:text-slate-600 transition-colors flex items-center gap-1 cursor-pointer"
        >
          <RefreshCw size={12} />
          Reset Practice Game
        </button>
        <span className="text-[10px] text-slate-400 font-medium">
          No sign-in required to play!
        </span>
      </div>
    </div>
  );
}

import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  MessageCircle, 
  X, 
  Send, 
  CheckCircle2, 
  Loader2, 
  ChevronLeft, 
  MessageSquare,
  Sparkles,
  HelpCircle,
  ShieldCheck,
  BookOpen
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { 
  submitSupportTicket, 
  addSupportTicketReply,
  subscribeToMySupportTickets,
  getOrCreateTutorChat,
  sendTutorChatMessage,
  subscribeToTutorChatMessages
} from '../services/dataService';
import { db } from '../lib/firebase';
import { doc, onSnapshot } from 'firebase/firestore';

const formatSafeDate = (val: any, options: Intl.DateTimeFormatOptions = {}): string => {
  if (!val) return "";
  let date: Date;
  if (val && typeof val.toDate === "function") {
    date = val.toDate();
  } else {
    date = new Date(val);
  }
  if (isNaN(date.getTime())) return "";
  return date.toLocaleString('en-US', options);
};

interface SupportWidgetProps {
  assignedTutor?: any;
  onOpenTutorChat?: (tutor: any) => void;
}

export default function SupportWidget({ assignedTutor, onOpenTutorChat }: SupportWidgetProps) {
  const { user } = useAuth();
  const [isOpen, setIsOpen] = useState(false);
  const [widgetTab, setWidgetTab] = useState<'chooser' | 'admin' | 'tutor'>('chooser');
  const [parentName, setParentName] = useState('');
  const [parentEmail, setParentEmail] = useState('');
  const [topic, setTopic] = useState('Curriculum & Program structure');
  const [question, setQuestion] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [submitSuccess, setSubmitSuccess] = useState(false);
  
  // Real-time conversation tracking for admin tickets
  const [activeTicketId, setActiveTicketId] = useState<string | null>(
    localStorage.getItem('active_support_ticket_id')
  );
  const [activeTicket, setActiveTicket] = useState<any | null>(null);
  const [replyText, setReplyText] = useState('');
  const [sendingReply, setSendingReply] = useState(false);

  // Tutor chat states
  const [activeTutorChatId, setActiveTutorChatId] = useState<string | null>(null);
  const [tutorChatMessages, setTutorChatMessages] = useState<any[]>([]);
  const [tutorChatMessageInput, setTutorChatMessageInput] = useState('');
  const [tutorChatViolationWarning, setTutorChatViolationWarning] = useState<string | null>(null);
  const [sendingTutorChatMessageState, setSendingTutorChatMessageState] = useState(false);
  const [loadingTutorChat, setLoadingTutorChat] = useState(false);
  
  // For logged-in users, let them see a list of their tickets
  const [myTickets, setMyTickets] = useState<any[]>([]);
  const [showMyTicketsList, setShowMyTicketsList] = useState(false);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Auto-prefill if user logged in
  useEffect(() => {
    if (user) {
      setParentName(user.fullName || '');
      setParentEmail(user.email || '');
    }
  }, [user]);

  // Adjust widget tab based on active ticket or assigned tutor context
  // Default to chooser welcome screen ALWAYS when first clicked open.
  useEffect(() => {
    if (activeTicketId) {
      setWidgetTab('admin');
    } else if (isOpen) {
      setWidgetTab('chooser');
    }
  }, [activeTicketId, isOpen]);

  // Real-time tutor chat connection when 'tutor' tab is selected
  useEffect(() => {
    if (widgetTab === 'tutor' && assignedTutor && user) {
      const loadChat = async () => {
        setLoadingTutorChat(true);
        const res = await getOrCreateTutorChat({
          parentId: user.uid,
          parentName: user.fullName || user.displayName || "Parent",
          parentEmail: user.email || "",
          tutorId: assignedTutor.id,
          tutorName: assignedTutor.displayName || assignedTutor.name || "Tutor",
          tutorEmail: assignedTutor.email || ""
        });
        setLoadingTutorChat(false);
        if (res.success && res.id) {
          setActiveTutorChatId(res.id);
        } else {
          console.error("Failed to get or create tutor chat thread");
        }
      };
      loadChat();
    } else {
      setActiveTutorChatId(null);
      setTutorChatMessages([]);
    }
  }, [widgetTab, assignedTutor, user]);

  // Subscribe to real-time tutor chat messages
  useEffect(() => {
    if (!activeTutorChatId) return;

    const unsubscribe = subscribeToTutorChatMessages(activeTutorChatId, (messages) => {
      setTutorChatMessages(messages);
    });

    return () => unsubscribe();
  }, [activeTutorChatId]);

  // Real-time subscription to the active ticket, if set
  useEffect(() => {
    if (!activeTicketId) {
      setActiveTicket(null);
      return;
    }
    
    const docRef = doc(db, 'support_tickets', activeTicketId);
    const unsubscribe = onSnapshot(docRef, (docSnap) => {
      if (docSnap.exists()) {
        setActiveTicket({ id: docSnap.id, ...docSnap.data() });
      } else {
        setActiveTicket(null);
        setActiveTicketId(null);
        localStorage.removeItem('active_support_ticket_id');
      }
    }, (error) => {
      console.warn("Permission restricted or ticket not found", error);
    });
    
    return () => unsubscribe();
  }, [activeTicketId]);

  // Real-time subscription to all tickets for logged-in parents
  useEffect(() => {
    if (!user || !user.email) return;
    
    const unsubscribe = subscribeToMySupportTickets(user.email, (tickets) => {
      setMyTickets(tickets);
    });
    
    return () => unsubscribe();
  }, [user]);

  // Always scroll replies/tutor messages to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [activeTicket?.replies, tutorChatMessages]);

  const handleSubmitTicket = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!parentName.trim() || !parentEmail.trim() || !question.trim()) return;

    setSubmitting(true);
    const result = await submitSupportTicket({
      parentName: parentName.trim(),
      parentEmail: parentEmail.trim(),
      question: question.trim(),
      topic
    });
    
    setSubmitting(false);

    if (result.success && result.id) {
      setSubmitSuccess(true);
      setActiveTicketId(result.id);
      localStorage.setItem('active_support_ticket_id', result.id);
      setQuestion('');
      
      setTimeout(() => {
        setSubmitSuccess(false);
      }, 3000);
    } else {
      alert("Something went wrong. Please check your network and try again.");
    }
  };

  const handleSendReply = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!replyText.trim() || !activeTicketId) return;

    setSendingReply(true);
    const senderName = user ? (user.fullName || 'Parent') : (activeTicket?.parentName || 'Parent');
    const result = await addSupportTicketReply(activeTicketId, {
      senderRole: 'parent',
      senderName,
      text: replyText.trim()
    });
    setSendingReply(false);
    
    if (result.success) {
      setReplyText('');
    }
  };

  const handleSendTutorChatMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !activeTutorChatId || !assignedTutor || !tutorChatMessageInput.trim()) return;

    setSendingTutorChatMessageState(true);
    setTutorChatViolationWarning(null);

    const textToSend = tutorChatMessageInput.trim();
    setTutorChatMessageInput('');

    const res = await sendTutorChatMessage({
      chatId: activeTutorChatId,
      parentId: user.uid,
      tutorId: assignedTutor.id,
      senderId: user.uid,
      senderName: user.fullName || user.displayName || "Parent",
      senderRole: 'parent',
      text: textToSend
    });

    setSendingTutorChatMessageState(false);

    if (res.success) {
      if (res.hasViolation) {
        setTutorChatViolationWarning("Notice: Your message/contact info was redacted for security.");
        setTimeout(() => setTutorChatViolationWarning(null), 6000);
      }
    } else {
      alert("Failed to send message. Please try again.");
    }
  };

  const startNewTicket = () => {
    setActiveTicketId(null);
    setActiveTicket(null);
    localStorage.removeItem('active_support_ticket_id');
    setQuestion('');
    setShowMyTicketsList(false);
    setWidgetTab('admin');
  };

  const selectHistoricTicket = (ticket: any) => {
    setActiveTicketId(ticket.id);
    localStorage.setItem('active_support_ticket_id', ticket.id);
    setShowMyTicketsList(false);
  };

  return (
    <div className="fixed bottom-6 right-6 z-[999]" id="support-widget-root">
      {/* Floating Toggle Button */}
      <button
        type="button"
        id="toggle-support-widget-btn"
        onClick={() => setIsOpen(!isOpen)}
        className="w-14 h-14 bg-secondary text-white rounded-full flex items-center justify-center shadow-2xl hover:scale-105 transition-all cursor-pointer relative"
        title="Contact Parent support & Classroom channels"
      >
        <AnimatePresence mode="wait">
          {isOpen ? (
            <X size={24} key="close-icon" />
          ) : (
            <MessageCircle size={28} key="open-icon" />
          )}
        </AnimatePresence>
        {myTickets.some(t => t.status === 'open' && t.replies?.length > 0 && t.replies[t.replies.length - 1].senderRole === 'admin') && (
          <span className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 rounded-full border-2 border-white animate-pulse" />
        )}
      </button>

      {/* Floating Panel (Dual Choice + Chats) */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            id="support-panel"
            initial={{ opacity: 0, y: 30, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 30, scale: 0.95 }}
            transition={{ duration: 0.2, ease: 'easeOut' }}
            className="absolute bottom-16 right-0 w-[360px] sm:w-[380px] h-[520px] bg-white rounded-2xl shadow-3xl border border-slate-100 flex flex-col overflow-hidden font-sans"
          >
            {/* Panel Header */}
            <div className="bg-slate-900 text-white p-4 flex items-center justify-between text-left relative">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-secondary/15 flex items-center justify-center text-sm font-bold text-secondary">
                  🔮
                </div>
                <div>
                  <h3 className="font-bold text-sm tracking-wide flex items-center gap-1">
                    <span>HabKids Communication Hub</span>
                    <Sparkles size={12} className="text-secondary animate-bounce" />
                  </h3>
                  <p className="text-[10px] text-slate-400 font-medium">Coordinate seamlessly with Admin & Teachers</p>
                </div>
              </div>
                          <button
                type="button"
                onClick={() => setIsOpen(false)}
                className="text-slate-400 hover:text-white p-1 rounded-full transition-colors"
                id="close-support-btn"
              >
                <X size={18} />
              </button>
            </div>

            {/* Panel Body */}
            <div className="flex-1 overflow-y-auto bg-slate-50/50 flex flex-col relative" id="support-panel-body">
              
              {/* Tab Case 1: Chooser Screen */}
              {widgetTab === 'chooser' && !showMyTicketsList && (
                <div className="p-5 flex-1 flex flex-col justify-center gap-4 text-left">
                  <div className="text-center pb-2">
                    <h4 className="font-extrabold text-slate-800 text-sm">How can we assist you today?</h4>
                    <p className="text-[10px] text-slate-400 font-semibold mt-1">Select one of our secure channels below</p>
                  </div>

                  {/* Choice A: Admin Private Desk */}
                  <button
                    onClick={() => setWidgetTab('admin')}
                    className="bg-white hover:bg-slate-50 border border-slate-150 p-4 rounded-2xl shadow-xs transition-colors text-left flex items-start gap-3.5 cursor-pointer hover:border-slate-300 w-full"
                  >
                    <div className="w-10 h-10 rounded-xl bg-orange-100 text-orange-600 flex items-center justify-center shrink-0">
                      <ShieldCheck size={20} />
                    </div>
                    <div className="flex-1">
                      <h5 className="font-bold text-slate-900 text-xs flex items-center gap-1.5">
                        <span>💳 Contact Support / Billing</span>
                      </h5>
                      <p className="text-[10px] text-slate-505 font-medium leading-relaxed mt-0.5">
                        For administrative, scheduling, course payments or billing plans coordination. Private from tutors.
                      </p>
                    </div>
                  </button>

                  {/* Choice B: Message Tutor Direct */}
                  <button
                    onClick={() => setWidgetTab('tutor')}
                    className="bg-white hover:bg-slate-50 border border-slate-150 p-4 rounded-2xl shadow-xs transition-all text-left flex items-start gap-3.5 cursor-pointer hover:border-slate-300 w-full"
                  >
                    <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-600 flex items-center justify-center shrink-0">
                      <BookOpen size={20} />
                    </div>
                    <div className="flex-1">
                      <h5 className="font-bold text-slate-900 text-xs flex items-center justify-between">
                        <span>🎓 Message My Tutor</span>
                        {assignedTutor && (
                          <span className="text-[8px] bg-emerald-50 text-emerald-700 font-extrabold px-1 py-0.5 rounded tracking-wider uppercase shrink-0">
                            Active
                          </span>
                        )}
                      </h5>
                      <p className="text-[10px] text-slate-505 font-medium leading-relaxed mt-0.5">
                        Direct chat interface with your child's lessons mentor. Discuss homework details, vocabulary, and active feedback.
                      </p>
                    </div>
                  </button>
                </div>
              )}

              {/* Tab Case 3: Embedded Tutor Chat */}
              {widgetTab === 'tutor' && (
                !assignedTutor ? (
                  <div className="p-6 flex flex-col items-center justify-center text-center gap-4 flex-1">
                    <div className="w-16 h-16 bg-emerald-50 text-emerald-600 rounded-full flex items-center justify-center border border-emerald-100">
                      <BookOpen size={30} />
                    </div>
                    <div>
                      <h3 className="font-extrabold text-slate-950 text-xs">Tutor Pairing In Progress</h3>
                      <p className="text-[11px] text-slate-500 mt-2 leading-relaxed font-semibold">
                        Your academic registration is active. HabKids admin group is presently aligning your native-speaking language teacher. You'll be notified immediately!
                      </p>
                    </div>
                    <button
                      onClick={() => setWidgetTab('chooser')}
                      className="text-xs text-slate-650 font-bold border rounded-xl px-4 py-2 hover:bg-slate-55 transition-colors cursor-pointer shadow-xs bg-white"
                    >
                      Return to Menu
                    </button>
                  </div>
                ) : (
                  <div className="flex-1 flex flex-col h-full bg-white relative">
                    {/* Tutor Chat Header */}
                    <div className="p-3 bg-slate-50 border-b border-slate-100 flex items-center justify-between text-left">
                      <button
                        onClick={() => setWidgetTab('chooser')}
                        className="text-xs text-slate-520 hover:text-slate-805 flex items-center gap-1 font-bold bg-white px-2 py-1 rounded border border-slate-100"
                      >
                        <ChevronLeft size={14} /> Back
                      </button>
                      
                      <div className="flex items-center gap-1.5 max-w-[170px] truncate">
                        <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 border border-emerald-100 px-2 py-0.5 rounded uppercase font-sans">
                          Teacher {assignedTutor.displayName || assignedTutor.name || "Tutor"}
                        </span>
                      </div>
                    </div>

                    {/* Messages Window */}
                    <div className="flex-1 overflow-y-auto p-4 space-y-3.5 bg-slate-50/20 text-left">
                      {loadingTutorChat ? (
                        <div className="h-full flex flex-col items-center justify-center text-slate-400 gap-2">
                          <Loader2 className="animate-spin text-emerald-600" size={24} />
                          <span className="text-[10px] font-semibold">Initializing secured chat...</span>
                        </div>
                      ) : tutorChatMessages.length === 0 ? (
                        <div className="p-6 text-center bg-white border border-slate-100 rounded-xl italic text-slate-400 text-[10px] leading-relaxed font-semibold">
                          👋 Start Amharic conversation! Send a message to {assignedTutor.displayName || assignedTutor.name || "Tutor"} with homework questions or speech feedback.
                        </div>
                      ) : (
                        tutorChatMessages.map((msg) => {
                          const isMe = msg.senderId === user?.uid;
                          return (
                            <div 
                              key={msg.id}
                              className={`flex flex-col space-y-0.5 max-w-[85%] ${isMe ? "ml-auto items-end" : "mr-auto items-start"}`}
                            >
                              <span className="text-[8px] text-slate-400 font-extrabold uppercase">
                                {isMe ? "You" : msg.senderName}
                              </span>
                              <div className={`p-2.5 rounded-2xl text-xs font-semibold leading-relaxed ${
                                isMe 
                                  ? "bg-emerald-600 text-white rounded-tr-none shadow-xs font-bold" 
                                  : "bg-slate-100 text-slate-800 rounded-tl-none border border-slate-200"
                              }`}>
                                {msg.text}
                              </div>
                              <span className="text-[8px] text-slate-450 self-end font-mono">
                                {formatSafeDate(msg.createdAt, { hour: '2-digit', minute: '2-digit' })}
                              </span>
                            </div>
                          );
                        })
                      )}
                      
                      <div ref={messagesEndRef} />
                    </div>

                    {/* Chat Redaction Guard Notice */}
                    {tutorChatViolationWarning && (
                      <div className="bg-amber-50 text-amber-900 border-t border-amber-100 px-3 py-1.5 text-[9px] font-semibold text-left">
                        ⚠️ Notice: {tutorChatViolationWarning}
                      </div>
                    )}

                    {/* Chat Editor Form */}
                    <form onSubmit={handleSendTutorChatMessage} className="p-3 border-t border-slate-100 bg-white flex gap-2">
                      <input
                        type="text"
                        disabled={sendingTutorChatMessageState || loadingTutorChat}
                        placeholder="Type message directly..."
                        value={tutorChatMessageInput}
                        onChange={(e) => setTutorChatMessageInput(e.target.value)}
                        className="flex-1 bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs focus:ring-1 focus:ring-emerald-500 focus:bg-white outline-none font-semibold text-slate-700"
                      />
                      <button
                        type="submit"
                        disabled={sendingTutorChatMessageState || !tutorChatMessageInput.trim() || loadingTutorChat}
                        className="bg-emerald-600 hover:bg-emerald-700 text-white p-2.5 rounded-xl flex items-center justify-center transition-all outline-none disabled:opacity-40 shrink-0 cursor-pointer"
                      >
                        {sendingTutorChatMessageState ? <Loader2 className="animate-spin" size={14} /> : <Send size={14} />}
                      </button>
                    </form>
                  </div>
                )
              )}

              {/* Tab Case 2: Support Ticket Lists or Form */}
              {widgetTab === 'admin' && (
                showMyTicketsList ? (
                  /* List of current admin support cases */
                  <div className="p-4 space-y-3 flex-1 text-left">
                    <div className="flex items-center justify-between mb-2">
                      <button
                        onClick={() => setShowMyTicketsList(false)}
                        className="text-xs text-slate-550 flex items-center gap-1 font-bold"
                      >
                        <ChevronLeft size={14} /> Back
                      </button>
                      <button 
                        onClick={startNewTicket}
                        className="text-xs text-secondary font-bold hover:underline"
                      >
                        + Submit New Query
                      </button>
                    </div>
                    <div className="space-y-2.5">
                      {myTickets.map((ticket) => (
                        <button
                          key={ticket.id}
                          onClick={() => selectHistoricTicket(ticket)}
                          className="w-full bg-white p-3.5 rounded-xl border border-slate-100 shadow-xs hover:border-slate-300 transition-colors flex flex-col gap-1 text-left"
                        >
                          <div className="flex items-center justify-between">
                            <span className="text-[11px] font-semibold text-slate-400 uppercase truncate max-w-[200px]">
                              {ticket.topic || "General support"}
                            </span>
                            <span className={`text-[9px] font-bold uppercase px-1.5 py-0.5 rounded ${
                              ticket.status === 'resolved' 
                                ? 'bg-emerald-50 text-emerald-700 border border-emerald-100' 
                                : 'bg-amber-50 text-amber-700 border border-amber-100'
                            }`}>
                              {ticket.status === 'resolved' ? 'Resolved' : 'Pending'}
                            </span>
                          </div>
                          <p className="text-xs text-slate-800 font-semibold truncate leading-tight mt-1">{ticket.question}</p>
                          {ticket.replies?.length > 0 && (
                            <div className="mt-1.5 pt-1.5 border-t border-slate-50 flex items-center justify-between text-[10px] text-slate-400">
                              <span className="font-semibold text-secondary">
                                ↩ Admin replied {ticket.replies.length} time{ticket.replies.length > 1 ? 's' : ''}
                              </span>
                              <span>{new Date(ticket.replies[ticket.replies.length - 1].createdAt).toLocaleDateString()}</span>
                            </div>
                          )}
                        </button>
                      ))}
                    </div>
                  </div>
                ) : activeTicket ? (
                  /* Admin ticket live discussion chat pane */
                  <div className="flex-1 flex flex-col h-full bg-white">
                    <div className="p-3 bg-slate-50 border-b border-slate-100 flex items-center justify-between text-left">
                      <button
                        onClick={() => {
                          if (user && myTickets.length > 0) {
                            setShowMyTicketsList(true);
                          } else {
                            startNewTicket();
                            if (assignedTutor) {
                              setWidgetTab('chooser');
                            }
                          }
                        }}
                        className="text-xs text-slate-500 hover:text-slate-800 flex items-center gap-1 font-medium bg-white px-2 py-1 rounded border border-slate-100"
                      >
                        <ChevronLeft size={14} /> Back
                      </button>
                      
                      <div className="flex items-center gap-2 max-w-[150px] truncate">
                        <span className="text-[10px] font-bold uppercase truncate bg-slate-120 px-1.5 py-0.5 rounded border">
                          Topic: {activeTicket.topic?.split(" ")[0] || "Support"}
                        </span>
                      </div>
                    </div>

                    {/* Chat Messages */}
                    <div className="flex-1 overflow-y-auto p-4 space-y-3.5 bg-slate-50/30 text-left">
                      {/* Original question */}
                      <div className="space-y-1 max-w-[85%]">
                        <p className="text-[10px] text-slate-400 font-semibold uppercase">{activeTicket.parentName || 'You'}</p>
                        <div className="bg-slate-100/90 text-slate-850 p-3 rounded-2xl rounded-tl-none text-xs border border-slate-200 font-semibold">
                          <strong className="text-[10px] block text-slate-500 uppercase tracking-wide mb-1 font-extrabold">
                            Topic: {activeTicket.topic || "General Enquiry"}
                          </strong>
                          {activeTicket.question}
                        </div>
                      </div>

                      {/* Replies */}
                      {activeTicket.replies?.map((reply: any, idx: number) => {
                        const isAdmin = reply.senderRole === 'admin';
                        return (
                          <div 
                            key={idx}
                            className={`flex flex-col space-y-1 max-w-[85%] ${isAdmin ? "ml-auto items-end" : "mr-auto items-start"}`}
                          >
                            <span className="text-[10px] text-slate-450 font-semibold uppercase">
                              {reply.senderName} ({reply.senderRole === 'admin' ? 'Support' : 'You'})
                            </span>
                            <div className={`p-3 rounded-2xl text-xs font-semibold leading-relaxed ${
                              isAdmin 
                                ? "bg-secondary text-white rounded-tr-none shadow-sm font-bold" 
                                : "bg-slate-100 text-slate-805 rounded-tl-none border border-slate-200"
                            }`}>
                              {reply.text}
                            </div>
                          </div>
                        );
                      })}

                      {(!activeTicket.replies || activeTicket.replies.length === 0) && (
                        <div className="p-6 text-center bg-white border border-slate-100 rounded-xl italic text-slate-400 text-[10px] leading-relaxed font-semibold">
                          📬 Question received! Our education director will review it and reply shortly. Your conversation history is synchronized in real-time.
                        </div>
                      )}
                      
                      <div ref={messagesEndRef} />
                    </div>

                    {/* Reply Form */}
                    <form onSubmit={handleSendReply} className="p-3 border-t border-slate-100 bg-white flex gap-2">
                      <input
                        type="text"
                        disabled={sendingReply || activeTicket.status === 'resolved'}
                        placeholder={activeTicket.status === 'resolved' ? "Ticket resolved. Tap Back to submit new." : "Type reply..."}
                        value={replyText}
                        onChange={(e) => setReplyText(e.target.value)}
                        className="flex-1 bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs focus:ring-1 focus:ring-primary focus:bg-white outline-none font-medium"
                      />
                      <button
                        type="submit"
                        disabled={sendingReply || !replyText.trim() || activeTicket.status === 'resolved'}
                        className="bg-secondary text-white p-2.5 rounded-xl flex items-center justify-center hover:scale-105 transition-all outline-none disabled:opacity-40 shrink-0 cursor-pointer"
                      >
                        {sendingReply ? <Loader2 className="animate-spin" size={14} /> : <Send size={14} />}
                      </button>
                    </form>
                  </div>
                ) : submitSuccess ? (
                  /* Success Feedback form submission */
                  <div className="p-8 flex flex-col items-center justify-center text-center gap-4 flex-1">
                    <div className="w-16 h-16 bg-emerald-50 text-emerald-600 rounded-full flex items-center justify-center border border-emerald-100">
                      <CheckCircle2 size={36} />
                    </div>
                    <div>
                      <h3 className="font-extrabold text-slate-900 text-sm">Message Saved Successfully!</h3>
                      <p className="text-[11px] text-slate-500 mt-2 leading-relaxed font-semibold">
                        Your ticket has been dispatched to HabKids Administration. We are loading your real-time secure reply channel now...
                      </p>
                    </div>
                  </div>
                ) : (
                  /* Standard Support Ticket launcher form */
                  <form onSubmit={handleSubmitTicket} className="p-4 space-y-3.5 text-left flex-1 bg-white">
                    <div className="flex items-center justify-between border-b pb-1.5">
                      <button
                        type="button"
                        onClick={() => {
                          if (assignedTutor) {
                            setWidgetTab('chooser');
                          }
                        }}
                        className="text-xs text-slate-500 hover:text-slate-800 flex items-center gap-1 font-semibold"
                      >
                        <ChevronLeft size={14} /> Menu
                      </button>
                      
                      {user && myTickets.length > 0 && (
                        <button
                          type="button"
                          onClick={() => setShowMyTicketsList(true)}
                          className="text-[10px] font-bold text-primary bg-primary/5 px-2 py-0.5 rounded hover:bg-primary/10"
                        >
                          My Tickets ({myTickets.length})
                        </button>
                      )}
                    </div>

                    <div className="space-y-1">
                      <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Your Name</label>
                      <input
                        required
                        type="text"
                        value={parentName}
                        onChange={(e) => setParentName(e.target.value)}
                        placeholder="e.g. Almaz Kebede"
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-700 focus:ring-1 focus:ring-primary focus:bg-white outline-none font-semibold shadow-none"
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Email Address</label>
                      <input
                        required
                        type="email"
                        value={parentEmail}
                        onChange={(e) => setParentEmail(e.target.value)}
                        placeholder="e.g. almaz.k@example.com"
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-700 focus:ring-1 focus:ring-primary focus:bg-white outline-none font-semibold shadow-none"
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block font-sans">Category / Topic</label>
                      <select
                        value={topic}
                        onChange={(e) => setTopic(e.target.value)}
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-800 outline-none appearance-none cursor-pointer focus:ring-1 focus:ring-primary"
                      >
                        <option value="Curriculum & Program structure">Curriculum Questions</option>
                        <option value="Scheduling & Time Availability">Scheduling & Shifts</option>
                        <option value="Billing, Plans & Pricing">Payments/Billing Plans</option>
                        <option value="Languages & Heritage Tutoring">Selecting a Private Tutor</option>
                        <option value="Other / General Inquiries">General / Other questions</option>
                      </select>
                    </div>

                    <div className="space-y-1">
                      <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block font-sans">Your Question</label>
                      <textarea
                        required
                        rows={3}
                        value={question}
                        onChange={(e) => setQuestion(e.target.value)}
                        placeholder="Detail your administrative or billing query..."
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-700 focus:ring-1 focus:ring-primary focus:bg-white outline-none h-16 resize-none font-medium text-left block"
                      />
                    </div>

                    <button
                      type="submit"
                      disabled={submitting || !parentName || !parentEmail || !question}
                      className="w-full bg-secondary hover:bg-secondary/95 text-white py-2.5 rounded-xl flex items-center justify-center gap-1.5 transition-all cursor-pointer font-bold mt-1 shadow-md shadow-secondary/15"
                    >
                      {submitting ? (
                        <Loader2 className="animate-spin" size={16} />
                      ) : (
                        <>
                          <Send size={14} />
                          <span>Send</span>
                        </>
                      )}
                    </button>
                  </form>
                )
              )}

            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

import { 
  collection, 
  addDoc, 
  serverTimestamp, 
  getDocs, 
  query, 
  orderBy, 
  limit, 
  onSnapshot, 
  where,
  updateDoc,
  doc,
  getDoc,
  setDoc,
  deleteDoc,
  arrayUnion
} from 'firebase/firestore';
import { db, auth } from '../lib/firebase';
import emailjs from '@emailjs/browser';
import { Notification } from '../types';

// Helper function to validate if a string is a valid EmailJS public key format to prevent standard SMTP passwords from overriding it
function isValidEmailJSPublicKey(f: string): boolean {
  if (!f) return false;
  f = f.trim();
  if (f.includes(' ') || f.includes('-') || f.includes('.') || f.includes('@')) return false;
  if (f === 'smtp' || f === 'resend' || f === 'brevo') return false;
  if (f.startsWith('service_') || f.startsWith('template_')) return false;
  if (f.startsWith('user_')) return true; // Legacy EmailJS public keys

  const hasUppercase = /[A-Z]/.test(f);
  const isAlphanumeric = /^[a-zA-Z0-9]+$/.test(f);
  return isAlphanumeric && hasUppercase && f.length >= 10 && f.length <= 25;
}

// Lexically scoped custom fetch function to intercept outbound mail dispatches and deliver them via EmailJS directly
const originalFetch = typeof window !== 'undefined' ? window.fetch.bind(window) : undefined as any;
export const customFetch = async function(input: RequestInfo | URL, init?: RequestInit): Promise<Response> {
  if (!originalFetch) {
    return new Response(JSON.stringify({ error: "No window environment" }), { status: 500 });
  }

  let url = '';
  if (typeof input === 'string') {
    url = input;
  } else if (input instanceof URL) {
    url = input.toString();
  } else if (input && typeof input === 'object' && 'url' in input) {
    url = (input as any).url || '';
  }

  if (url.includes('/api/notify/email') || url.includes('/api/notify/test-smtp')) {
    try {
      // 1. Parse request parameters
      let to = '';
      let subject = '';
      let body = '';
      let role = 'user';
      let clientConfigOverride: any = null;

      if (init && init.body) {
        try {
          const bodyObj = JSON.parse(init.body as string);
          to = bodyObj.to || bodyObj.toEmail || '';
          subject = bodyObj.subject || 'HabKids Notification';
          body = bodyObj.body || bodyObj.message || 'Verification / System Alert';
          role = bodyObj.role || 'user';
          if (bodyObj.smtpConfig) {
            clientConfigOverride = bodyObj.smtpConfig;
          }
        } catch (_) {}
      }

      // If no custom address exists, bypass cleanly
      if (!to) {
        return new Response(JSON.stringify({ success: true, message: "No recipient address provided." }), {
          status: 200,
          headers: { 'Content-Type': 'application/json' }
        });
      }

      // 2. Load the latest active delivery credentials (prioritize LocalStorage form-state, fallback to Firestore)
      let config = clientConfigOverride;

      if (!config) {
        try {
          const stored = localStorage.getItem('smtp_override_credentials');
          if (stored) {
            config = JSON.parse(stored);
          }
        } catch (_) {}
      }

      if (!config) {
        try {
          const docSnap = await getDoc(doc(db, 'settings', 'smtp'));
          if (docSnap.exists()) {
            config = docSnap.data();
          }
        } catch (dbErr) {
          console.warn("[EmailJS Interceptor] Firestore /settings/smtp read failed:", dbErr);
        }
      }

      // 3. Derive EmailJS parameters from standard SMTP override fields dynamically
      let serviceId = 'service_aa0pk04';
      let templateId = 'template_rkkuz0e';
      let publicKey = '7YClDSKiRylIncGX2';

      if (config) {
        const fields = [config.host, config.user, config.pass, config.port, config.provider]
          .map(v => String(v || '').trim());
        
        // Auto-detect service ID and template ID prefixes if provided
        const foundService = fields.find(f => f.startsWith('service_'));
        const foundTemplate = fields.find(f => f.startsWith('template_'));

        if (foundService) {
          serviceId = foundService;
        } else if (config.host && config.host !== 'smtp.gmail.com' && config.host !== 'smtp.gmail.cor' && !config.host.includes('.')) {
          serviceId = config.host.trim();
        } else if (config.provider && config.provider !== 'smtp') {
          serviceId = config.provider.trim();
        }

        if (foundTemplate) {
          templateId = foundTemplate;
        } else if (config.port && config.port !== '587' && config.port !== '465' && config.port !== '443' && config.port.includes('_')) {
          templateId = config.port.trim();
        } else if (config.pass && config.pass.startsWith('template_')) {
          templateId = config.pass.trim();
        }

        // Extract public API key using the helper to reject standard App Passwords or standard API keys
        const foundPublicKey = fields.find(isValidEmailJSPublicKey);

        if (foundPublicKey) {
          publicKey = foundPublicKey;
        }
      }

      console.log(`[EmailJS Client Interceptor] Direct Client Dispatch to ${to}`);
      console.log(`[EmailJS Client Interceptor] Engine Service ID: ${serviceId} | Template: ${templateId} | Public Key: ${publicKey ? '***' + publicKey.slice(-4) : 'Not specified'}`);

      // 4. Synthesise beautiful professional HTML container inline
      const isEnrollment = subject.toLowerCase().includes('enrollment') || subject.toLowerCase().includes('subscription');
      const htmlBody = `
        <div style="font-family: 'Inter', 'Helvetica Neue', Helvetica, Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 40px; background-color: #ffffff; border: 1px solid #f1f5f9; border-radius: 24px; color: #1e293b; box-shadow: 0 4px 6px -1px rgb(0 0 0 / 0.1);">
          <div style="text-align: center; margin-bottom: 32px;">
            <h1 style="color: #0f172a; margin: 0; font-size: 28px; font-weight: 800; letter-spacing: -0.025em; text-transform: uppercase;">HabKids</h1>
            <div style="height: 4px; width: 48px; background: linear-gradient(to right, #ea580c, #f97316); margin: 16px auto; border-radius: 2px;"></div>
          </div>
          
          <div style="font-size: 16px; line-height: 1.7; color: #475569;">
            ${body.split('\n').map((line: string) => {
              const trimmed = line.trim();
              if (!trimmed) return '';
              if (trimmed.includes(':') && !trimmed.startsWith('http')) {
                const [label, ...val] = trimmed.split(':');
                return `<p style="margin-bottom: 12px;"><strong style="color: #0f172a; display: inline-block; width: 120px;">${label}:</strong> <span style="background: #f8fafc; padding: 2px 8px; border-radius: 4px; font-weight: 500; color: #334155;">${val.join(':').trim()}</span></p>`;
              }
              return `<p style="margin-bottom: 16px;">${trimmed}</p>`;
            }).join('')}
          </div>

          ${isEnrollment ? `
            <div style="margin-top: 32px; padding: 24px; background: #f0fdf4; border: 1px solid #dcfce7; border-radius: 16px; text-align: center;">
              <h4 style="margin: 0 0 8px 0; color: #166534; font-size: 14px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.05em;">Status: Active Enrollment</h4>
              <p style="margin: 0; font-size: 13px; color: #15803d;">Your student's curriculum and materials are being prepared.</p>
            </div>
          ` : ''}

          <div style="margin-top: 48px; padding-top: 24px; border-top: 1px solid #f1f5f9; text-align: center;">
            <p style="font-size: 11px; color: #94a3b8; font-weight: 600; text-transform: uppercase; letter-spacing: 0.1em; margin-bottom: 12px;">HabKids Language Academy</p>
            <div style="display: flex; justify-content: center; gap: 16px; margin-bottom: 16px;">
              <a href="#" style="color: #64748b; text-decoration: none; font-size: 12px; font-weight: 500;">Parent Portal</a>
              <span style="color: #cbd5e1;">&bull;</span>
              <a href="#" style="color: #64748b; text-decoration: none; font-size: 12px; font-weight: 500;">Support Center</a>
            </div>
            <p style="font-size: 10px; color: #cbd5e1; margin: 0;">&copy; ${new Date().getFullYear()} HabKids. All rights reserved.</p>
          </div>
        </div>
      `;

      const templateParams = {
        to_email: to,
        email: to,
        to: to,
        to_name: to,
        recipient: to,
        subject: subject,
        message: body,
        message_html: htmlBody,
        html_body: htmlBody,
        message_content: body,
        body: body,
        from_name: "HabKids",
        role: role || 'user'
      };

      let success = false;
      let errorMsg = '';

      if (!publicKey) {
        console.warn("[EmailJS Client Interceptor] Missing active frontend credentials. Running simulation fallback...");
        success = true;
      } else {
        try {
          await emailjs.send(serviceId, templateId, templateParams, publicKey);
          success = true;
          console.log("[EmailJS Client Interceptor] Outbound transaction confirmed.");
        } catch (dispatchErr: any) {
          console.error("[EmailJS Client Interceptor] Failed to trigger EmailJS:", dispatchErr);
          errorMsg = dispatchErr?.text || dispatchErr?.message || String(dispatchErr);
        }
      }

      // 5. Fire background request to server simply to register the transaction in audit logs index
      try {
        await originalFetch.call(window, '/api/notify/email', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            to,
            subject,
            body,
            role,
            logOnly: true,
            status: success ? 'SMTP_SENT' : 'FAILED',
            errorMessage: errorMsg ? `[EmailJS Client Error]: ${errorMsg}` : undefined
          })
        });
      } catch (logErr) {
        console.warn("[EmailJS Client Interceptor] Log sync failed:", logErr);
      }

      if (success) {
        return new Response(JSON.stringify({
          success: true,
          message: "Professional dispatch confirmed via client-side EmailJS engine."
        }), {
          status: 200,
          headers: { 'Content-Type': 'application/json' }
        });
      } else {
        return new Response(JSON.stringify({
          success: false,
          error: errorMsg || "EmailJS failed to deliver the message"
        }), {
          status: 400,
          headers: { 'Content-Type': 'application/json' }
        });
      }
    } catch (e: any) {
      console.error("[EmailJS Client Interceptor Error]", e);
      return new Response(JSON.stringify({
        success: false,
        error: e.message || String(e)
      }), {
        status: 500,
        headers: { 'Content-Type': 'application/json' }
      });
    }
  }

  return originalFetch(input, init);
};

// Use local customFetch inside this module
const fetch = customFetch;

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: any;
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
    },
    operationType,
    path
  };
  console.warn('Firestore Error: ', errInfo);
  // We no longer throw to avoid crashing the app in async contexts
  return errInfo;
}

// Leads
export async function captureLead(leadData: any) {
  const path = 'leads';
  try {
    const currentUid = auth.currentUser?.uid;
    const docRef = await addDoc(collection(db, path), {
      ...leadData,
      parentId: currentUid || '',
      status: 'new',
      createdAt: serverTimestamp(),
    });

    const isParentChoose = leadData.tutorId && leadData.tutorId.trim() !== "";

    // 1. Trigger Real-time Notification for Admin IMMEDIATELY
    notifyAdmins(
      `New Booking: ${leadData.childName}`,
      `${leadData.parentName} requested a trial session for ${leadData.childName}. Goal: ${leadData.learningGoal || 'General'}`,
      '/admin/leads',
      docRef.id
    ).catch(err => console.warn("Admin notification failed:", err));

    // 2. Trigger Notification for Tutor IMMEDIATELY if hand-selected
    if (isParentChoose && leadData.tutorId && leadData.tutorEmail) {
      const tutorUid = 'virtual_' + leadData.tutorEmail.trim().toLowerCase().replace(/[@.]/g, '_');
      createNotification({
        userId: tutorUid,
        title: `Special Request from ${leadData.parentName}`,
        message: `You have been hand-selected for a trial with ${leadData.childName}.`,
        type: 'booking',
        link: '/tutor',
        relatedId: docRef.id
      }).catch(err => console.warn("Tutor notification failed:", err));
    }

    const triggerSecondaryTasks = async () => {
      let assessment: any = null;
      
      // 1. AI Assessment
      try {
        const aiResponse = await fetch('/api/assess', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            childName: leadData.childName,
            childAge: leadData.childAge,
            goals: leadData.learningGoal
          })
        });
        if (aiResponse.ok) {
          assessment = await aiResponse.json();
        }
      } catch (aiErr) {
        console.error("AI Assessment failed, proceeding with fallback:", aiErr);
      }

      // If assessment failed, let's make a fallback assessment object
      if (!assessment) {
        assessment = {
          heritageFact: "Amharic is the only African language with its own unique script, known as the Ge'ez abugida."
        };
      }
      
      // 2. WhatsApp Notification
      try {
        await fetch('/api/notify/whatsapp', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            phone: leadData.whatsapp,
            message: `Welcome ${leadData.parentName}! We received your request for ${leadData.childName}. ${assessment.heritageFact}`
          })
        });
      } catch (waErr) {
        console.error("WhatsApp Notification failed:", waErr);
      }

      // 3. Custom Email to Parent based on Auto-Assign vs Parent Chosen
      const isParentChoose = leadData.tutorId && leadData.tutorId.trim() !== "";
       let parentSubject = 'Welcome to HabKids — Trial Booking Request received!';
      let parentBody = `Dear ${leadData.parentName},\n\nThank you for booking a trial session for ${leadData.childName}.\n\nOur platform has registered your request matching our expert curriculum with the best system-assigned native tutor based on your exact language objectives.\n\nSummary of Goals: ${leadData.learningGoal || 'Continuous language immersion'}\n\nOur administrator will coordinate with our tutoring board and reach out shortly to lock in your child's paid 25-minute evaluation trial session ($5 booking fee paid).\n\nBest regards,\nHabKids Team`;

      if (isParentChoose) {
        parentSubject = `Welcome to HabKids — You chose ${leadData.tutorName || 'Private Tutor'}!`;
        parentBody = `Dear ${leadData.parentName},\n\nThank you for booking a trial session for ${leadData.childName}!\n\nYou have hand-picked ${leadData.tutorName || 'your designated tutor'} as your child's continuous learning guide. They are remarkably excited to meet you and your family!\n\nWe are already preparing initial introductory activities and interactive evaluation benchmarks customized for child age: ${leadData.childAge || '6-12'} years.\n\nSummary of Goals: ${leadData.learningGoal || 'Continuous language immersion'}\n\nOur administrative coordinator will contact you and ${leadData.tutorName} within the next 2 hours to finalize the perfect timeslot for your child's trial session!\n\nBest regards,\nHabKids Team`;
      }

      try {
        await fetch('/api/notify/email', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            to: leadData.email || 'parent@example.com',
            role: 'parent',
            subject: parentSubject,
            body: parentBody
          })
        });
      } catch (emailErr) {
        console.error("Parent Email Notification failed:", emailErr);
      }

      // 4. Notify hand-selected tutor as well (if applicable)
      if (isParentChoose && leadData.tutorEmail) {
        try {
          const goldTime = leadData.preferredTime || 'Not specified';
          const silverTime = leadData.preferredTime2 || 'Not specified';
          const bronzeTime = leadData.preferredTime3 || 'Not specified';
          const parentTimezone = leadData.timezone || 'Not specified';

          await fetch('/api/notify/email', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              to: leadData.tutorEmail,
              role: 'tutor',
              subject: `You Were Specially Hand-Selected for a Trial: ${leadData.childName || 'New Student'}`,
              body: `Dear ${leadData.tutorName},\n\nExciting news! A parent (${leadData.parentName}) has visited HabKids and specially hand-selected you for a paid 25-minute Amharic trial session with their child, ${leadData.childName}.\n\nStudent age: ${leadData.childAge || '6-12'} years\nLearning Objectives: ${leadData.learningGoal || 'Continuous language immersion'}\n\nParent's Suggested Trial Times (${parentTimezone}):\n- Option 1 (Gold Choice): ${goldTime}\n- Option 2 (Silver Choice): ${silverTime}\n- Option 3 (Bronze Choice): ${bronzeTime}\n\nOur administrative desk will contact you and coordinate with the parent shortly to lock in a time that matches your available dashboard slots. Please keep an eye on your calendar and let the coordinator know which option works best for you!\n\nBest regards,\nHabKids Team`
            })
          });
        } catch (tutorMailErr) {
          console.warn("Could not dispatch lead selected notification to tutor email", tutorMailErr);
        }
      }

      return assessment;
    };

    // We return success once the database is updated.
    // Secondary tasks (assessment, email) run in the background.
    triggerSecondaryTasks().then(async (assessment) => {
      console.log("Secondary tasks completed:", assessment);
    });

    return { success: true, id: docRef.id };
  } catch (error) {
    console.error("captureLead Error:", error);
    return { success: false };
  }
}

/**
 * Notifies all users with the 'admin' role.
 */
export async function notifyAdmins(title: string, message: string, link?: string, relatedId?: string) {
  try {
    // 1. Collect UIDs of all admins
    const adminIds = new Set<string>();

    // Query by explicit role field
    const q = query(collection(db, 'users'), where('role', '==', 'admin'));
    const snapshot = await getDocs(q);
    snapshot.docs.forEach(doc => adminIds.add(doc.id));

    // Hardcoded fallback for the primary developer email
    const mainAdminQuery = query(collection(db, 'users'), where('email', '==', 'brtsegayetad@gmail.com'));
    const mainAdminSnap = await getDocs(mainAdminQuery);
    mainAdminSnap.docs.forEach(doc => adminIds.add(doc.id));

    if (adminIds.size === 0) {
      console.warn("notifyAdmins: No admin users found in Firestore to notify.");
      return;
    }

    const promises = Array.from(adminIds).map(userId => createNotification({
      userId,
      title,
      message,
      type: 'system',
      link,
      relatedId
    }));
    await Promise.all(promises);
  } catch (err) {
    console.warn("Failed to notify admins:", err);
  }
}

// Real-time Listeners
export function subscribeToLeads(callback: (leads: any[]) => void, onError?: () => void) {
  const q = query(collection(db, 'leads'));
  return onSnapshot(q, (snapshot) => {
    const leads = snapshot.docs
      .map(doc => ({ id: doc.id, ...doc.data() }))
      .sort((a: any, b: any) => {
        const t1 = a.createdAt?.toDate ? a.createdAt.toDate().getTime() : 0;
        const t2 = b.createdAt?.toDate ? b.createdAt.toDate().getTime() : 0;
        return t2 - t1; // Descending
      });
    callback(leads);
  }, (error) => {
    console.error("Firestore error in subscribeToLeads:", error);
    onError?.();
  });
}

export function subscribeToPendingLeadsForTutor(
  tutorId: string, 
  callback: (leads: any[]) => void, 
  onError?: () => void,
  tutorEmail?: string
) {
  const collectionRef = collection(db, 'leads');
  
  const query1 = query(collectionRef, where('tutorId', '==', tutorId), where('status', '==', 'new'));
  const activeUnsubscribes: any[] = [];
  const resultsMap = new Map<string, any>();
  
  const triggerCallback = () => {
    callback(Array.from(resultsMap.values()));
  };

  const unsub1 = onSnapshot(query1, (snapshot) => {
    snapshot.docChanges().forEach(change => {
      if (change.type === 'removed') {
        resultsMap.delete(change.doc.id);
      } else {
        resultsMap.set(change.doc.id, { id: change.doc.id, ...change.doc.data() });
      }
    });
    // Add active docs
    snapshot.docs.forEach(doc => {
      resultsMap.set(doc.id, { id: doc.id, ...doc.data() });
    });
    triggerCallback();
  }, (error) => {
    console.error("Firestore error in subscribeToPendingLeadsForTutor query 1:", error);
    onError?.();
  });
  activeUnsubscribes.push(unsub1);

  if (tutorEmail && tutorEmail.trim()) {
    const cleanEmail = tutorEmail.trim().toLowerCase();
    const query2 = query(collectionRef, where('tutorEmail', '==', cleanEmail), where('status', '==', 'new'));
    const unsub2 = onSnapshot(query2, (snapshot) => {
      snapshot.docChanges().forEach(change => {
        if (change.type === 'removed') {
          resultsMap.delete(change.doc.id);
        } else {
          resultsMap.set(change.doc.id, { id: change.doc.id, ...change.doc.data() });
        }
      });
      snapshot.docs.forEach(doc => {
        resultsMap.set(doc.id, { id: doc.id, ...doc.data() });
      });
      triggerCallback();
    }, (error) => {
      console.error("Firestore error in subscribeToPendingLeadsForTutor query 2:", error);
      onError?.();
    });
    activeUnsubscribes.push(unsub2);
  }

  return () => {
    activeUnsubscribes.forEach(unsub => unsub());
  };
}

const processedReminders = new Set<string>();

async function triggerClientSideReminders(sessions: any[]) {
  const now = new Date();
  for (const session of sessions) {
    if (session.status !== 'scheduled' || session.reminderSent === true) {
      continue;
    }
    if (processedReminders.has(session.id)) {
      continue;
    }

    let startDate: Date;
    if (session.startTime && typeof session.startTime.toDate === 'function') {
      startDate = session.startTime.toDate();
    } else if (session.startTime && (session.startTime.seconds || session.startTime._seconds)) {
      const seconds = session.startTime.seconds || session.startTime._seconds;
      const nanoseconds = session.startTime.nanoseconds || session.startTime._nanoseconds || 0;
      startDate = new Date(seconds * 1000 + nanoseconds / 1000000);
    } else if (session.startTime) {
      startDate = new Date(session.startTime);
    } else {
      continue;
    }

    const diffMs = startDate.getTime() - now.getTime();
    if (diffMs > 0 && diffMs <= 24 * 60 * 60 * 1000) {
      processedReminders.add(session.id);
      
      const formattedTime = startDate.toLocaleString('en-US', {
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        timeZoneName: 'short'
      });

      const tutorName = session.tutorName || "HabKids Tutor";
      const studentName = session.studentName || "your child";
      const parentName = session.parentName || "Parent";

      // 1. Dispatch to Tutor (if tutorEmail exists)
      if (session.tutorEmail) {
        try {
          await fetch('/api/notify/email', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              to: session.tutorEmail,
              role: 'tutor',
              subject: `Session Reminder: ${studentName}`,
              body: `Dear ${tutorName},\n\nThis is a friendly reminder that you have an upcoming HabKids Session scheduled.\n\nStudent: ${studentName}\nType: ${session.type || 'regular'} session\nScheduled Time: ${formattedTime}\n\nPlease join the meeting via your Tutor Dashboard 5 minutes before your class.\n\nBest regards,\nHabKids Team`
            })
          });
        } catch (err) {
          console.error("Client failed sending email reminder to tutor:", err);
        }
      }

      // 2. Dispatch to Parent (if parentEmail exists)
      if (session.parentEmail) {
        try {
          await fetch('/api/notify/email', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              to: session.parentEmail,
              role: 'parent',
              subject: `HabKids Session Reminder: ${studentName}`,
              body: `Dear ${parentName},\n\nThis is a friendly reminder that ${studentName} has an upcoming HabKids Session scheduled.\n\nAssigned Tutor: ${tutorName}\nType: ${session.type || 'regular'} session\nScheduled Time: ${formattedTime}\n\nYou can access your classroom meeting link via your Parent Dashboard 5 minutes before the class starts.\n\nBest regards,\nHabKids Team`
            })
          });
        } catch (err) {
          console.error("Client failed sending email reminder to parent:", err);
        }
      }

      // 3. Mark in DB as reminderSent: true
      try {
        await updateDoc(doc(db, 'sessions', session.id), {
          reminderSent: true,
          updatedAt: serverTimestamp()
        });
        console.log(`[CLIENT-REMINDER] Marked session ${session.id} as reminderSent: true`);
      } catch (err) {
        console.error("Failed to mark session as reminderSent on client:", err);
        processedReminders.delete(session.id);
      }
    }
  }
}

export function subscribeToSessions(
  role: 'tutor' | 'parent', 
  uid: string, 
  callback: (sessions: any[]) => void, 
  onError?: () => void,
  email?: string
) {
  if (role === 'tutor') {
    const q = query(collection(db, 'sessions'), where('tutorId', '==', uid));
    return onSnapshot(q, (snapshot) => {
      const sessions = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      callback(sessions);
    }, (error) => {
      console.error("Firestore error in subscribeToSessions:", error);
      onError?.();
    });
  }

  // If role is parent, listen on parentId == uid OR parentEmail == email
  const parentIdCheck = uid;
  const parentEmailCheck = (email || '').trim().toLowerCase();

  const qById = query(collection(db, 'sessions'), where('parentId', '==', parentIdCheck));
  let qByEmail: any = null;
  if (parentEmailCheck) {
    qByEmail = query(collection(db, 'sessions'), where('parentEmail', '==', parentEmailCheck));
  }

  let sessionsById: any[] = [];
  let sessionsByEmail: any[] = [];

  const handleMerge = () => {
    const allSessionsMap = new Map();
    sessionsById.forEach(s => allSessionsMap.set(s.id, s));
    sessionsByEmail.forEach(s => allSessionsMap.set(s.id, s));
    const merged = Array.from(allSessionsMap.values())
      .sort((a: any, b: any) => {
        const t1 = a.startTime?.toDate ? a.startTime.toDate().getTime() : 0;
        const t2 = b.startTime?.toDate ? b.startTime.toDate().getTime() : 0;
        return t1 - t2;
      });
    triggerClientSideReminders(merged);
    callback(merged);
  };

  const unsubById = onSnapshot(qById, (snapshot) => {
    sessionsById = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    handleMerge();
  }, (error) => {
    console.warn("error in subscribeToSessions parentId listener:", error);
    handleMerge();
  });

  let unsubByEmail = () => {};
  if (qByEmail) {
    unsubByEmail = onSnapshot(qByEmail, (snapshot) => {
      sessionsByEmail = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      handleMerge();
    }, (error) => {
      console.warn("error in subscribeToSessions parentEmail listener:", error);
      handleMerge();
    });
  }

  return () => {
    unsubById();
    unsubByEmail();
  };
}

export function subscribeToStudentProgress(tutorId: string, callback: (students: any[]) => void, onError?: () => void) {
  const q = query(collection(db, 'students'), where('tutorId', '==', tutorId));
  return onSnapshot(q, (snapshot) => {
    const students = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    callback(students);
  }, (error) => {
    console.error("Firestore error in subscribeToStudentProgress:", error);
    onError?.();
  });
}

export function subscribeToParentData(parentId: string, callback: (data: any) => void, onError?: () => void, email?: string) {
  const parentEmailCheck = (email || '').trim().toLowerCase();
  
  const qById = query(collection(db, 'students'), where('parentId', '==', parentId));
  
  let unsubById = () => {};
  let unsubByEmail = () => {};
  
  let studentsById: any[] = [];
  let studentsByEmail: any[] = [];
  
  const handleMerge = async () => {
    const studentMap = new Map();
    studentsById.forEach(s => studentMap.set(s.id, s));
    studentsByEmail.forEach(s => studentMap.set(s.id, s));
    let students = Array.from(studentMap.values());
    
    try {
      // Look up all subscriptions for this parent to run the automated lifecycle checker
      let subs: any[] = [];
      const subsSnapById = await getDocs(query(collection(db, 'subscriptions'), where('parentId', '==', parentId)));
      subs = subsSnapById.docs.map(doc => ({ id: doc.id, ...doc.data() as any }));

      if (parentEmailCheck) {
        const subsSnapByEmail = await getDocs(query(collection(db, 'subscriptions'), where('parentEmail', '==', parentEmailCheck)));
        const subsByEmail = subsSnapByEmail.docs.map(doc => ({ id: doc.id, ...doc.data() as any }));
        // Merge without duplicates
        const subMap = new Map();
        subs.forEach(s => subMap.set(s.id, s));
        subsByEmail.forEach(s => subMap.set(s.id, s));
        subs = Array.from(subMap.values());
      }

      // Ensure any student matching the subscription studentId is also fetched in case of parentId transitions
      const studentIds = new Set(students.map(s => s.id));
      for (const sub of subs) {
        if (sub.studentId && !studentIds.has(sub.studentId)) {
          const studentDoc = await getDoc(doc(db, 'students', sub.studentId));
          if (studentDoc.exists()) {
            students.push({ id: studentDoc.id, ...studentDoc.data() as any });
            studentIds.add(studentDoc.id);
          }
        }
      }

      const now = new Date();
      for (const student of students) {
        // Find LATEST active or pending subscription for this student (sorted by billingCycleEnd descending)
        const studentSubs = subs
          .filter(s => s.studentId === student.id)
          .sort((a, b) => {
            const dA = a.billingCycleEnd?.toDate ? a.billingCycleEnd.toDate() : new Date(a.billingCycleEnd);
            const dB = b.billingCycleEnd?.toDate ? b.billingCycleEnd.toDate() : new Date(b.billingCycleEnd);
            return dB.getTime() - dA.getTime();
          });
        
        const studentSub = studentSubs[0]; // The latest one
        
        let shouldExpire = false;
        let expireReason = '';

        if (studentSub) {
          const endDate = studentSub.billingCycleEnd?.toDate ? studentSub.billingCycleEnd.toDate() : new Date(studentSub.billingCycleEnd);
          if (endDate < now) {
            shouldExpire = true;
            expireReason = 'calendar_expired';
          }
        }

        const remainingCredits = student.remainingClassCredits;
        if (remainingCredits !== undefined && remainingCredits <= 0) {
          shouldExpire = true;
          expireReason = 'credits_exhausted';
        }

        if (shouldExpire && student.status !== 'expired') {
          console.log(`Auto-expiring student ${student.id} subscription. Reason: ${expireReason}`);
          
          // 1. Flip student state to 'expired'
          const studentRef = doc(db, 'students', student.id);
          await updateDoc(studentRef, { 
            status: 'expired',
            expireReason: expireReason
          });
          student.status = 'expired';
          student.expireReason = expireReason;
          
          // 2. Flip subscription ledger record to 'expired'
          if (studentSub) {
            const subRef = doc(db, 'subscriptions', studentSub.id);
            await updateDoc(subRef, { status: 'expired' });
            studentSub.status = 'expired';
          }
        } else if (student.status === 'expired') {
          // Ensure they carry someexpireReason to aid UI warnings
          const rCredits = student.remainingClassCredits;
          student.expireReason = student.expireReason || (rCredits !== undefined && rCredits <= 0 ? 'credits_exhausted' : 'calendar_expired');
        }
      }
      callback({ students, subscriptions: subs });
    } catch (err) {
      console.error("Lifecycle checker error:", err);
      callback({ students, subscriptions: [] });
    }
  };

  unsubById = onSnapshot(qById, (snapshot) => {
    studentsById = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() as any }));
    handleMerge();
  }, (error) => {
    console.error("error in subscribeToParentData parentId listener:", error);
    handleMerge();
  });

  if (parentEmailCheck) {
    const qByEmail = query(collection(db, 'students'), where('parentEmail', '==', parentEmailCheck));
    unsubByEmail = onSnapshot(qByEmail, (snapshot) => {
      studentsByEmail = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() as any }));
      handleMerge();
    }, (error) => {
      console.error("error in subscribeToParentData email listener:", error);
      handleMerge();
    });
  }

  return () => {
    unsubById();
    unsubByEmail();
  };
}

export async function updateStudentSchedule(studentId: string, recurringTimes: string[], schedulePattern: string[]) {
  try {
    const studentRef = doc(db, 'students', studentId);
    const studentSnap = await getDoc(studentRef);
    
    await updateDoc(studentRef, {
      recurringTimes,
      schedulePattern,
      updatedAt: serverTimestamp()
    });

    if (studentSnap.exists()) {
      const studentData = studentSnap.data();
      const parentId = studentData.parentId;
      const tutorId = studentData.tutorId;
      const tutorEmail = studentData.tutorEmail;

      // Notify Parent
      if (parentId) {
        await createNotification({
          userId: parentId,
          title: "Schedule Updated",
          message: `The schedule for ${studentData.name} has been updated.`,
          type: 'schedule_change',
          link: '/parent/schedule',
          relatedId: studentId
        });
      }

      // Notify Tutor
      if (tutorEmail) {
        const tutorUid = 'virtual_' + tutorEmail.trim().toLowerCase().replace(/[@.]/g, '_');
        await createNotification({
          userId: tutorUid,
          title: "Student Schedule Updated",
          message: `The schedule for ${studentData.name} has been updated by the administrator.`,
          type: 'schedule_change',
          link: '/tutor/calendar',
          relatedId: studentId
        });
      }
    }

    return { success: true };
  } catch (error) {
    console.error("updateStudentSchedule Error:", error);
    return { success: false };
  }
}

export async function completeTrialSession(sessionId: string, leadId: string, evaluation: any, parentData: { email: string, name: string }) {
  try {
    const sessionRef = doc(db, 'sessions', sessionId);
    await updateDoc(sessionRef, {
      ...evaluation,
      status: 'completed',
      updatedAt: serverTimestamp()
    });

    const sessionSnap = await getDoc(sessionRef);
    let sData: any = {};
    if (sessionSnap.exists()) {
      sData = sessionSnap.data();
    }

    if (leadId) {
      const leadRef = doc(db, 'leads', leadId);
      await updateDoc(leadRef, {
        status: 'trial_completed',
        evaluation: evaluation.evaluation,
        recommendedLevel: evaluation.recommendedLevel,
        updatedAt: serverTimestamp()
      });

      // Send professional email after trial
      try {
        await fetch('/api/notify/email', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            to: parentData.email,
            role: 'parent',
            subject: 'Trial Session Completed!',
            body: `Dear ${parentData.name},\n\nYour child has completed the trial session! Our tutor has provided an evaluation of their current level and goals.\n\nYou can now log in to your dashboard to view the evaluation and choose a subscription plan to continue the learning journey.\n\nThank you for choosing HabKids!\n\nBest regards,\nHabKids Team`
          })
        });
      } catch (trialEmailError) {
        console.error("Failed to send post-trial email notification:", trialEmailError);
      }

      // Use request requirement: make subscription active immediately upon completing trial
      const parentEmailVal = parentData.email || sData.parentEmail || '';
      const studentNameVal = sData.studentName || 'Student';
      const tutorIdVal = sData.tutorId || '';

      let finalParentId = sData.parentId || 'guest';
      if (parentEmailVal) {
        const usersQ = query(collection(db, 'users'), where('email', '==', parentEmailVal.trim().toLowerCase()));
        const usersSnap = await getDocs(usersQ);
        if (!usersSnap.empty) {
          finalParentId = usersSnap.docs[0].id;
        }
      }

      // Check if student with this name and parentId already exists
      let existingDocId = '';
      if (finalParentId && finalParentId !== 'guest') {
        const studentQ = query(
          collection(db, 'students'), 
          where('parentId', '==', finalParentId),
          where('name', '==', studentNameVal)
        );
        const studentSnap = await getDocs(studentQ);
        if (!studentSnap.empty) {
          existingDocId = studentSnap.docs[0].id;
        }
      }

      if (!existingDocId) {
        console.log(`[Automated Activation] Creating trial_completed student profile for parent ${finalParentId} and student ${studentNameVal}`);
        await createSubscription(
          finalParentId,
          'pro',
          studentNameVal,
          tutorIdVal,
          [], // clear schedule
          '', // clear schedule pattern
          parentEmailVal,
          undefined,
          undefined,
          'trial_completed' // status 'trial_completed'
        );
      } else {
        console.log(`[Automated Activation] Setting existing student ${existingDocId} to trial_completed and archiving temporary trial schedules`);
        const studentRef = doc(db, 'students', existingDocId);
        await updateDoc(studentRef, {
          status: 'trial_completed',
          schedule: [], // clear / archive temporary trial schedules
          schedulePattern: '',
          recurringTimes: [], // clear
          updatedAt: serverTimestamp()
        });
        
        const subsQ = query(collection(db, 'subscriptions'), where('studentId', '==', existingDocId));
        const subsSnap = await getDocs(subsQ);
        for (const subDoc of subsSnap.docs) {
          await updateDoc(doc(db, 'subscriptions', subDoc.id), {
            status: 'trial_completed',
            updatedAt: serverTimestamp()
          });
        }
      }
    } else {
      // Regular scheduled tutoring class consumption logic: subtract 1 credit
      if (sData.studentId) {
        const studentRef = doc(db, 'students', sData.studentId);
        const studentSnap = await getDoc(studentRef);
        if (studentSnap.exists()) {
          const currentCredits = studentSnap.data().remainingClassCredits !== undefined 
            ? studentSnap.data().remainingClassCredits 
            : 4;
          const newCredits = Math.max(0, currentCredits - 1);
          await updateDoc(studentRef, {
            remainingClassCredits: newCredits,
            updatedAt: serverTimestamp()
          });
          console.log(`Deducted 1 credit for student ${sData.studentId}: ${currentCredits} -> ${newCredits}`);
        }
      }
    }

    return { success: true };
  } catch (error) {
    console.error("completeTrialSession Error:", error);
    return { success: false };
  }
}

export async function markSessionMissed(sessionId: string, reason: string, deductCredit: boolean = true) {
  try {
    const sessionRef = doc(db, 'sessions', sessionId);
    await updateDoc(sessionRef, {
      status: 'missed',
      missedReason: reason,
      deductedCredit: deductCredit,
      updatedAt: serverTimestamp()
    });

    if (deductCredit) {
      const sessionSnap = await getDoc(sessionRef);
      if (sessionSnap.exists()) {
        const sData = sessionSnap.data();
        if (sData.studentId) {
          const studentRef = doc(db, 'students', sData.studentId);
          const studentSnap = await getDoc(studentRef);
          if (studentSnap.exists()) {
            const currentCredits = studentSnap.data().remainingClassCredits !== undefined 
              ? studentSnap.data().remainingClassCredits 
              : 4;
            const newCredits = Math.max(0, currentCredits - 1);
            await updateDoc(studentRef, {
              remainingClassCredits: newCredits,
              updatedAt: serverTimestamp()
            });
            console.log(`Deducted 1 credit (missed) for student ${sData.studentId}: ${currentCredits} -> ${newCredits}`);
          }
        }
      }
    }
    return { success: true };
  } catch (error) {
    console.error("markSessionMissed Error:", error);
    return { success: false };
  }
}

export async function updateSessionEvaluation(sessionId: string, evaluation: any) {
  try {
    const sessionRef = doc(db, 'sessions', sessionId);
    await updateDoc(sessionRef, {
      ...evaluation,
      status: 'completed',
      updatedAt: serverTimestamp()
    });

    const sessionSnap = await getDoc(sessionRef);
    if (sessionSnap.exists()) {
      const sData = sessionSnap.data();
      if (sData.studentId) {
        const studentRef = doc(db, 'students', sData.studentId);
        const studentSnap = await getDoc(studentRef);
        if (studentSnap.exists()) {
          const currentCredits = studentSnap.data().remainingClassCredits !== undefined 
            ? studentSnap.data().remainingClassCredits 
            : 4;
          const newCredits = Math.max(0, currentCredits - 1);
          await updateDoc(studentRef, {
            remainingClassCredits: newCredits,
            updatedAt: serverTimestamp()
          });
          console.log(`Deducted 1 credit (eval) for student ${sData.studentId}: ${currentCredits} -> ${newCredits}`);
        }
      }
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, `sessions/${sessionId}`);
  }
}

export async function updateLeadStatus(leadId: string, status: string) {
  try {
    const leadRef = doc(db, 'leads', leadId);
    await updateDoc(leadRef, {
      status,
      updatedAt: serverTimestamp()
    });
    return { success: true };
  } catch (error) {
    console.error("updateLeadStatus Error:", error);
    return { success: false };
  }
}

export async function updateLeadData(leadId: string, updateData: any) {
  try {
    const leadRef = doc(db, 'leads', leadId);
    await updateDoc(leadRef, {
      ...updateData,
      updatedAt: serverTimestamp()
    });
    return { success: true };
  } catch (error) {
    console.error("updateLeadData Error:", error);
    return { success: false };
  }
}

export async function deleteLead(leadId: string) {
  try {
    const leadRef = doc(db, 'leads', leadId);
    await deleteDoc(leadRef);
    return { success: true };
  } catch (error) {
    console.error("deleteLead Error:", error);
    return { success: false };
  }
}

export async function createLeadManually(leadData: any, parentPassword?: string) {
  try {
    const cleanEmail = leadData.email.trim().toLowerCase();
    
    // 1. Check if user already exists
    const q = query(collection(db, 'users'), where('email', '==', cleanEmail));
    const qSnap = await getDocs(q);
    
    let parentId = '';
    
    if (qSnap.empty) {
      // Create virtual user if password is provided
      if (parentPassword) {
        parentId = 'virtual_' + cleanEmail.replace(/[@.]/g, '_');
        await setDoc(doc(db, 'users', parentId), {
          uid: parentId,
          email: cleanEmail,
          fullName: leadData.parentName,
          displayName: leadData.parentName,
          role: 'parent',
          password: parentPassword,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp()
        });
        console.log(`[Admin] Created virtual parent profile for manual lead: ${parentId}`);
      }
    } else {
      parentId = qSnap.docs[0].id;
      // If parent password is provided, update the user record for fallback authentication
      if (parentPassword) {
        await updateDoc(doc(db, 'users', parentId), {
          password: parentPassword,
          updatedAt: serverTimestamp()
        });
      }
    }

    // 2. Create lead document
    const leadRef = await addDoc(collection(db, 'leads'), {
      ...leadData,
      email: cleanEmail,
      parentId: parentId,
      status: leadData.status || 'new',
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp()
    });

    return { success: true, id: leadRef.id };
  } catch (error) {
    console.error("createLeadManually Error:", error);
    return { success: false };
  }
}

export async function createSubscription(
  parentId: string, 
  plan: string, 
  studentName: string, 
  tutorId: string, 
  schedule?: string[], 
  schedulePatternInput?: string[] | string,
  parentEmail?: string,
  rate?: number,
  remainingClassCredits?: number,
  status: string = 'active',
  paymentScreenshotBase64?: string,
  paymentRef?: string,
  paymentSenderName?: string,
  paymentType?: string
) {
  try {
    let schedulePattern = '';
    
    if (typeof schedulePatternInput === 'string') {
      schedulePattern = schedulePatternInput;
    } else if (Array.isArray(schedulePatternInput) && schedulePatternInput.length > 0) {
      schedulePattern = schedulePatternInput.join(', ');
    } else if (schedule && schedule.length > 0) {
      // compile short pattern from ISO schedule times
      schedulePattern = schedule.map(timeStr => {
        try {
          const d = new Date(timeStr);
          if (!isNaN(d.getTime())) {
            const day = d.toLocaleDateString('en-US', { weekday: 'short' }).toUpperCase();
            const time = d.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
            return `${day} @ ${time}`;
          }
        } catch (e) {
          console.error(e);
        }
        return timeStr;
      }).join(', ');
    } else {
      schedulePattern = 'Not Set';
    }

    const initialCredits = remainingClassCredits !== undefined ? remainingClassCredits : (plan === 'mastery' ? 12 : plan === 'pro' ? 8 : 4);

    // 1. Create or Update student record (converting lead/pre-existing student to subscribed active student)
    let sId = '';
    const studentQ = query(
      collection(db, 'students'), 
      where('parentId', '==', parentId),
      where('name', '==', studentName)
    );
    const studentSnap = await getDocs(studentQ);
    if (!studentSnap.empty) {
      sId = studentSnap.docs[0].id;
      const studentRef = doc(db, 'students', sId);
      await updateDoc(studentRef, {
        tutorId,
        status: status,
        plan: plan,
        schedule: schedule || [],
        schedulePattern: schedulePattern,
        remainingClassCredits: initialCredits,
        subscriptionStartDate: new Date().toISOString(), // Ensure cycle calculation starts today
      });
    } else {
      const studentRef = await addDoc(collection(db, 'students'), {
        parentId,
        tutorId,
        name: studentName,
        status: status,
        plan: plan,
        progress: 0,
        schedule: schedule || [],
        schedulePattern: schedulePattern,
        remainingClassCredits: initialCredits,
        subscriptionStartDate: new Date().toISOString(), // Ensure cycle calculation starts today
        createdAt: serverTimestamp()
      });
      sId = studentRef.id;
    }

    // 2. Create the explicit 'subscriptions' Firestore ledger record
    const now = new Date();
    const billingCycleStart = now;
    const billingCycleEnd = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000); // 30 days from start

    await addDoc(collection(db, 'subscriptions'), {
      studentId: sId,
      parentId,
      parentEmail: parentEmail || '',
      planType: plan,
      rate: rate || (plan === 'mastery' ? 320 : plan === 'pro' ? 240 : 160),
      billingCycleStart,
      billingCycleEnd,
      status: status,
      remainingClassCredits: initialCredits,
      createdAt: serverTimestamp(),
      ...(paymentScreenshotBase64 ? { paymentScreenshotBase64 } : {}),
      ...(paymentRef ? { paymentRef } : {}),
      ...(paymentSenderName ? { paymentSenderName } : {}),
      ...(paymentType ? { paymentType } : {})
    });

    // 3. Trigger Professional Subscription Confirmation Emails
    const triggerSubscriptionEmails = async () => {
      if (!parentEmail) return;
      let tutorName = 'Auto-Assigned Tutor';
      let tutorEmail = '';
      if (tutorId && tutorId !== 'auto-assign') {
        try {
          const tutorRef = doc(db, 'tutors', tutorId);
          const tutorSnap = await getDoc(tutorRef);
          if (tutorSnap.exists()) {
            const td = tutorSnap.data();
            tutorName = td.name || td.displayName || 'Designated Tutor';
            tutorEmail = td.email || '';
          }
        } catch (err) {
          console.error("Error fetching tutor for subscription email:", err);
        }
      }

      const planDisplayName = plan === 'custom' ? `Custom Credit Package` : (plan.charAt(0).toUpperCase() + plan.slice(1) + " Plan");
      const creditsLabel = `${initialCredits} credits / month`;
      const scheduleText = schedulePattern || 'Not Scheduled Yet';

      const parentSubject = `HabKids — Subscription Confirmed: ${studentName}'s Amharic Journey Begins!`;
      const parentBody = `Dear Parent,

Thank you for choosing HabKids! We are thrilled to confirm your subscription and class schedule for ${studentName}.

Here are the details of your active plan:
• Student Name: ${studentName}
• Subscription Plan: ${planDisplayName}
• Monthly Class Allowance: ${creditsLabel}
• Designated Tutor: ${tutorName}
• Selected Recurring Class Schedule:
  ${scheduleText}

You can access your virtual classrooms and message your tutor directly from your Parent Dashboard at any time.

We are excited to support your family's language learning journey!

Best regards,
HabKids Team`;

      // Email to Parent
      try {
        await fetch('/api/notify/email', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            to: parentEmail,
            role: 'parent',
            subject: parentSubject,
            body: parentBody
          })
        });
      } catch (parentEmailErr) {
        console.error("Failed to send subscription confirmation email to parent:", parentEmailErr);
      }

      // Email to Tutor (if available)
      if (tutorEmail) {
        const tutorSubject = `HabKids — New Subscriber Assigned: ${studentName}`;
        const tutorBody = `Dear ${tutorName},

You have been successfully matched as the designated instructor for ${studentName}!

Subscription Plan: ${planDisplayName} (${creditsLabel})
Active Weekly Schedule:
${scheduleText}

Please visit your Tutor Dashboard to view the student's learning profile, review trial feedback, and pre-plan custom syllabi for their lessons. Thank you for your continued dedication to excellence!

Best regards,
HabKids Team`;

        try {
          await fetch('/api/notify/email', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              to: tutorEmail,
              role: 'tutor',
              subject: tutorSubject,
              body: tutorBody
            })
          });
        } catch (tutorEmailErr) {
          console.error("Failed to send subscription notification email to tutor:", tutorEmailErr);
        }
      }
    };

    triggerSubscriptionEmails().catch(e => console.error("Subscription emails failed", e));

    return { success: true, studentId: sId };
  } catch (error) {
    console.error("createSubscription Error:", error);
    return { success: false };
  }
}

// Helper to find the next occurrence of a specific day and time
export function getNextOccurrence(dayName: string, timeStr: string, fromDate: Date = new Date()) {
  const days = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
  const targetDay = days.indexOf(dayName.toLowerCase().trim());
  if (targetDay === -1) return fromDate;

  const resultDate = new Date(fromDate);
  
  // Parse timeStr (e.g. "04:00 PM")
  const parts = timeStr.trim().split(' ');
  const time = parts[0];
  const modifier = parts[1] || 'AM';
  let [hours, minutes] = (time || "12:00").split(':').map(Number);
  if (modifier === 'PM' && hours < 12) hours += 12;
  if (modifier === 'AM' && hours === 12) hours = 0;
  
  resultDate.setHours(hours, minutes, 0, 0);

  const currentDay = resultDate.getDay();
  let daysUntil = targetDay - currentDay;
  if (daysUntil < 0 || (daysUntil === 0 && resultDate < fromDate)) {
    daysUntil += 7;
  }
  
  resultDate.setDate(resultDate.getDate() + daysUntil);
  return resultDate;
}

/**
 * Robustly converts a slot string into "Day @ Time" format.
 * Handles existing "Day @ Time" and ISO date strings.
 */
function ensureRecurringFormat(slot: string): string {
  if (!slot) return "";
  if (slot.includes('@') && !slot.includes('T')) return slot.trim();
  
  // Try to parse as date
  const d = new Date(slot);
  if (!isNaN(d.getTime())) {
    const day = d.toLocaleDateString('en-US', { weekday: 'long' });
    const time = d.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
    return `${day} @ ${time}`;
  }
  
  return slot.trim();
}

/**
 * Manually synchronizes/generates recurring sessions for a student based on their stored pattern.
 * Used by Admin to force visibility in Tutor Dashboard if auto-generation failed or was skipped.
 */
export async function syncStudentSessions(studentId: string) {
  try {
    const studentRef = doc(db, 'students', studentId);
    const studentSnap = await getDoc(studentRef);
    if (!studentSnap.exists()) throw new Error("Student not found");
    
    const student = studentSnap.data();
    const tutorId = student.tutorId;
    const schedulePattern = student.schedulePattern;
    const parentId = student.parentId;
    const parentEmail = student.parentEmail;

    if (!tutorId || !schedulePattern) {
      throw new Error("Student must have an assigned Tutor and Schedule Pattern to sync sessions.");
    }

    const rawSlots = Array.isArray(schedulePattern) 
      ? schedulePattern 
      : schedulePattern.split(',').map((s: string) => s.trim()).filter(Boolean);
    
    const slots = rawSlots.map(ensureRecurringFormat);
    
    const tutorSnap = await getDoc(doc(db, 'tutors', tutorId));
    const tData = tutorSnap.exists() ? tutorSnap.data() : {};
    const tutorName = tData.name || tData.displayName || "Assigned Tutor";
    const tutorEmail = tData.email || '';
    const classroomLink = tData.classroomLink || '';
    
    for (const slot of slots) {
      const [dayPart, timePart] = slot.split(' @ ');
      if (dayPart && timePart) {
        const nextStart = getNextOccurrence(dayPart, timePart, new Date());
        await scheduleRecurringSessions(
          { id: studentId, name: student.name },
          { id: tutorId, name: tutorName },
          nextStart,
          parentId,
          parentEmail,
          tutorEmail,
          classroomLink
        );
      }
    }
    
    return { success: true, count: slots.length * 4 };
  } catch (error: any) {
    console.error("syncStudentSessions Error:", error);
    throw error;
  }
}

export async function renewSubscription(
  studentId: string,
  parentId: string,
  parentEmail: string,
  planType: string,
  rate: number,
  tutorId: string,
  schedulePatternInput?: string[] | string,
  purchasedCredits?: number,
  paymentScreenshotBase64?: string,
  paymentRef?: string,
  paymentSenderName?: string,
  paymentType?: string
) {
  try {
    let schedulePattern = '';
    if (typeof schedulePatternInput === 'string') {
      schedulePattern = schedulePatternInput;
    } else if (Array.isArray(schedulePatternInput)) {
      schedulePattern = schedulePatternInput.join(', ');
    } else {
      schedulePattern = 'Heritage Class Schedule';
    }

    const creditsToAdd = purchasedCredits !== undefined ? purchasedCredits : (planType === 'mastery' ? 12 : planType === 'pro' ? 8 : 4);

    // Fetch existing credits of student, and add the credits newly purchased!
    const studentRef = doc(db, 'students', studentId);
    const studentSnap = await getDoc(studentRef);
    let currentCredits = 0;
    let studentName = "Student";
    if (studentSnap.exists()) {
      currentCredits = studentSnap.data().remainingClassCredits || 0;
      studentName = studentSnap.data().name || "Student";
    }
    const newCreditsTotal = currentCredits + creditsToAdd;

    // 1. Reset student status to active
    await updateDoc(studentRef, {
      status: 'active',
      plan: planType,
      schedulePattern,
      remainingClassCredits: newCreditsTotal,
      subscriptionStartDate: new Date().toISOString(), // Set start date to now for cycle calculations
      expireReason: null, // Clear expiration reason
      updatedAt: serverTimestamp()
    });

    // 2. Create subscription ledger record
    const now = new Date();
    const billingCycleStart = now;
    const billingCycleEnd = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000); // 30 days

    await addDoc(collection(db, 'subscriptions'), {
      studentId,
      parentId,
      parentEmail,
      planType,
      rate,
      billingCycleStart,
      billingCycleEnd,
      status: 'active',
      remainingClassCredits: creditsToAdd,
      createdAt: serverTimestamp(),
      ...(paymentScreenshotBase64 ? { paymentScreenshotBase64 } : {}),
      ...(paymentRef ? { paymentRef } : {}),
      ...(paymentSenderName ? { paymentSenderName } : {}),
      ...(paymentType ? { paymentType } : {})
    });

    // 3. Automatically schedule the next batch of sessions for the Tutor Dashboard sync
    if (tutorId && tutorId !== 'auto-assign' && schedulePatternInput) {
      try {
        const rawSlots = Array.isArray(schedulePatternInput) 
          ? schedulePatternInput 
          : schedulePatternInput.split(',').map(s => s.trim()).filter(Boolean);
        
        const slots = rawSlots.map(ensureRecurringFormat);
        
        const tutorSnap = await getDoc(doc(db, 'tutors', tutorId));
        const tutorName = tutorSnap.exists() ? (tutorSnap.data().name || tutorSnap.data().displayName || "Assigned Tutor") : "Assigned Tutor";
        
        for (const slot of slots) {
          // slot is "Monday @ 04:00 PM"
          const [dayPart, timePart] = slot.split(' @ ');
          if (dayPart && timePart) {
            const nextStart = getNextOccurrence(dayPart, timePart, new Date());
            await scheduleRecurringSessions(
              { id: studentId, name: studentName },
              { id: tutorId, name: tutorName },
              nextStart,
              parentId
            );
          }
        }
        console.log(`Successfully auto-scheduled ${slots.length * 4} sessions for renewal.`);
      } catch (schedErr) {
        console.error("Failed to auto-schedule sessions during renewal:", schedErr);
      }
    }

    const triggerRenewalEmails = async () => {
      if (!parentEmail) return;
      let studentName = 'Your student';
      let tutorName = 'Auto-Assigned Tutor';
      try {
        const studentSnap = await getDoc(doc(db, 'students', studentId));
        if (studentSnap.exists()) {
          studentName = studentSnap.data().name || 'Your student';
        }
      } catch (e) {
        console.error("Error fetching student name for renewal email:", e);
      }

      if (tutorId && tutorId !== 'auto-assign') {
        try {
          const tutorSnap = await getDoc(doc(db, 'tutors', tutorId));
          if (tutorSnap.exists()) {
            tutorName = tutorSnap.data().name || tutorSnap.data().displayName || 'Designated Tutor';
          }
        } catch (e) {
          console.error("Error fetching tutor name for renewal email:", e);
        }
      }

      const planDisplayName = planType === 'custom' ? `Custom Credit Package` : (planType.charAt(0).toUpperCase() + planType.slice(1) + " Plan");
      const scheduleText = schedulePattern || 'Not Scheduled Yet';

      const parentSubject = `HabKids — Subscription Renewed Successfully!`;
      const parentBody = `Dear Parent,

We are happy to confirm that your subscription for ${studentName} has been successfully renewed!

Your details are updated as follows:
• Student Name: ${studentName}
• Subscription Plan: ${planDisplayName}
• Added Credits: ${creditsToAdd} classes
• Designated Tutor: ${tutorName}
• Recurring Schedule: ${scheduleText}

Thank you for choosing HabKids to support your child's Amharic education!

Best regards,
HabKids Team`;

      try {
        await fetch('/api/notify/email', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            to: parentEmail,
            role: 'parent',
            subject: parentSubject,
            body: parentBody
          })
        });
      } catch (err) {
        console.error("Failed to send subscription renewal email:", err);
      }
    };

    triggerRenewalEmails().catch(e => console.error("Renewal email trigger error:", e));

    return { success: true };
  } catch (error) {
    console.error("renewSubscription Error:", error);
    return { success: false };
  }
}

export async function updateTutorProfile(uid: string, profileData: any, tutorId?: string) {
  try {
    const userRef = doc(db, 'users', uid);
    await updateDoc(userRef, {
      ...profileData,
      updatedAt: serverTimestamp()
    });

    let targetTutorId = tutorId;
    if (!targetTutorId) {
      const userSnap = await getDoc(userRef);
      if (userSnap.exists()) {
        targetTutorId = userSnap.data().tutorId;
      }
    }

    if (targetTutorId) {
      const tutorRef = doc(db, 'tutors', targetTutorId);
      await updateDoc(tutorRef, {
        name: profileData.displayName || profileData.fullName || '',
        'specialized syllabus': profileData.expertise || '',
        specializedSyllabus: profileData.expertise || '',
        classroomLink: profileData.classroomLink || '',
        updatedAt: serverTimestamp()
      });
    } else {
      const userSnap = await getDoc(userRef);
      if (userSnap.exists() && userSnap.data().email) {
        const q = query(collection(db, 'tutors'), where('email', '==', userSnap.data().email.trim().toLowerCase()));
        const qSnap = await getDocs(q);
        if (!qSnap.empty) {
          const tutorRef = doc(db, 'tutors', qSnap.docs[0].id);
          await updateDoc(tutorRef, {
            name: profileData.displayName || profileData.fullName || '',
            'specialized syllabus': profileData.expertise || '',
            specializedSyllabus: profileData.expertise || '',
            classroomLink: profileData.classroomLink || '',
            updatedAt: serverTimestamp()
          });
        }
      }
    }
    return { success: true };
  } catch (error) {
    console.error("updateTutorProfile Error:", error);
    return { success: false };
  }
}

export async function scheduleRecurringSessions(
  studentData: { id: string, name: string }, 
  tutorData: { id: string, name: string }, 
  startTime: Date, 
  parentId: string,
  parentEmail?: string,
  tutorEmail?: string,
  classroomLink?: string
) {
  try {
    const sessions = [];
    // Creating 4 sessions (weekly)
    for (let i = 0; i < 4; i++) {
      const sessionDate = new Date(startTime);
      sessionDate.setDate(sessionDate.getDate() + (i * 7));
      
      const sessionPromise = addDoc(collection(db, 'sessions'), {
        studentId: studentData.id,
        studentName: studentData.name,
        tutorId: tutorData.id,
        tutorName: tutorData.name,
        tutorEmail: tutorEmail || '',
        classroomLink: classroomLink || '',
        parentId,
        parentEmail: parentEmail || '',
        startTime: sessionDate,
        status: 'scheduled',
        type: 'regular',
        createdAt: serverTimestamp()
      });
      sessions.push(sessionPromise);
    }

    await Promise.all(sessions);

    // Notify Parent
    if (parentId) {
      await createNotification({
        userId: parentId,
        title: "Sessions Scheduled",
        message: `4 recurring weekly sessions have been scheduled for ${studentData.name} starting ${startTime.toLocaleDateString()}.`,
        type: 'booking',
        link: '/parent/schedule'
      });
    }

    // Notify Tutor
    if (tutorData.id) {
      // Find tutor email/uid to notify
      const tutorRef = doc(db, 'tutors', tutorData.id);
      const tutorSnap = await getDoc(tutorRef);
      if (tutorSnap.exists()) {
        const tutorEmail = tutorSnap.data().email;
        if (tutorEmail) {
          const tutorUid = 'virtual_' + tutorEmail.trim().toLowerCase().replace(/[@.]/g, '_');
          await createNotification({
            userId: tutorUid,
            title: "New Recurring Student",
            message: `You have 4 new recurring sessions with ${studentData.name} starting ${startTime.toLocaleDateString()}.`,
            type: 'booking',
            link: '/tutor/calendar'
          });
        }
      }
      await incrementTutorRealBookings(tutorData.id, 4);
    }

    return { success: true };
  } catch (error) {
    console.error("scheduleRecurringSessions Error:", error);
    return { success: false };
  }
}

export function subscribeToMyLeads(email: string, callback: (leads: any[]) => void, onError?: () => void) {
  const q = query(collection(db, 'leads'), where('email', '==', email));
  return onSnapshot(q, (snapshot) => {
    const leads = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    callback(leads);
  }, (error) => {
    console.error("Firestore error in subscribeToMyLeads:", error);
    onError?.();
  });
}

export async function updateTutorAvailability(uid: string, availability: any, tutorId?: string) {
  try {
    const userRef = doc(db, 'users', uid);
    await updateDoc(userRef, {
      availability,
      updatedAt: serverTimestamp()
    });

    let targetTutorId = tutorId;
    if (!targetTutorId) {
      const userSnap = await getDoc(userRef);
      if (userSnap.exists()) {
        targetTutorId = userSnap.data().tutorId;
      }
    }

    if (targetTutorId) {
      const tutorRef = doc(db, 'tutors', targetTutorId);
      await updateDoc(tutorRef, {
        availability,
        updatedAt: serverTimestamp()
      });
    } else {
      const userSnap = await getDoc(userRef);
      if (userSnap.exists() && userSnap.data().email) {
        const q = query(collection(db, 'tutors'), where('email', '==', userSnap.data().email.trim().toLowerCase()));
        const qSnap = await getDocs(q);
        if (!qSnap.empty) {
          const tutorRef = doc(db, 'tutors', qSnap.docs[0].id);
          await updateDoc(tutorRef, {
            availability,
            updatedAt: serverTimestamp()
          });
        }
      }
    }

    // 3. Make sure to update availability in tutor_applications as well so that the original application remains perfectly similar!
    try {
      const userSnap = await getDoc(userRef);
      if (userSnap.exists() && userSnap.data().email) {
        const emailVal = userSnap.data().email.trim().toLowerCase();
        const qApps = query(collection(db, 'tutor_applications'), where('email', '==', emailVal));
        const appsSnap = await getDocs(qApps);
        for (const appDoc of appsSnap.docs) {
          await updateDoc(doc(db, 'tutor_applications', appDoc.id), {
            availability,
            updatedAt: serverTimestamp()
          });
        }
      }
    } catch (appErr) {
      console.warn("Could not sync availability update to tutor_applications:", appErr);
    }

    return { success: true };
  } catch (error) {
    console.error("updateTutorAvailability Error:", error);
    return { success: false };
  }
}

export function isDemoOrHardcodedTutor(t: any) {
  if (!t) return false;
  const email = (t.email || '').toLowerCase().trim();
  const name = (t.displayName || t.name || t.fullName || '').toLowerCase().trim();
  const id = (t.id || '').toLowerCase().trim();
  
  return (
    email.includes('sample') || 
    name.includes('sample') ||
    id.includes('sample')
  );
}

export function getTutorSlug(t: any): string {
  if (!t) return '';
  const name = (t.displayName || t.name || t.fullName || '').trim();
  if (!name) {
    const rawId = t.tutorId || t.uid || t.id || '';
    return String(rawId).substring(0, 8).toLowerCase();
  }
  
  // Extract the first word (first name)
  const firstWord = name.split(/\s+/)[0];
  
  // Clean special characters but keep letters (including Ge'ez/Amharic Unicode range \u1200-\u137F)
  const firstName = firstWord.toLowerCase().replace(/[^\w\u1200-\u137F\-]+/g, '');
  
  const rawId = t.tutorId || t.uid || t.id || '';
  const shortId = String(rawId).substring(0, 4).toLowerCase();
  
  return firstName ? `${firstName}-${shortId}` : shortId;
}

export async function getTutorsWithAvailability() {
  try {
    const daysOfWeek = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'];

    // Load admin setting first to dynamically override the hourlyRate
    let globalHourlyRate = 25;
    try {
      const settingsSnap = await getDoc(doc(db, 'settings', 'global'));
      if (settingsSnap.exists() && settingsSnap.data()?.tutorHourlyRate !== undefined) {
        globalHourlyRate = Number(settingsSnap.data().tutorHourlyRate) || 25;
      }
    } catch (e) {
      console.error("Error reading global hourly rate:", e);
    }

    // 1. Fetch from 'tutors' collection containing master approved recruiter profiles
    const tutorsSnap = await getDocs(collection(db, 'tutors'));
    const tutorsList = tutorsSnap.docs.map(doc => {
      const data = doc.data();
      
      // Parse availability (either nestled object "availability" or root-level weekday fields)
      let tutorAvailability = data.availability || null;
      if (!tutorAvailability || Object.keys(tutorAvailability).length === 0) {
        const constructed: any = {};
        let hasRootDays = false;
        for (const d of daysOfWeek) {
          if (data[d] !== undefined) {
            constructed[d] = data[d];
            hasRootDays = true;
          }
        }
        if (hasRootDays) {
          tutorAvailability = constructed;
        }
      }

      return {
        id: doc.id,
        ...data,
        hourlyRate: String(globalHourlyRate),
        availability: tutorAvailability,
        displayName: data.name || data.displayName || '',
        expertise: data.specializedSyllabus || data['specialized syllabus'] || data.expertise || 'Heritage Language Tutor',
        specializedSyllabus: data.specializedSyllabus || data['specialized syllabus'] || data.expertise || 'Heritage Language Tutor',
        primarySyllabusSpecialization: data.primarySyllabusSpecialization || (
          ((data.specializedSyllabus || data['specialized syllabus'] || data.expertise || '').toLowerCase().includes('geez') ||
           (data.specializedSyllabus || data['specialized syllabus'] || data.expertise || '').toLowerCase().includes("ge'ez") ||
           (data.specializedSyllabus || data['specialized syllabus'] || data.expertise || '').toLowerCase().includes('ግዕዝ')) ? "Ge'ez" : "Amharic"
        )
      };
    }) as any[];

    // 2. Fetch from 'users' collection with role 'tutor'
    const usersQ = query(collection(db, 'users'), where('role', '==', 'tutor'));
    const usersSnap = await getDocs(usersQ);
    const usersList = usersSnap.docs.map(doc => {
      const data = doc.data();

      // Parse availability (either nestled object "availability" or root-level weekday fields)
      let userAvailability = data.availability || null;
      if (!userAvailability || Object.keys(userAvailability).length === 0) {
        const constructed: any = {};
        let hasRootDays = false;
        for (const d of daysOfWeek) {
          if (data[d] !== undefined) {
            constructed[d] = data[d];
            hasRootDays = true;
          }
        }
        if (hasRootDays) {
          userAvailability = constructed;
        }
      }

      return {
        id: data.tutorId || doc.id,
        ...data,
        hourlyRate: String(globalHourlyRate),
        availability: userAvailability,
        displayName: data.displayName || data.fullName || '',
        expertise: data.specializedSyllabus || data.expertise || 'Heritage Language Tutor',
        specializedSyllabus: data.specializedSyllabus || data.expertise || 'Heritage Language Tutor',
        primarySyllabusSpecialization: data.primarySyllabusSpecialization || (
          ((data.specializedSyllabus || data.expertise || '').toLowerCase().includes('geez') ||
           (data.specializedSyllabus || data.expertise || '').toLowerCase().includes("ge'ez") ||
           (data.specializedSyllabus || data.expertise || '').toLowerCase().includes('ግዕዝ')) ? "Ge'ez" : "Amharic"
        )
      };
    }) as any[];

    // 3. Merge cleanly by email (case-insensitive) to prevent duplicates and combine info
    const mergedMap = new Map<string, any>();
    
    for (const t of tutorsList) {
      const emailKey = t.email ? t.email.trim().toLowerCase() : t.id;
      mergedMap.set(emailKey, { ...t, hourlyRate: String(globalHourlyRate) });
    }
    
    for (const u of usersList) {
      const emailKey = u.email ? u.email.trim().toLowerCase() : u.id;
      const existing = mergedMap.get(emailKey);
      if (existing) {
        // Find most complete availability profile between the two documents
        const mergedAvailability = (u.availability && Object.keys(u.availability).length > 0)
          ? u.availability
          : (existing.availability && Object.keys(existing.availability).length > 0)
            ? existing.availability
            : null;

        const mergedSpecialization = u.primarySyllabusSpecialization || existing.primarySyllabusSpecialization || (
          ((u.specializedSyllabus || u.expertise || '').toLowerCase().includes('geez') ||
           (u.specializedSyllabus || u.expertise || '').toLowerCase().includes("ge'ez") ||
           (u.specializedSyllabus || u.expertise || '').toLowerCase().includes('ግዕዝ')) ? "Ge'ez" : "Amharic"
        );

        mergedMap.set(emailKey, { 
          ...u, 
          ...existing,
          hourlyRate: String(globalHourlyRate),
          availability: mergedAvailability,
          primarySyllabusSpecialization: mergedSpecialization
        });
      } else {
        const specialized = (u.expertise || u.specializedSyllabus || "").toLowerCase();
        const primarySyllabusSpecialization = u.primarySyllabusSpecialization || (
          (specialized.includes("geez") || specialized.includes("ge'ez") || specialized.includes("g'eez") || specialized.includes("ግዕዝ")) ? "Ge'ez" : "Amharic"
        );
        mergedMap.set(emailKey, { 
          ...u, 
          primarySyllabusSpecialization,
          hourlyRate: String(globalHourlyRate) 
        });
      }
    }

    const filtered = Array.from(mergedMap.values()).filter(t => !isDemoOrHardcodedTutor(t));
    return filtered;
  } catch (error) {
    console.error("getTutorsWithAvailability Error:", error);
    return [];
  }
}

/**
 * Efficiently fetches a single tutor profile by its unique slug or Firestore document ID.
 * This prevents fetching the entire tutor directory when only one profile is needed.
 */
export async function getTutorBySlugOrId(slugOrId: string) {
  if (!slugOrId) return null;

  try {
    // 1. Check if slugOrId is a Firestore ID (direct hit)
    // Firestore IDs are usually 20 chars, but we can just try a direct getDoc
    const directDoc = await getDoc(doc(db, 'tutors', slugOrId));
    if (directDoc.exists()) {
      return { id: directDoc.id, ...directDoc.data() };
    }

    // 2. Query by slug
    const qSlug = query(collection(db, 'tutors'), where('slug', '==', slugOrId), limit(1));
    const snapSlug = await getDocs(qSlug);
    if (!snapSlug.empty) {
      const d = snapSlug.docs[0];
      return { id: d.id, ...d.data() };
    }

    // 3. Check 'users' collection if not found in 'tutors' (for legacy or direct links)
    const userDoc = await getDoc(doc(db, 'users', slugOrId));
    if (userDoc.exists() && userDoc.data()?.role === 'tutor') {
      return { id: userDoc.id, ...userDoc.data() };
    }

    // 4. Final attempt: query users by slug if they have a tutor role
    const qUserSlug = query(collection(db, 'users'), where('role', '==', 'tutor'), where('slug', '==', slugOrId), limit(1));
    const snapUserSlug = await getDocs(qUserSlug);
    if (!snapUserSlug.empty) {
      const d = snapUserSlug.docs[0];
      return { id: d.id, ...d.data() };
    }

    return null;
  } catch (error) {
    console.error("getTutorBySlugOrId Error:", error);
    return null;
  }
}
export async function createTutor(tutorData: { 
  displayName: string; 
  email: string; 
  expertise: string; 
  bio?: string;
  languages_taught?: string[];
  years_of_experience?: number;
  avatar?: string;
  videoUrl?: string;
  rating?: string;
  reviewsCount?: string;
  location?: string;
  stats?: string;
  quote?: string;
  ageSpecialty?: string;
  hourlyRate?: string;
  availability?: any;
  initialBookings?: number;
  initialReviews?: number;
  initialRating?: number;
  realBookingsCount?: number;
  realReviewsCount?: number;
  uid?: string;
}) {
  const path = 'tutors';
  try {
    const cleanEmail = tutorData.email.trim().toLowerCase();
    const targetUid = tutorData.uid || 'virtual_' + cleanEmail.replace(/[@.]/g, '_');
 
    const fallbackAvailability = {
      monday: { active: true, slots: ['22:00', '23:00', '00:00', '01:00', '02:00', '03:00', '04:00', '05:00'] },
      tuesday: { active: true, slots: ['22:00', '23:00', '00:00', '01:00', '02:00', '03:00', '04:00', '05:00'] },
      wednesday: { active: true, slots: ['22:00', '23:00', '00:00', '01:00', '02:00', '03:00', '04:00', '05:00'] },
      thursday: { active: true, slots: ['22:00', '23:00', '00:00', '01:00', '02:00', '03:00', '04:00', '05:00'] },
      friday: { active: true, slots: ['22:00', '23:00', '00:00', '01:00', '02:00', '03:00', '04:00', '05:00'] },
      saturday: { active: true, slots: ['14:00', '15:00', '16:00', '17:00', '18:00', '19:00', '20:00', '21:00', '22:00', '23:00', '00:00', '01:00'] },
      sunday: { active: true, slots: ['14:00', '15:00', '16:00', '17:00', '18:00', '19:00', '20:00', '21:00', '22:00', '23:00', '00:00', '01:00'] }
    };
    const finalAvailability = tutorData.availability && Object.keys(tutorData.availability).length > 0 ? tutorData.availability : fallbackAvailability;
 
    const initialBookings = tutorData.initialBookings !== undefined ? Number(tutorData.initialBookings) : 0;
    const initialReviews = tutorData.initialReviews !== undefined ? Number(tutorData.initialReviews) : 0;
    const initialRating = tutorData.initialRating !== undefined ? Number(tutorData.initialRating) : 5.0;
    const realBookingsCount = tutorData.realBookingsCount !== undefined ? Number(tutorData.realBookingsCount) : 0;
    const realReviewsCount = tutorData.realReviewsCount !== undefined ? Number(tutorData.realReviewsCount) : 0;

    const totalBookings = initialBookings + realBookingsCount;
    const reviewsCount = initialReviews + realReviewsCount;
    const ratingStr = initialRating.toFixed(1);

    // Fetch dynamic hourly rate from global settings
    let finalHourlyRate = '25';
    try {
      const settingsRef = doc(db, 'settings', 'global');
      const settingsSnap = await getDoc(settingsRef);
      if (settingsSnap.exists()) {
        const settingsData = settingsSnap.data();
        if (settingsData && settingsData.tutorHourlyRate !== undefined) {
          finalHourlyRate = String(settingsData.tutorHourlyRate);
        }
      }
    } catch (e) {
      console.warn("Could not load dynamic tutorHourlyRate, falling back:", e);
      finalHourlyRate = tutorData.hourlyRate || '25';
    }

    // 1. Check if a tutor with this exact email already exists to prevent duplicate profiles
    const tutorsCollection = collection(db, 'tutors');
    const qTutors = query(tutorsCollection, where('email', '==', cleanEmail));
    const tutorsSnapshot = await getDocs(qTutors);
    
    let tutorId = "";
    const tutorDataPayload = {
      name: tutorData.displayName,
      displayName: tutorData.displayName,
      email: cleanEmail,
      'specialized syllabus': tutorData.expertise,
      specializedSyllabus: tutorData.expertise,
      bio: tutorData.bio || '',
      languages_taught: tutorData.languages_taught || [],
      years_of_experience: Number(tutorData.years_of_experience) || 0,
      avatar: tutorData.avatar || '',
      videoUrl: tutorData.videoUrl || '',
      rating: ratingStr,
      reviewsCount: String(reviewsCount),
      totalBookings: totalBookings,
      initialBookings,
      initialReviews,
      initialRating,
      realBookingsCount,
      realReviewsCount,
      location: tutorData.location || 'Addis Ababa Native Speaker',
      stats: tutorData.stats || 'Trial Onboarded',
      quote: tutorData.quote || '',
      ageSpecialty: tutorData.ageSpecialty || 'All children aged 6-12',
      hourlyRate: finalHourlyRate,
      availability: finalAvailability,
      role: 'tutor',
      updatedAt: serverTimestamp()
    };
 
    if (!tutorsSnapshot.empty) {
      // Key: Update existing tutor record and preserve its document ID!
      const existingTutorDoc = tutorsSnapshot.docs[0];
      tutorId = existingTutorDoc.id;
      await setDoc(doc(db, 'tutors', tutorId), {
        ...tutorDataPayload,
        createdAt: existingTutorDoc.data().createdAt || serverTimestamp()
      }, { merge: true });
    } else {
      // Create a brand new record
      const tutorRef = await addDoc(tutorsCollection, {
        ...tutorDataPayload,
        createdAt: serverTimestamp()
      });
      tutorId = tutorRef.id;
    }
    
    // 2. Mirror into users collection for authentication context using deterministic targetUid
    await setDoc(doc(db, 'users', targetUid), {
      displayName: tutorData.displayName,
      fullName: tutorData.displayName,
      email: cleanEmail,
      expertise: tutorData.expertise,
      specializedSyllabus: tutorData.expertise,
      bio: tutorData.bio || '',
      languages_taught: tutorData.languages_taught || [],
      years_of_experience: Number(tutorData.years_of_experience) || 0,
      avatar: tutorData.avatar || '',
      videoUrl: tutorData.videoUrl || '',
      rating: ratingStr,
      reviewsCount: String(reviewsCount),
      totalBookings: totalBookings,
      initialBookings,
      initialReviews,
      initialRating,
      realBookingsCount,
      realReviewsCount,
      location: tutorData.location || 'Addis Ababa Native Speaker',
      stats: tutorData.stats || 'Trial Onboarded',
      quote: tutorData.quote || '',
      ageSpecialty: tutorData.ageSpecialty || 'All children aged 6-12',
      hourlyRate: finalHourlyRate,
      availability: finalAvailability,
      role: 'tutor',
      tutorId: tutorId, // Explicitly link the tutor auto ID!
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
      uid: targetUid
    }, { merge: true });

    console.log("Tutor synchronized with ID inside tutors collection:", tutorId);

    // Send a beautifully styled welcome/activation email to the new active tutor
    try {
      const subject = `Welcome to the Team! Your Scholar Account is Active 🎓🌟`;
      const body = `Dear ${tutorData.displayName},\n\nCongratulations! Your professional tutor profile has been successfully published to our Parent Booking Registry at HabKids.\n\nNow, parents can book paid 25-minute evaluation trial sessions with you directly based on your listed specialties:\n- Expertise: ${tutorData.expertise}\n- Specialty: ${tutorData.ageSpecialty || "All Ages (Ages 6-12)"}\n- Hourly Rate: $${finalHourlyRate}/hr\n\nYour official login details are active using your professional registered email address:\n- Registered Email: ${cleanEmail}\n- Access URL: Please log in using the Tutor Portal on the homepage.\n\nTo manage your profile or view booked sessions, simply log in using your Google account or the password setup on our application.\n\nThank you for dedicating your language expertise to our wonderful children abroad!\n\nBest regards,\nHabKids Team`;

      await fetch('/api/notify/email', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          to: cleanEmail,
          role: 'tutor',
          subject: subject,
          body: body
        })
      });
      console.log(`[ONBOARD_MAIL] Successfully dispatched welcome activation email to professional tutor: ${cleanEmail}`);
    } catch (emailErr) {
      console.warn("Could not dispatch welcome email to active tutor:", emailErr);
    }

    return { success: true, id: tutorId, availability: finalAvailability };
  } catch (error: any) {
    console.error("createTutor Error:", error);
    handleFirestoreError(error, OperationType.CREATE, path);
    if (error.code === 'permission-denied') {
      return { success: false, error: 'Permission denied. Make sure you are an administrator.' };
    }
    return { success: false, error: error.message };
  }
}

export async function updateTutor(
  tutorId: string, 
  tutorData: { 
    displayName: string; 
    expertise: string; 
    email: string; 
    bio?: string;
    languages_taught?: string[];
    years_of_experience?: number;
    initialBookings?: number;
    initialReviews?: number;
    initialRating?: number;
  },
  oldEmail?: string
) {
  try {
    const tutorDocRef = doc(db, 'tutors', tutorId);
    const tutorSnap = await getDoc(tutorDocRef);
    
    let existingRealBookings = 0;
    let existingRealReviews = 0;
    let existingInitialBookings = 0;
    let existingInitialReviews = 0;
    let existingInitialRating = 5.0;

    if (tutorSnap.exists()) {
      const data = tutorSnap.data();
      existingRealBookings = data.realBookingsCount || 0;
      existingRealReviews = data.realReviewsCount || 0;
      existingInitialBookings = data.initialBookings !== undefined ? Number(data.initialBookings) : 0;
      existingInitialReviews = data.initialReviews !== undefined ? Number(data.initialReviews) : 0;
      existingInitialRating = data.initialRating !== undefined ? Number(data.initialRating) : 5.0;
    }

    const initialBookings = tutorData.initialBookings !== undefined ? Number(tutorData.initialBookings) : existingInitialBookings;
    const initialReviews = tutorData.initialReviews !== undefined ? Number(tutorData.initialReviews) : existingInitialReviews;
    const initialRating = tutorData.initialRating !== undefined ? Number(tutorData.initialRating) : existingInitialRating;

    const totalBookings = initialBookings + existingRealBookings;
    const reviewsCount = initialReviews + existingRealReviews;
    const ratingStr = initialRating.toFixed(1);

    await updateDoc(tutorDocRef, {
      name: tutorData.displayName,
      displayName: tutorData.displayName,
      email: tutorData.email.toLowerCase().trim(),
      specializedSyllabus: tutorData.expertise,
      'specialized syllabus': tutorData.expertise,
      expertise: tutorData.expertise,
      bio: tutorData.bio ?? '',
      languages_taught: tutorData.languages_taught ?? [],
      years_of_experience: Number(tutorData.years_of_experience) ?? 0,
      initialBookings,
      initialReviews,
      initialRating,
      totalBookings,
      reviewsCount: String(reviewsCount),
      rating: ratingStr,
      realBookingsCount: existingRealBookings,
      realReviewsCount: existingRealReviews
    });

    const targetEmails = [tutorData.email.toLowerCase().trim()];
    if (oldEmail) {
      targetEmails.push(oldEmail.toLowerCase().trim());
    }

    for (const emailToSearch of targetEmails) {
      const q = query(collection(db, 'users'), where('email', '==', emailToSearch));
      const snapshot = await getDocs(q);
      for (const userDoc of snapshot.docs) {
        await updateDoc(doc(db, 'users', userDoc.id), {
          displayName: tutorData.displayName,
          fullName: tutorData.displayName,
          email: tutorData.email.toLowerCase().trim(),
          expertise: tutorData.expertise,
          bio: tutorData.bio ?? '',
          languages_taught: tutorData.languages_taught ?? [],
          years_of_experience: Number(tutorData.years_of_experience) ?? 0,
          initialBookings,
          initialReviews,
          initialRating,
          totalBookings,
          reviewsCount: String(reviewsCount),
          rating: ratingStr,
          realBookingsCount: existingRealBookings,
          realReviewsCount: existingRealReviews
        });
      }
    }

    if (oldEmail) {
      const oldClean = oldEmail.toLowerCase().trim();
      const newClean = tutorData.email.toLowerCase().trim();
      if (oldClean !== newClean) {
        const oldVirtualUid = 'virtual_' + oldClean.replace(/[@.]/g, '_');
        const newVirtualUid = 'virtual_' + newClean.replace(/[@.]/g, '_');
        try {
          const oldVirtualDoc = await getDoc(doc(db, 'users', oldVirtualUid));
          if (oldVirtualDoc.exists()) {
            const oldData = oldVirtualDoc.data();
            await setDoc(doc(db, 'users', newVirtualUid), {
              ...oldData,
              uid: newVirtualUid,
              displayName: tutorData.displayName,
              fullName: tutorData.displayName,
              email: newClean,
              expertise: tutorData.expertise,
              bio: tutorData.bio ?? '',
              languages_taught: tutorData.languages_taught ?? [],
              years_of_experience: Number(tutorData.years_of_experience) ?? 0,
              initialBookings,
              initialReviews,
              initialRating,
              totalBookings,
              reviewsCount: String(reviewsCount),
              rating: ratingStr,
              realBookingsCount: existingRealBookings,
              realReviewsCount: existingRealReviews
            });
            await deleteDoc(doc(db, 'users', oldVirtualUid));
          }
        } catch (err) {
          console.warn("Virtual user migration error:", err);
        }
      }
    }

    return { success: true };
  } catch (error: any) {
    console.error("updateTutor Error:", error);
    return { success: false, error: error.message };
  }
}

export async function incrementTutorRealBookings(tutorId: string, count: number) {
  try {
    const tutorDocRef = doc(db, 'tutors', tutorId);
    const tutorSnap = await getDoc(tutorDocRef);
    if (tutorSnap.exists()) {
      const data = tutorSnap.data();
      const initialBookings = data.initialBookings !== undefined ? Number(data.initialBookings) : 0;
      const realBookingsCount = (data.realBookingsCount !== undefined ? Number(data.realBookingsCount) : 0) + count;
      const totalBookings = initialBookings + realBookingsCount;

      const updatePayload = {
        realBookingsCount,
        totalBookings
      };

      await updateDoc(tutorDocRef, updatePayload);

      // Sync user doc
      const email = data.email;
      if (email) {
        const q = query(collection(db, 'users'), where('email', '==', email.toLowerCase().trim()));
        const snapshot = await getDocs(q);
        for (const userDoc of snapshot.docs) {
          await updateDoc(doc(db, 'users', userDoc.id), updatePayload);
        }
      }
    }
  } catch (error) {
    console.error("incrementTutorRealBookings Error:", error);
  }
}

export async function incrementTutorRealReviews(tutorId: string, count: number) {
  try {
    const tutorDocRef = doc(db, 'tutors', tutorId);
    const tutorSnap = await getDoc(tutorDocRef);
    if (tutorSnap.exists()) {
      const data = tutorSnap.data();
      const initialReviews = data.initialReviews !== undefined ? Number(data.initialReviews) : 0;
      const realReviewsCount = (data.realReviewsCount !== undefined ? Number(data.realReviewsCount) : 0) + count;
      const reviewsCount = initialReviews + realReviewsCount;

      const updatePayload = {
        realReviewsCount,
        reviewsCount: String(reviewsCount)
      };

      await updateDoc(tutorDocRef, updatePayload);

      // Sync user doc
      const email = data.email;
      if (email) {
        const q = query(collection(db, 'users'), where('email', '==', email.toLowerCase().trim()));
        const snapshot = await getDocs(q);
        for (const userDoc of snapshot.docs) {
          await updateDoc(doc(db, 'users', userDoc.id), updatePayload);
        }
      }
    }
  } catch (error) {
    console.error("incrementTutorRealReviews Error:", error);
  }
}

export async function deleteTutor(tutorId: string, email: string) {
  try {
    const tutorDocRef = doc(db, 'tutors', tutorId);
    await deleteDoc(tutorDocRef);

    if (email) {
      const cleanEmail = email.trim().toLowerCase();
      // Delete deterministic virtual user id
      const virtualUid = 'virtual_' + cleanEmail.replace(/[@.]/g, '_');
      try {
        await deleteDoc(doc(db, 'users', virtualUid));
      } catch (err) {
        console.warn("Could not delete virtual user doc:", err);
      }

      const q = query(collection(db, 'users'), where('email', '==', cleanEmail));
      const snapshot = await getDocs(q);
      for (const userDoc of snapshot.docs) {
        await deleteDoc(doc(db, 'users', userDoc.id));
      }
    }
    return { success: true };
  } catch (error: any) {
    console.error("deleteTutor Error:", error);
    return { success: false, error: error.message };
  }
}

export function subscribeToAllSessions(callback: (sessions: any[]) => void, onError?: () => void) {
  const q = query(collection(db, 'sessions'));
  return onSnapshot(q, (snapshot) => {
    const sessions = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    
    // Check reminders asynchronously
    triggerClientSideReminders(sessions);
    
    callback(sessions);
  }, (error) => {
    console.error("Firestore error in subscribeToAllSessions:", error);
    onError?.();
  });
}

export function subscribeToTutors(callback: (tutors: any[]) => void, onError?: () => void) {
  const qTutors = query(collection(db, 'tutors'));
  const qUsers = query(collection(db, 'users'), where('role', '==', 'tutor'));
  const docRef = doc(db, 'settings', 'global');

  let tutorsList: any[] = [];
  let usersList: any[] = [];
  let globalHourlyRate = 25;

  const handleMerge = () => {
    const mergedMap = new Map<string, any>();
    
    for (const t of tutorsList) {
      const emailKey = t.email ? t.email.trim().toLowerCase() : t.id;
      const specialized = (t.specializedSyllabus || t.expertise || "").toLowerCase();
      const primarySyllabusSpecialization = t.primarySyllabusSpecialization || (
        (specialized.includes("geez") || specialized.includes("ge'ez") || specialized.includes("g'eez") || specialized.includes("ግዕዝ")) ? "Ge'ez" : "Amharic"
      );
      mergedMap.set(emailKey, { 
        ...t, 
        primarySyllabusSpecialization,
        hourlyRate: String(globalHourlyRate) 
      });
    }
    
    for (const u of usersList) {
      const emailKey = u.email ? u.email.trim().toLowerCase() : u.id;
      const existing = mergedMap.get(emailKey);
      if (existing) {
        const specialized = (u.expertise || u.specializedSyllabus || existing.specializedSyllabus || existing.expertise || "").toLowerCase();
        const primarySyllabusSpecialization = u.primarySyllabusSpecialization || existing.primarySyllabusSpecialization || (
          (specialized.includes("geez") || specialized.includes("ge'ez") || specialized.includes("g'eez") || specialized.includes("ግዕዝ")) ? "Ge'ez" : "Amharic"
        );
        
        // Pick the best available name, avoiding 'Anonymous User'
        const candidateNames = [
          existing.name,
          existing.displayName,
          u.fullName,
          u.displayName,
          u.email ? u.email.split('@')[0] : ''
        ].filter(n => n && n !== 'Anonymous User');
        
        const bestName = candidateNames[0] || u.fullName || u.displayName || 'Tutor';

        mergedMap.set(emailKey, { 
          ...u, 
          ...existing, 
          displayName: bestName,
          fullName: bestName,
          name: bestName,
          primarySyllabusSpecialization,
          hourlyRate: String(globalHourlyRate) 
        });
      } else {
        const specialized = (u.expertise || u.specializedSyllabus || "").toLowerCase();
        const primarySyllabusSpecialization = u.primarySyllabusSpecialization || (
          (specialized.includes("geez") || specialized.includes("ge'ez") || specialized.includes("g'eez") || specialized.includes("ግዕዝ")) ? "Ge'ez" : "Amharic"
        );

        // Pick the best name even if no 'tutors' record exists yet
        const bestName = (u.fullName !== 'Anonymous User' && u.fullName) ? u.fullName : 
                         (u.displayName !== 'Anonymous User' && u.displayName) ? u.displayName : 
                         (u.email ? u.email.split('@')[0] : 'Tutor');

        mergedMap.set(emailKey, { 
          ...u, 
          displayName: bestName,
          fullName: bestName,
          primarySyllabusSpecialization,
          hourlyRate: String(globalHourlyRate) 
        });
      }
    }
    
    const filtered = Array.from(mergedMap.values()).filter(t => !isDemoOrHardcodedTutor(t));
    callback(filtered);
  };

  const unsubscribeSettings = onSnapshot(docRef, (snap) => {
    if (snap.exists()) {
      const sData = snap.data();
      if (sData && sData.tutorHourlyRate !== undefined) {
        globalHourlyRate = Number(sData.tutorHourlyRate) || 25;
        handleMerge();
      }
    }
  }, (err) => {
    console.error("Firestore error in subscribeToTutors settings listener:", err);
  });

  const unsubscribeTutors = onSnapshot(qTutors, (snapshot) => {
    tutorsList = snapshot.docs.map(doc => {
      const data = doc.data();
      const specialized = (data.specializedSyllabus || data['specialized syllabus'] || data.expertise || '').toLowerCase();
      const primarySyllabusSpecialization = data.primarySyllabusSpecialization || (
        (specialized.includes("geez") || specialized.includes("ge'ez") || specialized.includes("g'eez") || specialized.includes("ግዕዝ")) ? "Ge'ez" : "Amharic"
      );
      return {
        id: doc.id,
        ...data,
        displayName: data.name || data.displayName || '',
        expertise: data.specializedSyllabus || data['specialized syllabus'] || data.expertise || 'General Instruction',
        role: data.role || 'tutor',
        primarySyllabusSpecialization
      };
    });
    handleMerge();
  }, (err) => {
    console.error("Firestore error in subscribeToTutors (tutors):", err);
    onError?.();
  });

  const unsubscribeUsers = onSnapshot(qUsers, (snapshot) => {
    usersList = snapshot.docs.map(doc => {
      const data = doc.data();
      const specialized = (data.expertise || data.specializedSyllabus || "").toLowerCase();
      const primarySyllabusSpecialization = data.primarySyllabusSpecialization || (
        (specialized.includes("geez") || specialized.includes("ge'ez") || specialized.includes("g'eez") || specialized.includes("ግዕዝ")) ? "Ge'ez" : "Amharic"
      );
      return {
        id: doc.id,
        ...data,
        displayName: data.displayName || data.name || data.fullName || '',
        expertise: data.expertise || data.specializedSyllabus || data['specialized syllabus'] || 'General Instruction',
        role: data.role || 'tutor',
        primarySyllabusSpecialization
      };
    });
    handleMerge();
  }, (err) => {
    console.error("Firestore error in subscribeToTutors (users):", err);
    onError?.();
  });

  return () => {
    unsubscribeSettings();
    unsubscribeTutors();
    unsubscribeUsers();
  };
}

// Manually Add Lead
export async function addManualLead(leadData: {
  studentName: string;
  parentName: string;
  parentEmail: string;
  phone: string;
  targetCourse: string;
}) {
  const path = 'leads';
  try {
    const docRef = await addDoc(collection(db, path), {
      childName: leadData.studentName,
      studentName: leadData.studentName,
      parentName: leadData.parentName,
      email: leadData.parentEmail,
      parentEmail: leadData.parentEmail,
      whatsapp: leadData.phone,
      phone: leadData.phone,
      learningGoal: leadData.targetCourse,
      targetCourse: leadData.targetCourse,
      status: 'trial_pending',
      createdAt: serverTimestamp(),
    });
    return { success: true, id: docRef.id };
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
    return { success: false, error };
  }
}

// Global Settings Subscriptions & Writes
function sanitizeFidelUrls(data: any): any {
  if (!data) return data;
  const copy = { ...data };
  
  if (copy.fidelFundamentalsUrl && typeof copy.fidelFundamentalsUrl === 'string') {
    let url = copy.fidelFundamentalsUrl.trim();
    // Fix singular or truncated endings like fidel-fundamental, fidel-fundamen
    if (url.includes('fidel-fundamental') && !url.includes('fidel-fundamentals')) {
      url = url.replace('fidel-fundamental', 'fidel-fundamentals');
    } else if (url.includes('fidel-fundamen') && !url.includes('fidel-fundamentals')) {
      url = url.replace('fidel-fundamen', 'fidel-fundamentals');
    }
    // Ensure trailing slash
    if (url && !url.endsWith('/')) {
      url = url + '/';
    }
    copy.fidelFundamentalsUrl = url;
  }
  
  if (copy.fidelFundamentalsGit && typeof copy.fidelFundamentalsGit === 'string') {
    let git = copy.fidelFundamentalsGit.trim();
    if (git.includes('fidel-fundamental') && !git.includes('fidel-fundamentals')) {
      git = git.replace('fidel-fundamental', 'fidel-fundamentals');
    } else if (git.includes('fidel-fundamen') && !git.includes('fidel-fundamentals')) {
      git = git.replace('fidel-fundamen', 'fidel-fundamentals');
    }
    copy.fidelFundamentalsGit = git;
  }
  
  return copy;
}

export function subscribeToSettings(callback: (settings: any) => void, onError?: () => void) {
  // Sync load from localStorage to instantly update views & prevent logo/text flash before Firestore snapshot loads
  try {
    const cached = localStorage.getItem('habkids_cached_settings');
    if (cached) {
      const parsed = JSON.parse(cached);
      if (parsed) {
        callback(parsed);
      }
    }
  } catch (e) {
    console.warn("Could not load cached settings from localStorage:", e);
  }

  const path = 'settings';
  const q = doc(db, 'settings', 'global');
  return onSnapshot(q, (snapshot) => {
    if (snapshot.exists()) {
      const data = snapshot.data() || {};
      let sanitized = { ...data };
      if (!sanitized.academyName || sanitized.academyName.includes('Selam') || sanitized.academyName.includes('Abyssinia') || sanitized.academyName.includes('LinguKid')) {
        sanitized.academyName = "HabKids";
      }
      sanitized.facebookUrl = data.facebookUrl || 'https://www.facebook.com/habkids';
      sanitized.youtubeUrl = data.youtubeUrl || 'https://www.youtube.com/@habkids';
      sanitized.instagramUrl = data.instagramUrl || 'https://www.instagram.com/habkids';
      sanitized.whatsappUrl = data.whatsappUrl || 'https://wa.me/251940651491';
      sanitized.fidelFundamentalsUrl = data.fidelFundamentalsUrl || 'https://brtsegayetad-glitch.github.io/fidel-fundamentals/';
      sanitized.fidelFundamentalsGit = data.fidelFundamentalsGit || 'https://github.com/brtsegayetad-glitch/fidel-fundamentals';
      
      // Auto-correct any user URL spelling typos (e.g., singular vs plural)
      sanitized = sanitizeFidelUrls(sanitized);
      sanitized.tutorHourlyRate = typeof data.tutorHourlyRate === 'number' ? data.tutorHourlyRate : (typeof data.tutorHourlyRate === 'string' ? parseInt(data.tutorHourlyRate) : 25);
      
      sanitized.trialSessionFee = typeof data.trialSessionFee === 'number' ? data.trialSessionFee : (typeof data.trialSessionFee === 'string' ? parseFloat(data.trialSessionFee) : 5);
      sanitized.trialSessionFeeBirr = typeof data.trialSessionFeeBirr === 'number' ? data.trialSessionFeeBirr : (typeof data.trialSessionFeeBirr === 'string' ? parseFloat(data.trialSessionFeeBirr) : 280);
      sanitized.telebirrNumber = data.telebirrNumber || '0940651491';
      sanitized.telebirrName = data.telebirrName || 'HabKids Tutor Admin';
      sanitized.zelleEmail = data.zelleEmail || 'billing@habkids.com';
      sanitized.zelleName = data.zelleName || 'HabKids Inc.';
      sanitized.cbeAccountNumber = data.cbeAccountNumber || '1000349204910';
      sanitized.cbeAccountName = data.cbeAccountName || 'HabKids Tutor Registry';

      // Subscription-specific Payment Details & prices in Birr
      sanitized.proPriceBirr = typeof data.proPriceBirr === 'number' ? data.proPriceBirr : 3500;
      sanitized.masteryPriceBirr = typeof data.masteryPriceBirr === 'number' ? data.masteryPriceBirr : 5200;
      sanitized.standardPriceBirr = typeof data.standardPriceBirr === 'number' ? data.standardPriceBirr : 2300;
      sanitized.subTelebirrNumber = data.subTelebirrNumber || '+251 912 345 678';
      sanitized.subTelebirrName = data.subTelebirrName || 'HabKids tutor';
      sanitized.subTelebirrMerchantCode = data.subTelebirrMerchantCode || '882910';
      sanitized.subZelleEmail = data.subZelleEmail || 'payment@heritageacademy.com';
      sanitized.subZelleName = data.subZelleName || 'HabKids Inc.';
      sanitized.subCbeAccountNumber = data.subCbeAccountNumber || '1000492811726';
      sanitized.subCbeAccountName = data.subCbeAccountName || 'HabKids Language School';
      
      try {
        localStorage.setItem('habkids_cached_settings', JSON.stringify(sanitized));
      } catch (err) {
        console.warn("Could not save settings to localStorage:", err);
      }
      
      callback(sanitized);
    } else {
      // Return beautiful default configurations in fallback
      callback({
        standardPrice: 160,
        proPrice: 240,
        masteryPrice: 320,
        tutorHourlyRate: 25,
        academyName: "HabKids",
        supportEmail: "info@habkids.com",
        supportPhone: "+1 (555) 019-2834",
        welcomeMotto: "Expanding heritage language tutoring and curriculum worldwide",
        instagramUrl: "https://www.instagram.com/habkids",
        whatsappUrl: "https://wa.me/251940651491",
        facebookUrl: "https://www.facebook.com/habkids",
        youtubeUrl: "https://www.youtube.com/@abyssiniatutors",
        fidelFundamentalsUrl: "https://brtsegayetad-glitch.github.io/fidel-fundamentals/",
        fidelFundamentalsGit: "https://github.com/brtsegayetad-glitch/fidel-fundamentals",
        trialSessionFee: 5,
        trialSessionFeeBirr: 280,
        telebirrNumber: '0940651491',
        telebirrName: 'HabKids Tutor Admin',
        zelleEmail: 'billing@habkids.com',
        zelleName: 'HabKids Inc.',
        cbeAccountNumber: '1000349204910',
        cbeAccountName: 'HabKids Tutor Registry',
        proPriceBirr: 3500,
        masteryPriceBirr: 5200,
        standardPriceBirr: 2300,
        subTelebirrNumber: '+251 912 345 678',
        subTelebirrName: 'HabKids tutor',
        subTelebirrMerchantCode: '882910',
        subZelleEmail: 'payment@heritageacademy.com',
        subZelleName: 'HabKids Inc.',
        subCbeAccountNumber: '1000492811726',
        subCbeAccountName: 'HabKids Language School'
      });
    }
  }, (error) => {
    console.error("Firestore error in subscribeToSettings:", error);
    onError?.();
  });
}

export async function saveSettings(settingsData: any) {
  const path = 'settings';
  try {
    const docRef = doc(db, 'settings', 'global');
    // Auto-sanitize typos before saving
    const sanitizedData = sanitizeFidelUrls(settingsData);
    await setDoc(docRef, {
      ...sanitizedData,
      updatedAt: serverTimestamp()
    }, { merge: true });

    try {
      localStorage.setItem('habkids_cached_settings', JSON.stringify({
        ...sanitizedData,
        facebookUrl: sanitizedData.facebookUrl || 'https://www.facebook.com/habkids',
        youtubeUrl: sanitizedData.youtubeUrl || 'https://www.youtube.com/@habkids',
        instagramUrl: sanitizedData.instagramUrl || 'https://www.instagram.com/habkids',
        whatsappUrl: sanitizedData.whatsappUrl || 'https://wa.me/251940651491',
        fidelFundamentalsUrl: sanitizedData.fidelFundamentalsUrl || 'https://brtsegayetad-glitch.github.io/fidel-fundamentals/',
        fidelFundamentalsGit: sanitizedData.fidelFundamentalsGit || 'https://github.com/brtsegayetad-glitch/fidel-fundamentals'
      }));
    } catch (err) {
      console.warn("Could not save settings to localStorage:", err);
    }

    // Also update all existing tutors' hourly rates in the database for absolute data consistency and persistence!
    if (sanitizedData.tutorHourlyRate !== undefined) {
      const rateStr = String(sanitizedData.tutorHourlyRate);
      
      // 1. Update active tutors collection profiles
      const tutorsSnap = await getDocs(collection(db, 'tutors'));
      for (const tutorDoc of tutorsSnap.docs) {
        await updateDoc(tutorDoc.ref, { hourlyRate: rateStr, updatedAt: serverTimestamp() });
      }

      // 2. Update user collection tutor profiles
      const usersQ = query(collection(db, 'users'), where('role', '==', 'tutor'));
      const usersSnap = await getDocs(usersQ);
      for (const userDoc of usersSnap.docs) {
        await updateDoc(userDoc.ref, { hourlyRate: rateStr, tutorHourlyRate: Number(sanitizedData.tutorHourlyRate), updatedAt: serverTimestamp() });
      }
    }

    return { success: true };
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `${path}/global`);
    return { success: false, error };
  }
}

export function subscribeToAllStudents(callback: (students: any[]) => void, onError?: () => void) {
  const q = query(collection(db, 'students'));
  return onSnapshot(q, (snapshot) => {
    const students = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    callback(students);
  }, (error) => {
    console.error("Firestore error in subscribeToAllStudents:", error);
    onError?.();
  });
}

export async function scheduleTrial(leadId: string, tutorData: { id: string, name: string, email: string, classroomLink?: string }, sessionTime: Date, leadData: any) {
  try {
    // 1. Update lead status
    const leadRef = doc(db, 'leads', leadId);
    await updateDoc(leadRef, {
      status: 'scheduled',
      tutorId: tutorData.id,
      scheduledAt: sessionTime,
      updatedAt: serverTimestamp()
    });

    // 2. Create session entry
    const sessionRef = await addDoc(collection(db, 'sessions'), {
      leadId,
      tutorId: tutorData.id,
      tutorName: tutorData.name,
      tutorEmail: tutorData.email,
      classroomLink: tutorData.classroomLink || '',
      parentId: leadData.parentId || 'guest',
      parentEmail: leadData.email,
      parentName: leadData.parentName,
      studentName: leadData.childName || 'Student',
      studentAge: leadData.childAge || 'N/A',
      learningGoal: leadData.learningGoal || 'No goals specified',
      startTime: sessionTime,
      status: 'scheduled',
      type: 'trial',
      createdAt: serverTimestamp()
    });

    // Increment real bookings counter by 1 (and recalculate totalBookings on top of base initialBookings seed)
    if (tutorData.id) {
      await incrementTutorRealBookings(tutorData.id, 1);
    }

    // 3. Trigger Professional Emails
    const triggerEmails = async () => {
      const isParentChoose = leadData.tutorId && leadData.tutorId.trim() !== "";
      const parentSubject = isParentChoose
        ? `HabKids — Chosen Tutor Trial Scheduled & Locked!`
        : `HabKids — Trial Session Scheduled!`;

      const parentBody = isParentChoose
        ? `Dear ${leadData.parentName},\n\nGreat news! Your trial session with your designated hand-selected tutor, ${tutorData.name}, has been officially scheduled and locked!\n\nScheduled Time: ${sessionTime.toLocaleString()}\n\nYou can access your class coordinates directly from your Parent Dashboard 5 minutes before the session is slated to start. We are excited to support your child's Amharic journey!\n\nBest regards,\nHabKids Team`
        : `Dear ${leadData.parentName},\n\nGreat news! We have match-scheduled your introductory trial session with ${tutorData.name}.\n\nScheduled Time: ${sessionTime.toLocaleString()}\n\nYou can access your class coordinates directly from your Parent Dashboard 5 minutes before the session starts. We look forward to meeting you!\n\nBest regards,\nHabKids Team`;

      const tutorSubject = isParentChoose
        ? `Personal Selection Confirmation: Trial Scheduled with ${leadData.parentName}`
        : `New Trial Session Assigned`;

      const tutorBody = isParentChoose
        ? `Dear ${tutorData.name},\n\nYou have been chosen specifically by parent ${leadData.parentName} for a paid 25-minute evaluation trial session. The session has now been officially scheduled!\n\nTime: ${sessionTime.toLocaleString()}\n\nBecause the parent chose your profile, please review their learning expectations and student objectives on your Tutor Dashboard beforehand.\n\nBest regards,\nHabKids Team`
        : `Dear ${tutorData.name},\n\nYou have been assigned a new trial session with ${leadData.parentName}.\n\nTime: ${sessionTime.toLocaleString()}\n\nPlease review the student's goals in your dashboard.\n\nBest regards,\nHabKids Team`;

      // Email to Parent
      try {
        await fetch('/api/notify/email', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            to: leadData.email,
            role: 'parent',
            subject: parentSubject,
            body: parentBody
          })
        });
      } catch (parentEmailErr) {
        console.error("Failed to send scheduled trial email to parent:", parentEmailErr);
      }

      // Email to Tutor
      try {
        await fetch('/api/notify/email', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            to: tutorData.email,
            role: 'tutor',
            subject: tutorSubject,
            body: tutorBody
          })
        });
      } catch (tutorEmailErr) {
        console.error("Failed to send scheduled trial email to tutor:", tutorEmailErr);
      }
    };

    triggerEmails().catch(e => console.error("Scheduling emails failed", e));

    return { success: true, sessionId: sessionRef.id };
  } catch (error) {
    console.error("scheduleTrial Error:", error);
    return { success: false };
  }
}

/**
 * Manually adds a single class session for a specific student.
 */
export async function addManualSession(
  student: any,
  tutor: any,
  startTime: Date,
  sessionType: 'regular' | 'trial' = 'regular'
) {
  try {
    const candidateNames = [
      tutor.name,
      tutor.displayName,
      tutor.fullName
    ].filter(n => n && n !== 'Anonymous User');
    const bestTutorName = candidateNames[0] || tutor.displayName || tutor.name || 'Assigned Tutor';

    const sessionRef = await addDoc(collection(db, 'sessions'), {
      studentId: student.id,
      studentName: student.name,
      tutorId: tutor.id,
      tutorName: bestTutorName,
      tutorEmail: tutor.email || '',
      classroomLink: tutor.classroomLink || '',
      parentId: student.parentId || 'guest',
      parentEmail: student.parentEmail || '',
      parentName: student.parentName || 'Parent',
      startTime: startTime,
      status: 'scheduled',
      type: sessionType,
      createdAt: serverTimestamp()
    });

    if (tutor.id) {
      await incrementTutorRealBookings(tutor.id, 1);
    }

    // Notify Parent
    if (student.parentId) {
      await createNotification({
        userId: student.parentId,
        title: "New Class Scheduled",
        message: `A new ${sessionType} session has been manually scheduled for ${student.name} on ${startTime.toLocaleDateString()}.`,
        type: 'booking',
        link: '/parent/schedule',
        relatedId: sessionRef.id
      });
    }

    // Notify Tutor
    if (tutor.id) {
      const tutorUid = tutor.uid || 'virtual_' + (tutor.email || '').trim().toLowerCase().replace(/[@.]/g, '_');
      await createNotification({
        userId: tutorUid,
        title: "New Session Assigned",
        message: `A manual ${sessionType} session with ${student.name} has been assigned to you for ${startTime.toLocaleDateString()}.`,
        type: 'booking',
        link: '/tutor/calendar',
        relatedId: sessionRef.id
      });
    }

    // Dispatch Emails
    const triggerEmails = async () => {
      const parentEmail = student.parentEmail || '';
      const tutorEmail = tutor.email || '';

      if (parentEmail) {
        try {
          await fetch('/api/notify/email', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              to: parentEmail,
              role: 'parent',
              subject: `New Class Scheduled: ${student.name}`,
              body: `Dear ${student.parentName || 'Parent'},\n\nA new class session has been manually scheduled for ${student.name} by the administrator.\n\nTutor: ${tutor.displayName || tutor.name}\nTime: ${startTime.toLocaleString()}\n\nYou can access the classroom from your Parent Dashboard.\n\nBest regards,\nHabKids Team`
            })
          });
        } catch (err) {}
      }

      if (tutorEmail) {
        try {
          await fetch('/api/notify/email', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              to: tutorEmail,
              role: 'tutor',
              subject: `Manual Session Assigned: ${student.name}`,
              body: `Dear ${tutor.displayName || tutor.name},\n\nA new manual session with ${student.name} has been assigned to you by the administrator.\n\nTime: ${startTime.toLocaleString()}\n\nPlease check your Tutor Dashboard for details.\n\nBest regards,\nHabKids Team`
            })
          });
        } catch (err) {}
      }
    };

    triggerEmails().catch(e => console.error("Manual session emails failed", e));

    return { success: true, id: sessionRef.id };
  } catch (error) {
    console.error("addManualSession Error:", error);
    return { success: false };
  }
}

export function subscribeToMessages(callback: (messages: any[]) => void, onError?: () => void) {
  const path = 'messages';
  const q = query(collection(db, path), orderBy('createdAt', 'asc'));
  return onSnapshot(q, (snapshot) => {
    const messages = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    callback(messages);
  }, (error) => {
    handleFirestoreError(error, OperationType.GET, path);
    onError?.();
  });
}

export async function sendMessage(messageData: {
  senderId: string;
  senderName: string;
  senderRole: string;
  recipientId: string;
  text: string;
}) {
  const path = 'messages';
  try {
    const docRef = await addDoc(collection(db, path), {
      ...messageData,
      createdAt: serverTimestamp()
    });
    return { success: true, id: docRef.id };
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
    return { success: false };
  }
}

/**
 * Automates the synchronization of all tutors inside the 'tutors' collection
 * to the virtual 'users' collection to ensure they can log in seamlessly.
 */
export async function syncAllExistingTutorsToUsers(): Promise<{ success: boolean; count: number }> {
  try {
    const qTutors = query(collection(db, 'tutors'));
    const tutorSnap = await getDocs(qTutors);
    let count = 0;
    
    for (const docObj of tutorSnap.docs) {
      const tutor = docObj.data();
      if (!tutor.email) continue;
      
      const cleanEmail = tutor.email.trim().toLowerCase();
      const virtualUid = 'virtual_' + cleanEmail.replace(/[@.]/g, '_');
      const userRef = doc(db, 'users', virtualUid);
      const userSnap = await getDoc(userRef);
      
      // Always merge/update the document to ensure tutorId is linked properly for already signed in tutors
      await setDoc(userRef, {
        uid: virtualUid,
        email: cleanEmail,
        displayName: tutor.name || tutor.displayName || cleanEmail.split('@')[0],
        fullName: tutor.name || tutor.displayName || cleanEmail.split('@')[0],
        role: 'tutor',
        tutorId: docObj.id, // Always mapped to the Firestore tutors document auto ID
        expertise: tutor.specializedSyllabus || tutor['specialized syllabus'] || tutor.expertise || 'General Instruction',
        updatedAt: serverTimestamp()
      }, { merge: true });
      count++;
      console.log(`Synced tutor ${cleanEmail} (uid: ${virtualUid}) with tutorId: ${docObj.id}`);
    }
    return { success: true, count };
  } catch (e) {
    console.warn("Could not sync tutors to users database:", e);
    return { success: false, count: 0 };
  }
}

// Tutor Applications Submissions & Subscriptions
export async function submitTutorApplication(appData: {
  fullName: string;
  email: string;
  whatsapp: string;
  experience: string;
  expertise: string;
  timezone: string;
  hourlyRate?: string;
  yearsOfExperience?: string;
  quote?: string;
  detailedBio?: string;
  videoUrl?: string;
  avatarUrl?: string;
  targetAge?: string;
  instantDemoOnboard?: boolean;
  availability?: any;
}) {
  const path = 'tutor_applications';
  try {
    const docRef = await addDoc(collection(db, path), {
      ...appData,
      status: 'pending',
      createdAt: serverTimestamp(),
    });

    // Send a beautifully styled application received email to the prospective tutor
    try {
      const subject = `Application Received: Welcome to HabKids! 🎓✨`;
      const body = `Dear ${appData.fullName},\n\nWe have successfully received your professional application to join the expert teaching roster at HabKids!\n\nHere is a copy of your submitted application summary:\n- Subject/Expertise: ${appData.expertise || 'Amharic Tutor'}\n- Experience: ${appData.yearsOfExperience || 'Experienced'}\n- Timezone: ${appData.timezone || 'Not specified'}\n- Preferred Rate: $${appData.hourlyRate || '25'}/hr\n\nOur administrative desk and language coordinators are currently reviewing your teaching portfolio, introductory video, and experience credentials. This process typically takes between 24 and 48 business hours.\n\nOnce approved, your interactive tutor profile will be published live to our selective Parent Booking Registry where parents can book paid 25-minute evaluation trial sessions with you. We will also activate your official Tutor Dashboard account details for tracking coordinates.\n\nThank you for choosing HabKids as your virtual classroom partner!\n\nBest regards,\nHabKids Team`;

      await fetch('/api/notify/email', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          to: appData.email,
          role: 'tutor',
          subject: subject,
          body: body
        })
      });
      console.log(`[APPLICATION_MAIL] Successfully dispatched received email to prospective tutor: ${appData.email}`);
    } catch (emailErr) {
      console.warn("Could not dispatch application received email to prospective tutor:", emailErr);
    }

    return { success: true, id: docRef.id };
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
    return { success: false, error: error instanceof Error ? error.message : String(error) };
  }
}

export function subscribeToTutorApplications(callback: (apps: any[]) => void, onError?: () => void) {
  const q = query(collection(db, 'tutor_applications'));
  return onSnapshot(q, (snapshot) => {
    const apps = snapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data()
    })).sort((a: any, b: any) => {
      const t1 = a.createdAt?.toDate ? a.createdAt.toDate().getTime() : 0;
      const t2 = b.createdAt?.toDate ? b.createdAt.toDate().getTime() : 0;
      return t2 - t1;
    });
    callback(apps);
  }, (error) => {
    console.error("Firestore error in subscribeToTutorApplications:", error);
    onError?.();
  });
}

export async function updateTutorApplicationStatus(appId: string, status: string, extraData?: any) {
  const path = `tutor_applications/${appId}`;
  try {
    const ref = doc(db, 'tutor_applications', appId);
    const updatePayload: any = {
      status,
      updatedAt: serverTimestamp()
    };
    if (extraData) {
      Object.assign(updatePayload, extraData);
    }
    await updateDoc(ref, updatePayload);
    return { success: true };
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
    return { success: false };
  }
}

// Support Tickets Operations
export async function submitSupportTicket(ticketData: {
  parentName: string;
  parentEmail: string;
  question: string;
  topic?: string;
}) {
  const path = 'support_tickets';
  try {
    const docRef = await addDoc(collection(db, path), {
      ...ticketData,
      status: 'open',
      replies: [],
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp()
    });
    return { success: true, id: docRef.id };
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
    return { success: false };
  }
}

export function subscribeToSupportTickets(callback: (tickets: any[]) => void, onError?: () => void) {
  const path = 'support_tickets';
  const q = query(collection(db, path), orderBy('createdAt', 'desc'));
  return onSnapshot(q, (snapshot) => {
    const tickets = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    callback(tickets);
  }, (error) => {
    handleFirestoreError(error, OperationType.LIST, path);
    onError?.();
  });
}

export function subscribeToMySupportTickets(email: string, callback: (tickets: any[]) => void, onError?: () => void) {
  const path = 'support_tickets';
  // Query without orderBy to prevent composite index errors in Firestore
  const q = query(collection(db, path), where('parentEmail', '==', email));
  return onSnapshot(q, (snapshot) => {
    const tickets = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() as any }));
    
    // Sort client-side by createdAt desc
    tickets.sort((a, b) => {
      const getMs = (timestamp: any) => {
        if (!timestamp) return 0;
        if (typeof timestamp.toDate === 'function') return timestamp.toDate().getTime();
        if (timestamp.seconds) return timestamp.seconds * 1000;
        return new Date(timestamp).getTime();
      };
      return getMs(b.createdAt) - getMs(a.createdAt);
    });

    callback(tickets);
  }, (error) => {
    handleFirestoreError(error, OperationType.LIST, path);
    onError?.();
  });
}

export async function addSupportTicketReply(ticketId: string, reply: {
  senderRole: 'admin' | 'parent';
  senderName: string;
  text: string;
}) {
  const path = `support_tickets/${ticketId}`;
  try {
    const ref = doc(db, 'support_tickets', ticketId);
    await updateDoc(ref, {
      replies: arrayUnion({
        ...reply,
        createdAt: new Date().toISOString()
      }),
      updatedAt: serverTimestamp()
    });
    return { success: true };
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
    return { success: false };
  }
}

export async function updateSupportTicketStatus(ticketId: string, status: 'open' | 'resolved') {
  const path = `support_tickets/${ticketId}`;
  try {
    const ref = doc(db, 'support_tickets', ticketId);
    await updateDoc(ref, {
      status,
      updatedAt: serverTimestamp()
    });
    return { success: true };
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
    return { success: false };
  }
}

/**
 * Creates a new notification in the database.
 * @param notification - The notification data without ID, timestamp and read status.
 */
export async function createNotification(notification: Omit<Notification, 'id' | 'createdAt' | 'isRead'>) {
  const path = 'notifications';
  try {
    const docRef = await addDoc(collection(db, path), {
      ...notification,
      createdAt: serverTimestamp(),
      isRead: false
    });

    return { success: true, id: docRef.id };
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
    return { success: false };
  }
}

/**
 * Subscribes to real-time notifications for a specific user.
 * @param userId - The UID of the user to listen for.
 * @param callback - Function to handle the results.
 */
export function subscribeToNotifications(userId: string, callback: (notifications: Notification[]) => void) {
  const path = 'notifications';
  const q = query(
    collection(db, path),
    where('userId', '==', userId),
    orderBy('createdAt', 'desc'),
    limit(50)
  );

  return onSnapshot(q, (snapshot) => {
    const notifications = snapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data()
    })) as Notification[];
    callback(notifications);
  }, (error) => {
    handleFirestoreError(error, OperationType.LIST, path);
  });
}

/**
 * Marks a single notification as read.
 */
export async function markNotificationAsRead(notificationId: string) {
  const path = `notifications/${notificationId}`;
  try {
    const ref = doc(db, 'notifications', notificationId);
    await updateDoc(ref, { isRead: true });
    return { success: true };
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
    return { success: false };
  }
}

/**
 * Marks all unread notifications for a user as read.
 */
export async function markAllNotificationsAsRead(userId: string) {
  const path = 'notifications';
  try {
    const q = query(
      collection(db, path),
      where('userId', '==', userId),
      where('isRead', '==', false)
    );
    const snapshot = await getDocs(q);
    const promises = snapshot.docs.map(d => updateDoc(doc(db, path, d.id), { isRead: true }));
    await Promise.all(promises);
    return { success: true };
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
    return { success: false };
  }
}

// --- TUTOR CHATS OPERATIONS ---


// 1. Keyword contact-blocking filter
export function runContactSharingFilter(text: string): { filteredText: string; hasViolation: boolean } {
  let hasViolation = false;
  let filteredText = text;

  // Email filter
  const emailRegex = /[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/gi;
  if (emailRegex.test(filteredText)) {
    hasViolation = true;
    filteredText = filteredText.replace(emailRegex, "[Email Redacted]");
  }

  // Phone number filter (7 to 15 digits)
  const phoneRegex = /(\+?\d[\d\s\)\(-]{6,14}\d)/g;
  if (phoneRegex.test(filteredText)) {
    hasViolation = true;
    filteredText = filteredText.replace(phoneRegex, "[Phone Redacted]");
  }

  // Common contact indicators and social/chat handles/keywords
  const blockKeywords = [
    /\bwhatsapp\b/i,
    /\btelegram\b/i,
    /\b@\w+/gi, // Telegram handle style
    /\binstagram\b/i,
    /\bphone number\b/i,
    /\bcall me\b/i,
    /\bmy email\b/i,
    /\bcontact me\b/i,
    /\bzoom\b/i,
    /\bteams\b/i,
    /\bskype\b/i,
    /\bfacebook\b/i,
    /\bwechat\b/i,
    /\bviber\b/i
  ];

  for (const regex of blockKeywords) {
    if (regex.test(filteredText)) {
      hasViolation = true;
      filteredText = filteredText.replace(regex, "[Redacted Term]");
    }
  }

  return { filteredText, hasViolation };
}

// 2. Fetch or create a deterministic Tutor Chat Thread
export async function getOrCreateTutorChat(params: {
  parentId: string;
  parentName: string;
  parentEmail: string;
  tutorId: string;
  tutorName: string;
  tutorEmail: string;
}) {
  const chatId = `${params.parentId}_${params.tutorId}`;
  const ref = doc(db, 'tutor_chats', chatId);
  
  // Deterministic tutor UID if they used virtual login
  const tutorUid = 'virtual_' + params.tutorEmail.trim().toLowerCase().replace(/[@.]/g, '_');

  try {
    const snap = await getDoc(ref);
    if (snap.exists()) {
      // Migrate old chats to include tutorUid if missing
      const data = snap.data();
      if (!data.tutorUid) {
        await updateDoc(ref, { tutorUid });
      }
      return { success: true, id: chatId, data: { ...data, tutorUid } };
    } else {
      const data = {
        id: chatId,
        parentId: params.parentId,
        parentName: params.parentName,
        parentEmail: params.parentEmail,
        tutorId: params.tutorId,
        tutorUid: tutorUid, // Store for easier notifications
        tutorName: params.tutorName,
        tutorEmail: params.tutorEmail,
        lastMessage: "No messages yet",
        lastMessageAt: serverTimestamp(),
        lastMessageSenderId: "",
        updatedAt: serverTimestamp()
      };
      await setDoc(ref, data);
      return { success: true, id: chatId, data };
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `tutor_chats/${chatId}`);
    return { success: false, error };
  }
}

// 3. Send message with auto keyword filters applied
export async function sendTutorChatMessage(params: {
  chatId: string;
  parentId: string;
  tutorId: string;
  senderId: string;
  senderName: string;
  senderRole: 'parent' | 'tutor';
  text: string;
}) {
  const { filteredText, hasViolation } = runContactSharingFilter(params.text);
  const msgData: any = {
    chatId: params.chatId,
    parentId: params.parentId,
    tutorId: params.tutorId,
    senderId: params.senderId,
    senderName: params.senderName,
    senderRole: params.senderRole,
    text: filteredText,
    createdAt: serverTimestamp()
  };

  if (hasViolation) {
    msgData.hasSharingViolation = true;
    msgData.originalText = params.text; // Admin view log
  }

  const messagesPath = `tutor_chats/${params.chatId}/messages`;
  try {
    // Add message
    const msgRef = await addDoc(collection(db, messagesPath), msgData);
    
    // Update thread meta details 
    const threadRef = doc(db, 'tutor_chats', params.chatId);
    await updateDoc(threadRef, {
      lastMessage: filteredText,
      lastMessageAt: serverTimestamp(),
      lastMessageSenderId: params.senderId,
      updatedAt: serverTimestamp()
    });

    // --- Trigger Real-time Notification ---
    try {
      const threadSnap = await getDoc(threadRef);
      if (threadSnap.exists()) {
        const threadData = threadSnap.data();
        const isParentSender = params.senderRole === 'parent';
        
        // Recipient is the other party
        const recipientUserId = isParentSender ? threadData.tutorUid : threadData.parentId;
        const recipientName = isParentSender ? threadData.tutorName : threadData.parentName;

        if (recipientUserId) {
          await createNotification({
            userId: recipientUserId,
            title: `New message from ${params.senderName}`,
            message: filteredText.length > 60 ? filteredText.substring(0, 57) + '...' : filteredText,
            type: 'message',
            link: isParentSender ? '/tutor?messages=true' : '/parent/support', // Adjust link as needed
            relatedId: params.chatId
          });
        }
      }
    } catch (notifErr) {
      console.warn("Notification trigger failed for chat message:", notifErr);
    }

    return { success: true, id: msgRef.id, hasViolation, filteredText };
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, messagesPath);
    return { success: false, error };
  }
}

// 4. Subscribe to Tutor Chat Thread list (for Parent or Tutor or Admin)
export function subscribeToTutorChats(role: 'admin' | 'tutor' | 'parent', userId: string, callback: (chats: any[]) => void, onError?: () => void) {
  const path = 'tutor_chats';
  let q = query(collection(db, path));

  if (role === 'parent') {
    q = query(collection(db, path), where('parentId', '==', userId));
  } else if (role === 'tutor') {
    q = query(collection(db, path), where('tutorId', '==', userId));
  }

  return onSnapshot(q, (snapshot) => {
    const chats = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() as any }));
    
    // Sort client-side by updatedAt desc
    chats.sort((a, b) => {
      const getMs = (timestamp: any) => {
        if (!timestamp) return 0;
        if (typeof timestamp.toDate === 'function') return timestamp.toDate().getTime();
        if (timestamp.seconds) return timestamp.seconds * 1000;
        return new Date(timestamp).getTime();
      };
      return getMs(b.updatedAt) - getMs(a.updatedAt);
    });

    callback(chats);
  }, (error) => {
    handleFirestoreError(error, OperationType.LIST, path);
    onError?.();
  });
}

// 5. Subscribe to Tutor Chat Messages
export function subscribeToTutorChatMessages(chatId: string, callback: (messages: any[]) => void, onError?: () => void) {
  const path = `tutor_chats/${chatId}/messages`;
  const q = query(collection(db, path), orderBy('createdAt', 'asc'));
  
  return onSnapshot(q, (snapshot) => {
    const messages = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    callback(messages);
  }, (error) => {
    handleFirestoreError(error, OperationType.LIST, path);
    onError?.();
  });
}

// 6. Subscribe to Email Logs for Admin Diagnostics (Completely database-decoupled via REST polling to protect Firestore read limits)
export function subscribeToEmailLogs(callback: (logs: any[]) => void, onError?: () => void) {
  let active = true;
  const poll = async () => {
    try {
      const res = await window.fetch('/api/notify/logs');
      if (!res.ok) throw new Error();
      const data = await res.json();
      if (active) {
        const logs = (data.logs || []).map((l: any) => ({
          ...l,
          timestamp: l.timestamp ? new Date(l.timestamp) : new Date()
        }));
        callback(logs);
      }
    } catch (e) {
      console.warn("Failed to fetch fresh in-memory logs, falling back to empty list:", e);
      if (active) {
        callback([]);
      }
    }
  };
  
  poll();
  const interval = setInterval(poll, 4000);
  
  return () => {
    active = false;
    clearInterval(interval);
  };
}

/**
 * Automatically generates a consistent free-tier Jitsi Meet link formatted as https://meet.jit.si/HabKidsClass-xxx-yyyy-zzz
 * based deterministically on the tutor's unique ID (primary) or email (secondary) to ensure the tutor and parent 
 * always join the exact same virtual room even if profile data loading is delayed.
 */
export function getDeterministicGoogleMeetUrl(email?: string, id?: string): string {
  // Use ID as the primary seed because it's the most stable identifier available on both dashboards.
  const seedSource = (id || email || 'anonymous').toLowerCase();
  const seed = seedSource.replace(/[^a-z0-9]/g, '');
  
  let letters = seed;
  const pad = 'abyssiniahabkidstutor';
  let padIdx = 0;
  
  while (letters.length < 12) {
    letters += pad[padIdx % pad.length];
    padIdx++;
  }
  
  const part1 = letters.slice(0, 4);
  const part2 = letters.slice(4, 8);
  const part3 = letters.slice(8, 12);
  
  return `https://meet.jit.si/HabKidsClass-${part1}-${part2}-${part3}`;
}






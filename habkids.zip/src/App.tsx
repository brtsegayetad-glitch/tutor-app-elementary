/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import LandingPage from './pages/LandingPage';
import BookingPage from './pages/BookingPage';
import LoginPage from './pages/LoginPage';
import SignupPage from './pages/SignupPage';
import BecomeTutorPage from './pages/BecomeTutorPage';
import TutorProfilePage from './pages/TutorProfilePage';
import DashboardLayout from './layouts/DashboardLayout';
import AdminDashboard from './pages/Admin/AdminDashboard';
import AdminLeads from './pages/Admin/AdminLeads';
import AdminTutors from './pages/Admin/AdminTutors';
import AdminSubscriptions from './pages/Admin/AdminSubscriptions';
import AdminConversations from './pages/Admin/AdminConversations';
import AdminReports from './pages/Admin/AdminReports';
import AdminSettings from './pages/Admin/AdminSettings';
import AdminTickets from './pages/Admin/AdminTickets';
import AdminAmbassadors from './pages/Admin/AdminAmbassadors';
import TutorDashboard from './pages/Tutor/TutorDashboard';
import TutorSettings from './pages/Tutor/TutorSettings';
import TutorCalendar from './pages/Tutor/TutorCalendar';
import TutorStudents from './pages/Tutor/TutorStudents';
import ParentDashboard from './pages/Parent/ParentDashboard';

import HabKidsApp from './habkids/App';
import ErrorBoundary from './components/ErrorBoundary';
import PWAInstallPrompt from './components/PWAInstallPrompt';

const ProtectedRoute = ({ children, allowedRoles }: { children: React.ReactNode, allowedRoles?: string[] }) => {
  const { user, loading } = useAuth();

  if (loading) return <div className="h-screen w-screen flex items-center justify-center font-sans">Loading...</div>;
  
  // Explicitly define public paths that should NEVER trigger a login redirect
  const publicPaths = ['/', '/login', '/signup', '/book', '/book-trial', '/become-tutor', '/ambassador', '/geez-hub'];
  const isPublicPath = publicPaths.includes(window.location.pathname) || window.location.pathname.startsWith('/tutors/');

  if (!user && !isPublicPath) {
    const currentPathAndSearch = window.location.pathname + window.location.search;
    return <Navigate to={`/login?redirect=${encodeURIComponent(currentPathAndSearch)}`} replace />;
  }
  
  if (allowedRoles && user && user.role) {
    if (!allowedRoles.includes(user.role)) {
      if (user.role === 'tutor') {
        return <Navigate to="/tutor" />;
      }
      if (user.role === 'parent') {
        return <Navigate to="/parent" />;
      }
      return <Navigate to="/" />;
    }
  }

  return <>{children}</>;
};

const RedirectToAmbassador = () => {
  const { user, loading } = useAuth();
  if (loading) return <div className="h-screen w-screen flex items-center justify-center font-sans">Loading...</div>;
  if (!user) {
    const search = window.location.search;
    return <Navigate to={`/signup?intent=ambassador${search ? `&${search.substring(1)}` : ''}`} replace />;
  }
  return <Navigate to="/parent/referrals" replace />;
};

export default function App() {
  React.useEffect(() => {
    document.title = "Online Amharic and Ge'ez Tutoring";
    
    // Global referral tracking - capture ref from URL anywhere in the app
    const searchParams = new URLSearchParams(window.location.search);
    const ref = searchParams.get('ref');
    if (ref) {
      localStorage.setItem('habkids_referral_code', ref);
      console.log("Global: Captured referral code:", ref);
    }
  }, []);

  return (
    <ErrorBoundary>
      <Router>
        <AuthProvider>
          <PWAInstallPrompt />
          <Routes>
            <Route path="/" element={<LandingPage />} />
            <Route path="/geez-hub" element={<HabKidsApp />} />
            <Route path="/book" element={<BookingPage />} />
            <Route path="/book-trial" element={<BookingPage />} />
            <Route path="/tutors/:tutorId" element={<TutorProfilePage />} />
            <Route path="/login" element={<LoginPage />} />
            <Route path="/signup" element={<SignupPage />} />
            <Route path="/become-tutor" element={<BecomeTutorPage />} />
            <Route path="/ambassador" element={
              <RedirectToAmbassador />
            } />
            
            <Route path="/admin/*" element={
              <ProtectedRoute allowedRoles={['admin']}>
                <DashboardLayout role="admin">
                  <Routes>
                    <Route index element={<AdminDashboard />} />
                    <Route path="leads" element={<AdminLeads />} />
                    <Route path="tutors" element={<AdminTutors />} />
                    <Route path="subscriptions" element={<AdminSubscriptions />} />
                    <Route path="conversations" element={<AdminConversations />} />
                    <Route path="reports" element={<AdminReports />} />
                    <Route path="settings" element={<AdminSettings />} />
                    <Route path="tickets" element={<AdminTickets />} />
                    <Route path="ambassadors" element={<AdminAmbassadors />} />
                  </Routes>
                </DashboardLayout>
              </ProtectedRoute>
            } />

            <Route path="/tutor/*" element={
              <ProtectedRoute allowedRoles={['tutor']}>
                <DashboardLayout role="tutor">
                  <Routes>
                    <Route index element={<TutorDashboard />} />
                    <Route path="calendar" element={<TutorCalendar />} />
                    <Route path="students" element={<TutorStudents />} />
                    <Route path="settings" element={<TutorSettings />} />
                  </Routes>
                </DashboardLayout>
              </ProtectedRoute>
            } />

            <Route path="/parent/*" element={
              <ProtectedRoute allowedRoles={['parent']}>
                <DashboardLayout role="parent">
                  <Routes>
                    <Route index element={<ParentDashboard />} />
                    <Route path="schedule" element={<ParentDashboard />} />
                    <Route path="billing" element={<ParentDashboard />} />
                    <Route path="progress" element={<ParentDashboard />} />
                    <Route path="referrals" element={<ParentDashboard />} />
                    <Route path="support" element={<ParentDashboard />} />
                    <Route path="settings" element={<ParentDashboard />} />
                  </Routes>
                </DashboardLayout>
              </ProtectedRoute>
            } />

            {/* Fallback */}
            <Route path="*" element={<Navigate to="/" />} />
          </Routes>
        </AuthProvider>
      </Router>
    </ErrorBoundary>
  );
}

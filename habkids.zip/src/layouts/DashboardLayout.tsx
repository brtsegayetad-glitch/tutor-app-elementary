import React, { useState, useEffect } from 'react';
import { 
  BarChart3, 
  Users, 
  BookOpen, 
  Calendar, 
  Settings, 
  Menu, 
  X, 
  LogOut, 
  MessageSquare, 
  CreditCard,
  Bell,
  Search,
  User as UserIcon,
  LayoutDashboard,
  Inbox,
  Gift,
  GraduationCap
} from 'lucide-react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { cn } from '../lib/utils';
import { subscribeToSettings } from '../services/dataService';
import BrandLogo from '../components/BrandLogo';
import NotificationBell from '../components/NotificationBell';
import { collection, query, where, getDocs } from 'firebase/firestore';
import { db } from '../lib/firebase';

interface DashboardLayoutProps {
  children: React.ReactNode;
  role: 'admin' | 'tutor' | 'parent';
}

const NAV_ITEMS = {
  admin: [
    { name: 'Overview', icon: LayoutDashboard, path: '/admin' },
    { name: 'Leads', icon: Users, path: '/admin/leads' },
    { name: 'Tutors', icon: BookOpen, path: '/admin/tutors' },
    { name: 'Subscriptions', icon: CreditCard, path: '/admin/subscriptions' },
    { name: 'Conversations', icon: MessageSquare, path: '/admin/conversations' },
    { name: 'Helpdesk Tickets', icon: Inbox, path: '/admin/tickets' },
    { name: 'Reports', icon: BarChart3, path: '/admin/reports' },
    { name: 'Ambassadors', icon: Gift, path: '/admin/ambassadors' },
    { name: 'Settings', icon: Settings, path: '/admin/settings' },
  ],
  tutor: [
    { name: 'Dashboard', icon: LayoutDashboard, path: '/tutor' },
    { name: 'Classroom Messages', icon: MessageSquare, path: '/tutor?messages=true' },
    { name: 'Curriculum Library', icon: BookOpen, path: '/tutor?library=true' },
    { name: 'Calendar', icon: Calendar, path: '/tutor/calendar' },
    { name: 'My Students', icon: Users, path: '/tutor/students' },
    { name: 'Settings', icon: Settings, path: '/tutor/settings' },
  ],
  parent: [
    { name: 'Dashboard', icon: LayoutDashboard, path: '/parent' },
    { name: 'Global Library', icon: BookOpen, path: '/parent?library=true' },
    { name: 'Schedule', icon: Calendar, path: '/parent/schedule' },
    { name: 'Billing', icon: CreditCard, path: '/parent/billing' },
    { name: 'Progress', icon: BarChart3, path: '/parent/progress' },
    { name: 'Referral & Ambassador', icon: Gift, path: '/parent/referrals' },
    { name: 'Apply as Tutor', icon: GraduationCap, path: '/become-tutor' },
    { name: 'Help & Support', icon: Inbox, path: '/parent/support' },
    { name: 'Settings', icon: Settings, path: '/parent/settings' },
  ],
};

export default function DashboardLayout({ children, role }: DashboardLayoutProps) {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const { user, signOut } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();

  const [brandSettings, setBrandSettings] = useState<any>(() => {
    try {
      const cached = localStorage.getItem('habkids_cached_settings');
      if (cached) {
        const data = JSON.parse(cached);
        if (data) {
          return {
            activeLogoUrl: data.activeLogoUrl || '',
            academyName: data.academyName || 'HabKids'
          };
        }
      }
    } catch (e) {
      console.warn("Could not parse cached settings in DashboardLayout:", e);
    }
    return { activeLogoUrl: '', academyName: 'HabKids' };
  });

  useEffect(() => {
    const unsubscribe = subscribeToSettings((data) => {
      if (data) {
        setBrandSettings({
          activeLogoUrl: data.activeLogoUrl || '',
          academyName: data.academyName || 'HabKids'
        });
      }
    });
    return () => unsubscribe();
  }, []);

  // Load items based on authentication state's verified role directly from context
  const effectiveRole = user?.role || role;
  const [hasChildren, setHasChildren] = useState<boolean | null>(null);

  useEffect(() => {
    if (effectiveRole === 'parent' && user?.uid) {
      const parentId = user.uid;
      const studentQuery = query(collection(db, 'students'), where('parentId', '==', parentId));
      
      getDocs(studentQuery)
        .then((snap) => {
          if (!snap.empty) {
            setHasChildren(true);
          } else {
            if (user.email) {
              const emailLower = user.email.toLowerCase().trim();
              const leadQueryByEmail = query(collection(db, 'leads'), where('email', '==', emailLower));
              const leadQueryByParentId = query(collection(db, 'leads'), where('parentId', '==', parentId));
              
              Promise.all([
                getDocs(leadQueryByEmail),
                getDocs(leadQueryByParentId)
              ])
                .then(([emailSnap, parentSnap]) => {
                  const allLeadDocs = [...emailSnap.docs, ...parentSnap.docs];
                  // Deduplicate by doc ID
                  const uniqueLeadsMap = new Map();
                  allLeadDocs.forEach(d => uniqueLeadsMap.set(d.id, d));
                  const activeLeads = Array.from(uniqueLeadsMap.values()).filter(d => d.data().status !== 'converted');
                  setHasChildren(activeLeads.length > 0);
                })
                .catch(() => {
                  setHasChildren(false);
                });
            } else {
              setHasChildren(false);
            }
          }
        })
        .catch(() => {
          setHasChildren(false);
        });
    } else {
      setHasChildren(null);
    }
  }, [effectiveRole, user?.uid, user?.email]);

  let items = NAV_ITEMS[effectiveRole === 'tutor' ? 'tutor' : effectiveRole === 'parent' ? 'parent' : 'admin'];

  if (effectiveRole === 'parent' && (user?.isAmbassador || hasChildren === false)) {
    items = [
      { name: 'Dashboard', icon: LayoutDashboard, path: '/parent' },
      { name: 'Global Library', icon: BookOpen, path: '/parent?library=true' },
      { name: 'Referral & Ambassador', icon: Gift, path: '/parent/referrals' },
      { name: 'Apply as Tutor', icon: GraduationCap, path: '/become-tutor' },
      { name: 'Settings', icon: Settings, path: '/parent/settings' },
    ];
  }

  const handleSignOut = async () => {
    await signOut();
    navigate('/');
  };

  const showSandbox = false;


  return (
    <div className="min-h-screen bg-slate-50 flex font-sans">
      {/* Desktop Sidebar */}
      <aside className="hidden lg:flex w-64 flex-col bg-slate-900 text-white sticky top-0 h-screen">
        <div className="p-5 border-b border-slate-800">
          <Link to="/" className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg flex items-center justify-center shrink-0">
              <BrandLogo 
                logoUrl={brandSettings.activeLogoUrl || '/logo_option_one.png'} 
                className="w-full h-full"
              />
            </div>
            <span className="text-lg font-bold tracking-tight text-slate-100 truncate">
              {brandSettings.academyName}
            </span>
          </Link>
        </div>

        <nav className="flex-1 px-3 space-y-1 mt-6">
          {items.map((item) => {
            const isActive = item.path.includes('?')
              ? (location.pathname + location.search === item.path)
              : (location.pathname === item.path && !location.search.includes('library=true'));
            return (
              <Link
                key={item.name}
                to={item.path}
                className={cn(
                  "flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium transition-all group",
                  isActive 
                    ? "bg-slate-800 text-slate-100" 
                    : "text-slate-400 hover:bg-slate-800 hover:text-slate-100"
                )}
              >
                <item.icon size={18} className={cn("transition-colors", isActive ? "text-secondary" : "group-hover:text-slate-100")} />
                {item.name}
              {item.name === 'Leads' && (
                <span className="ml-auto bg-secondary text-white text-[10px] px-1.5 py-0.5 rounded-full">4</span>
              )}
            </Link>
            );
          })}
        </nav>

        <div className="flex-1 mt-auto"></div>

        <div className="p-6 border-t border-slate-800">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 rounded-full bg-slate-700 flex items-center justify-center text-xs font-bold ring-2 ring-slate-800">
              {(user?.fullName || 'User').split(' ').filter(Boolean).map(n => n[0]).join('') || 'U'}
            </div>
            <div>
              <p className="text-sm font-semibold truncate max-w-[120px]">{user?.fullName || 'User'}</p>
              <p className="text-xs text-slate-400 capitalize">{effectiveRole} Portal</p>
            </div>
          </div>
          <button 
            onClick={handleSignOut}
            className="flex items-center gap-3 px-3 py-2 w-full text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-all text-sm font-medium"
          >
            <LogOut size={18} />
            Sign Out
          </button>
        </div>
      </aside>

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Header */}
        <header className="h-16 bg-white border-b border-slate-200 flex items-center justify-between px-8 sticky top-0 z-40">
          <div className="flex items-center gap-4">
            <button 
              className="lg:hidden p-2 text-slate-600" 
              onClick={() => setIsSidebarOpen(true)}
            >
              <Menu size={20} />
            </button>
            <div className="hidden md:flex items-center bg-slate-50 border border-slate-200 rounded-lg px-3 py-1.5 w-64 transition-focus-within focus-within:ring-2 focus-within:ring-primary/5 focus-within:border-primary">
              <Search size={16} className="text-slate-400 mr-2" />
              <input type="text" placeholder="Search..." className="bg-transparent border-none focus:outline-none text-xs w-full text-slate-600" />
            </div>
          </div>

          <div className="flex items-center gap-4 relative">
            <NotificationBell />

            <div className="h-6 w-px bg-slate-200 mx-2"></div>
            <div className="flex items-center gap-3">
              <div className="text-right hidden sm:block mr-1">
                <p className="text-xs font-bold text-slate-900 leading-tight">
                  {effectiveRole === 'admin' ? 'Admin Operations' : effectiveRole === 'tutor' ? 'Tutor Portal' : (user?.isAmbassador ? 'Ambassador Portal' : 'Parent Portal')}
                </p>
                <p className="text-[10px] text-slate-400 uppercase tracking-wider font-bold font-sans">Priority Support</p>
              </div>
            </div>
          </div>
        </header>

        {/* Dynamic Dashboard Page */}
        <main className="flex-1 p-8 overflow-auto">
          {children}
        </main>
      </div>

      {/* Mobile Sidebar Overlay */}
      {isSidebarOpen && (
        <>
          <div 
            onClick={() => setIsSidebarOpen(false)}
            className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm z-50 lg:hidden"
          />
          <aside 
            className="fixed top-0 left-0 bottom-0 w-72 bg-slate-900 text-white z-[60] flex flex-col lg:hidden"
          >
            <div className="p-5 flex items-center justify-between border-b border-slate-800">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg flex items-center justify-center shrink-0">
                  <BrandLogo 
                    logoUrl={brandSettings.activeLogoUrl || '/logo_option_one.png'} 
                    className="w-full h-full"
                  />
                </div>
                <span className="text-lg font-bold tracking-tight text-slate-100 truncate">
                  {brandSettings.academyName}
                </span>
              </div>
              <button onClick={() => setIsSidebarOpen(false)} className="p-2 text-slate-400 hover:text-white">
                <X size={20} />
              </button>
            </div>
            
            <nav className="flex-1 p-4 space-y-1">
              {items.map((item) => (
                <Link
                  key={item.name}
                  to={item.path}
                  onClick={() => setIsSidebarOpen(false)}
                  className={cn(
                    "flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium transition-all",
                    location.pathname === item.path 
                      ? "bg-slate-800 text-slate-100" 
                      : "text-slate-400 hover:bg-slate-800 hover:text-slate-100"
                  )}
                >
                  <item.icon size={18} className={location.pathname === item.path ? "text-secondary" : ""} />
                  {item.name}
                </Link>
              ))}
            </nav>



            <div className="p-6 border-t border-slate-800">
              <button 
                onClick={handleSignOut}
                className="flex items-center gap-3 px-3 py-2 w-full text-slate-400 hover:text-white hover:bg-slate-800 rounded-lg transition-all text-sm font-medium"
              >
                <LogOut size={18} />
                Sign Out
              </button>
            </div>
          </aside>
        </>
      )}
    </div>
  );
}

# Agent Instructions & Project Guidelines

You are the primary AI Coding Agent for **HabKids**, a production-ready web application teaching Amharic to diaspora children.

## 🚀 Absolute Constraints
1. **VETO THE MONOLITH**: NEVER consolidate logic into single giant files. 
   - Extract sub-components to `src/components/`.
   - Extract shared types to `src/types.ts` or local type files.
   - Extract business logic to `src/services/` (primarily `dataService.ts`).
2. **AUTOMATIC DOCSTRINGS**: Every new file and major function MUST have a clear JSDoc-style comment block explaining:
   - Purpose of the module/function.
   - Input parameters and expected types.
   - Return values and side effects.
3. **PRESERVE EXISTING LOGIC**: Do not refactor or overwrite existing architecture without explicit user instruction. Always verify that new features integrate seamlessly with current implementations.

## 🏗️ Architecture Overview
- **Frontend**: React 18 + Vite + Tailwind CSS + Framer Motion.
- **Backend**: Express.js (Entry point: `server.ts`).
- **Database/Auth**: Firebase Firestore & Firebase Auth.
- **Service Layer**: `src/services/dataService.ts` is the source of truth for database operations.
- **Email System**: Backend-driven via Nodemailer/Resend/Brevo.

## 🛠️ Development Rules
- **Database**: Use the Firestore REST helper in `server.ts` for backend tasks to avoid WebSocket overhead.
- **State Management**: Use React Context (`src/context/`) for global state like Auth.
- **Styling**: Strictly Tailwind CSS. No custom CSS files.
- **Icons**: Use `lucide-react` only.
- **Animations**: Use `motion/react` for all layout transitions and interactions.
- **Port**: The application MUST run on port 3000.

## 📄 File Organization
- `/src/components/`: Reusable UI elements.
- `/src/pages/`: Main view components (Admin, Tutor, Parent directories).
- `/src/services/`: Business logic and API clients.
- `/src/layouts/`: Shared layout wrappers.
- `/src/habkids/`: Core curriculum and game engine logic.

---

*Last Updated: 2026-07-24*

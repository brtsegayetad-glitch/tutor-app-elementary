import express from 'express';
import path from 'path';
import { GoogleGenAI, Type } from "@google/genai";
import dotenv from 'dotenv';
import nodemailer from 'nodemailer';
import cron from 'node-cron';
import fs from 'fs';

dotenv.config();

const SMTP_USER_DEFAULT = "brtsegayetad@gmail.com";
const SMTP_PASS_DEFAULT = "vpno xhjk obge xtdf";

// In-memory email logs to completely protect the Firestore writes quota of the Spark free tier
const email_logs_in_memory: any[] = [];

function getSmtpCredentials() {
  let envUser = process.env.SMTP_USER;
  if (!envUser || envUser === 'undefined' || envUser === 'null') {
    envUser = '';
  }
  let envPass = process.env.SMTP_PASS;
  if (!envPass || envPass === 'undefined' || envPass === 'null') {
    envPass = '';
  }

  const user = (envUser || SMTP_USER_DEFAULT).trim();
  let pass = (envPass || SMTP_PASS_DEFAULT).trim();
  
  if (pass) {
    pass = pass.replace(/\s+/g, '');
  }
  const host = (process.env.SMTP_HOST || 'smtp.gmail.com').trim();
  const port = parseInt(process.env.SMTP_PORT || '587');
  const secure = process.env.SMTP_SECURE === 'true' || port === 465;
  const provider = (process.env.EMAIL_PROVIDER || 'smtp').trim().toLowerCase();
  return { user, pass, host, port, secure, provider };
}

function getTransporter(credentials?: { user: string; pass: string; host: string; port: number; secure: boolean; provider?: string }) {
  const { user, pass, host, port, secure } = credentials || getSmtpCredentials();

  if (!user || !pass) {
    console.warn("SMTP_USER or SMTP_PASS not set. Emails will be simulated.");
    return null;
  }

  console.log(`[SMTP SETUP] Configured - Host: ${host} | Port: ${port} | Secure: ${secure} | User: ${user}`);

  let activeTransporter;
  if (host === 'smtp.gmail.com') {
    activeTransporter = nodemailer.createTransport({
      service: 'gmail',
      auth: {
        user: user,
        pass: pass
      },
      connectionTimeout: 4000,
      greetingTimeout: 4000,
      socketTimeout: 4000
    });
  } else {
    activeTransporter = nodemailer.createTransport({
      host: host,
      port: port,
      secure: secure,
      auth: {
        user: user,
        pass: pass
      },
      tls: {
        rejectUnauthorized: false
      },
      connectionTimeout: 4000,
      greetingTimeout: 4000,
      socketTimeout: 4000
    });
  }
  return activeTransporter;
}

// Stateless, ultra-optimized Firestore REST helper that prevents WebSocket hangs & FUNCTION_INVOCATION_FAILED in Vercel/serverless environments.
const PROD_FIREBASE_CONFIG = {
  apiKey: "AIzaSyCcKmVR15JnaFqDesBzTG-25JNCuBMEHBY",
  authDomain: "habkids-prod.firebaseapp.com",
  projectId: "habkids-prod",
  storageBucket: "habkids-prod.firebasestorage.app",
  messagingSenderId: "1000767625497",
  appId: "1:1000767625497:web:b9357bd2bb107bffc34d88",
  measurementId: "G-3MF9XESHFL"
};

const DEV_FIREBASE_CONFIG = {
  apiKey: "AIzaSyAGeBgCZ_2UnaGIcMbS0_0YdC1YWtgD7Xs",
  authDomain: "influential-energy-b8gvj.firebaseapp.com",
  projectId: "influential-energy-b8gvj",
  storageBucket: "influential-energy-b8gvj.firebasestorage.app",
  messagingSenderId: "803875179116",
  appId: "1:803875179116:web:145cf6f11ad75bd0c02649",
  databaseId: "ai-studio-2d2d3598-6e2b-4108-8600-02eab14adb35"
};

function mapRestFields(fields: any): any {
  const result: any = {};
  if (!fields) return result;
  for (const key of Object.keys(fields)) {
    const valObj = fields[key];
    if (!valObj) continue;
    if (valObj.stringValue !== undefined) result[key] = valObj.stringValue;
    else if (valObj.integerValue !== undefined) result[key] = parseInt(valObj.integerValue);
    else if (valObj.doubleValue !== undefined) result[key] = parseFloat(valObj.doubleValue);
    else if (valObj.booleanValue !== undefined) result[key] = !!valObj.booleanValue;
    else if (valObj.timestampValue !== undefined) result[key] = valObj.timestampValue;
    else if (valObj.mapValue !== undefined) result[key] = mapRestFields(valObj.mapValue.fields);
    else if (valObj.arrayValue !== undefined) {
      result[key] = (valObj.arrayValue.values || []).map((v: any) => {
        if (!v) return null;
        if (v.stringValue !== undefined) return v.stringValue;
        if (v.integerValue !== undefined) return parseInt(v.integerValue);
        if (v.doubleValue !== undefined) return parseFloat(v.doubleValue);
        if (v.booleanValue !== undefined) return !!v.booleanValue;
        if (v.timestampValue !== undefined) return v.timestampValue;
        if (v.mapValue !== undefined) return mapRestFields(v.mapValue.fields);
        return v;
      });
    }
  }
  return result;
}

function mapToRestFields(obj: any): any {
  const fields: any = {};
  if (!obj) return fields;
  for (const key of Object.keys(obj)) {
    const val = obj[key];
    if (val === null || val === undefined) continue;
    if (typeof val === 'string') {
      fields[key] = { stringValue: val };
    } else if (typeof val === 'number') {
      if (Number.isInteger(val)) {
        fields[key] = { integerValue: String(val) };
      } else {
        fields[key] = { doubleValue: val };
      }
    } else if (typeof val === 'boolean') {
      fields[key] = { booleanValue: val };
    } else if (val instanceof Date) {
      fields[key] = { timestampValue: val.toISOString() };
    } else if (Array.isArray(val)) {
      fields[key] = {
        arrayValue: {
          values: val.map(v => {
            if (typeof v === 'string') return { stringValue: v };
            if (typeof v === 'number') return Number.isInteger(v) ? { integerValue: String(v) } : { doubleValue: v };
            if (typeof v === 'boolean') return { booleanValue: v };
            if (v instanceof Date) return { timestampValue: v.toISOString() };
            if (typeof v === 'object') return { mapValue: { fields: mapToRestFields(v) } };
            return { stringValue: String(v) };
          })
        }
      };
    } else if (typeof val === 'object') {
      fields[key] = { mapValue: { fields: mapToRestFields(val) } };
    }
  }
  return fields;
}

async function firestoreRest(method: 'GET' | 'POST' | 'PATCH' | 'DELETE', path: string, bodyObj?: any, req?: express.Request) {
  let useDev = false;
  if (req) {
    const host = (req.get('host') || req.headers.host || '').toLowerCase();
    if (host.includes('europe-west2.run.app') || host.includes('localhost') || host.includes('127.0.0.1')) {
      useDev = true;
    }
  } else {
    const isVercel = !!process.env.VERCEL;
    const envVal = process.env.NODE_ENV;
    const hasAppletConf = fs.existsSync(`${process.cwd()}/firebase-applet-config.json`);
    if (!isVercel && (hasAppletConf || envVal !== 'production')) {
      useDev = true;
    }
  }

  const config = useDev ? DEV_FIREBASE_CONFIG : PROD_FIREBASE_CONFIG;
  const dbId = useDev ? (config.databaseId || '(default)') : '(default)';
  const apiKey = config.apiKey;
  const projectId = config.projectId;

  let url = `https://firestore.googleapis.com/v1/projects/${projectId}/databases/${dbId}/documents/${path}`;
  if (url.includes('?')) {
    url += `&key=${apiKey}`;
  } else {
    url += `?key=${apiKey}`;
  }

  const headers: Record<string, string> = {
    'Content-Type': 'application/json'
  };

  const init: any = {
    method,
    headers
  };

  if (bodyObj !== undefined) {
    init.body = JSON.stringify(bodyObj);
  }

  const res = await fetch(url, init);
  if (!res.ok) {
    if (method === 'GET' && res.status === 404) {
      return null;
    }
    const errText = await res.text();
    console.warn(`[Firestore REST Warning] ${method} on ${path} returned status ${res.status}:`, errText);
    throw new Error(`Firestore REST error ${res.status}: ${errText}`);
  }
  return res.json();
}

async function getDynamicSmtpCredentials(req?: express.Request) {
  const defaults = getSmtpCredentials();
  try {
    // 1. Check if the request body contain explicit client-supplied SMTP overrides (client localStorage injection)
    if (req && req.body && req.body.smtpConfig) {
      const cfg = req.body.smtpConfig;
      if (cfg.user || cfg.pass) {
        let passClean = String(cfg.pass || '').trim();
        if (passClean) {
          passClean = passClean.replace(/\s+/g, '');
        }
        return {
          user: String(cfg.user || '').trim(),
          pass: passClean,
          host: String(cfg.host || defaults.host).trim(),
          port: parseInt(String(cfg.port || defaults.port)) || 587,
          secure: cfg.secure !== undefined ? !!cfg.secure : (parseInt(String(cfg.port || defaults.port)) === 465),
          provider: String(cfg.provider || defaults.provider || 'smtp').trim().toLowerCase()
        };
      }
    }

    // 2. Load from Firestore dynamically using our robust REST helper as backup (crucial for background cron jobs!)
    const docSnapRaw = await firestoreRest('GET', 'settings/smtp', undefined, req);
    if (docSnapRaw && docSnapRaw.fields) {
      const data = mapRestFields(docSnapRaw.fields);
      if (data.user || data.pass) {
        let passClean = String(data.pass || '').trim();
        if (passClean) {
          passClean = passClean.replace(/\s+/g, '');
        }
        return {
          user: String(data.user || '').trim(),
          pass: passClean,
          host: String(data.host || defaults.host).trim(),
          port: parseInt(String(data.port || defaults.port)) || 587,
          secure: data.secure !== undefined ? !!data.secure : (parseInt(String(data.port || defaults.port)) === 465),
          provider: String(data.provider || defaults.provider || 'smtp').trim().toLowerCase()
        };
      }
    }
  } catch (err) {
    console.warn("[SMTP Dynamic Config] Error reading dynamic / Firestore SMTP overrides:", err);
  }
  return defaults;
}

async function logEmailToDb(to: string, subject: string, body: string, role: string | undefined, status: 'SMTP_SENT' | 'SIMULATED' | 'FAILED', errorMsg?: string, req?: express.Request) {
  try {
    const logItem = {
      id: `log_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
      to: to || 'unknown',
      subject: subject || 'No Subject',
      body: body || '',
      role: role || 'user',
      status: status,
      errorMessage: errorMsg || null,
      timestamp: new Date().toISOString()
    };
    
    // Unshift to the front of the in-memory log list (limited to 50 entries)
    email_logs_in_memory.unshift(logItem);
    if (email_logs_in_memory.length > 50) {
      email_logs_in_memory.pop();
    }
    
    console.log(`[EMAIL LOG_MEM] Logged: ${status} to ${to}`);
  } catch (err) {
    console.warn(`[EMAIL LOG_MEM] Failed to log email in memory:`, err);
  }
}


async function sendFormattedEmail(to: string, subject: string, body: string, role?: string, req?: express.Request) {
  console.log(`[EMAIL DISPATCH] to: ${to} | Subject: ${subject}`);
  const credentials = await getDynamicSmtpCredentials(req);
  
  const isEnrollment = subject.toLowerCase().includes('enrollment') || subject.toLowerCase().includes('subscription');

  // Normalize and clean up existing sign-offs from body to avoid duplication in the HTML layout
  let cleanBody = body;
  const signOffPatterns = [
    /best\s+regards,?/gi,
    /warm\s+regards,?/gi,
    /the\s+lingukid\s+academic\s+team/gi,
    /abyssinia\s+tutors/gi,
    /heritage\s+academy\s+board/gi,
    /heritage\s+academy\s+onboarding\s+board/gi,
    /heritage\s+academy\s+coordinators\s+board/gi,
    /heritage\s+academy\s+board\s+&\s+language\s+coordinators/gi,
    /the\s+linguKid\s+academic\s+team/gi,
    /heritage\s+academy\s+academic\s+team/gi
  ];
  
  let lines = cleanBody.split('\n');
  lines = lines.filter(line => {
    const trimmed = line.trim();
    if (!trimmed) return true;
    return !signOffPatterns.some(pattern => pattern.test(trimmed));
  });
  
  // Remove trailing empty lines
  while (lines.length > 0 && !lines[lines.length - 1].trim()) {
    lines.pop();
  }
  cleanBody = lines.join('\n').trim();
  
  // Beautiful professional template
  const html = `
    <div style="font-family: 'Inter', 'Helvetica Neue', Helvetica, Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 40px; background-color: #ffffff; border: 1px solid #f1f5f9; border-radius: 24px; color: #1e293b; box-shadow: 0 4px 6px -1px rgb(0 0 0 / 0.1);">
      <div style="text-align: center; margin-bottom: 32px;">
        <h1 style="color: #0f172a; margin: 0; font-size: 28px; font-weight: 800; letter-spacing: -0.025em; text-transform: uppercase;">HabKids</h1>
        <div style="height: 4px; width: 48px; background: linear-gradient(to right, #ea580c, #f97316); margin: 16px auto; border-radius: 2px;"></div>
      </div>
      
      <div style="font-size: 16px; line-height: 1.7; color: #475569;">
        ${cleanBody.split('\n').map(line => {
          const trimmed = line.trim();
          if (!trimmed) return '';
          if (trimmed.includes(':') && !trimmed.startsWith('http')) {
            const [label, ...val] = trimmed.split(':');
            return `<p style="margin-bottom: 12px;"><strong style="color: #0f172a; display: inline-block; width: 120px;">${label}:</strong> <span style="background: #f8fafc; padding: 2px 8px; border-radius: 4px; font-weight: 500; color: #334155;">${val.join(':').trim()}</span></p>`;
          }
          return `<p style="margin-bottom: 16px;">${trimmed}</p>`;
        }).join('')}
      </div>

      <div style="margin-top: 32px; font-size: 15px; line-height: 1.5; color: #334155; border-top: 1px dashed #f1f5f9; padding-top: 20px;">
        <p style="margin: 0 0 4px 0; color: #64748b; font-size: 13px;">Warm regards,</p>
        ${role === 'parent' ? `
          <strong style="color: #0f172a; font-size: 15px;">HabKids Academic Team</strong>
        ` : role === 'tutor' ? `
          <strong style="color: #0f172a; font-size: 15px;">HabKids Coordinators Board</strong>
        ` : `
          <strong style="color: #0f172a; font-size: 15px;">HabKids Team</strong>
        `}
      </div>

      ${isEnrollment ? `
        <div style="margin-top: 32px; padding: 24px; background: #f0fdf4; border: 1px solid #dcfce7; border-radius: 16px; text-align: center;">
          <h4 style="margin: 0 0 8px 0; color: #166534; font-size: 14px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.05em;">Status: Active Enrollment</h4>
          <p style="margin: 0; font-size: 13px; color: #15803d;">Your student's curriculum and materials are being prepared.</p>
        </div>
      ` : ''}

      <div style="margin-top: 48px; padding-top: 24px; border-top: 1px solid #f1f5f9; text-align: center;">
        <p style="font-size: 11px; color: #94a3b8; font-weight: 600; text-transform: uppercase; letter-spacing: 0.1em; margin-bottom: 12px;">HabKids Language Academy</p>
        <div style="display: flex; justify-content: center; gap: 16px; margin-bottom: 16px;">
          <a href="${process.env.APP_URL || '#'}" style="color: #64748b; text-decoration: none; font-size: 12px; font-weight: 500;">Parent Portal</a>
          <span style="color: #cbd5e1;">&bull;</span>
          <a href="${process.env.APP_URL || '#'}/support" style="color: #64748b; text-decoration: none; font-size: 12px; font-weight: 500;">Support Center</a>
        </div>
        <p style="font-size: 10px; color: #cbd5e1; margin: 0;">&copy; ${new Date().getFullYear()} HabKids. All rights reserved.</p>
      </div>
    </div>
  `;

  const provRaw = credentials.provider || 'smtp';
  const passVal = credentials.pass || '';
  const userVal = credentials.user || '';

  // Smart detect provider if configured as standard but contains explicit API keys
  let activeProvider = provRaw;
  if (activeProvider === 'smtp') {
    if (passVal.startsWith('re_')) {
      activeProvider = 'resend';
    } else if (passVal.includes('xkeysib') || passVal.length === 32) {
      activeProvider = 'brevo';
    }
  }

  // Fallback simulation if passive/empty credentials
  if (!passVal) {
    console.log(`[SIMULATION]: Sent scheduled email to ${to} | Subject: ${subject}\nBody: ${body}\n`);
    logEmailToDb(to, subject, body, role, 'SIMULATED', undefined, req).catch(e => console.error("Async logEmailToDb error:", e));
    return { success: true, simulated: true };
  }

  if (activeProvider === 'resend') {
    console.log(`[EMAIL DISPATCH] Bypassing raw SMTP sockets. Routing through secure Resend Web REST API in production.`);
    try {
      const fromEmail = userVal.includes('@') ? userVal : 'onboarding@resend.dev';
      const senderString = fromEmail === 'onboarding@resend.dev' ? `onboarding@resend.dev` : fromEmail;
      
      const payload = {
        from: `HabKids <${senderString}>`,
        to: [to],
        subject: subject,
        html: html
      };

      const res = await fetch('https://api.resend.com/emails', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${passVal}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(payload)
      });

      if (!res.ok) {
        const text = await res.text();
        throw new Error(`Resend HTTPS ${res.status}: ${text}`);
      }

      await res.json();
      console.log(`[EMAIL DISPATCH] Resend HTTPS delivery successful to ${to}`);
      logEmailToDb(to, subject, body, role, 'SMTP_SENT', undefined, req).catch(e => console.error("Async logEmailToDb error:", e));
      return { success: true, simulated: false };
    } catch (err: any) {
      console.error(`Resend HTTPS dispatch failed:`, err);
      logEmailToDb(to, subject, body, role, 'FAILED', `[Resend API Error]: ${err.message || String(err)}`, req).catch(e => console.error("Async logEmailToDb error:", e));
      return { success: false, simulated: true, error: err.message || String(err) };
    }
  }

  if (activeProvider === 'brevo') {
    console.log(`[EMAIL DISPATCH] Bypassing raw SMTP sockets. Routing through secure Brevo Web REST API in production.`);
    try {
      const fromEmail = userVal.includes('@') ? userVal : 'brtsegayetad@gmail.com';
      const payload = {
        sender: { name: "HabKids", email: fromEmail },
        to: [{ email: to }],
        subject: subject,
        htmlContent: html
      };

      const res = await fetch('https://api.brevo.com/v3/smtp/email', {
        method: 'POST',
        headers: {
          'api-key': passVal,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(payload)
      });

      if (!res.ok) {
        const text = await res.text();
        throw new Error(`Brevo HTTPS ${res.status}: ${text}`);
      }

      await res.json();
      console.log(`[EMAIL DISPATCH] Brevo HTTPS delivery successful to ${to}`);
      logEmailToDb(to, subject, body, role, 'SMTP_SENT', undefined, req).catch(e => console.error("Async logEmailToDb error:", e));
      return { success: true, simulated: false };
    } catch (err: any) {
      console.error(`Brevo HTTPS dispatch failed:`, err);
      logEmailToDb(to, subject, body, role, 'FAILED', `[Brevo API Error]: ${err.message || String(err)}`, req).catch(e => console.error("Async logEmailToDb error:", e));
      return { success: false, simulated: true, error: err.message || String(err) };
    }
  }

  // Default standard SMTP transport mechanism
  const mailTransporter = getTransporter(credentials);
  if (mailTransporter) {
    try {
      await mailTransporter.sendMail({
        from: `"HabKids" <${credentials.user}>`,
        to: to,
        subject: subject,
        html: html
      });
      logEmailToDb(to, subject, body, role, 'SMTP_SENT', undefined, req).catch(e => console.error("Async logEmailToDb error:", e));
      return { success: true, simulated: false };
    } catch (err: any) {
      console.error(`SMTP Send Error to ${to}:`, err);
      logEmailToDb(to, subject, body, role, 'FAILED', String(err.message || err), req).catch(e => console.error("Async logEmailToDb error:", e));
      // Intercept and return fallback response so SMTP issues are non-blocking to the application's core logic
      return { success: false, simulated: true, error: err.message || String(err) };
    }
  } else {
    console.log(`[SIMULATION]: Sent scheduled email to ${to} | Subject: ${subject}\nBody: ${body}\n`);
    logEmailToDb(to, subject, body, role, 'SIMULATED', undefined, req).catch(e => console.error("Async logEmailToDb error:", e));
    return { success: true, simulated: true };
  }
}

async function checkAndDispatchReminders() {
  console.log("[CRON] Checking for sessions starting within 24 hours...");

  try {
    const now = new Date();
    const queryResult = await firestoreRest('POST', ':runQuery', {
      structuredQuery: {
        from: [{ collectionId: 'sessions' }],
        where: {
          fieldFilter: {
            field: { fieldPath: 'status' },
            op: 'EQUAL',
            value: { stringValue: 'scheduled' }
          }
        }
      }
    });

    const docs = Array.isArray(queryResult) ? queryResult.filter((item: any) => item.document) : [];
    let sentCount = 0;

    for (const item of docs) {
      const session = mapRestFields(item.document.fields);
      const sId = item.document.name.split('/').pop();

      // Skip if reminder was already sent
      if (session.reminderSent) {
        continue;
      }

      let startDate: Date;
      if (session.startTime && (session.startTime.seconds || session.startTime._seconds)) {
        const seconds = session.startTime.seconds || session.startTime._seconds;
        const nanoseconds = session.startTime.nanoseconds || session.startTime._nanoseconds || 0;
        startDate = new Date(seconds * 1000 + nanoseconds / 1000000);
      } else if (session.startTime && typeof session.startTime === 'string' && session.startTime.endsWith('Z')) {
        startDate = new Date(session.startTime);
      } else if (session.startTime) {
        startDate = new Date(session.startTime);
      } else {
        continue;
      }

      const diffMs = startDate.getTime() - now.getTime();
      const isWithin24Hours = diffMs > 0 && diffMs <= 24 * 60 * 60 * 1000;

      if (isWithin24Hours) {
        console.log(`[CRON] Found active session ${sId} starting in ${Math.round(diffMs / (60 * 1000))} minutes. Resolving emails...`);

        // Resolve tutor email
        let tutorEmail = session.tutorEmail || null;
        if (!tutorEmail && session.tutorId) {
          try {
            const tDoc = await firestoreRest('GET', `tutors/${session.tutorId}`);
            if (tDoc && tDoc.fields) {
              const tData = mapRestFields(tDoc.fields);
              tutorEmail = tData.email || null;
            }
          } catch (e) {
            console.error(`Error resolving tutor email from tutors:`, e);
          }
          if (!tutorEmail) {
            try {
              const uDoc = await firestoreRest('GET', `users/${session.tutorId}`);
              if (uDoc && uDoc.fields) {
                const uData = mapRestFields(uDoc.fields);
                tutorEmail = uData.email || null;
              }
            } catch (e) {
              console.error(`Error resolving tutor email from users:`, e);
            }
          }
        }

        // Resolve parent email
        let parentEmail = session.parentEmail || null;
        if (!parentEmail && session.parentId) {
          try {
            const pDoc = await firestoreRest('GET', `users/${session.parentId}`);
            if (pDoc && pDoc.fields) {
              const pData = mapRestFields(pDoc.fields);
              parentEmail = pData.email || null;
            }
          } catch (e) {
            console.error(`Error resolving parent email:`, e);
          }
        }

        const formattedTime = startDate.toLocaleString('en-US', {
          weekday: 'long',
          year: 'numeric',
          month: 'long',
          day: 'numeric',
          hour: '2-digit',
          minute: '2-digit',
          timeZoneName: 'short'
        });

        const tutorName = session.tutorName || "HabKids Tutor";
        const studentName = session.studentName || "your child";

        // Dispatch to Tutor
        if (tutorEmail) {
          try {
            await sendFormattedEmail(
              tutorEmail,
              `Session Reminder: ${studentName}`,
              `Dear ${tutorName},\n\nThis is a friendly reminder that you have an upcoming HabKids Session scheduled.\n\nStudent: ${studentName}\nType: ${session.type || 'regular'} session\nScheduled Time: ${formattedTime}\n\nPlease join the meeting via your Tutor Dashboard 5 minutes before your class.`
            );
          } catch (err) {
            console.error(`[CRON] Failed to send reminder to tutor (${tutorEmail}):`, err);
          }
        } else {
          console.log(`[CRON] Tutor email not found for tutorId ${session.tutorId}`);
        }

        // Dispatch to Parent
        if (parentEmail) {
          try {
            const parentName = session.parentName || "Parent";
            await sendFormattedEmail(
              parentEmail,
              `HabKids Session Reminder: ${studentName}`,
              `Dear ${parentName},\n\nThis is a friendly reminder that ${studentName} has an upcoming HabKids Session scheduled.\n\nAssigned Tutor: ${tutorName}\nType: ${session.type || 'regular'} session\nScheduled Time: ${formattedTime}\n\nYou can access your classroom meeting link via your Parent Dashboard 5 minutes before the class starts.`
            );
          } catch (err) {
            console.error(`[CRON] Failed to send reminder to parent (${parentEmail}):`, err);
          }
        } else {
          console.log(`[CRON] Parent email not found for parentId ${session.parentId}`);
        }

        // Mark reminder as sent in the database
        try {
          await firestoreRest('PATCH', `sessions/${sId}?updateMask.fieldPaths=reminderSent`, {
            fields: {
              reminderSent: { booleanValue: true }
            }
          });
          console.log(`[CRON] Marked session ${sId} as reminderSent: true.`);
          sentCount++;
        } catch (err) {
          console.error(`[CRON] Failed to mark session ${sId} as reminderSent:`, err);
        }
      }
    }

    return { success: true, processed: docs.length, sentCount };
  } catch (err: any) {
    const errMsg = String(err);
    if (errMsg.includes('PERMISSION_DENIED')) {
      console.log("[CRON] Info: Firebase service account has read/write boundaries. Automatic reminders are driven securely on authenticated client dashboard loads.");
      return { success: true, info: "Reminders delegating gracefully to client dashboards." };
    }
    console.error("[CRON] Error during reminder checks:", err);
    return { success: false, error: errMsg };
  }
}

export const app = express();
const PORT = 3000;

// 301 Permanent Domain Redirect Rule (Old Domains -> HabKids)
app.use((req, res, next) => {
  const host = req.get('host');
  if (host && (host.includes('abyssiniatutors.com') || host.includes('abyssinia-tutors.com') || host.includes('lingukid.com') || host.includes('lingukids.com'))) {
    const newHost = host.replace(/abyssiniatutors\.com|abyssinia-tutors\.com|lingukid\.com|lingukids\.com/g, 'habkids.com');
    return res.redirect(301, `https://${newHost}${req.originalUrl}`);
  }
  next();
});

app.use(express.json());

// Gemini Setup
export const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY || '',
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    }
  }
});

// API Routes
  app.post("/api/notify/email", async (req, res) => {
    const { to, subject, body, role, logOnly, status, errorMessage } = req.body;
    try {
      if (logOnly) {
        await logEmailToDb(to, subject, body, role, status || 'SMTP_SENT', errorMessage, req);
        return res.json({ 
          success: true, 
          message: `Email logged to diagnostics in memory for ${to}`,
          timestamp: new Date().toISOString()
        });
      }
      const result = await sendFormattedEmail(to, subject, body, role, req);
      res.json({ 
        success: true, 
        message: result.simulated
          ? `Professional ${role || 'user'} notification simulated for ${to} (Fallback)`
          : `Professional mail sent to ${to} via SMTP`,
        timestamp: new Date().toISOString()
      });
    } catch (error) {
      console.error("Email sending failed:", error);
      res.status(500).json({ success: false, error: "Failed to send email", details: String(error) });
    }
  });

  app.get("/api/notify/status", async (req, res) => {
    const credentials = await getDynamicSmtpCredentials(req);
    const { user, pass, host, port, provider } = credentials;
    const isConfigured = !!pass;

    let displayHost = host;
    let displayPort = String(port);

    if (provider === 'resend') {
      displayHost = 'api.resend.com (HTTPS REST API)';
      displayPort = '443';
    } else if (provider === 'brevo') {
      displayHost = 'api.brevo.com (HTTPS REST API)';
      displayPort = '443';
    }

    res.json({
      success: true,
      configured: isConfigured,
      host: displayHost,
      port: displayPort,
      user: user && user.includes('@') ? `${user.split('@')[0].substring(0, 3)}***@${user.split('@')[1]}` : (user || 'API Key Attached'),
      provider: provider || 'smtp',
      simulationFallback: !isConfigured
    });
  });

  app.get("/api/notify/logs", (req, res) => {
    res.json({ logs: email_logs_in_memory });
  });

  app.post("/api/notify/test-smtp", async (req, res) => {
    const { toEmail } = req.body;
    if (!toEmail) {
      return res.status(400).json({ success: false, error: "Recipient email is required" });
    }
    try {
      console.log(`[EMAIL TEST] Initiating direct test mail to: ${toEmail}`);
      const credentials = await getDynamicSmtpCredentials(req);
      const isResend = credentials.provider === 'resend' || (credentials.pass && credentials.pass.startsWith('re_'));
      const isBrevo = credentials.provider === 'brevo';
      const modeText = isResend ? 'Resend HTTP API' : (isBrevo ? 'Brevo HTTP API' : 'SMTP Nodemailer');

      const result = await sendFormattedEmail(
        toEmail,
        `HabKids Connection Test ✔ (${modeText})`,
        `This is a professional notification confirming your ${modeText} integration works flawlessly on HabKids!\n\nEmail Delivery: ACTIVE\nStatus: Secure Connection Verified and Active.`
      );

      if (result.success && !result.simulated) {
        res.json({ success: true, message: `E-mail connection established & test email sent successfully via ${modeText}!` });
      } else if (result.success && result.simulated) {
        res.json({ success: true, message: "E-mail simulation completed successfully (Credential overrides empty, running locally in Simulation mode)." });
      } else {
        throw new Error(result.error || "Delivery returned success: false unexpectedly.");
      }
    } catch (err: any) {
      console.error("[SMTP TEST ERROR]", err);
      res.status(500).json({ success: false, error: err.message || String(err) });
    }
  });

  app.post("/api/subscription/confirm", async (req, res) => {
    const {
      parentEmail,
      parentName,
      studentName,
      planName,
      tutorEmail,
      tutorName,
      price,
      schedulePattern,
      paymentType,
      paymentRef,
      paymentSenderName,
      bookingType
    } = req.body;

    try {
      const pmLabel = paymentType === "telebirr" ? "Telebirr Code 882910" : paymentType === "cbe" ? "CBE Transfer" : "International (Zelle/Remitly)";
      
      let parentSubject = `HabKids - Automated Schedule Lock Received!`;
      let parentBody = `Dear ${parentName || 'Parent'},\n
Welcome to the HabKids family! We have received your enrollment and are thrilled to begin this language learning journey with your child.\n
Our platform has automatically matched your student's requested timeslots with a top-rated, certified Amharic tutor matching your exact timezone requirements.\n
Student Name: ${studentName}
Chosen Plan: ${planName}
Price: $${price} (Verification Pending)
Auto-Assigned Matching Tutor: ${tutorName}
Allocated Schedule: ${schedulePattern || 'Weekly recurring slots'}
Payment Method: ${pmLabel}
Transaction RefID: ${paymentRef || 'N/A'}
Remitter Name: ${paymentSenderName || 'N/A'}\n
Verification Status: PENDING ADMINISTRATIVE APPROVAL\n
Our finance office is validating your Bank/Telebirr reference ID. It takes under 2 hours to confirm that the auto-matched tutor assignment page has registered. Once checked, physical progress reports, student accounts, and classroom coordinates will launch instantly.`;
 
      let tutorSubject = `Remittance Pending Assignment: Match Detected (${studentName})`;
      let tutorBody = `Dear ${tutorName || 'HabKids Expert'},\n
This is an immediate schedule locking notification from the HabKids Administrator.\n
A new student has been automatically matched to your open availability schedule based on a high-precision timezone compatibility lock. This enrollment is currently pending final payment confirmation.\n
Student Name: ${studentName}
Plan Option: ${planName}
Parent Email: ${parentEmail}
Auto-Matched Schedule: ${schedulePattern || 'Weekly recurring slots'}
Payment Remittance: ${pmLabel}
Verification Status: PENDING ADMINISTRATIVE APPROVAL\n
Please check your Tutor Dashboard. Once the parent's payment receipt reference is approved by our billing desk, this match will be permanently locked into your weekly calendar.`;
 
      if (bookingType === "parent_choose") {
        parentSubject = `HabKids - Enrollment Pending Verification - Parent Chosen Lock!`;
        parentBody = `Dear ${parentName || 'Parent'},\n
Welcome to the HabKids family! We have received your enrollment and are thrilled to begin this language learning journey with your child.\n
You have hand-picked ${tutorName} as your child's designated continuous learning guide! ${tutorName} is remarkably excited about this class and is currently standardizing curriculum objectives tailored to your child's age profile.\n
Student Name: ${studentName}
Chosen Plan: ${planName}
Price: $${price} (Verification Pending)
Selected Native Speaker Tutor: ${tutorName}
Designated Schedule: ${schedulePattern || 'Weekly recurring slots'}
Payment Method: ${pmLabel}
Transaction RefID: ${paymentRef || 'N/A'}
Remitter Name: ${paymentSenderName || 'N/A'}\n
Verification Status: PENDING ADMINISTRATIVE APPROVAL\n
Our finance office is validating your Bank/Telebirr reference ID. Once checked (usually within 2 hours), your curated native speaker's calendar will lock into permanent focus, and your parent portal dashboard will active immediately.`;
 
        tutorSubject = `Congratulations! You Were Selected by a Parent: New Student Registration (${studentName})`;
        tutorBody = `Dear ${tutorName || 'HabKids Expert'},\n
Fantastic news! A HabKids parent has hand-picked you as their child's designated live Amharic guide after reviewing your profile credentials and video presentation.\n
The parent has scheduled recurring spots directly on your weekly calendar. This enrollment is currently awaiting payment verification.\n
Student Name: ${studentName}
Plan Option: ${planName}
Parent Email: ${parentEmail}
Requested Live Schedule: ${schedulePattern || 'Weekly recurring slots'}
Payment Remittance: ${pmLabel}
Verification Status: PENDING ADMINISTRATIVE APPROVAL\n
Please prepare initial diagnostic welcome activities for ${studentName}. Once our billing desk validates the transaction, you will receive student profile details, and the classroom access coordinates will launch.`;
      }

      const parentEmailPromise = sendFormattedEmail(
        parentEmail,
        parentSubject,
        parentBody,
        'parent',
        req
      );

      const tutorEmailPromise = sendFormattedEmail(
        tutorEmail,
        tutorSubject,
        tutorBody,
        'tutor',
        req
      );

      const [parentRes, tutorRes] = await Promise.all([parentEmailPromise, tutorEmailPromise]);

      res.json({
        success: true,
        message: "Dual transaction pending verification confirmation emails dispatched successfully in parallel.",
        parentSimulated: parentRes.simulated,
        tutorSimulated: tutorRes.simulated,
        timestamp: new Date().toISOString()
      });
    } catch (error) {
      console.error("Dual subscription email flow failed:", error);
      res.status(500).json({ success: false, error: "Failed to dispatch subscription welcome chain", details: String(error) });
    }
  });

  app.post("/api/test/reminders", async (req, res) => {
    try {
      const result = await checkAndDispatchReminders();
      res.json(result);
    } catch (error) {
      console.error("Manual test reminders run failed:", error);
      res.status(500).json({ success: false, error: String(error) });
    }
  });

  app.post("/api/assess", async (req, res) => {
    const { childName, childAge, goals } = req.body;

    try {
      const prompt = `
        Generate a professional "Initial Assessment Report" in JSON format for:
        Student: ${childName}
        Age: ${childAge}
        Learning goals: ${goals}
        
        The result MUST populate:
        - "welcome": A welcoming, inspiring message for the Ethiopian parents abroad.
        - "curriculum": A proposed 3-month curriculum focus customized for their goals.
        - "heritageFact": A fascinating history or linguistical fact about Amharic or Syrian/Ethiopian Ge'ez heritage.
      `;

      let result;
      let lastError;
      
      // Retry logic for 503 or transient errors
      for (let i = 0; i < 3; i++) {
        try {
          result = await ai.models.generateContent({
            model: "gemini-3.5-flash",
            contents: prompt,
            config: {
              systemInstruction: "You are a specialized JSON api translator. You MUST output ONLY valid JSON conforming strictly to the requested schema. Do not enclose response in markdown tags, do not output prefaces, introductory headers, or explanatory notes. Out of scope text output is strictly prohibited.",
              responseMimeType: "application/json",
              responseSchema: {
                type: Type.OBJECT,
                properties: {
                  welcome: {
                    type: Type.STRING,
                    description: "A welcoming message for the Ethiopian parents abroad."
                  },
                  curriculum: {
                    type: Type.STRING,
                    description: "A proposed 3-month curriculum focus based on their goals."
                  },
                  heritageFact: {
                    type: Type.STRING,
                    description: "A fun fact of the day about Amharic or Ethiopian heritage."
                  }
                },
                required: ["welcome", "curriculum", "heritageFact"]
              }
            }
          });
          break;
        } catch (error: any) {
          lastError = error;
          if (error?.status === 503 || error?.code === 503) {
            console.warn(`Gemini 503 (Busy) - Attempt ${i + 1} failed, retrying...`);
            await new Promise(resolve => setTimeout(resolve, 2000 * (i + 1)));
            continue;
          }
          throw error;
        }
      }

      if (!result) throw lastError || new Error("Failed to generate content after retries");

      let text = result.text;
      if (!text) throw new Error("No text returned from Gemini");
      
      // Robustly sanitize response text to strip any markdown code blocks or header text surrounding the JSON
      text = text.trim();
      if (text.startsWith("```json")) {
        text = text.substring(7);
      } else if (text.startsWith("```")) {
        text = text.substring(3);
      }
      if (text.endsWith("```")) {
        text = text.substring(0, text.length - 3);
      }
      text = text.trim();

      // Extract JSON boundaries precisely to handle text preamble/postscripts
      const firstCurly = text.indexOf('{');
      const lastCurly = text.lastIndexOf('}');
      if (firstCurly !== -1 && lastCurly !== -1 && lastCurly > firstCurly) {
        text = text.substring(firstCurly, lastCurly + 1);
      }
      
      const parsed = JSON.parse(text);
      res.json({
        welcome: parsed.welcome || `Welcome ${childName} to HabKids Language Academy!`,
        curriculum: parsed.curriculum || `Our tutors will focus on ${goals} through interactive 1-on-1 sessions tailored for HabKids learners.`,
        heritageFact: parsed.heritageFact || "Amharic is the only African language with its own unique script, known as the Ge'ez abugida."
      });
    } catch (error) {
      console.error("Gemini Error Final (handeled gracefully):", error);
      // Fallback response for better UX
      res.json({ 
        welcome: `Welcome ${childName} to HabKids Language Academy!`,
        curriculum: `Our tutors will focus on ${goals} through interactive 1-on-1 sessions tailored for HabKids learners.`,
        heritageFact: "Amharic is the only African language with its own unique script, known as the Ge'ez abugida."
      });
    }
  });

  // Mock WhatsApp Notification
  app.post("/api/notify/whatsapp", (req, res) => {
    console.log("SIMULATED WHATSAPP SEND:", req.body);
    res.json({ success: true, messageId: "wa_" + Math.random().toString(36).substr(2, 9) });
  });

async function startServer() {
  // Only handle Vite development server or static serving if NOT in Vercel serverless context
  if (!process.env.VERCEL) {
    if (process.env.NODE_ENV !== "production") {
      const { createServer: createViteServer } = await import('vite');
      const vite = await createViteServer({
        server: { middlewareMode: true },
        appType: "spa",
      });
      app.use(vite.middlewares);
    } else {
      const distPath = `${process.cwd()}/dist`;
      app.use(express.static(distPath));
      app.get('*', (req, res) => {
        res.sendFile(`${distPath}/index.html`);
      });
    }

    // Schedule automated class reminders to run at the beginning of every hour
    cron.schedule('0 * * * *', async () => {
      try {
        await checkAndDispatchReminders();
      } catch (e) {
        console.error("Error running hourly checkAndDispatchReminders cron:", e);
      }
    });
    console.log("Hourly class reminder scheduler registered.");

    // Non-blocking initial reminder check 10 seconds after server starting
    setTimeout(() => {
      checkAndDispatchReminders().catch(err => {
        console.error("Initial class reminder scan failed:", err);
      });
    }, 10000);

    app.listen(PORT, "0.0.0.0", () => {
      console.log(`Server running on http://localhost:${PORT}`);
    });
  }
}

startServer();
